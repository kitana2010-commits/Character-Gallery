// capture.js — the bridge back from an image site into the photobook. v0.8.0
//
// v0.8.0 (SnapScapes 2.2) — the Snap window. This script still loads on every
// ChatGPT / Grok / Gemini tab (the manifest puts it there), but it does
// NOTHING unless the worker says this tab is the Snap window: no panel, no
// heart, no image watching, no styles. A snap is handed over inside the
// message that arms it, so the tab never asks back and can't read an older
// snap (2.1's "it only works after a refresh"). References come from the
// list frozen into the snap when Send was pressed.
//
// Never types anything the user didn't ask for and never submits. Saving
// needs a click — unless the reader switches on Auto-save, in which case the
// finished generation (in a model turn, held still for several seconds) is
// saved and set as the Snapscape, with an Undo.
//
// Telling a reference apart from the generation is done by DOM position: an
// image in the user's turn or the composer is never a candidate, whatever it
// looks like. That's what makes Auto-save safe to offer at all.
//
// v0.7.0 — "no image found" with the picture on screen. Detection used to
// hear about new pictures only through a childList MutationObserver, and the
// save button only ever read the list that observer filled. Any way of
// putting a picture on the page that doesn't add an element at the right
// moment — a src swapped on an <img> that was already there, an image that
// finishes loading after the last DOM change, a picture in a shadow root or a
// same-origin frame, a <canvas>, a CSS background — never reached the list,
// so both the ♥ picker and Save newest image went quiet. Now:
//   • every <img> load in the document is heard (capture-phase listener),
//     and src/srcset attribute changes are observed, not just new elements;
//   • an element reused for a NEW picture counts as fresh again;
//   • the save button rescans the live page when it is clicked, through
//     open shadow roots and same-origin frames, with <canvas> and CSS
//     backgrounds as a last resort — and if the picture was already on the
//     page when the snap was armed, it still takes the newest one;
//   • turns are recognised by data-turn as well as data-message-author-role;
//   • a preview inside a model turn may be as small as 160px, and the
//     largest srcset entry is fetched when there is one;
//   • when nothing at all is found, "📋 Copy details" puts a short,
//     privacy-safe report on the clipboard for the developer.

(() => {
  const SEEN = new WeakSet();
  // Element identity is not enough on ChatGPT: scrolling a long conversation
  // remounts <img> nodes, so a picture from three turns ago arrives as a
  // brand-new element and looks freshly generated. Srcs survive remounting;
  // element references do not.
  const SEEN_SRC = new Set();
  // The src each seen element had last time we looked, so an element the
  // site REUSES for a new picture is noticed.
  const LAST_SRC = new WeakMap();
  // Everything already on the page the moment a snap was armed. Whatever the
  // model draws for THIS snap cannot be in here.
  let armedSrcs = null;
  const FRESH = [];          // images that appeared after load, newest last
  const MIN_EDGE = 256;      // avatars, icons and inline logos are smaller
  const MIN_EDGE_TURN = 160; // inside a model turn a preview can be smaller
  let initialScanDone = false;
  let castNames = { charName: null, userName: null };
  let toastMinimized = false; // persistent collapse state for mobile
  let lastArmed = null;       // { message, snap } — to bring the panel back
  let active = false;         // true only in the Snap window
  let currentSnap = null;     // the snap waiting in this tab
  let autoSave = false;       // the reader's Auto-save switch (storage)
  const AUTO_SAVE_KEY = "djpbAutoSave";

  // ---------- where an element sits ----------

  /** closest() that climbs out of shadow roots and same-origin frames. */
  function closestDeep(el, sel) {
    let n = el;
    for (let hops = 0; n && hops < 12; hops += 1) {
      const hit = n.closest?.(sel);
      if (hit) return hit;
      const root = n.getRootNode?.();
      if (root?.host) { n = root.host; continue; }                 // out of a shadow root
      try { n = root?.defaultView?.frameElement || null; }         // out of a frame
      catch { n = null; }                                           // top document: done
    }
    return null;
  }

  const MODEL_ROLES = new Set(["assistant", "tool", "model", "bot"]);

  /** Whose turn an element sits in: "user", "assistant", "tool"…, or null
   *  when the page carries no author markers to read. ChatGPT marks each
   *  message with data-message-author-role and each turn <article> with
   *  data-turn; Gemini uses <user-query> and <model-response>. */
  function turnRole(el) {
    const m = closestDeep(el, "[data-message-author-role]");
    if (m) return m.getAttribute("data-message-author-role") || null;
    const t = closestDeep(el, "[data-turn]");
    if (t) return t.getAttribute("data-turn") || null;
    if (closestDeep(el, "user-query")) return "user";
    if (closestDeep(el, "model-response")) return "assistant";
    return null;
  }

  /** true inside a model's turn, false inside the user's, null when there
   *  are no markers (a lightbox, or a site that doesn't label turns). */
  function assistantTurn(el) {
    const role = turnRole(el);
    if (!role) return null;
    return MODEL_ROLES.has(role);
  }

  /** An image sitting inside a USER turn is an attachment echo — the
   *  reference we pasted, bounced back by the site. A generation only ever
   *  renders in a model turn, so these are never candidates at all. This is
   *  DOM position, not pixel similarity: it cannot mistake a gen for its
   *  reference the way the old fingerprint comparison could. */
  function isUserUpload(el) {
    const role = turnRole(el);
    if (role === "user") return true;
    // The site stating outright that this is the model's own output outranks
    // the composer heuristic below.
    if (role && MODEL_ROLES.has(role)) return false;
    // Attachment previews waiting in the composer live inside the send form;
    // no site renders a finished generation inside a <form>.
    if (closestDeep(el, "form")) return true;
    return false;
  }

  // ---------- what an element shows ----------

  const CANVAS_KEY = new WeakMap();
  let canvasSeq = 0;

  function bgUrl(el) {
    try {
      const bg = getComputedStyle(el).backgroundImage || "";
      const m = /url\(\s*["']?([^"')]+)["']?\s*\)/i.exec(bg);
      return m ? m[1] : "";
    } catch { return ""; }
  }

  /** A stable identity for what the element is showing: the src for an
   *  <img>, a per-element key for a <canvas>, the url for a CSS background. */
  function srcOf(el) {
    if (!el) return "";
    if (el.tagName === "IMG") return el.currentSrc || el.src || "";
    if (el.tagName === "CANVAS") {
      if (!CANVAS_KEY.has(el)) CANVAS_KEY.set(el, `canvas:${++canvasSeq}`);
      return CANVAS_KEY.get(el);
    }
    return bgUrl(el);
  }

  function sizeOf(el) {
    const r = el.getBoundingClientRect();
    let nw = 0, nh = 0;
    if (el.tagName === "IMG") { nw = el.naturalWidth || 0; nh = el.naturalHeight || 0; }
    else if (el.tagName === "CANVAS") { nw = el.width || 0; nh = el.height || 0; }
    return { r, nw, nh, w: Math.max(r.width, nw), h: Math.max(r.height, nh) };
  }

  const minEdgeFor = (el) => (assistantTurn(el) === true ? MIN_EDGE_TURN : MIN_EDGE);

  function isReady(el) {
    if (el.tagName === "IMG") return Boolean(el.complete && el.naturalWidth);
    if (el.tagName === "CANVAS") return el.width > 0 && el.height > 0;
    return true;
  }

  /** Changes while a picture is still being drawn; holds still once it's
   *  done. A canvas keeps one element and one key while its pixels change,
   *  so for those the signature is a tiny downscaled fingerprint. */
  function signatureOf(el) {
    const src = srcOf(el);
    if (el.tagName !== "CANVAS") return src;
    try {
      const c = document.createElement("canvas");
      c.width = 8; c.height = 8;
      const g = c.getContext("2d");
      g.drawImage(el, 0, 0, 8, 8);
      const d = g.getImageData(0, 0, 8, 8).data;
      let h = 0;
      for (let i = 0; i < d.length; i += 1) h = (h * 31 + d[i]) >>> 0;
      return `${src}#${h}`;
    } catch { return src; }
  }

  // ---------- noticing images as they arrive ----------

  function isCandidate(img) {
    if (SEEN.has(img)) return false;
    if (closestDeep(img, "[data-djpb-ui]")) return false;

    const src = srcOf(img);
    if (!src) return false;
    if (src.startsWith("data:image/svg")) return false;

    const { w, h } = sizeOf(img);
    if (w < MIN_EDGE_TURN || h < MIN_EDGE_TURN) return false; // too small anywhere
    const min = minEdgeFor(img);
    if (w < min || h < min) return false;

    if (closestDeep(img, "header, nav, [role='banner']")) return false;
    return true;
  }

  function whenLoaded(img, fn) {
    if (img.complete && img.naturalWidth) fn();
    else img.addEventListener("load", fn, { once: true });
  }

  /** Look at one <img>. New and big enough → tracked. Already tracked but
   *  now showing a picture we have never seen → fresh again, because the
   *  site reused the element for a new generation. */
  function consider(img) {
    const src = srcOf(img);
    if (SEEN.has(img)) {
      if (!src || src === LAST_SRC.get(img)) return;
      LAST_SRC.set(img, src);
      const isNew = !SEEN_SRC.has(src);
      SEEN_SRC.add(src);
      if (isNew && initialScanDone && !FRESH.includes(img)) {
        whenLoaded(img, () => onImage(img, true));
      }
      return;
    }
    if (!isCandidate(img)) return;
    SEEN.add(img);
    LAST_SRC.set(img, src);
    if (src) SEEN_SRC.add(src);
    const fresh = initialScanDone;
    whenLoaded(img, () => onImage(img, fresh));
  }

  function scan() {
    for (const img of document.images) consider(img);
  }

  function onImage(img, fresh) {
    if (!fresh || !active) return;

    const srcNow = srcOf(img);
    if (srcNow) SEEN_SRC.add(srcNow);
    if (!FRESH.includes(img)) FRESH.push(img);

    // Armed: make sure the watcher is running. A watcher already going for
    // THIS snap is left alone — it re-reads the candidate list every tick, so
    // restarting would only reset the settle counter for no reason.
    const snap = currentSnap;
    if (snap && !(watch && watch.snap?.id === snap.id)) {
      startSettleWatch(snap);
    }
  }

  // ---------- the candidate lists ----------

  const SKIPPED = new Set(); // srcs already saved this session — don't re-offer

  /** Why an element is NOT a candidate, or null when it is. One function so
   *  the picker, the save button and the debug report can't disagree. */
  function rejectReason(el, baseline) {
    if (!el.isConnected) return "detached";
    if (closestDeep(el, "[data-djpb-ui]")) return "ours";
    const src = srcOf(el);
    if (!src) return "no src";
    if (/^data:image\/svg/i.test(src)) return "svg";
    if (SKIPPED.has(src)) return "already saved";
    if (baseline && baseline.has(src)) return "on page before snap";
    if (closestDeep(el, "header, nav, [role='banner']")) return "page chrome";
    if (isUserUpload(el)) return "user turn / composer";
    const { r, w, h } = sizeOf(el);
    if (r.width < 2 || r.height < 2) return "hidden";
    const min = minEdgeFor(el);
    if (w < min || h < min) return `small ${Math.round(w)}x${Math.round(h)}`;
    if (el.tagName === "CANVAS" && assistantTurn(el) !== true && !closestDeep(el, "main")) {
      return "canvas outside chat";
    }
    return null;
  }

  /** Fresh, connected, unsaved images, newest first. A blob:/data: src that
   *  we can place in a model turn is a generation; anything else local
   *  trails the list, reachable through ◀ ▶ if the default pick is wrong. */
  function candidates(baseline) {
    const out = [];
    const local = [];
    // Prune disconnected elements while we're here so FRESH can't grow forever.
    for (let i = FRESH.length - 1; i >= 0; i--) {
      if (!FRESH[i].isConnected) { FRESH.splice(i, 1); continue; }
      const img = FRESH[i];
      if (rejectReason(img, baseline)) continue;
      const src = srcOf(img);
      if (src.startsWith("blob:") || src.startsWith("data:")) {
        // ChatGPT renders finished generations as blob: URLs, the same as
        // our own pasted references. Position decides it: rejectReason has
        // already dropped composer previews and user-turn echoes, so a local
        // src in a model turn is the generation; unplaceable ones trail.
        if (assistantTurn(img) === true) out.push(img);
        else local.push(img);
      } else {
        out.push(img);
      }
    }
    return dedupe(out.concat(local));
  }

  /** Every <img> and <canvas> in document order, descending into open
   *  shadow roots and same-origin frames where they sit. */
  function collectDeep(root, out, depth = 0) {
    if (depth > 6 || !root?.querySelectorAll) return out;
    for (const el of root.querySelectorAll("*")) {
      const tag = el.tagName;
      if (tag === "IMG" || tag === "CANVAS") out.push(el);
      if (el.shadowRoot) collectDeep(el.shadowRoot, out, depth + 1);
      if (tag === "IFRAME" || tag === "FRAME") {
        let doc = null;
        try { doc = el.contentDocument; } catch { /* cross-origin */ }
        if (doc) collectDeep(doc, out, depth + 1);
      }
    }
    return out;
  }

  /** Elements painting a CSS background picture inside the newest few model
   *  turns. Last resort only: getComputedStyle on every node is not free. */
  function backgroundCandidates() {
    const turns = [...document.querySelectorAll(
      "[data-message-author-role], [data-turn], model-response")]
      .filter((t) => assistantTurn(t) === true)
      .slice(-3);
    const out = [];
    for (const t of turns) {
      for (const el of [t, ...t.querySelectorAll("*")]) {
        const url = bgUrl(el);
        if (url && !/^data:image\/svg/i.test(url)) out.push(el);
      }
    }
    // Inline background pictures anywhere in the chat, for unlabelled pages.
    for (const el of document.querySelectorAll("main [style*='background-image']")) {
      if (!out.includes(el) && bgUrl(el)) out.push(el);
    }
    return out;
  }

  /** The live page, rescanned now — not just what the observer heard about.
   *  Newest first: model turns before unlabelled spots, then bottom-most
   *  (latest in document order) first. <img> beats <canvas> beats a CSS
   *  background. */
  function liveCandidates(baseline, { backgrounds = true } = {}) {
    const all = collectDeep(document, []);
    const rank = (el) => {
      const a = assistantTurn(el);
      return a === true ? 2 : a === null ? 1 : 0;
    };
    const pick = (els) => els
      .map((el, i) => ({ el, i }))
      .filter(({ el }) => rejectReason(el, baseline) === null)
      .sort((x, y) => (rank(y.el) - rank(x.el)) || (y.i - x.i))
      .map(({ el }) => el);

    const imgs = pick(all.filter((el) => el.tagName === "IMG"));
    if (imgs.length) return dedupe(imgs);
    const canvases = pick(all.filter((el) => el.tagName === "CANVAS"));
    if (canvases.length) return dedupe(canvases);
    return backgrounds ? dedupe(pick(backgroundCandidates())) : [];
  }

  /** What 💾 Save newest image saves: the newest fresh picture the observer
   *  heard about; failing that, the newest one on the live page that arrived
   *  after the snap was armed; failing that, the newest picture on the page
   *  at all (it was already there when the snap was armed — the button says
   *  "newest image", so that is the one the user means). Only finished
   *  pictures qualify; already-saved ones never do. */
  function pickForSave() {
    scan();
    const base = armedSrcs || new Set();
    let list = candidates(base).filter(isReady);
    if (!list.length) list = liveCandidates(base).filter(isReady);
    if (!list.length) list = liveCandidates(null).filter(isReady);
    return list[0] || null;
  }

  /** One generation arrives as SEVERAL elements: ChatGPT remounts the <img>
   *  while it sharpens and leaves crossfade layers stacked in place — so a
   *  single finished picture read as "(3/3)" in the picker. Collapse the
   *  stack: same src is the same picture, and two candidates whose rendered
   *  boxes overlap almost completely are the same picture on screen whatever
   *  their srcs say. Newest-first order means the freshest layer survives. */
  function dedupe(list) {
    const out = [];
    const seenSrc = new Set();
    for (const img of list) {
      const src = srcOf(img);
      if (src && seenSrc.has(src)) continue;
      const r = img.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) continue; // hidden crossfade leftover
      const stacked = out.some((o) => {
        const q = o.getBoundingClientRect();
        const ix = Math.max(0, Math.min(r.right, q.right) - Math.max(r.left, q.left));
        const iy = Math.max(0, Math.min(r.bottom, q.bottom) - Math.max(r.top, q.top));
        return ix * iy > 0.8 * Math.min(r.width * r.height, q.width * q.height);
      });
      if (stacked) continue;
      if (src) seenSrc.add(src);
      out.push(img);
    }
    return out;
  }

  // ---------- the ♥ picker ----------

  /** ChatGPT renders generated images progressively: the element and its src
   *  are replaced several times as the picture sharpens. The watcher tracks
   *  the newest fresh candidate, shows it as a thumbnail in the toast, and
   *  enables the ♥ save button only once it has held still — so a click
   *  can't grab a half-baked frame. Nothing is ever saved without the click.
   *
   *  The reference echo appears at send time; the generation lands much
   *  later and becomes the newest candidate on its own. If the default pick
   *  is ever wrong, ◀ ▶ steps through the other fresh images. */
  let watch = null; // { iv, snap, baseline, offset, lastSig, stable, shownSrc }

  function stopWatch() {
    if (watch?.iv) clearInterval(watch.iv);
    watch = null;
  }

  /** (Re)start watching for THIS snap. Re-arming replaces the whole watcher,
   *  baseline included, so a second snap can't save with the first snap's
   *  prompt, session and baseline still in the interval's closure.
   *
   *  It starts when a snap is armed, not only when the observer reports a
   *  new image — and each tick it falls back to rescanning the live page —
   *  so a picture the observer never heard about still reaches the picker. */
  // Auto-save is held to a stricter standard than the ♥ button, because
  // nobody looks first: the picture must sit in a model turn, be a real
  // size, show no blur (ChatGPT blurs its in-progress previews), and hold
  // still for about six seconds rather than three.
  // ---------- your references vs. the generation ----------
  //
  // v2.2.2: auto-save saved the reader's PERSONA picture — the reference we
  // had just attached, echoed back in their own message. 2.2.1 had started
  // trusting pictures the page doesn't label as anyone's turn, and on the
  // real ChatGPT the echo isn't labelled the way we look for. It was sharp,
  // full size and perfectly still from the moment of sending, so it "won"
  // long before the generation finished.
  //
  // Labels can't be relied on, so this goes by the picture itself: a small
  // fingerprint (a difference hash) of every reference this snap attached,
  // and of anything that sits in the message box. A picture that matches
  // one is never auto-saved, and goes to the back of the ♥ picker's list.
  // An echo is the same picture re-encoded or resized, which the hash shrugs
  // off; a generation is a new picture.

  const HASH_W = 17, HASH_H = 16;          // 16×16 = 256 comparisons
  const SAME_PICTURE = 0.22;               // share of differing bits (echoes measure ≤0.15, gens ~0.45)
  const PRINT = new Map();                 // src → fingerprint | null (couldn't read)
  const PRINT_PENDING = new Set();
  let refPrints = [];                      // [{bits, from}]
  let refPrintsFor = null;                 // snap id they belong to
  let refPrintsReady = true;               // false while this snap's are loading
  const composerSeen = new Set();          // srcs fingerprinted from the box

  async function fingerprintBlob(blob) {
    const bmp = await createImageBitmap(blob);
    const c = document.createElement("canvas");
    c.width = HASH_W; c.height = HASH_H;
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(bmp, 0, 0, HASH_W, HASH_H);
    bmp.close?.();
    const d = g.getImageData(0, 0, HASH_W, HASH_H).data;
    const lum = (x, y) => { const i = (y * HASH_W + x) * 4; return d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114; };
    const bits = new Uint8Array(HASH_H * (HASH_W - 1));
    for (let y = 0; y < HASH_H; y += 1) {
      for (let x = 0; x < HASH_W - 1; x += 1) bits[y * (HASH_W - 1) + x] = lum(x, y) > lum(x + 1, y) ? 1 : 0;
    }
    return bits;
  }

  function printDistance(a, b) {
    let diff = 0;
    for (let i = 0; i < a.length; i += 1) if (a[i] !== b[i]) diff += 1;
    return diff / a.length;
  }

  /** The fingerprint of what an element shows: cached by src, computed in
   *  the background. undefined = not known yet; null = couldn't be read. */
  function printOf(el) {
    const src = srcOf(el);
    if (!src) return null;
    if (PRINT.has(src)) return PRINT.get(src);
    if (!PRINT_PENDING.has(src)) {
      PRINT_PENDING.add(src);
      (async () => {
        let bits = null;
        try {
          const dataUrl = await toDataUrl(el);
          bits = await fingerprintBlob(await (await fetch(dataUrl)).blob());
        } catch { /* unreadable: treated as unknown, never auto-saved */ }
        PRINT.set(src, bits);
        PRINT_PENDING.delete(src);
      })();
    }
    return undefined;
  }

  /** true: looks like one of this snap's references. false: doesn't.
   *  undefined: can't tell yet. */
  function likeReference(el) {
    if (!refPrints.length) return refPrintsReady ? false : undefined;
    const p = printOf(el);
    if (p === undefined) return undefined;
    if (p === null) return undefined;
    return refPrints.some((r) => printDistance(r.bits, p) < SAME_PICTURE);
  }

  /** Fingerprint this snap's references, from the same pictures that get
   *  pasted (fetched once and shared with attachRefs). */
  let refImagesCache = { id: null, promise: null };
  function refImagesFor(snap) {
    if (refImagesCache.id === snap?.id && refImagesCache.promise) return refImagesCache.promise;
    const refs = Array.isArray(snap?.refs) ? snap.refs : [];
    const promise = (!refs.length || !snap?.sessionId) ? Promise.resolve([]) : (async () => {
      try {
        const res = await chrome.runtime.sendMessage(
          { type: "snap:refimages", sessionId: snap.sessionId, refs });
        return res?.ok && Array.isArray(res.images) ? res.images : [];
      } catch { return []; }
    })();
    refImagesCache = { id: snap?.id || null, promise };
    return promise;
  }

  async function loadRefPrints(snap) {
    refPrintsFor = snap?.id || null;
    refPrints = [];
    composerSeen.clear();
    const wanted = Array.isArray(snap?.refs) ? snap.refs.length : 0;
    refPrintsReady = wanted === 0;
    if (!wanted) return;
    const images = await refImagesFor(snap);
    const prints = [];
    for (const ref of images) {
      try {
        prints.push({ bits: await fingerprintBlob(await (await fetch(ref.dataUrl)).blob()), from: ref.name || "reference" });
      } catch { /* one unreadable reference doesn't stop the rest */ }
    }
    if (refPrintsFor !== (snap?.id || null)) return;   // another snap took over
    refPrints = refPrints.concat(prints);
    refPrintsReady = true;
  }

  /** Anything sitting in the message box is the reader's own attachment —
   *  including ones they added by hand — so it joins the references. */
  function noteComposerImages() {
    for (const im of document.querySelectorAll("form img")) {
      if (im.closest("[data-djpb-ui]")) continue;
      const src = srcOf(im);
      if (!src || composerSeen.has(src)) continue;
      const p = printOf(im);
      if (p === undefined) continue;           // try again next tick
      composerSeen.add(src);
      if (p) refPrints.push({ bits: p, from: "message box" });
    }
  }

  const AUTO_STABLE_TICKS = 7;
  const AUTO_MIN_EDGE = 384;

  /** The strongest blur on an element or its near ancestors, in px.
   *
   *  2.2.0 treated ANY blur(...) as blurred, including blur(0px), which a
   *  page often leaves on a picture after a sharpen-in transition. A
   *  finished picture styled that way was "blurred" forever and never
   *  auto-saved. Now only a real blur counts. */
  function blurPx(el) {
    let max = 0;
    let n = el;
    for (let i = 0; n && n.nodeType === 1 && i < 4; i += 1, n = n.parentElement) {
      try {
        const f = getComputedStyle(n).filter || "";
        for (const m of f.matchAll(/blur\(\s*([\d.]+)px\s*\)/g)) max = Math.max(max, parseFloat(m[1]) || 0);
      } catch { /* detached */ }
    }
    return max;
  }

  /** Blurred only when EVERY copy of this picture on the page is. A blurred
   *  duplicate laid behind the sharp one as a glow used to be the one
   *  checked, and the picture never auto-saved. */
  function looksBlurred(el) {
    const src = srcOf(el);
    // Never our own panel's thumbnail: it shows the same picture, unblurred.
    const same = el.tagName === "IMG" && src
      ? [...document.images].filter((x) => srcOf(x) === src && !x.closest("[data-djpb-ui]"))
      : [el];
    if (!same.includes(el)) same.push(el);
    return same.every((x) => {
      const r = x.getBoundingClientRect();
      return r.width < 2 || r.height < 2 || blurPx(x) > 1.5;
    });
  }

  /** Why auto-save won't take this picture yet, or null when it will.
   *  `stable` is how many ticks it has held still. */
  function autoVerdict(el, stable) {
    // Pictures in the reader's own message (the pasted references) and in
    // the message box were already ruled out by rejectReason(). A picture
    // the page doesn't label as anyone's turn is allowed: 2.2.0 insisted on
    // a labelled ChatGPT turn and refused everything else without a word.
    if (assistantTurn(el) === false) return "it's in your own message";
    const { nw, nh, w, h } = sizeOf(el);
    if (Math.max(nw, w) < AUTO_MIN_EDGE || Math.max(nh, h) < AUTO_MIN_EDGE) {
      return `it's small (${Math.round(Math.max(nw, w))}×${Math.round(Math.max(nh, h))})`;
    }
    if (looksBlurred(el)) return "it still looks blurred";
    const like = likeReference(el);
    if (like === true) return "it's one of your reference pictures";
    if (like === undefined) return "checking it against your references";
    if (stable < AUTO_STABLE_TICKS) return "wait";
    return null;
  }

  function startSettleWatch(snap) {
    stopWatch();
    const baseline = armedSrcs || new Set();
    watch = { snap, baseline, offset: 0, lastSig: null, stable: 0, shownSrc: null, iv: null,
              autoDone: false, autoSig: null, autoStable: 0 };
    if (refPrintsFor !== snap?.id) loadRefPrints(snap).catch(() => { refPrintsReady = true; });

    let ticks = 0;
    watch.iv = setInterval(() => {
      if (!active) { stopWatch(); return; }
      ticks += 1;
      if (ticks > 750) { stopWatch(); return; } // ~10 min cap
      noteComposerImages();

      // CSS backgrounds are costly to look for, so they're checked every
      // fifth tick — until one turns up, then every tick, so the settle
      // count below can actually run.
      let list = candidates(watch.baseline);
      if (!list.length) {
        list = liveCandidates(watch.baseline, { backgrounds: watch.bg || ticks % 5 === 0 });
        if (list.some((el) => el.tagName !== "IMG" && el.tagName !== "CANVAS")) watch.bg = true;
      }
      if (!list.length) return;
      // Pictures that look like the reader's own references go to the back:
      // the first thing the ♥ picker offers should be the generation.
      list = [...list.filter((el) => likeReference(el) !== true),
              ...list.filter((el) => likeReference(el) === true)];

      const idx = Math.min(watch.offset, list.length - 1);
      const img = list[idx];
      const sig = signatureOf(img);

      if (sig === watch.lastSig && isReady(img)) {
        watch.stable += 1;
      } else {
        watch.stable = 0;
        watch.lastSig = sig;
      }

      const ready = watch.stable >= 4; // unchanged ~3s → done rendering

      // Auto-save chooses its own picture: the newest one that is NOT one
      // of the reader's references, whatever the picker is showing. It has
      // to hold still on its own count, once per snap.
      let autoWhy = "";
      if (autoSave && !watch.autoDone) {
        const target = list.find((el) => likeReference(el) === false) ||
                       list.find((el) => likeReference(el) === undefined) || null;
        if (target) {
          const tsig = signatureOf(target);
          if (tsig === watch.autoSig && isReady(target)) watch.autoStable += 1;
          else { watch.autoStable = 0; watch.autoSig = tsig; }
          const verdict = watch.autoStable >= 4 ? autoVerdict(target, watch.autoStable) : "wait";
          if (!verdict) {
            watch.autoDone = true;
            const w = watch;
            toast("Auto-saving…", null, null, thumbOf(target));
            capture(target, w.snap, null, { auto: true }).catch(() => {
              // Couldn't save. Leave the reason up for a moment, then hand
              // control back to the ♥ button.
              setTimeout(() => { if (watch === w) w.shownSrc = null; }, 4000);
            });
            return;
          }
          if (target === img && ready) autoWhy = verdict;
        } else if (ready) {
          autoWhy = "waiting for ChatGPT's picture";
        }
      }

      // Redraw the toast only when something the user can see changed.
      const key = `${sig}|${ready ? 1 : 0}|${idx}|${list.length}|${autoSave ? 1 : 0}|${autoWhy}`;
      if (key !== watch.shownSrc) {
        watch.shownSrc = key;
        showSaveToast(img, ready, idx, list.length, autoWhy);
      }
    }, 800);
  }

  function thumbOf(el) {
    if (el.tagName === "CANVAS") {
      try {
        const c = document.createElement("canvas");
        const s = 104 / Math.max(el.width, el.height, 1);
        c.width = Math.max(1, Math.round(el.width * s));
        c.height = Math.max(1, Math.round(el.height * s));
        c.getContext("2d").drawImage(el, 0, 0, c.width, c.height);
        return c.toDataURL("image/png");
      } catch { return ""; }
    }
    return srcOf(el);
  }

  /** The save toast: thumbnail of the current pick, ◀ ▶ when there is more
   *  than one, and the ♥ button — disabled with a spinner note until the
   *  image has finished rendering. */
  function showSaveToast(img, ready, idx, count, autoWhy = "") {
    const snap = watch?.snap;
    const actions = [];

    if (count > 1) {
      actions.push({ label: "◀", small: true, fn: () => {
        if (!watch) return;
        watch.offset = (idx + 1) % count;   // older
        watch.stable = 0; watch.lastSig = null; watch.shownSrc = null;
      } });
      actions.push({ label: "▶", small: true, fn: () => {
        if (!watch) return;
        watch.offset = (idx - 1 + count) % count; // newer
        watch.stable = 0; watch.lastSig = null; watch.shownSrc = null;
      } });
    }

    actions.push({
      label: "Save + set as Snapscape", heart: true, disabled: !ready,
      fn: async (btn) => {
        btn.disabled = true;
        const label = btn.querySelector("[data-djpb-label]") || btn;
        label.textContent = "Saving…";
        try {
          await capture(img, snap);
        } catch { /* capture() already toasts the failure */ }
      },
    });

    actions.push(autoSaveSwitch());

    // Auto-save says what it's waiting for. 2.2.0 just never saved, with
    // nothing on screen to say why.
    const waitingForGen = autoWhy === "waiting for ChatGPT's picture";
    const holding = autoSave && autoWhy && autoWhy !== "wait" && !waitingForGen &&
      autoWhy !== "checking it against your references";
    if (holding) {
      actions.push({ label: "📋 Copy details", small: true,
        title: "Copies a short report about the pictures on this page (no chat text) for the extension's developer",
        fn: async (btn) => {
          let text;
          try { text = JSON.stringify(debugReport(), null, 1); }
          catch (err) { text = `report failed: ${err?.message || err}`; }
          btn.textContent = (await copyText(text)) ? "✓ copied" : "couldn't copy";
          setTimeout(() => (btn.textContent = "📋 Copy details"), 3000);
        } });
    }

    const msg = !ready
      ? (autoSave ? "Still rendering… (auto-save is on)" : "Still rendering…")
      : autoSave && waitingForGen
      ? "Waiting for ChatGPT's picture… (auto-save is on — your references won't be saved)"
      : holding
      ? `Auto-save is holding off — ${autoWhy}. Save it yourself if it looks right:`
      : autoSave && autoWhy === "wait"
      ? "Finished — auto-saving in a moment…"
      : (count > 1 ? `This one? (${idx + 1}/${count})` : "Ready when you are:");
    toast(msg, null, actions, thumbOf(img));
  }

  /** The Auto-save switch, as a toast action. Same setting as the Snap card's
   *  and Options' switches. */
  function autoSaveSwitch() {
    return {
      label: autoSave ? "Auto-save: on" : "Auto-save: off",
      small: true,
      toggle: autoSave,
      title: "On: when the picture finishes, it's saved to the album and set as your Snapscape without a click.",
      fn: async (btn) => {
        autoSave = !autoSave;
        try { await chrome.storage.local.set({ [AUTO_SAVE_KEY]: autoSave }); } catch { /* still applies now */ }
        btn.textContent = autoSave ? "Auto-save: on" : "Auto-save: off";
        btn.dataset.on = autoSave ? "1" : "0";
        btn.style.background = autoSave ? "#2e2150" : "transparent";
        if (watch) watch.shownSrc = null;   // redraw with the new wording
      },
    };
  }

  // ---------- the armed panel ----------

  function showArmedToast(message, snap) {
    lastArmed = { message, snap };
    const refs = Array.isArray(snap?.refs) ? snap.refs : [];

    // 2.1 had one button per portrait here and nothing for album photos, so
    // anyone attaching by hand could only ever send the two portraits. This
    // attaches exactly what was ticked in the Snap card when Send was pressed.
    const attachLabel = `⤵ Attach ${refs.length} reference${refs.length === 1 ? "" : "s"}`;
    const attach = {
      label: attachLabel,
      fn: async (btn) => {
        btn.textContent = "…";
        const n = await attachRefs(snap);
        btn.textContent = n === refs.length ? `✓ ${n} attached`
          : n ? `${n} of ${refs.length} attached` : "couldn't attach";
        setTimeout(() => (btn.textContent = attachLabel), 3000);
      },
    };

    toast(message, null, [
      { label: "⤵ Put prompt in the box", fn: async (btn) => {
          const ok = insertPrompt(snap?.prompt || "");
          btn.textContent = ok ? "✓ in the box — hit send" : "couldn't find the box";
          setTimeout(() => (btn.textContent = "⤵ Put prompt in the box"), 3000);
        } },
      ...(refs.length ? [attach] : []),
      autoSaveSwitch(),
      { label: "💾 Save newest image", fn: async (btn) => {
          // Rescans the live page at click time (see pickForSave) — the old
          // version read only what the MutationObserver had collected, so a
          // picture it never heard about was "no image found" while plainly
          // on screen.
          let img = null;
          try { img = pickForSave(); } catch (err) {
            console.warn("[SnapScapes] image search failed:", err);
          }
          if (!img) {
            btn.textContent = "no image found";
            offerDebugCopy(btn);
            console.info("[SnapScapes] Save newest image found nothing. Report:", debugReport());
            setTimeout(() => (btn.textContent = "💾 Save newest image"), 2500);
            return;
          }
          btn.textContent = "saving…";
          try {
            await capture(img, currentSnap || snap);
          } catch {
            btn.textContent = "failed";
            setTimeout(() => (btn.textContent = "💾 Save newest image"), 2500);
          }
        } },
    ]);
  }

  // ---------- debug report ----------

  /** A short description of every picture-like thing on the page and why
   *  each was or wasn't taken — no prompt, no conversation text, and srcs
   *  cut to host + path prefix so no file ids or signatures leave the page.
   *  When ChatGPT changes its markup again, this says what changed. */
  function debugReport() {
    const short = (s) => {
      if (!s) return "";
      if (s.startsWith("data:")) return `${s.slice(0, s.indexOf(",") > 0 ? Math.min(s.indexOf(","), 30) : 30)}…`;
      if (s.startsWith("blob:")) { try { return `blob:${new URL(s.slice(5)).host}`; } catch { return "blob:"; } }
      if (s.startsWith("canvas:")) return "canvas";
      try {
        const u = new URL(s, location.href);
        return u.host + u.pathname.split("/").slice(0, 4).join("/").slice(0, 60);
      } catch { return s.slice(0, 40); }
    };
    const count = (sel, attr) => {
      const out = {};
      for (const el of document.querySelectorAll(sel)) {
        const k = el.getAttribute(attr) || "?";
        out[k] = (out[k] || 0) + 1;
      }
      return out;
    };
    const base = armedSrcs;
    const els = collectDeep(document, []);
    let shadowHosts = 0;
    for (const el of document.querySelectorAll("*")) if (el.shadowRoot) shadowHosts += 1;
    const frames = [...document.querySelectorAll("iframe")].slice(0, 12).map((f) => {
      let same = false;
      try { same = Boolean(f.contentDocument); } catch { /* cross-origin */ }
      const r = f.getBoundingClientRect();
      return { src: short(f.src || ""), sameOrigin: same, box: `${Math.round(r.width)}x${Math.round(r.height)}` };
    });
    const pictures = els
      .filter((el) => { const { w, h } = sizeOf(el); return w >= 64 && h >= 64; })
      .slice(-40)
      .map((el) => {
        const { r, nw, nh } = sizeOf(el);
        return {
          tag: el.tagName.toLowerCase(),
          src: short(srcOf(el)),
          natural: `${nw}x${nh}`,
          box: `${Math.round(r.width)}x${Math.round(r.height)}`,
          loaded: el.tagName === "IMG" ? Boolean(el.complete && el.naturalWidth) : null,
          role: turnRole(el),
          inForm: Boolean(closestDeep(el, "form")),
          inShadow: Boolean(el.getRootNode?.()?.host),
          inFrame: el.ownerDocument !== document,
          tracked: FRESH.includes(el),
          verdict: rejectReason(el, base) || "OK",
          blurPx: blurPx(el),
          likeReference: likeReference(el),
          auto: rejectReason(el, base) ? undefined : (autoVerdict(el, Infinity) || "OK"),
        };
      });
    let manifest = {};
    try { manifest = chrome.runtime.getManifest(); } catch { /* reloaded */ }
    return {
      snapscapes: manifest.version || "?",
      site: location.host,
      when: new Date().toISOString(),
      browser: navigator.userAgent,
      armed: Boolean(armedSrcs),
      snapWindow: active,
      autoSave,
      referencePrints: refPrints.map((r) => r.from),
      baseline: armedSrcs ? armedSrcs.size : 0,
      tracked: FRESH.length,
      saved: SKIPPED.size,
      markers: {
        authorRole: count("[data-message-author-role]", "data-message-author-role"),
        dataTurn: count("[data-turn]", "data-turn"),
        userQuery: document.querySelectorAll("user-query").length,
        modelResponse: document.querySelectorAll("model-response").length,
      },
      imgsOnPage: document.images.length,
      canvases: document.querySelectorAll("canvas").length,
      inlineBackgrounds: document.querySelectorAll("main [style*='background-image']").length,
      shadowHosts,
      frames,
      pictures,
    };
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; } catch { /* fall back */ }
    try {
      const ta = document.createElement("textarea");
      ta.dataset.djpbUi = "1";
      ta.value = text;
      Object.assign(ta.style, { position: "fixed", left: "-9999px", top: "0" });
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch { return false; }
  }

  /** Put a "📋 Copy details" button next to a control that just failed. */
  function offerDebugCopy(nextTo) {
    const row = nextTo?.parentElement;
    if (!row || row.querySelector("[data-djpb-debug]")) return;
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.djpbDebug = "1";
    b.textContent = "📋 Copy details";
    b.title = "Copies a short report about the pictures on this page (no chat text) for the extension's developer";
    Object.assign(b.style, {
      font: "600 12px/1 system-ui, sans-serif", color: "#e9e4f5",
      background: "rgba(255,255,255,0.08)", border: "1px solid #3a2b55",
      borderRadius: "999px", padding: narrow() ? "11px 14px" : "7px 11px",
      minHeight: narrow() ? "42px" : "auto", cursor: "pointer",
    });
    b.addEventListener("click", async () => {
      let text;
      try { text = JSON.stringify(debugReport(), null, 1); }
      catch (err) { text = `report failed: ${err?.message || err}`; }
      b.textContent = (await copyText(text)) ? "✓ copied — paste it to the developer" : "couldn't copy";
      setTimeout(() => (b.textContent = "📋 Copy details"), 4000);
    });
    nextTo.insertAdjacentElement("afterend", b);
  }

  // ---------- capture ----------

  /** The biggest picture an <img> offers: its largest srcset entry. */
  function largestSrcset(img) {
    const set = img.getAttribute?.("srcset") || "";
    if (!set) return "";
    let best = "", bestW = 0;
    for (const part of set.split(",")) {
      const [url, desc = ""] = part.trim().split(/\s+/);
      if (!url) continue;
      const n = parseFloat(desc) || 1;
      const w = /x$/i.test(desc) ? n * 10000 : n; // density beats unlabelled
      if (w > bestW) { bestW = w; best = url; }
    }
    try { return best ? new URL(best, img.baseURI).href : ""; } catch { return ""; }
  }

  async function toDataUrl(el) {
    if (el.tagName === "CANVAS") {
      // Throws on a tainted canvas; capture() reports it.
      return el.toDataURL("image/png");
    }

    const urls = [];
    if (el.tagName === "IMG") {
      const big = largestSrcset(el);
      if (big) urls.push(big);
    }
    const own = srcOf(el);
    if (own && !urls.includes(own)) urls.push(own);

    for (const src of urls) {
      try {
        const res = await fetch(src);
        if (res.ok) {
          const blob = await res.blob();
          if (blob.type.startsWith("image/") || src.startsWith("blob:")) {
            return await blobToDataUrl(blob);
          }
        }
      } catch { /* try the next */ }
    }

    if (el.tagName === "IMG") {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = el.naturalWidth;
        canvas.height = el.naturalHeight;
        canvas.getContext("2d").drawImage(el, 0, 0);
        return canvas.toDataURL("image/png");
      } catch { /* fall through */ }
    }

    let lastErr = "couldn't read that image";
    for (const src of urls) {
      if (!/^https?:/i.test(src)) continue;
      try {
        const res = await chrome.runtime.sendMessage({ type: "fetchImage", url: src });
        if (res?.ok && res.dataUrl) return res.dataUrl;
        lastErr = res?.error || lastErr;
      } catch (err) { lastErr = err?.message || lastErr; }
    }
    throw new Error(lastErr);
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error("read failed"));
      r.readAsDataURL(blob);
    });
  }

  /** Save the picture to the chat's album and make it the chat's Snapscape.
   *  The worker does both in one step (setScape): in follow mode the newest
   *  photo already is the Snapscape; pinned or switched off for this chat,
   *  it is pinned to this photo. */
  async function capture(img, snap, preDataUrl, { auto = false } = {}) {
    try {
      const dataUrl = preDataUrl || await toDataUrl(img);
      const res = await chrome.runtime.sendMessage({
        type: "snap:save",
        dataUrl,
        snapId: snap?.id || null,
        sessionId: snap?.sessionId || null,
        caption: snap?.replyText || "",
        setScape: true,
      });
      if (!res?.ok) throw new Error(res?.error || "save failed");

      // The Snap tab is reused across snaps, so this image stays on the page.
      // Mark it saved so it never shows up as a candidate again.
      SKIPPED.add(srcOf(img));
      stopWatch();
      if (currentSnap && snap && currentSnap.id === snap.id) currentSnap = null;

      const actions = [];
      let savedMsg;
      if (auto) {
        // Nobody looked before this one was saved, so it gets a way back.
        actions.push({ label: "↶ Undo", fn: async (btn) => {
          btn.disabled = true;
          try {
            const u = await chrome.runtime.sendMessage({
              type: "snap:undo", id: res.id, sessionId: res.sessionId, prevBackdrop: res.prevBackdrop,
            });
            if (!u?.ok) throw new Error(u?.error || "undo failed");
            SKIPPED.delete(srcOf(img));
            currentSnap = snap;
            toast("Undone — it's out of the album. Pick the right one:", null, null, "");
            startSettleWatch(snap);
            if (watch) watch.autoDone = true;   // don't auto-save the same one again
          } catch {
            btn.textContent = "couldn't undo";
          }
        } });
      }
      if (res.sessionId === "unfiled") {
        savedMsg = "Saved to Loose photos ♥ (no chat to set it behind)";
      } else if (res.backdropOn === false) {
        // Snapscapes are switched off everywhere — the user's own choice, so
        // offer the switch rather than flipping it for them.
        savedMsg = "Saved ♥ and set as this chat's Snapscape — but Snapscapes are switched off.";
        actions.push({ label: "🌄 Turn Snapscapes on", fn: async (btn) => {
          btn.disabled = true;
          try {
            await chrome.storage.local.set({ djpbBackdropOn: true });
            btn.textContent = "✓ Snapscapes on";
          } catch {
            btn.textContent = "couldn't switch them on";
          }
        } });
      } else {
        savedMsg = "Saved ♥ and set as your Snapscape";
      }
      if (auto) savedMsg = savedMsg.replace(/^Saved/, "Auto-saved");
      toast(savedMsg, res.returnUrl, actions.length ? actions : null,
        typeof dataUrl === "string" ? dataUrl : "");
    } catch (err) {
      console.warn("[SnapScapes] Capture failed:", err);
      const again = lastArmed
        ? [{ label: "↩ Back", fn: () => showArmedToast(lastArmed.message, lastArmed.snap) }]
        : null;
      toast(`Couldn't save: ${err.message}`, null, again);
      throw err;
    }
  }

  // ---------- toast & dragging ----------

  const TOAST_POS_KEY = "djpbToastPos";
  let toastPos = null;
  let toastPosLoaded = false;

  async function loadToastPos() {
    if (toastPosLoaded) return;
    toastPosLoaded = true;
    try {
      const v = await chrome.storage.local.get({ [TOAST_POS_KEY]: null });
      toastPos = v[TOAST_POS_KEY];
      if (toastPos && toastEl) placeToast(toastEl);
    } catch { /* defaults apply */ }
  }

  const narrow = () => innerWidth < 820;

  function placeToast(el) {
    if (!toastPos) {
      el.style.left = "auto";
      el.style.top = "auto";
      el.style.right = narrow() ? "10px" : "20px";
      el.style.bottom = narrow()
        ? "calc(env(safe-area-inset-bottom, 0px) + 150px)"
        : "20px";
      return;
    }
    const w = el.offsetWidth || 300;
    const h = el.offsetHeight || 60;
    const x = Math.min(Math.max(toastPos.xPct * innerWidth, 4), innerWidth - w - 4);
    const y = Math.min(Math.max(toastPos.yPct * innerHeight, 4), innerHeight - h - 4);
    Object.assign(el.style, {
      left: `${Math.round(x)}px`, top: `${Math.round(y)}px`,
      right: "auto", bottom: "auto",
    });
  }

  function makeToastDraggable(el) {
    let origin = null;
    let dragging = false;
    el.style.touchAction = "none";

    el.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button, a, input, textarea")) return;
      const r = el.getBoundingClientRect();
      origin = { px: e.clientX, py: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top };
      dragging = false;
      try { el.setPointerCapture(e.pointerId); } catch { /* fine */ }
    });

    el.addEventListener("pointermove", (e) => {
      if (!origin) return;
      const dist = Math.hypot(e.clientX - origin.px, e.clientY - origin.py);
      if (!dragging && dist > 5) {
        dragging = true;
        el.style.opacity = "0.92";
        el.style.cursor = "grabbing";
      }
      if (!dragging) return;
      e.preventDefault();
      const w = el.offsetWidth, h = el.offsetHeight;
      const x = Math.min(Math.max(e.clientX - origin.dx, 4), innerWidth - w - 4);
      const y = Math.min(Math.max(e.clientY - origin.dy, 4), innerHeight - h - 4);
      Object.assign(el.style, {
        left: `${Math.round(x)}px`, top: `${Math.round(y)}px`,
        right: "auto", bottom: "auto",
      });
    });

    const end = (e) => {
      if (!origin) return;
      origin = null;
      try { el.releasePointerCapture(e.pointerId); } catch { /* fine */ }
      el.style.opacity = "1";
      el.style.cursor = "grab";
      if (!dragging) return;
      dragging = false;
      const r = el.getBoundingClientRect();
      toastPos = { xPct: r.left / innerWidth, yPct: r.top / innerHeight };
      chrome.storage.local.set({ [TOAST_POS_KEY]: toastPos });
    };
    el.addEventListener("pointerup", end);
    el.addEventListener("pointercancel", end);
  }

  let toastEl = null;

  /** The heartbeat lives in a real stylesheet because inline styles can't
   *  carry keyframes. Injected once, tiny, and only animates the ♥. */
  let heartCss = null;
  function ensureHeartCss() {
    if (heartCss?.isConnected) return;
    heartCss = document.createElement("style");
    heartCss.dataset.djpbUi = "1";
    heartCss.textContent = `
      @keyframes djpb-heartbeat {
        0%, 100% { transform: scale(1); }
        10%      { transform: scale(1.25); }
        20%      { transform: scale(1); }
        30%      { transform: scale(1.15); }
        40%      { transform: scale(1); }
      }
      @keyframes djpb-heartpop {
        0%   { transform: scale(1); }
        45%  { transform: scale(1.6) rotate(-8deg); }
        100% { transform: scale(1); }
      }
      .djpb-heart { display: inline-block; animation: djpb-heartbeat 1.6s ease-in-out infinite; }
      button:disabled .djpb-heart { animation: none; opacity: .6; }
      .djpb-heart.pop { animation: djpb-heartpop .5s ease-out 1; }
    `;
    (document.head || document.documentElement).appendChild(heartCss);
  }

  function toast(message, returnUrl, actions, thumbSrc) {
    toastEl?.remove();
    ensureHeartCss();
    toastEl = document.createElement("div");
    toastEl.dataset.djpbUi = "1";
    Object.assign(toastEl.style, {
      position: "fixed", zIndex: 2147483001,
      display: "flex", flexDirection: "column", gap: "10px",
      maxWidth: "min(420px, 92vw)",
      font: "13px/1.3 system-ui, sans-serif", color: "#e9e4f5",
      background: "#1f1830", border: "1px solid #3a2b55",
      borderRadius: "12px", padding: "10px 12px",
      boxShadow: "0 8px 30px rgba(0,0,0,.5)",
      cursor: "grab", userSelect: "none", webkitUserSelect: "none",
    });

    const headRow = document.createElement("div");
    Object.assign(headRow.style, {
      display: "flex", alignItems: "center", justifyContent: "space-between",
      gap: "8px", width: "100%",
    });

    const gripAndText = document.createElement("div");
    Object.assign(gripAndText.style, {
      display: "flex", alignItems: "center", gap: "8px", flex: "1 1 auto", minWidth: "0",
    });

    const grip = document.createElement("span");
    grip.textContent = "⠿";
    Object.assign(grip.style, { color: "#8b78af", fontSize: "15px", cursor: "grab", touchAction: "none" });
    grip.title = "Drag to move";

    const text = document.createElement("span");
    text.textContent = message;
    Object.assign(text.style, {
      whiteSpace: "normal", wordBreak: "break-word", flex: "1 1 auto",
    });

    // The thumbnail is the whole trick: the user can SEE whether this is the
    // generation or the reference echo before anything is saved. It sits in
    // the head row so it stays visible when the panel is minimized.
    if (thumbSrc) {
      const thumb = document.createElement("img");
      thumb.src = thumbSrc;
      thumb.alt = "";
      Object.assign(thumb.style, {
        width: "52px", height: "52px", objectFit: "cover",
        borderRadius: "10px", border: "2px solid #3a2b55",
        flex: "none", pointerEvents: "none",
      });
      gripAndText.append(grip, thumb, text);
    } else {
      gripAndText.append(grip, text);
    }

    const minBtn = document.createElement("button");
    minBtn.type = "button";
    minBtn.textContent = toastMinimized ? "＋" : "—";
    minBtn.title = toastMinimized ? "Expand bridge panel" : "Minimize bridge panel";
    Object.assign(minBtn.style, {
      font: "600 12px/1 system-ui, sans-serif", color: "#b7a8d8",
      background: "rgba(255,255,255,0.08)", border: "1px solid #3a2b55",
      borderRadius: "6px", padding: "4px 8px", cursor: "pointer", flexShrink: "0",
    });

    headRow.append(gripAndText, minBtn);
    toastEl.appendChild(headRow);

    const actionsWrap = document.createElement("div");
    Object.assign(actionsWrap.style, {
      display: toastMinimized ? "none" : "flex",
      alignItems: "center", gap: "8px", flexWrap: "wrap", width: "100%",
    });

    for (const a of actions || []) {
      const btn = document.createElement("button");
      btn.type = "button";
      if (a.disabled) btn.disabled = true;
      if (a.title) btn.title = a.title;
      const isToggle = typeof a.toggle === "boolean";
      if (isToggle) btn.dataset.on = a.toggle ? "1" : "0";
      Object.assign(btn.style, {
        font: "600 12px/1 system-ui, sans-serif", color: "#fff",
        background: isToggle
          ? (a.toggle ? "#2e2150" : "transparent")
          : a.heart
          ? "linear-gradient(135deg,#f472b6,#fb7185)"
          : "linear-gradient(135deg,#8b5cf6,#ec4899)",
        border: isToggle ? "1px solid #8b5cf6" : "none",
        borderRadius: "999px",
        padding: a.small
          ? (narrow() ? "11px 13px" : "7px 10px")
          : (narrow() ? "11px 14px" : "7px 11px"),
        minHeight: narrow() ? "42px" : "auto",
        cursor: a.disabled ? "default" : "pointer",
        opacity: a.disabled ? "0.55" : "1",
        display: "inline-flex", alignItems: "center", gap: "6px",
      });
      if (a.heart) {
        const heart = document.createElement("span");
        heart.className = "djpb-heart";
        heart.textContent = "♥";
        const label = document.createElement("span");
        label.dataset.djpbLabel = "1";
        label.textContent = a.label;
        btn.append(heart, label);
        btn.addEventListener("click", () => {
          heart.classList.add("pop"); // a little celebration on the way out
          a.fn(btn);
        });
      } else {
        btn.textContent = a.label;
        btn.addEventListener("click", () => a.fn(btn));
      }
      actionsWrap.appendChild(btn);
    }

    // A button, not a link: following a link took the Snap tab itself off
    // ChatGPT. This brings the chat's own tab forward instead.
    const safeReturn = /^https?:\/\//i.test(String(returnUrl || "")) ? returnUrl : null;
    if (safeReturn) {
      const back = document.createElement("button");
      back.type = "button";
      back.textContent = "Back to chat";
      Object.assign(back.style, {
        color: "#c4b5fd", fontWeight: "600", background: "none", border: "none",
        font: "600 13px/1.3 system-ui, sans-serif", cursor: "pointer",
        whiteSpace: "nowrap", padding: "4px 2px",
      });
      back.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "snap:back", returnUrl: safeReturn }).catch(() => {});
      });
      actionsWrap.appendChild(back);
    }

    if (actions?.length || safeReturn) {
      toastEl.appendChild(actionsWrap);
    } else {
      minBtn.style.display = "none";
    }

    minBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toastMinimized = !toastMinimized;
      minBtn.textContent = toastMinimized ? "＋" : "—";
      minBtn.title = toastMinimized ? "Expand bridge panel" : "Minimize bridge panel";
      actionsWrap.style.display = toastMinimized ? "none" : "flex";
      if (toastEl) placeToast(toastEl);
    });

    document.body.appendChild(toastEl);
    placeToast(toastEl);
    makeToastDraggable(toastEl);
    loadToastPos();

    // Only THIS toast goes away on the timer. It used to remove whatever
    // toast was showing by then, which could be a newer one with buttons.
    if (!actions?.length) {
      const mine = toastEl;
      setTimeout(() => {
        if (toastEl === mine) { mine.remove(); toastEl = null; }
      }, returnUrl ? 12000 : 5000);
    }
  }

  /** Remember everything on the page right now — <img>s and canvases in
   *  shadow roots and frames included — so nothing already here can be
   *  mistaken for the picture this snap is about to produce. */
  function armBaseline() {
    armedSrcs = new Set(SEEN_SRC);
    try {
      for (const el of collectDeep(document, [])) {
        const src = srcOf(el);
        if (src) armedSrcs.add(src);
      }
      for (const el of backgroundCandidates()) {
        const src = bgUrl(el);
        if (src) armedSrcs.add(src);
      }
    } catch { /* the plain list above still stands */ }
  }

  let zoomStyle = null;
  function preventFocusZoom() {
    if (zoomStyle?.isConnected) return;
    try {
      const style = document.createElement("style");
      zoomStyle = style;
      style.dataset.djpbUi = "1";
      style.textContent = `
        #prompt-textarea, textarea, input[type="text"], [contenteditable="true"] {
          font-size: max(16px, 1em) !important;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    } catch { /* page behaves as before */ }
  }

  function findComposer() {
    return document.querySelector("#prompt-textarea") ||
           document.querySelector("main [contenteditable='true']") ||
           document.querySelector("form textarea") ||
           document.querySelector("textarea");
  }

  function insertPrompt(text) {
    const box = findComposer();
    if (!box) return false;
    box.focus();
    if (box.isContentEditable) {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
      if (!box.textContent.trim()) {
        box.textContent = text;
        box.dispatchEvent(new InputEvent("input", { bubbles: true }));
      }
    } else {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value")?.set;
      setter ? setter.call(box, text) : (box.value = text);
      box.dispatchEvent(new Event("input", { bubbles: true }));
    }
    return true;
  }

  async function insertImage(blob, name) {
    const box = findComposer();
    if (!box) return false;
    const dt = new DataTransfer();
    dt.items.add(new File([blob], name || "reference.png", { type: blob.type || "image/png" }));
    box.focus();
    const ev = new ClipboardEvent("paste", {
      clipboardData: dt, bubbles: true, cancelable: true,
    });
    box.dispatchEvent(ev);
    return true;
  }

  let filledFor = null;

  async function autoFillEnabled() {
    try {
      const { djpbAutoFill } = await chrome.storage.local.get({ djpbAutoFill: true });
      return djpbAutoFill !== false;
    } catch {
      return true;
    }
  }

  async function waitForComposer(ms = 8000) {
    const started = Date.now();
    while (Date.now() - started < ms) {
      const box = findComposer();
      if (box) return box;
      await new Promise((r) => setTimeout(r, 250));
    }
    return null;
  }

  /** Paste the snap's own references into the box: the ones ticked in the
   *  Snap card when Send was pressed, nothing guessed. Returns how many went
   *  in. */
  async function attachRefs(snap) {
    const refs = Array.isArray(snap?.refs) ? snap.refs : [];
    if (!refs.length || !snap?.sessionId) return 0;
    const images = await refImagesFor(snap);

    let attached = 0;
    for (const ref of images) {
      try {
        const blob = await (await fetch(ref.dataUrl)).blob();
        if (await insertImage(blob, fileNameFor(ref.name, blob.type))) {
          attached += 1;
          await new Promise((r) => setTimeout(r, 700));
        }
      } catch { /* skip unavailable ref */ }
    }
    return attached;
  }

  /** "Book ref 2" → "Book ref 2.png": some sites decide what a pasted file
   *  is from its name. */
  function fileNameFor(name, type) {
    const ext = /png/.test(type) ? "png" : /webp/.test(type) ? "webp"
      : /gif/.test(type) ? "gif" : "jpg";
    const base = String(name || "reference").replace(/[\\/:*?"<>|]+/g, " ").trim() || "reference";
    return /\.(png|jpe?g|webp|gif)$/i.test(base) ? base : `${base}.${ext}`;
  }

  async function autoFill(snap, announce) {
    if (!snap?.prompt) return;
    const stamp = String(snap.id || snap.createdAt);
    if (filledFor === stamp) return;
    filledFor = stamp;

    if (!(await autoFillEnabled())) return;

    const box = await waitForComposer();
    if (!box) {
      if (announce) announce("Couldn't find ChatGPT's message box — use the buttons below.");
      return;
    }
    // The composer can mount before the page has finished hydrating it, and
    // a hydrating editor throws away what was typed into it. Give it a beat.
    await new Promise((r) => setTimeout(r, 400));
    if (currentSnap?.id !== snap.id) return;   // replaced meanwhile

    const promptOk = insertPrompt(snap.prompt);
    const wanted = Array.isArray(snap.refs) ? snap.refs.length : 0;
    const attached = await attachRefs(snap);

    if (announce && currentSnap?.id === snap.id) {
      const bits = [];
      if (promptOk) bits.push("Prompt");
      if (attached) bits.push(`${attached} reference${attached === 1 ? "" : "s"}`);
      const missing = wanted - attached;
      const tail = missing > 0 ? ` (${missing} reference${missing === 1 ? "" : "s"} couldn't be attached)` : "";
      announce(bits.length
        ? `✓ ${bits.join(" and ")} ${bits.length > 1 ? "are" : "is"} in the box — just hit send.${tail}`
        : "Couldn't fill the box — use the buttons below.");
    }
  }

  // ---------- the Snap window: on and off ----------

  let observer = null;
  const onLoadCapture = (e) => {
    const t = e.target;
    if (t && t.tagName === "IMG") consider(t);
  };
  const onVisible = () => {
    if (document.visibilityState === "visible") setTimeout(scan, 400);
  };

  /** Become the Snap window: start watching the page. Everything already
   *  on it counts as "before", so nothing old is offered as new. */
  function activate() {
    if (active) return;
    active = true;
    initialScanDone = false;
    scan();
    initialScanDone = true;

    // Every <img> load in the document, heard in the capture phase (load
    // doesn't bubble). This catches a picture that finishes loading after
    // the last DOM change — the childList observer alone never would.
    document.addEventListener("load", onLoadCapture, true);
    // New elements, and src/srcset swapped on elements already there.
    observer = new MutationObserver((records) => {
      let structural = false;
      for (const r of records) {
        if (r.type === "attributes") {
          if (r.target.tagName === "IMG") consider(r.target);
        } else {
          structural = true;
        }
      }
      if (structural) scan();
    });
    observer.observe(document.documentElement, {
      childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"],
    });
    document.addEventListener("visibilitychange", onVisible);
    preventFocusZoom();
    chrome.storage.local.get({ [AUTO_SAVE_KEY]: false })
      .then((v) => { autoSave = v[AUTO_SAVE_KEY] === true; if (watch) watch.shownSrc = null; })
      .catch(() => {});
  }

  /** Stop being the Snap window: the lock moved to another tab. */
  function deactivate() {
    active = false;
    currentSnap = null;
    lastArmed = null;
    stopWatch();
    observer?.disconnect();
    observer = null;
    document.removeEventListener("load", onLoadCapture, true);
    document.removeEventListener("visibilitychange", onVisible);
    zoomStyle?.remove();
    zoomStyle = null;
    toastEl?.remove();
    toastEl = null;
    heartCss?.remove();
    heartCss = null;
    document.querySelectorAll("[data-djpb-ui]").forEach((el) => el.remove());
    FRESH.length = 0;
  }

  /** A snap has arrived for this tab (or just the lock, when snap is null). */
  async function takeSnap(snap, names, { announceLock = false } = {}) {
    activate();
    if (!snap) {
      currentSnap = null;
      if (announceLock) toast("This tab is now your Snap window.", null, null, "");
      return;
    }
    currentSnap = snap;
    castNames = { charName: names?.charName || null, userName: names?.userName || null };
    armBaseline();
    const auto = await autoFillEnabled();
    if (currentSnap?.id !== snap.id) return;
    showArmedToast(auto
      ? "📖 Filling the box for you…"
      : "📖 Ready — use the buttons below, then send.", snap);
    // Watch from the moment of arming, not only once the observer reports a
    // new image — it may never hear about this one.
    startSettleWatch(snap);
    if (auto) {
      autoFill(snap, (m) => {
        if (currentSnap?.id === snap.id && !(watch && watch.autoDone)) showArmedToast(m, snap);
      });
    }
  }

  chrome.storage.onChanged?.addListener((changes, area) => {
    if (area !== "local" || !(AUTO_SAVE_KEY in changes)) return;
    autoSave = changes[AUTO_SAVE_KEY].newValue === true;
    if (watch) watch.shownSrc = null;
  });

  // The worker hands the snap over in the message itself and waits for the
  // answer: no answer means this tab predates the extension's last reload,
  // and it gets reloaded once.
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "snap:armed") {
      sendResponse({ ok: true });
      takeSnap(msg.snap || null, msg, { announceLock: true }).catch(() => {});
      return;
    }
    if (msg?.type === "snap:released") {
      sendResponse({ ok: true });
      deactivate();
    }
  });

  // ---------- boot ----------
  // Quiet until the worker says this is the Snap window. Every other
  // ChatGPT tab stops here and never touches the page.

  (async () => {
    let res = null;
    for (let attempt = 0; attempt < 3 && !res; attempt += 1) {
      try { res = await chrome.runtime.sendMessage({ type: "snap:hello" }); }
      catch { await new Promise((r) => setTimeout(r, 500)); }   // worker waking
    }
    if (!res?.ok || !res.snapTab) return;
    if (active && currentSnap) return;   // a snap:armed already beat us here
    await takeSnap(res.snap || null, res);
  })();
})();
