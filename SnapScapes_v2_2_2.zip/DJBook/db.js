// db.js — v0.4: thin proxy to the service worker, which owns the real
// IndexedDB (extension origin). This lets the browse page and the content
// script share one photo store. All images travel as data URLs in messages.

const PhotobookDB = (() => {
  async function call(op, args = {}) {
    const res = await chrome.runtime.sendMessage({ type: "db", op, args });
    if (!res || !res.ok) throw new Error(res?.error || "Storage error");
    return res.result;
  }

  return {
    /** Add an image (data URL). Returns the new record id. */
    add: (sessionId, dataUrl, meta = {}) => call("add", { sessionId, dataUrl, meta }),

    /** All images for a session, oldest first: [{id, dataUrl, caption, createdAt, source}] */
    list: (sessionId) => call("list", { sessionId }),

    /** Reference images per session (data URLs in/out), up to 4. */
    getCast: (sessionId) => call("getCast", { sessionId }),
    /** `on` ticks it for sending in the same step. Returns the new id. */
    addReference: (sessionId, dataUrl, label, on = false) =>
      call("addReference", { sessionId, dataUrl, label, on }),
    /** [{id, index, label, dataUrl, thumb}] */
    listReferences: (sessionId) => call("listReferences", { sessionId }),
    /** By id; the index is only a fallback for older callers. */
    removeReference: (sessionId, index, refId) =>
      call("removeReference", { sessionId, index, refId }),

    /** The image that belongs behind this chat. Pass the id already on screen
     *  to get {unchanged:true} instead of the whole picture again. */
    backdrop: (sessionId, knownId) => call("backdrop", { sessionId, knownId }),
    setBackdrop: (sessionId, id) => call("setBackdrop", { sessionId, id }),

    /** Snapscape state: {mode:"follow"|"pinned"|"none", id, newestId}. */
    scapeInfo: (sessionId) => call("scapeInfo", { sessionId }),

    /** Per-image scene effect override. null = use auto-detected effects; otherwise pass either a legacy array or {effects, intensity}. */
    setEffects: (id, effects) => call("setEffects", { id, effects }),

    /** [{name, role: "bot"|"user", portrait}] from the captured sheet. */
  };
})();
