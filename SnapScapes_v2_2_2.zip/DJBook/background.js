// background.js — the service worker.
//
// Owns the photo store, the session records (sheet + scene memory), the
// generation backends and the ChatGPT/Grok/Gemini bridge. Drafting a prompt
// is delegated to draft.js. Message types:
//   {type:"db", op, args}                          → storage operations
//   {type:"payload:store", payload, lastReply, lastUserMsg}
//   {type:"prompt:draft", sessionId, replyText, thinkText, …}
//   {type:"generate", prompt, negative, reference, strength}
//   {type:"fetchImage", url}                       → fetch any image as data URL
//   {type:"snap:arm", sessionId, prompt, returnUrl}→ send a snap to the Snap window
//   {type:"snap:hello"}                            → capture.js: am I the Snap window?
//   {type:"snap:save", dataUrl, snapId, sessionId, setScape}
//   {type:"snap:undo", id, sessionId, prevBackdrop}
//   {type:"snapwin:status"} / {type:"snapwin:open"} → the Snap card's button
//   {type:"snap:refpicks"|"snap:setrefpick"|"snap:refimages", sessionId, …}

let BOOT_ERROR = null;
try {
  // Order matters: each one reads the globals the previous ones define.
  importScripts("condense.js", "scene.js", "sheet.js", "draft.js", "polish.js");
} catch (err) {
  BOOT_ERROR = String(err?.message || err);
  console.error("[SnapScapes] startup failed — a helper script did not load:", err);
}

// ======================= storage =======================

const DB_NAME = "dj-photobook";
const DB_VERSION = 3;
const IMAGES = "images";
const SESSIONS = "sessions";

let dbPromise = null;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(IMAGES)) {
        const s = db.createObjectStore(IMAGES, { keyPath: "id", autoIncrement: true });
        s.createIndex("bySession", "sessionId", { unique: false });
      }
      if (!db.objectStoreNames.contains(SESSIONS)) {
        db.createObjectStore(SESSIONS, { keyPath: "sessionId" });
      }
    };
    r.onblocked = () =>
      reject(new Error("photobook database is blocked by another tab — close the album tab"));
    r.onsuccess = () => {
      const db = r.result;
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    r.onerror = () => reject(r.error);
  });
  dbPromise = dbPromise.catch((err) => { dbPromise = null; throw err; });
  return dbPromise;
}

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function store(name, mode) {
  const db = await openDb();
  return db.transaction(name, mode).objectStore(name);
}

async function dataUrlToBlob(dataUrl) {
  return (await fetch(dataUrl)).blob();
}

async function blobToDataUrl(blob) {
  const buf = await blob.arrayBuffer();
  return `data:${blob.type || "image/png"};base64,${arrayBufferToBase64(buf)}`;
}

const MAX_REFS = 4;

// A small JPEG of a reference, sized for the Snap card's chips (192px covers
// the hover preview at 1x and the 26px chip at any density). Generated once
// per reference and cached on the record, so chips open instantly after the
// first time. Falls back to the full image if OffscreenCanvas is unavailable.
const THUMB_PX = 192;

async function makeThumb(blob) {
  try {
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, THUMB_PX / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext("2d").drawImage(bmp, 0, 0, w, h);
    bmp.close?.();
    const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.75 });
    return blobToDataUrl(out);
  } catch {
    return blobToDataUrl(blob);   // tiny worst case: chip shows the full image
  }
}

/** One queue for every write to a chat's reference list. Two quick taps in
 *  the Snap card used to read the same list, each add one photo, and the
 *  second write dropped the first. */
let refQueue = Promise.resolve();
function refSerial(fn) {
  const run = refQueue.then(fn, fn);
  refQueue = run.catch(() => {});
  return run;
}

const isBlob = (b) => b instanceof Blob;

const newId = () =>
  `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

/** A chat's references, cleaned up, with a stable `id` and a `thumb` on
 *  every entry — and the cleanup saved back.
 *
 *  v2.2: references used to be known only by their position in the list,
 *  and the ticks in the Snap card were saved against that position. Each now
 *  carries an id. Ones saved before ids existed get one derived from their
 *  position and size, so two readers racing on the first load agree on it.
 *
 *  A reference whose picture is not a real Blob is dropped. Backups written
 *  by 2.1 and earlier turned these pictures into `{}`, so after a Restore a
 *  chip still showed its thumbnail while the photo itself was silently
 *  skipped on every send. */
async function loadRefs(sessionId) {
  const read = async () =>
    req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const first = await normalizeRefs(await read());
  if (!first.dirty) return first.refs;
  // Something needs saving: redo it inside the queue on a fresh read, so a
  // photo added or removed meanwhile is neither lost nor brought back.
  return refSerial(async () => {
    const now = await read();
    const { refs, dirty } = await normalizeRefs(now);
    if (dirty && now) {
      const rec2 = { ...now, sessionId, references: refs };
      delete rec2.referenceBlob;
      await req((await store(SESSIONS, "readwrite")).put(rec2));
    }
    return refs;
  }).catch(() => first.refs);
}

async function normalizeRefs(rec) {
  const raw = refsOf(rec);
  let dirty = Boolean(rec?.referenceBlob) && !Array.isArray(rec?.references);
  const refs = [];
  raw.forEach((r, i) => {
    if (!isBlob(r.blob)) { dirty = true; return; }
    const out = { ...r };
    if (!out.id) { out.id = `legacy${i}-${r.blob.size}`; dirty = true; }
    refs.push(out);
  });
  for (const r of refs) {
    if (!r.thumb) { r.thumb = await makeThumb(r.blob); dirty = true; }
  }
  return { refs, dirty };
}

function refsOf(rec) {
  if (!rec) return [];
  if (Array.isArray(rec.references)) return [...rec.references];
  if (rec.referenceBlob) return [{ blob: rec.referenceBlob, label: "Book ref" }];
  return [];
}

async function recordOut(rec) {
  return {
    id: rec.id,
    sessionId: rec.sessionId,
    caption: rec.caption || "",
    createdAt: rec.createdAt,
    source: rec.source || "",
    dataUrl: await blobToDataUrl(rec.blob),
  };
}

const dbOps = {
  async add({ sessionId, dataUrl, meta = {} }) {
    const blob = await dataUrlToBlob(dataUrl);
    const s = await store(IMAGES, "readwrite");
    return req(s.add({
      sessionId: sessionId || "unfiled",
      blob,
      caption: meta.caption || "",
      source: meta.source || "",
      prompt: meta.prompt || "",
      conditions: meta.conditions && typeof meta.conditions === "object"
        ? { ...meta.conditions }
        : undefined,
      createdAt: meta.createdAt || Date.now(),
    }));
  },

  async backdrop({ sessionId, knownId }) {
    if (!sessionId) return null;

    let target = null;
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const pinned = Boolean(rec?.backdropId) && rec.backdropId !== "none";
    if (rec?.backdropId === "none") return null;
    if (rec?.backdropId) {
      target = await req((await store(IMAGES, "readonly")).get(rec.backdropId)).catch(() => null);
    }
    if (!target) {
      const all = await req(
        (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId)));
      all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      target = all[all.length - 1] || null;
    }
    if (!target) return null;
    const conditions = target.conditions && typeof target.conditions === "object"
      ? { ...target.conditions }
      : {};
    const manualEffects = Array.isArray(target.manualEffects)
      ? [...target.manualEffects]
      : (target.manualEffects && typeof target.manualEffects === "object"
        ? {
            effects: Array.isArray(target.manualEffects.effects) ? [...target.manualEffects.effects] : [],
            intensity: target.manualEffects.intensity && typeof target.manualEffects.intensity === "object"
              ? { ...target.manualEffects.intensity }
              : {},
          }
        : null);
    if (knownId && String(target.id) === String(knownId)) {
      return { id: target.id, unchanged: true, conditions, manualEffects, pinned };
    }
    return {
      id: target.id,
      pinned,
      dataUrl: await blobToDataUrl(target.blob),
      conditions,
      manualEffects,
    };
  },

  async setEffects({ id, effects }) {
    const rec = await req((await store(IMAGES, "readonly")).get(id));
    if (!rec) throw new Error("Image not found");

    const allowed = new Set([
      "rain", "lightning", "snow", "fog",
      "embers", "fireflies", "petals", "lilacs",
      "vignette", "sunlight",
    ]);
    const clampIntensity = (value) => {
      const n = Number(value);
      if (!Number.isFinite(n)) return 3;
      return Math.max(1, Math.min(4, Math.round(n)));
    };

    if (effects === null || effects === undefined) {
      delete rec.manualEffects;
    } else if (Array.isArray(effects)) {
      rec.manualEffects = [...new Set(effects.filter((name) => allowed.has(name)))];
    } else if (effects && typeof effects === "object") {
      const names = [...new Set(
        (Array.isArray(effects.effects) ? effects.effects : []).filter((name) => allowed.has(name))
      )];
      const intensity = {};
      const source = effects.intensity && typeof effects.intensity === "object"
        ? effects.intensity
        : {};
      for (const name of names) intensity[name] = clampIntensity(source[name]);
      rec.manualEffects = { effects: names, intensity };
    } else {
      rec.manualEffects = [];
    }

    await req((await store(IMAGES, "readwrite")).put(rec));
    return {
      id: rec.id,
      conditions: rec.conditions && typeof rec.conditions === "object"
        ? { ...rec.conditions }
        : {},
      manualEffects: Array.isArray(rec.manualEffects)
        ? [...rec.manualEffects]
        : (rec.manualEffects && typeof rec.manualEffects === "object"
          ? {
              effects: Array.isArray(rec.manualEffects.effects) ? [...rec.manualEffects.effects] : [],
              intensity: rec.manualEffects.intensity && typeof rec.manualEffects.intensity === "object"
                ? { ...rec.manualEffects.intensity }
                : {},
            }
          : null),
    };
  },

  /** The Snapscape mode for a chat, without touching any image blobs:
   *  {mode:"follow"|"pinned"|"none", id, newestId}. "follow" is backdropId
   *  null/absent (the backdrop tracks the newest photo); "pinned" holds one;
   *  "none" is the explicit off state. newestId lets a UI pin "what is
   *  showing right now" when the user turns follow off. */
  async scapeInfo({ sessionId }) {
    if (!sessionId) return { mode: "follow", id: null, newestId: null };
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const all = await req(
      (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId))
    ).catch(() => []);
    all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    const newestId = all.length ? all[all.length - 1].id : null;
    if (rec?.backdropId === "none") return { mode: "none", id: null, newestId };
    if (rec?.backdropId) return { mode: "pinned", id: rec.backdropId, newestId };
    return { mode: "follow", id: null, newestId };
  },

  async setBackdrop({ sessionId, id }) {
    await dbOps.mergeSession({ sessionId, patch: { backdropId: id || null } });
    return { ok: true };
  },

  async list({ sessionId }) {
    const s = await store(IMAGES, "readonly");
    const recs = await req(s.index("bySession").getAll(IDBKeyRange.only(sessionId)));
    recs.sort((a, b) => a.createdAt - b.createdAt);
    return Promise.all(recs.map(recordOut));
  },



  async getReference({ sessionId }) {
    const refs = await loadRefs(sessionId);
    return refs.length ? blobToDataUrl(refs[0].blob) : null;
  },

  /** Adds a photo to a chat's references. `on` ticks it in the same step
   *  (the Snap card's strips do), so there is no second message that could
   *  land somewhere else. Returns the new reference's id. */
  async addReference({ sessionId, dataUrl, label, on = false }) {
    if (!sessionId) throw new Error("No chat to add the reference to");
    await loadRefs(sessionId);                     // ids + cleanup first
    const blob = await dataUrlToBlob(dataUrl);
    const thumb = await makeThumb(blob);
    const id = newId();
    await refSerial(async () => {
      const prev = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
      const refs = refsOf(prev).filter((r) => isBlob(r.blob));
      if (refs.length >= MAX_REFS) {
        throw new Error(`Reference limit is ${MAX_REFS} — remove one first.`);
      }
      refs.push({ id, blob, thumb, label: String(label || "reference").slice(0, 48) });
      const rec = { ...(prev || {}), sessionId, references: refs };
      delete rec.referenceBlob;
      await req((await store(SESSIONS, "readwrite")).put(rec));
    });
    if (on) await setRefPick(sessionId, `book:${id}`, true);
    return id;
  },

  async listReferences({ sessionId }) {
    const refs = await loadRefs(sessionId);
    return Promise.all(
      refs.map(async (r, index) => ({
        id: r.id,
        index,
        // Auto-numbered labels are re-derived from position so they can't
        // drift after removals; hand-set labels pass through untouched.
        label: /^Book ref( \d+)?$/.test(r.label || "")
          ? `Book ref ${index + 1}`
          : (r.label || "reference"),
        dataUrl: await blobToDataUrl(r.blob),
        thumb: r.thumb || null,
      }))
    );
  },

  /** By id (v2.2); a bare index still works for anything older. */
  async removeReference({ sessionId, index, refId }) {
    if (!sessionId) throw new Error("No chat to remove the reference from");
    const refs = await loadRefs(sessionId);
    const gone = refId ? refs.find((r) => r.id === refId) : refs[Number(index)];
    if (!gone) return null;
    await refSerial(async () => {
      const prev = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
      if (!prev) return;
      const rec = { ...prev, sessionId,
        references: refsOf(prev).filter((r) => r.id !== gone.id && isBlob(r.blob)) };
      delete rec.referenceBlob;
      await req((await store(SESSIONS, "readwrite")).put(rec));
    });
    // Picks are keyed by id now, so nothing else shifts.
    try {
      const key = refPickKey(sessionId);
      const saved = (await chrome.storage.local.get({ [key]: null }))[key];
      if (saved && typeof saved === "object" && `book:${gone.id}` in saved) {
        delete saved[`book:${gone.id}`];
        await chrome.storage.local.set({ [key]: saved });
      }
    } catch { /* a stale key for a photo that's gone is harmless */ }
    return gone.id;
  },


  async mergeSession({ sessionId, patch }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const s = await store(SESSIONS, "readwrite");
    return req(s.put({ ...(prev || {}), sessionId, ...patch }));
  },

  /** The album's cast, for the Snap card's character picker. Portraits are
   *  already small (scaled on upload), so they travel as-is. */
  async getCast({ sessionId }) {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    return (Array.isArray(rec?.cast) ? rec.cast : [])
      .filter((c) => c.img)
      .map((c) => ({ id: c.id, name: c.name || "", img: c.img }));
  },
};

// ======================= config =======================

const DEFAULTS = {
  preset: "openrouter",
  endpoint: "",
  modelOpenRouter: "google/gemini-2.5-flash-image",
  width: 768,
  height: 768,
  steps: 25,
  style: "stylized digital illustration, semi realistic anime inspired",
  bridge: "chatgpt",
  polish: "off",                       // "claude": Claude writes the prompts
  polishModel: "claude-sonnet-5-5",
  polishNotes: "",                     // the reader's own instructions for Claude
};

(async () => {
  try {
    const { style } = await chrome.storage.sync.get({ style: null });
    if (style === "painterly digital art, cinematic composition") {
      await chrome.storage.sync.set({ style: DEFAULTS.style });
    }
  } catch { /* first run */ }
})();

const BRIDGE_URLS = {
  chatgpt: "https://chatgpt.com/",
  grok: "https://grok.com/",
  gemini: "https://gemini.google.com/",
};

/** Where a bridge lives, for finding a tab that is already open on it. */
const BRIDGE_MATCHES = {
  chatgpt: ["*://chatgpt.com/*", "*://chat.openai.com/*"],
  grok: ["*://grok.com/*"],
  gemini: ["*://gemini.google.com/*"],
};

/** The image services "Generate" can use. Pollinations and the OpenAI API
 *  were removed in v2.1; a preset saved by an older build reads as OpenRouter. */
const PRESETS = ["openrouter", "a1111"];

async function getConfig() {
  const [synced, local] = await Promise.all([
    chrome.storage.sync.get(DEFAULTS),
    chrome.storage.local.get({ apiKeyOpenRouter: "", apiKeyAnthropic: "" }),
  ]);
  const cfg = {
    ...DEFAULTS,
    ...synced,
    apiKeyOpenRouter: local.apiKeyOpenRouter || "",
    apiKeyAnthropic: local.apiKeyAnthropic || "",
  };
  if (!PRESETS.includes(cfg.preset)) cfg.preset = "openrouter";
  return cfg;
}

// v2.1 removed Pollinations, the OpenAI image backend and the old OpenAI
// prompt polishing. Clear what only they used, so no API key outlives the
// feature it was for. (The Anthropic key is kept: "Claude writes the prompts"
// uses it.)
chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  if (reason !== "update") return;
  // 2.1's bridge bookkeeping: one shared waiting snap, per-tab copies and
  // "which ChatGPT tab spoke last". The Snap window replaces all of it.
  try {
    await chrome.storage.session.remove(["pendingSnap", "pendingByTab", "bridgeTabs", "bridgeBySession"]);
  } catch { /* cleared at the next browser start anyway */ }
  try {
    await chrome.storage.local.remove(["apiKey"]);
    await chrome.storage.sync.remove(["model", "quality", "condenser",
      "condenserModel", "condenserModelClaude"]);
    const { preset } = await chrome.storage.sync.get({ preset: null });
    if (preset && !PRESETS.includes(preset)) await chrome.storage.sync.set({ preset: "openrouter" });
  } catch (err) {
    console.warn("[SnapScapes] settings cleanup skipped:", err.message);
  }
});

// ======================= message router =======================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (p) => p
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  switch (msg?.type) {
    case "db": {
      const op = dbOps[msg.op];
      if (!op) {
        sendResponse({ ok: false, error: `Unknown db op "${msg.op}"` });
        return;
      }
      reply(op(msg.args || {}).then((result) => ({ result: result ?? null })));
      return true;
    }
    // Manual diagnostic, no in-app caller by design. From any extension
    // page's console: chrome.runtime.sendMessage({ type: "health" })
    case "health":
      sendResponse({
        ok: true,
        boot: BOOT_ERROR,
        condenser: typeof PromptCondenser !== "undefined",
        sheet: typeof SheetBuilder !== "undefined",
        version: chrome.runtime.getManifest().version,
      });
      return true;
    case "config:summary":
      reply(configSummary());
      return true;
    case "options:open":
      reply((async () => { await chrome.runtime.openOptionsPage(); return {}; })());
      return true;
    case "albums:open":
      reply((async () => {
        await openAlbumTab(msg.sessionId || null);
        return {};
      })());
      return true;
    case "payload:store":
      reply(storePayload(msg));
      return true;
    case "prompt:draft":
      reply(draftPrompt(msg));
      return true;
    case "generate":
      reply(generate(msg));
      return true;
    case "prompt:polish":
      reply(polishPrompt(msg));
      return true;
    case "fetchImage":
      reply(fetchAsDataUrl(msg.url).then((dataUrl) => ({ dataUrl })));
      return true;
    // ---- the Snap window (v2.2) ----
    case "snap:arm":
      reply(armSnap(msg));
      return true;
    case "snap:hello":      // capture.js on load: "am I the Snap window?"
    case "snap:peek":       // (2.1's name for it)
      reply(bridgeSerial(() => snapHello(sender.tab?.id)));
      return true;
    case "snap:save":
      reply(saveSnap({ ...msg, tabId: sender.tab?.id }));
      return true;
    case "snap:undo":
      reply(undoSave(msg));
      return true;
    case "snap:back":
      reply(backToChat(msg.returnUrl, sender.tab));
      return true;
    case "snapwin:status":
      reply(snapWindowStatus());
      return true;
    case "snapwin:open":
      reply(goToSnapWindow());
      return true;

    // ---- references: always for a named chat, never a guess ----
    case "snap:refpicks":
      reply((async () => {
        if (!msg.sessionId) throw new Error("No chat given");
        return { sources: await snapRefPicks(msg.sessionId) };
      })());
      return true;
    case "snap:setrefpick":
      reply((async () => {
        if (!msg.sessionId) throw new Error("No chat given");
        await setRefPick(msg.sessionId, msg.id, msg.on === true);
        return { sources: await snapRefPicks(msg.sessionId) };
      })());
      return true;
    case "snap:refimages":
      // With `refs` (a snap's own list, frozen when Send was pressed) those
      // exact pictures; without, whatever is ticked for the chat right now
      // (the Generate route).
      reply((async () => {
        if (!msg.sessionId) throw new Error("No chat given");
        const list = Array.isArray(msg.refs)
          ? msg.refs
          : (await snapRefPicks(msg.sessionId)).filter((p) => p.on);
        const images = [];
        for (const src of list) {
          try {
            const got = await snapRefDataUrl(msg.sessionId, src);
            if (got?.dataUrl) images.push(got);
          } catch { /* unavailable */ }
        }
        return { images, wanted: list.length };
      })());
      return true;
    default:
      return;
  }
});

// ======================= sheet + drafting =======================

async function sessionRecord(sessionId) {
  return req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
}

/** Every send from the chat page lands here: the intercepted context becomes
 *  the sheet, and the two newest turns update the scene memory — so the next
 *  snap knows where the story was one turn ago, without waiting on the Nexus. */
async function storePayload({ payload, lastReply, lastUserMsg }) {
  const built = Sheet.fromPayload(payload || {});
  if (!built.sessionId) throw new Error("Payload had no sessionId");

  const existing = await sessionRecord(built.sessionId);
  const hasNewChars = Object.keys(built.characters || {}).length > 0;
  if (existing?.sheet?.characters && !hasNewChars) {
    return { sessionId: built.sessionId };
  }
  const sheet = existing?.sheet?.characters
    ? {
        ...built,
        characters: mergeCharacters(existing.sheet.characters, built.characters),
        lore: Object.keys(built.lore || {}).length ? built.lore : (existing.sheet.lore || {}),
      }
    : built;

  const patch = { sheet };
  if (built.album?.title) patch.album = built.album;
  if (String(lastReply || "").trim()) patch.lastReply = String(lastReply);
  if (String(lastUserMsg || "").trim()) patch.lastUserMsg = String(lastUserMsg);

  if (patch.lastReply || patch.lastUserMsg) {
    try {
      const learned = SceneLocator.memoryFromSend({
        lastUserMsg: patch.lastUserMsg || "",
        lastReply: patch.lastReply || "",
        previous: existing?.sceneMemory || null,
        cast: Object.values(sheet.characters || {}).map((c) => c.name),
        lore: sheet.lore || {},
      });
      if (learned) patch.sceneMemory = { ...(existing?.sceneMemory || {}), ...learned };
    } catch (err) {
      console.warn("[SnapScapes] scene memory skipped:", err?.message || err);
    }
  }

  await dbOps.mergeSession({ sessionId: built.sessionId, patch });
  await chrome.storage.local.set({ lastSession: built.sessionId });
  return { sessionId: built.sessionId };
}

function mergeCharacters(existing, incoming) {
  const out = { ...(existing || {}) };
  for (const [name, c] of Object.entries(incoming || {})) {
    const prev = out[name];
    if (prev?.edited) continue;
    if (!prev) { out[name] = c; continue; }
    const better = (c.appearance || "").length >= (prev.appearance || "").length ? c : prev;
    out[name] = { ...prev, ...better, portrait: c.portrait || prev.portrait || null };
  }
  return out;
}

/**
 * The snap. Gathers what the drafter needs from storage and config, hands it
 * the page's view of the conversation, and records what it learned about the
 * scene for next time.
 */
async function draftPrompt(msg) {
  const replyText = String(msg?.replyText || "");
  try {
    const cfg = await getConfig();
    const rec = await sessionRecord(msg.sessionId);
    const sheet = rec?.sheet || { characters: {}, lore: {} };

    // The stored player message only belongs to the NEWEST reply. Snapping an
    // older one with it attached described a turn that hadn't happened yet.
    const playerMsg = msg.isLatest === false ? "" : String(rec?.lastUserMsg || "");

    const result = await Drafter.draft({
      replyText,
      thinkText: msg.thinkText || "",
      playerMsg,
      history: Array.isArray(msg.history) ? msg.history.map(String) : [],
      nexus: msg.nexus || null,
      sheet,
      memory: rec?.sceneMemory || null,
      cfg,
    });

    // Older messages must not overwrite what we know about the present.
    if (result.memory && msg.isLatest !== false) {
      dbOps.mergeSession({ sessionId: msg.sessionId, patch: { sceneMemory: result.memory } })
        .catch(() => { /* memory is a nicety */ });
    }
    delete result.memory;   // stored above; the page has no use for it
    delete result.context;  // only the polish pass uses it
    result.polish = cfg.polish === "claude" && Boolean(cfg.apiKeyAnthropic);
    return result;
  } catch (err) {
    console.error("[SnapScapes] draft failed, using plain fallback:", err);
    const out = Drafter.fallbackDraft(replyText, err);
    delete out.memory;
    return out;
  }
}

/**
 * "Claude writes the prompts": the same reading as draftPrompt, then one
 * call to Claude. Returns Claude's drafts, or {ok:false} with a short reason
 * — the Snap card keeps the built-in prompt either way.
 */
async function polishPrompt(msg) {
  const cfg = await getConfig();
  if (cfg.polish !== "claude" || !cfg.apiKeyAnthropic) throw new Error("Claude prompts are off");
  const rec = await sessionRecord(msg.sessionId);
  const sheet = rec?.sheet || { characters: {}, lore: {} };
  const playerMsg = msg.isLatest === false ? "" : String(rec?.lastUserMsg || "");
  const base = await Drafter.draft({
    replyText: String(msg.replyText || ""),
    thinkText: msg.thinkText || "",
    playerMsg,
    history: Array.isArray(msg.history) ? msg.history.map(String) : [],
    nexus: msg.nexus || null,
    sheet,
    memory: rec?.sceneMemory || null,
    cfg,
  });
  const ctx = base.context;
  const out = await PromptPolish.write(ctx, {
    key: cfg.apiKeyAnthropic, model: cfg.polishModel, notes: cfg.polishNotes,
  });
  const drafts = PromptPolish.toDrafts(out.moments, ctx, cfg.style);
  // A prompt the roleplay bot wrote for itself stays on offer, last.
  if (ctx.botDraft) drafts.push(ctx.botDraft);
  return { drafts, model: out.model, usage: out.usage };
}

// ======================= generation =======================

async function generate({ prompt, negative, reference, references, strength, preset }) {
  const cfg = await getConfig();
  if (!prompt) throw new Error("No prompt");
  // The Snap menu's switch names the service; older callers fall back to
  // the saved one.
  if (PRESETS.includes(preset)) cfg.preset = preset;

  const refs = (Array.isArray(references) && references.length
    ? references
    : reference ? [reference] : []
  ).slice(0, MAX_REFS);

  switch (cfg.preset) {
    case "a1111":
      return { dataUrl: await genA1111(prompt, negative, refs[0] || null, strength, cfg),
               usedReference: Boolean(refs[0]) };
    case "openrouter":
      return { dataUrl: await genOpenRouter(prompt, refs, cfg),
               usedReference: refs.length > 0 };
    default:
      throw new Error(`Unknown preset "${cfg.preset}"`);
  }
}

async function genA1111(prompt, negative, reference, strength, cfg) {
  const base = normalizeBase(cfg.endpoint || "http://127.0.0.1:7860");
  const common = {
    prompt,
    negative_prompt: negative || PromptCondenser.SD_NEGATIVE,
    width: Number(cfg.width),
    height: Number(cfg.height),
    steps: Number(cfg.steps),
  };
  const body = reference
    ? { ...common, init_images: [stripDataUrl(reference)],
        denoising_strength: clamp(Number(strength) || 0.6, 0.2, 0.85) }
    : common;
  const path = reference ? "/sdapi/v1/img2img" : "/sdapi/v1/txt2img";

  const res = await fetch(base + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Backend returned ${res.status}`);
  const data = await res.json();
  const b64 = data.images?.[0];
  if (!b64) throw new Error("Backend returned no image");
  return `data:image/png;base64,${b64}`;
}

/** Width × height from Options → OpenRouter's nearest aspect ratio and size
 *  tier. 1920×1080 → 16:9 at 2K; 768×768 → 1:1 at 1K. */
const OR_ASPECTS = ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9", "9:21"];
function openRouterShape(width, height) {
  const w = width > 0 ? width : 1024;
  const h = height > 0 ? height : 1024;
  const want = Math.log(w / h);
  let aspect = "1:1";
  let best = Infinity;
  for (const a of OR_ASPECTS) {
    const [x, y] = a.split(":").map(Number);
    const d = Math.abs(Math.log(x / y) - want);
    if (d < best) { best = d; aspect = a; }
  }
  const long = Math.max(w, h);
  const tier = long <= 1280 ? "1K" : long <= 2560 ? "2K" : "4K";
  return { aspect, tier };
}

async function genOpenRouter(prompt, refs, cfg) {
  const model = cfg.modelOpenRouter || "google/gemini-2.5-flash-image";
  if (!cfg.apiKeyOpenRouter) {
    throw new Error("No OpenRouter API key set — open the extension's Options page.");
  }

  // Shape and size tier, not exact pixels. An explicit "1920x1080" is
  // passed straight to the provider, and each has its own rules (OpenAI's
  // models need both sides divisible by 16; Gemini's don't care), so one
  // setting worked on some models and failed on others. OpenRouter adapts
  // an aspect ratio and a tier to whatever each provider accepts.
  const { aspect, tier } = openRouterShape(Number(cfg.width), Number(cfg.height));
  const body = {
    model,
    prompt,
    aspect_ratio: aspect,
    resolution: tier,
    n: 1,
  };
  if (refs.length) {
    body.input_references = refs.map((url) => ({
      type: "image_url",
      image_url: { url },
    }));
  }

  const send = (payload) => fetch("https://openrouter.ai/api/v1/images", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.apiKeyOpenRouter}`,
      "HTTP-Referer": "https://dreamjourneyai.com",
      "X-Title": "SnapScapes",
    },
    body: JSON.stringify(payload),
  });
  let res = await send(body);
  // Aspect ratios are clamped to what a provider supports, but a size tier
  // can be refused outright ("No provider … supports the requested
  // parameter(s)"). Then ask again with the shape alone, at the model's
  // default size, rather than failing the picture.
  if (res.status === 400) {
    const text = await res.clone().text().catch(() => "");
    if (/resolution|supports the requested parameter|size/i.test(text)) {
      const { resolution, ...shapeOnly } = body;
      res = await send(shapeOnly);
    }
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let detail = text;
    try { detail = JSON.parse(text)?.error?.message || text; } catch { /* plain text */ }
    if (res.status === 401) {
      throw new Error("OpenRouter rejected the API key (401). Check it in Options.");
    }
    if (res.status === 402) {
      throw new Error("Your OpenRouter balance is too low — top up at openrouter.ai/credits.");
    }
    if (/no model found|does not support image output|not a valid model/i.test(detail)) {
      throw new Error(`OpenRouter can't make images with "${model}". Copy an image model's slug from openrouter.ai/models.`);
    }
    if (/safety|moderation|policy|content.?filter/i.test(detail)) {
      throw new Error(`${model} refused this prompt (content filter). Try rewording it, or another model.`);
    }
    throw new Error(`OpenRouter (${model}) said: ${String(detail).slice(0, 160)}`);
  }

  const data = await res.json();
  const img = data.data?.[0];
  if (!img?.b64_json) throw new Error("OpenRouter returned no image");
  return `data:${img.media_type || "image/png"};base64,${img.b64_json}`;
}

// ======================= snap bridge =======================

async function configSummary() {
  const cfg = await getConfig();
  const services = {
    openrouter: {
      label: "OpenRouter", note: "your API credit",
      ready: Boolean(cfg.apiKeyOpenRouter),
      why: "Add your OpenRouter key in ⚙ to generate here.",
    },
    a1111: {
      label: "Local", note: "your own GPU",
      // Local only shows in the Snap menu once an address is saved.
      ready: Boolean(cfg.endpoint),
      why: "Add your Stable Diffusion (A1111) address in ⚙.",
    },
  };
  const info = services[cfg.preset] || services.openrouter;
  return {
    bridge: cfg.bridge || "chatgpt",
    services,
    // Older fields, kept for anything that still reads them.
    preset: cfg.preset,
    label: info.label,
    note: info.note,
    ready: info.ready,
    needsKey: cfg.preset === "openrouter",
  };
}

// ======================= the Snap window (v2.2) =======================
//
// Every snap is addressed now. It carries its own id, the Dream Journey chat
// it came from, and the exact references that were ticked when Send was
// pressed, and it is delivered to ONE ChatGPT tab: the Snap window. Nothing
// here guesses "the last chat" or "whichever ChatGPT tab spoke last".
//
//   snapTab:<bridge>  {tabId}          the locked Snap tab      (storage.session)
//   snapByTab         {[tabId]: snap}  the snap waiting in it
//   orphanSnap        snap             its Snap window was closed; kept 30 min
//
// The first Send opens a NEW window and locks to its tab; later Sends reuse
// it. Right-click → "Make this my Snap window" on any ChatGPT page moves the
// lock, and any waiting snap, there. Every other ChatGPT tab stays inert.
//
// Why 2.1 went wrong: one shared "pendingSnap" that any ChatGPT tab could
// pick up, a per-tab copy written only AFTER the tab had been told to look
// (so a reused tab read its previous snap and needed a refresh), and the
// Snap card's reference ticks saved under whichever chat the worker guessed.

const SNAP_TTL = 30 * 60 * 1000;
const lockKey = (bridge) => `snapTab:${bridge}`;
const BOUNDS_KEY = "djpbSnapWindowBounds";
const freshSnap = (s) => Boolean(s && s.id && Date.now() - (s.createdAt || 0) <= SNAP_TTL);

/** Bridge state is read-modify-write in storage.session, and a Send, a tab
 *  closing and a "Make this my Snap window" can all arrive at once. One
 *  queue keeps them from overwriting each other. */
let bridgeQueue = Promise.resolve();
function bridgeSerial(fn) {
  const run = bridgeQueue.then(fn, fn);
  bridgeQueue = run.catch(() => {});
  return run;
}

function bridgeOfUrl(url) {
  let host = "";
  try { host = new URL(url).hostname; } catch { return null; }
  if (/(^|\.)grok\.com$/i.test(host)) return "grok";
  if (/^gemini\.google\.com$/i.test(host)) return "gemini";
  if (/(^|\.)(chatgpt\.com|chat\.openai\.com)$/i.test(host)) return "chatgpt";
  return null;
}

async function sessGet(key, fallback) {
  return (await chrome.storage.session.get({ [key]: fallback }))[key];
}

async function lockedTab(bridge) {
  const lock = await sessGet(lockKey(bridge), null);
  if (!lock?.tabId) return null;
  try { return await chrome.tabs.get(lock.tabId); }
  catch {
    await chrome.storage.session.remove(lockKey(bridge));
    return null;
  }
}

async function lockTo(bridge, tabId) {
  await chrome.storage.session.set({ [lockKey(bridge)]: { tabId } });
}

/** The bridge whose Snap window this tab is, or null. */
async function bridgeLockedTo(tabId) {
  if (tabId == null) return null;
  for (const b of Object.keys(BRIDGE_URLS)) {
    const lock = await sessGet(lockKey(b), null);
    if (lock?.tabId === tabId) return b;
  }
  return null;
}

async function snapInTab(tabId) {
  const map = await sessGet("snapByTab", {});
  return freshSnap(map[tabId]) ? map[tabId] : null;
}

async function putSnapInTab(tabId, snap) {
  const map = await sessGet("snapByTab", {});
  map[tabId] = snap;
  await chrome.storage.session.set({ snapByTab: map });
}

async function takeSnapFromTab(tabId, onlyId = null) {
  const map = await sessGet("snapByTab", {});
  const snap = map[tabId] || null;
  if (!snap || (onlyId && snap.id !== onlyId)) return null;
  delete map[tabId];
  await chrome.storage.session.set({ snapByTab: map });
  return snap;
}

async function castNamesFor(sessionId) {
  const rec = await sessionRecord(sessionId).catch(() => null);
  const chars = Object.values(rec?.sheet?.characters || {});
  return {
    charName: chars.find((c) => c.role === "bot")?.name || null,
    userName: chars.find((c) => c.role === "user")?.name || null,
  };
}

async function focusTab(tab) {
  try { await chrome.tabs.update(tab.id, { active: true }); } catch { /* gone */ }
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* no windows API */ }
}

/** A new window for the Snap tab, where the last one was. Browsers without
 *  separate windows (some phone browsers) get a tab instead, locked the same
 *  way. */
async function openSnapWindow(bridge) {
  const url = BRIDGE_URLS[bridge] || BRIDGE_URLS.chatgpt;
  if (chrome.windows?.create) {
    const { [BOUNDS_KEY]: b } = await chrome.storage.local.get({ [BOUNDS_KEY]: null });
    const attempts = [];
    if (b && [b.left, b.top, b.width, b.height].every(Number.isFinite) && b.width > 300 && b.height > 300) {
      attempts.push({ url, focused: true, type: "normal",
        left: Math.round(b.left), top: Math.round(b.top),
        width: Math.round(b.width), height: Math.round(b.height) });
    }
    attempts.push({ url, focused: true, type: "normal" });
    for (const opts of attempts) {
      try {
        const win = await chrome.windows.create(opts);
        const tab = win?.tabs?.[0] || (await chrome.tabs.query({ windowId: win.id }))[0];
        if (tab) return tab;
      } catch { /* saved spot is off-screen now — try without it */ }
    }
  }
  return chrome.tabs.create({ url, active: true });
}

/** Hand a snap (or just the lock, when snap is null) to the Snap tab in the
 *  message itself. The tab never has to ask back, so it can't read an older
 *  snap the way 2.1's reused tab did. A tab that doesn't answer predates the
 *  extension's last reload; it is reloaded once and picks the snap up on
 *  load. */
async function deliver(tabId, snap, { reloadIfDeaf = true } = {}) {
  const names = snap ? await castNamesFor(snap.sessionId) : {};
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: "snap:armed", snap, ...names });
    if (res?.ok) return true;
  } catch { /* nobody listening */ }
  if (reloadIfDeaf) { try { await chrome.tabs.reload(tabId); } catch { /* leave it */ } }
  return false;
}

/** Send to ChatGPT. */
async function armSnap(msg) {
  const sessionId = String(msg?.sessionId || "");
  if (!sessionId) throw new Error("No chat to snap from — reload the Dream Journey page");
  const cfg = await getConfig();
  const bridge = BRIDGE_URLS[cfg.bridge] ? cfg.bridge : "chatgpt";

  // The pictures ticked RIGHT NOW, frozen into the snap. Ticking something
  // in another window afterwards can't change what this one attaches.
  const refs = (await snapRefPicks(sessionId)).filter((p) => p.on)
    .map(({ id, kind, role, refId, name }) => ({ id, kind, role, refId, name }));

  const snap = {
    id: newId(),
    bridge,
    sessionId,
    prompt: String(msg.prompt || ""),
    returnUrl: msg.returnUrl || null,
    replyText: msg.replyText || "",
    conditions: msg.conditions && typeof msg.conditions === "object" ? { ...msg.conditions } : {},
    refs,
    createdAt: Date.now(),
  };

  return bridgeSerial(async () => {
    let tab = await lockedTab(bridge);
    let fresh = false;
    if (tab && bridgeOfUrl(tab.pendingUrl || tab.url || "") !== bridge) {
      // The Snap tab wandered off ChatGPT. Bring it back; it picks the
      // snap up when it loads.
      try { tab = await chrome.tabs.update(tab.id, { url: BRIDGE_URLS[bridge] }); fresh = true; }
      catch { tab = null; }
    }
    if (!tab) { tab = await openSnapWindow(bridge); fresh = true; }

    // Lock and file the snap BEFORE anything tells the tab to look.
    await lockTo(bridge, tab.id);
    await putSnapInTab(tab.id, snap);
    await chrome.storage.session.remove("orphanSnap");
    await focusTab(tab);
    if (!fresh) await deliver(tab.id, snap);
    return { snapId: snap.id, refs: refs.length, opened: fresh };
  });
}

/** capture.js on load. Only the Snap tab is told it is one. */
async function snapHello(tabId) {
  const bridge = await bridgeLockedTo(tabId);
  if (!bridge) return { snapTab: false };
  const snap = await snapInTab(tabId);
  return { snapTab: true, snap, ...(snap ? await castNamesFor(snap.sessionId) : {}) };
}

/** Right-click → "Make this my Snap window". Moves the lock here, and brings
 *  along whatever snap was waiting: in the old Snap tab, or in one that was
 *  closed less than half an hour ago. */
async function makeSnapWindow(tab) {
  const bridge = bridgeOfUrl(tab?.url || "");
  if (!tab?.id || !bridge) return { ok: false };
  return bridgeSerial(async () => {
    const prev = await lockedTab(bridge);
    let snap = null;
    if (prev && prev.id !== tab.id) {
      snap = await takeSnapFromTab(prev.id);
      try { await chrome.tabs.sendMessage(prev.id, { type: "snap:released" }); } catch { /* gone */ }
    }
    if (!freshSnap(snap)) snap = await snapInTab(tab.id);
    if (!snap) {
      const orphan = await sessGet("orphanSnap", null);
      if (freshSnap(orphan)) snap = orphan;
    }
    await lockTo(bridge, tab.id);
    await chrome.storage.session.remove("orphanSnap");
    if (snap) await putSnapInTab(tab.id, snap);
    await deliver(tab.id, snap || null);
    return { ok: true, moved: Boolean(snap) };
  });
}

/** The Snap card's "Snap window" button: go there, or reopen it — with the
 *  waiting snap, if the last one was closed with a snap still in it. */
async function goToSnapWindow() {
  const cfg = await getConfig();
  const bridge = BRIDGE_URLS[cfg.bridge] ? cfg.bridge : "chatgpt";
  return bridgeSerial(async () => {
    let tab = await lockedTab(bridge);
    if (tab) { await focusTab(tab); return { opened: false }; }
    tab = await openSnapWindow(bridge);
    await lockTo(bridge, tab.id);
    const orphan = await sessGet("orphanSnap", null);
    const restored = freshSnap(orphan);
    if (restored) await putSnapInTab(tab.id, orphan);
    await chrome.storage.session.remove("orphanSnap");
    return { opened: true, restored };
  });
}

async function snapWindowStatus() {
  const cfg = await getConfig();
  const bridge = BRIDGE_URLS[cfg.bridge] ? cfg.bridge : "chatgpt";
  const tab = await lockedTab(bridge);
  const waiting = tab ? Boolean(await snapInTab(tab.id)) : freshSnap(await sessGet("orphanSnap", null));
  return { open: Boolean(tab), waiting };
}

/** "Back to chat" from the Snap window. 2.1 navigated the Snap tab itself to
 *  the chat, which took it off ChatGPT; this finds the chat's own tab. */
async function backToChat(returnUrl, fromTab) {
  if (!/^https?:\/\//i.test(String(returnUrl || ""))) return { ok: false };
  const sid = String(returnUrl).match(/\/session\/([0-9a-f-]{36})/i)?.[1] || "";
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: ["*://dreamjourneyai.com/*", "*://www.dreamjourneyai.com/*"] }); }
  catch { /* no permission to look */ }
  const hit = tabs.find((t) => sid && (t.url || "").includes(sid)) || null;
  if (hit) { await focusTab(hit); return { ok: true, found: true }; }
  // Open it in some other window than the Snap window.
  let windowId;
  try {
    const wins = await chrome.windows.getAll({ windowTypes: ["normal"] });
    windowId = wins.find((w) => w.id !== fromTab?.windowId)?.id;
  } catch { /* no windows API */ }
  if (windowId != null) {
    const t = await chrome.tabs.create({ url: returnUrl, windowId, active: true });
    await focusTab(t);
  } else if (chrome.windows?.create) {
    await chrome.windows.create({ url: returnUrl, focused: true });
  } else {
    await chrome.tabs.create({ url: returnUrl, active: true });
  }
  return { ok: true, found: false };
}

// Closing the Snap window keeps its snap for half an hour: the next Snap
// window (Send, the Snap card's button, or the right-click) picks it up.
chrome.tabs.onRemoved.addListener((tabId) => {
  bridgeSerial(async () => {
    const bridge = await bridgeLockedTo(tabId);
    if (bridge) await chrome.storage.session.remove(lockKey(bridge));
    const snap = await takeSnapFromTab(tabId);
    if (freshSnap(snap)) await chrome.storage.session.set({ orphanSnap: snap });
  }).catch(() => {});
});

// Chrome occasionally swaps a tab for a prerendered one with a new id.
chrome.tabs.onReplaced?.addListener((addedId, removedId) => {
  bridgeSerial(async () => {
    const bridge = await bridgeLockedTo(removedId);
    if (!bridge) return;
    await lockTo(bridge, addedId);
    const snap = await takeSnapFromTab(removedId);
    if (snap) await putSnapInTab(addedId, snap);
  }).catch(() => {});
});

// Remember where the Snap window sits, so a new one opens in the same spot.
chrome.windows?.onBoundsChanged?.addListener(async (win) => {
  try {
    if (win.state && win.state !== "normal") return;
    for (const b of Object.keys(BRIDGE_URLS)) {
      const lock = await sessGet(lockKey(b), null);
      if (!lock?.tabId) continue;
      const tab = await chrome.tabs.get(lock.tabId).catch(() => null);
      if (tab?.windowId !== win.id) continue;
      await chrome.storage.local.set({ [BOUNDS_KEY]:
        { left: win.left, top: win.top, width: win.width, height: win.height } });
      return;
    }
  } catch { /* next move saves it */ }
});

/** Save a picture from the Snap window into the snap's own chat, with that
 *  snap's prompt and note, and make it the Snapscape. Only that snap is
 *  used up. */
async function saveSnap({ dataUrl, snapId, sessionId, caption, tabId, setScape }) {
  let snap = null;
  if (tabId != null) {
    const s = await snapInTab(tabId);
    if (s && (!snapId || s.id === snapId)) snap = s;
  }
  const target = snap?.sessionId || sessionId || "unfiled";

  let note = caption || snap?.replyText || "";
  if (!note && target !== "unfiled") {
    const rec = await sessionRecord(target);
    note = SceneLocator.stripThinking(rec?.lastReply || "").trim();
    if (note) note = Drafter.tidyProse(PromptCondenser.stripInstructions(note, 4000));
  }

  const id = await dbOps.add({
    sessionId: target,
    dataUrl,
    meta: {
      source: "captured",
      caption: note || snap?.prompt || "",
      prompt: snap?.prompt || "",
      conditions: snap?.conditions || {},
    },
  });
  if (snap && tabId != null) {
    await bridgeSerial(() => takeSnapFromTab(tabId, snap.id)).catch(() => {});
  }

  // setScape (the Snap window's save buttons): this photo becomes the chat's
  // Snapscape in the same step. In follow mode the newest photo already is
  // the Snapscape; pinned or switched off for this chat, it is pinned to this
  // one. prevBackdrop lets Undo put things back exactly.
  let follow = true;
  let scapeSet = false;
  let prevBackdrop;
  if (target !== "unfiled") {
    const scape = await dbOps.scapeInfo({ sessionId: target }).catch(() => null);
    follow = !scape || scape.mode === "follow";
    if (setScape) {
      if (!follow) {
        prevBackdrop = scape.mode === "none" ? "none" : (scape.id || null);
        await dbOps.setBackdrop({ sessionId: target, id });
      }
      scapeSet = true;
    }
  }
  const { djpbBackdropOn } = await chrome.storage.local.get({ djpbBackdropOn: true });

  return {
    id, sessionId: target, follow, scapeSet,
    prevBackdrop: prevBackdrop === undefined ? undefined : prevBackdrop,
    backdropOn: djpbBackdropOn !== false,
    returnUrl: snap?.returnUrl || null,
  };
}

/** Undo for an auto-save: take the photo out again and, if the save had
 *  pinned it as the Snapscape, put back what was pinned before. */
async function undoSave({ id, sessionId, prevBackdrop }) {
  if (id == null) throw new Error("Nothing to undo");
  const rec = await req((await store(IMAGES, "readonly")).get(id)).catch(() => null);
  if (!rec) return { undone: false };
  await req((await store(IMAGES, "readwrite")).delete(id));
  if (prevBackdrop !== undefined && sessionId && sessionId !== "unfiled") {
    const info = await dbOps.scapeInfo({ sessionId }).catch(() => null);
    if (info?.mode === "pinned" && String(info.id) === String(id)) {
      await dbOps.setBackdrop({ sessionId, id: prevBackdrop });
    }
  }
  return { undone: true };
}

// ---------- references for a snap ----------

async function snapRefSources(sessionId) {
  const rec = await sessionRecord(sessionId).catch(() => null);
  const out = [];
  for (const role of ["bot", "user"]) {
    const c = Object.values(rec?.sheet?.characters || {}).find((x) => x.role === role && x.portrait);
    if (c) out.push({
      id: `portrait:${role}`, kind: "portrait", role, name: c.name,
      thumbUrl: c.portrait,   // site-hosted; the chat page can render it directly
    });
  }
  // Every book reference gets its own chip, each carrying a thumbnail of its
  // actual photo. A photo picked from the album has no name worth printing —
  // captions are reply text and were cutting off mid-word — so those stay
  // numbered. A face picked from the CAST keeps its name.
  const AUTO_LABEL = /^(?:book ref(?: \d+)?|reference|character)$/i;
  const refs = await loadRefs(sessionId);
  refs.forEach((r, i) => {
    const named = String(r.label || "").trim();
    out.push({
      id: `book:${r.id}`, kind: "book", refId: r.id, index: i,
      name: named && !AUTO_LABEL.test(named)
        ? named.slice(0, 24)
        : (refs.length > 1 ? `Book ref ${i + 1}` : "Book ref"),
      thumb: r.thumb || null,
    });
  });
  return out;
}

const refPickKey = (sessionId) => `djpbSnapRefPick:${sessionId}`;

/** Each source with its tick. Portraits default on, album photos off.
 *  Ticks saved by 2.1 were keyed by position (book:0, book:1…); they are
 *  moved onto the photos' ids the first time they're read. */
async function snapRefPicks(sessionId) {
  const sources = await snapRefSources(sessionId);
  const key = refPickKey(sessionId);
  let saved = (await chrome.storage.local.get({ [key]: null }))[key];
  if (saved && typeof saved === "object") {
    let moved = false;
    for (const k of Object.keys(saved)) {
      const m = /^book:(\d+)$/.exec(k);
      if (!m) continue;
      const src = sources.find((s) => s.kind === "book" && s.index === Number(m[1]));
      if (src && !(src.id in saved)) saved[src.id] = saved[k];
      delete saved[k];
      moved = true;
    }
    if (moved) await chrome.storage.local.set({ [key]: saved });
  } else {
    saved = null;
  }
  return sources.map((src) => ({
    ...src,
    on: saved && src.id in saved ? saved[src.id] === true : src.kind === "portrait",
  }));
}

async function setRefPick(sessionId, id, on) {
  if (!sessionId || !id) throw new Error("No chat given");
  const key = refPickKey(sessionId);
  const saved = (await chrome.storage.local.get({ [key]: null }))[key] || {};
  saved[id] = on === true;
  await chrome.storage.local.set({ [key]: saved });
}

/** One reference's picture. Album photos are found by id (or, for anything
 *  older, by position). */
async function snapRefDataUrl(sessionId, src) {
  if (src.kind === "portrait") {
    const rec = await sessionRecord(sessionId);
    const c = Object.values(rec?.sheet?.characters || {})
      .find((x) => x.role === src.role && x.portrait);
    if (!c) return null;
    return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
  }
  const refs = await loadRefs(sessionId);
  const hit = src.refId ? refs.find((r) => r.id === src.refId)
    : (/^book:/.test(src.id || "") ? refs.find((r) => `book:${r.id}` === src.id) : null)
      || refs[src.index];
  if (!hit || !isBlob(hit.blob)) return null;
  return { dataUrl: await blobToDataUrl(hit.blob), name: hit.label || "Book photo" };
}

// ======================= right-click capture =======================

(async () => {
  try {
    if (navigator.storage?.persist && !(await navigator.storage.persisted())) {
      const ok = await navigator.storage.persist();
      console.info("[SnapScapes] persistent storage:", ok ? "granted" : "not granted");
    }
  } catch { /* storage fallback */ }
})();

// ======================= the toolbar icon =======================

/** Clicking the extension's icon opens the album — the one thing people
 *  want to reach without snapping something first. On a Dreamjourney chat
 *  it opens in-page, over the conversation, so the reader keeps their
 *  place; anywhere else (or if the page has no listener yet) it opens the
 *  shelf in a tab, reusing the one already open rather than stacking up. */
const DJ_APP = /^https?:\/\/(www\.)?dreamjourneyai\.com\/app\//i;
const ALBUM_TAB_KEY = "albumTabId";

chrome.action.onClicked.addListener(async (tab) => {
  const sessionId = (tab?.url || "").match(/\/app\/session\/([0-9a-f-]{36})/i)?.[1] || null;

  if (tab?.id && DJ_APP.test(tab.url || "")) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "album:open", sessionId });
      return;
    } catch { /* no content script here yet — fall through to a tab */ }
  }
  await openAlbumTab(sessionId);
});

async function openAlbumTab(sessionId) {
  const url = chrome.runtime.getURL("browse.html") +
    (sessionId ? `?session=${encodeURIComponent(sessionId)}` : "");
  const { [ALBUM_TAB_KEY]: known } = await chrome.storage.session.get({ [ALBUM_TAB_KEY]: null });
  if (known) {
    try {
      await chrome.tabs.update(known, { active: true, url });
      const t = await chrome.tabs.get(known);
      try { await chrome.windows.update(t.windowId, { focused: true }); } catch { /* focus */ }
      return;
    } catch { /* it was closed */ }
  }
  const created = await chrome.tabs.create({ url });
  await chrome.storage.session.set({ [ALBUM_TAB_KEY]: created.id });
}

// The only SnapScapes things on a ChatGPT page that isn't the Snap window
// live in the browser's own right-click menu, so nothing shows on the page.
const SNAP_HERE_PATTERNS = [
  "*://chatgpt.com/*", "*://chat.openai.com/*", "*://grok.com/*", "*://gemini.google.com/*",
];

function buildMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "djpb-save-image",
      title: "Save image to photobook",
      contexts: ["image"],
    });
    chrome.contextMenus.create({
      id: "djpb-snap-here",
      title: "Make this my Snap window",
      contexts: ["page", "frame", "selection", "link", "editable", "image"],
      documentUrlPatterns: SNAP_HERE_PATTERNS,
    });
  });
}
chrome.runtime.onInstalled.addListener(buildMenus);
chrome.runtime.onStartup?.addListener(buildMenus);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "djpb-snap-here") {
    try { await makeSnapWindow(tab); }
    catch (err) { console.warn("[SnapScapes] Couldn't move the Snap window:", err.message); }
    return;
  }
  if (info.menuItemId !== "djpb-save-image" || !info.srcUrl) return;
  try {
    const dataUrl = info.srcUrl.startsWith("data:")
      ? info.srcUrl
      : await fetchAsDataUrl(info.srcUrl);
    // In the Snap window, file it with the waiting snap's chat (and leave
    // the snap waiting). Anywhere else it goes to Loose photos, not a guess.
    const snap = tab?.id != null && (await bridgeLockedTo(tab.id)) ? await snapInTab(tab.id) : null;
    await dbOps.add({
      sessionId: snap?.sessionId || "unfiled",
      dataUrl,
      meta: { source: "captured", caption: snap?.replyText || "", prompt: snap?.prompt || "",
              conditions: snap?.conditions || {} },
    });
  } catch (err) {
    console.warn("[SnapScapes] Right-click save failed:", err.message);
  }
});

// ======================= helpers =======================

async function fetchAsDataUrl(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return blobToDataUrl(await res.blob());
}

function normalizeBase(endpoint) {
  return String(endpoint)
    .replace(/\/+$/, "")
    .replace(/\/v1\/images\/(generations|edits)$/i, "")
    .replace(/\/sdapi\/v1\/(txt2img|img2img)$/i, "")
    .replace(/\/v1$/i, "")
    .replace(/\/+$/, "");
}

function stripDataUrl(dataUrl) {
  const i = dataUrl.indexOf(",");
  return i >= 0 ? dataUrl.slice(i + 1) : dataUrl;
}

function clamp(n, lo, hi) {
  return Math.min(hi, Math.max(lo, n));
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}