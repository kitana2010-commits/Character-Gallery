// polish.js — Claude writes the image prompt.
//
// Loaded by the service worker (importScripts) after draft.js.
//
// The built-in drafter still runs first and its prompt appears instantly.
// When "Claude writes the prompts" is on (Options → For tinkerers), the Snap
// card then asks for this pass and swaps Claude's moments in when they land.
//
// Claude gets the same material the drafter gathered — the reply, the bot's
// thinking, the player's last message, a little history, the cast with their
// appearances, and what the scene reader already knows — and returns up to
// three moments as JSON. toDrafts() turns each into the same sections the
// built-in prompt uses (Characters / Scene / Location / Lighting / Style), so
// the Snap card's appearance toggle and pinned-location edits keep working.
//
// THE INSTRUCTION BELOW IS THE THING TO TUNE. If pictures keep missing
// something, the fix usually belongs in RULES.

const PromptPolish = (() => {
  const MODELS = {
    "claude-haiku-5-5": "Haiku 5.5",
    "claude-sonnet-5-5": "Sonnet 5.5",
    "claude-opus-5-5": "Opus 5.5",
  };
  const DEFAULT_MODEL = "claude-sonnet-5-5";

  const INSTRUCTION = `You turn a moment from an ongoing roleplay story into a prompt for an image model. The picture will be kept in the reader's photo album and shown behind the chat, so it has to look like THIS moment of THEIR story, not a generic scene.

You will get, in tags:
- <characters>: who exists in this story and what they look like. One of them may be the player's own character.
- <earlier>: the previous replies, oldest first, for context only.
- <player>: what the player just did or said. It often states the action the reply responds to.
- <reply>: the newest reply. The picture comes from here.
- <notes>: the story model's private planning for that reply. Useful for who is present and where, but the reply wins where they disagree.
- <known>: what an automatic reader already worked out (location, time, weather). Treat it as a hint.

Pick up to three moments from <reply>. Put the best one first: the beat the reply builds toward, or its emotional peak. Each moment is ONE frozen instant a camera could catch. Make them different beats, not the same beat reworded. If the reply only really has one picture in it, return one.

For each moment return:
- label: 2 to 5 words naming the beat.
- characters: only the people visible in the frame, at most three. Use their exact names from <characters>. "look" is what is visibly true of them RIGHT NOW: clothing, hair, injuries, what they hold, wet, dirty, dressed up. For someone <characters> doesn't describe, give their appearance from the story in a few words. If nothing specific is known, leave "look" empty.
- scene: two to four sentences of plain, present-tense description. Who is where, doing what, and how: posture, hands, facial expression, where each person is looking, how close they are and where they stand relative to each other, and the one or two props or details that make the moment recognisable.
- framing: shot type and angle that best tells the moment, e.g. "medium two-shot at eye level", "close-up on her face, slightly low angle", "wide shot from the doorway".
- location: where this is, specific to the story (a named place if it has one) plus the visible setting.
- lighting: the light source, its direction and colour, and the time of day.
- mood: a few words.

Rules:
- The player's character is a person IN the picture, seen from outside like everyone else. Never write "you" or "your", and never describe the scene from their eyes.
- Describe only what a camera would see. No dialogue, thoughts, memories, backstory or sounds. No text, signs or lettering in the image.
- Never add a person, creature, object or place the story doesn't support. Where the story is silent (the background, the weather), choose details that fit the location instead of leaving gaps.
- Say what IS there, not what isn't: "an empty street" rather than "no people".
- Keep the people consistent with <characters>: same hair, eyes, build, wings, scars.
- If the moment is sexually explicit, picture the closest tasteful instant instead: an embrace, a look, the moment before, bodies covered. If it is gory, show the tension and aftermath rather than the wound. Image services refuse explicit pictures, so an explicit prompt produces nothing.
- Do not mention art style, medium or quality; the reader's house style is added after you.`;

  const SCHEMA = {
    type: "object",
    properties: {
      moments: {
        type: "array",
        items: {
          type: "object",
          properties: {
            label: { type: "string" },
            characters: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  look: { type: "string" },
                },
                required: ["name", "look"],
                additionalProperties: false,
              },
            },
            scene: { type: "string" },
            framing: { type: "string" },
            location: { type: "string" },
            lighting: { type: "string" },
            mood: { type: "string" },
          },
          required: ["label", "characters", "scene", "framing", "location", "lighting", "mood"],
          additionalProperties: false,
        },
      },
    },
    required: ["moments"],
    additionalProperties: false,
  };

  const clip = (s, n) => {
    const t = String(s || "").trim();
    return t.length <= n ? t : t.slice(0, n).replace(/\s\S*$/, "") + " …";
  };

  /** The user turn: everything the drafter gathered, in labelled tags. */
  function userMessage(ctx) {
    const parts = [];
    const people = (ctx.characters || []).map((c) => {
      const who = c.role === "user" ? " (the player's character)" : c.role === "bot" ? " (main character)" : "";
      return `- ${c.name}${who}: ${clip(c.appearance, 600) || "appearance not given"}`;
    });
    parts.push(`<characters>\n${people.join("\n") || "(none known yet)"}\n</characters>`);

    const earlier = (ctx.history || []).slice(0, 2).reverse()
      .map((h, i) => `[${i + 1}] ${clip(h, 1500)}`);
    if (earlier.length) parts.push(`<earlier>\n${earlier.join("\n\n")}\n</earlier>`);
    if (ctx.player) parts.push(`<player>\n${clip(ctx.player, 1200)}\n</player>`);
    parts.push(`<reply>\n${clip(ctx.prose, 7000)}\n</reply>`);
    if (ctx.notes) parts.push(`<notes>\n${clip(ctx.notes, 2500)}\n</notes>`);

    const known = [];
    if (ctx.scene?.where) known.push(`location: ${ctx.scene.where}`);
    if (ctx.scene?.time) known.push(`time: ${ctx.scene.time}`);
    if (ctx.scene?.weather && ctx.scene.weather !== "clear") known.push(`weather: ${ctx.scene.weather}`);
    if (known.length) parts.push(`<known>\n${known.join("\n")}\n</known>`);
    return parts.join("\n\n");
  }

  /** One API call. Throws a short, human-readable error on any failure. */
  /** The built-in instruction, plus the reader's own (Options → For
   *  tinkerers → Your instructions for Claude). The built-in rules stay in
   *  charge, so a preference can't switch off, say, "no text in the image". */
  function systemFor(notes) {
    const extra = String(notes || "").trim();
    if (!extra) return INSTRUCTION;
    return `${INSTRUCTION}\n\nThe reader's own preferences. Follow them unless they conflict with the rules above:\n${extra}`;
  }

  async function write(ctx, { key, model, notes }) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 60000);
    let res;
    try {
      res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal: controller.signal,
        headers: {
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: MODELS[model] ? model : DEFAULT_MODEL,
          max_tokens: 2000,
          system: systemFor(notes),
          messages: [{ role: "user", content: userMessage(ctx) }],
          output_config: { format: { type: "json_schema", schema: SCHEMA } },
        }),
      });
    } catch (err) {
      throw new Error(err?.name === "AbortError" ? "Claude took too long" : "couldn't reach Claude");
    } finally {
      clearTimeout(timer);
    }

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      if (res.status === 401) throw new Error("Claude rejected the API key — check it in ⚙");
      if (res.status === 429) throw new Error("Claude is rate-limiting — try again in a moment");
      if (res.status === 529 || res.status >= 500) throw new Error("Claude is busy right now");
      if (/credit|billing/i.test(body)) throw new Error("your Claude account is out of credit");
      throw new Error(`Claude returned ${res.status}${body ? `: ${body.slice(0, 120)}` : ""}`);
    }
    const data = await res.json();
    if (data.stop_reason === "refusal") throw new Error("Claude declined to describe this scene");
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
    let parsed;
    try { parsed = JSON.parse(text); } catch { throw new Error("Claude's answer couldn't be read"); }
    const moments = (parsed.moments || []).filter((m) => m && String(m.scene || "").trim()).slice(0, 3);
    if (!moments.length) throw new Error("Claude didn't find a moment to draw");
    return { moments, model: MODELS[model] || MODELS[DEFAULT_MODEL], usage: data.usage || null };
  }

  /** Claude's moments → the Snap card's drafts, in the built-in sections. */
  function toDrafts(moments, ctx, style) {
    const byName = new Map((ctx.characters || []).map((c) => [String(c.name).toLowerCase(), c]));
    const dot = (s) => {
      const t = String(s || "").trim();
      return !t || /[.!?…]$/.test(t) ? t : t + ".";
    };
    return moments.map((m) => {
      const lines = ["Create an image of this moment.", ""];
      const people = (m.characters || []).filter((p) => p?.name).slice(0, 3);
      // Two blocks on purpose. "Characters:" holds each person's standing
      // looks from the sheet; the Snap card drops it when reference portraits
      // carry the faces (the Appearance toggle). "In frame:" holds what is
      // true of them in THIS moment — clothes, wet hair, what they hold — and
      // always stays, because no portrait can show it.
      const sheetLooks = people
        .map((p) => ({ p, known: byName.get(String(p.name).toLowerCase()) }))
        .filter(({ known }) => known?.appearance);
      if (sheetLooks.length) {
        lines.push("Characters:");
        for (const { p, known } of sheetLooks) {
          lines.push(`- ${p.name} — ${Sheet.promptAppearance(known.appearance)}`);
        }
        lines.push("");
      }
      const nowLines = people
        .map((p) => ({ name: p.name, look: String(p.look || "").trim() }))
        .filter((p) => p.look);
      if (nowLines.length) {
        lines.push("In frame:");
        for (const p of nowLines) lines.push(`- ${p.name}: ${dot(p.look)}`);
        lines.push("");
      }
      lines.push(`Scene: ${String(m.scene).trim()}`, "");
      if (m.framing) lines.push(`Framing: ${String(m.framing).trim()}`, "");
      if (m.location) lines.push(`Location: ${String(m.location).trim()}`, "");
      if (m.lighting) lines.push(`Lighting: ${String(m.lighting).trim()}`, "");
      if (m.mood) lines.push(`Mood: ${String(m.mood).trim()}`, "");
      if (style) lines.push(`Style: ${style}`);
      return {
        label: String(m.label || "This moment").trim().slice(0, 60),
        prose: lines.join("\n").replace(/\n{3,}/g, "\n\n").trim(),
        negative: PromptCondenser.SD_NEGATIVE,
        byClaude: true,
      };
    });
  }

  return { write, toDrafts, userMessage, systemFor, MODELS, DEFAULT_MODEL, INSTRUCTION };
})();
