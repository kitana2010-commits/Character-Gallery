// content.js — Photobook panel for Dreamjourney session pages.
(() => {
  // =========================================================================
  // SECTION 1: MESSAGING & EXTENSION CONTEXT
  // =========================================================================
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== "djpb:payload") return;

    chrome.runtime.sendMessage({
      type: "payload:store",
      payload: data.payload,
      lastReply: data.lastReply || "",
      lastUserMsg: data.lastUserMsg || "",
    }).catch(() => {});
  });

  const SESSION_RE = /\/app\/session\/([0-9a-f-]{36})/i;

  const alive = () => {
    try { return Boolean(chrome.runtime?.id); } catch { return false; }
  };

  let toldUser = false;
  let watchTimer = null;

  function goneStale() {
    if (toldUser) return;
    toldUser = true;
    console.info("[Photobook] The extension was reloaded — refresh this page to reconnect.");
    if (watchTimer) clearInterval(watchTimer);
  }

  async function ask(message) {
    if (!alive()) { goneStale(); return null; }
    try {
      return await chrome.runtime.sendMessage(message);
    } catch (err) {
      if (String(err?.message || "").includes("context invalidated")) goneStale();
      else throw err;
      return null;
    }
  }

  // =========================================================================
  // SECTION 2: SPA NAVIGATION & LIFECYCLE
  // =========================================================================
  let currentSession = null;
  let root = null;
  let keydownHandler = null;

  const sessionFromUrl = () => {
    const m = location.pathname.match(SESSION_RE);
    return m ? m[1] : null;
  };

  function watchUrl() {
    let lastHref = location.href;
    const check = () => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        onNavigate();
      }
    };
    watchTimer = setInterval(() => {
      if (!alive()) return goneStale();
      check();
    }, 500);
    addEventListener("popstate", check);
  }

  function onNavigate() {
    const session = sessionFromUrl();
    if (session === currentSession) return;
    currentSession = session;
    if (!session) {
      destroyUi();
      return;
    }
    ensureUi();
    closeEverything();
    renderReferenceBar();
    if (alive()) chrome.storage.local.set({ lastSession: session }).catch(() => {});
  }

  function destroyUi() {
    if (keydownHandler) {
      document.removeEventListener("keydown", keydownHandler);
      keydownHandler = null;
    }
    closeCaptionEditor();
    pickMode = false;
    if (root) {
      root.remove();
      root = null;
    }
  }

  // =========================================================================
  // SECTION 3: UI CONSTRUCTION & EVENT BINDING
  // =========================================================================
  const $ = (sel) => (root ? root.querySelector(sel) : null);
  const panel = () => $("#djpb-panel");
  const isOpen = (el) => Boolean(el && el.classList.contains("open"));
  const openEl = (el) => el && el.classList.add("open");
  const closeEl = (el) => el && el.classList.remove("open");

  function ensureUi() {
    if (root) return;
    root = document.createElement("div");
    root.id = "djpb-root";
    root.innerHTML = `
      <button id="djpb-toggle" type="button" title="Open photobook">📖 Photobook</button>

      <aside id="djpb-panel" role="dialog" aria-label="Photobook">
        <header>
          <h2>Photobook</h2>
          <div class="djpb-headbtns">
            <button class="djpb-btn djpb-small" id="djpb-albums" type="button" title="Open your albums">📚 Albums</button>
            <button class="djpb-btn djpb-small" id="djpb-settings" type="button" title="Settings">⚙</button>
            <button id="djpb-close" type="button" title="Close (Esc)">✕</button>
          </div>
        </header>

        <div id="djpb-toolbar">
          <label class="djpb-btn" for="djpb-file">Upload</label>
          <input type="file" id="djpb-file" accept="image/*" multiple>
          <button class="djpb-btn" id="djpb-gen-toggle" type="button">Generate</button>
          <button class="djpb-btn" id="djpb-remove-toggle" type="button">Remove</button>
        </div>

        <div id="djpb-refbar">
          <div class="djpb-refhead">
            <span class="djpb-ref-label">References (<span id="djpb-refcount">0</span>/4):</span>
            <button class="djpb-btn djpb-small" id="djpb-ref-char" type="button"
              title="Add the character's profile picture">Char pfp</button>
            <button class="djpb-btn djpb-small" id="djpb-ref-persona" type="button"
              title="Add your persona's profile picture">Persona pfp</button>
            <button class="djpb-btn djpb-small" id="djpb-ref-pick" type="button"
              title="Add an image from the gallery below">Pick from book</button>
          </div>
          <div id="djpb-refstrip"></div>
          <div id="djpb-ref-hint"></div>
        </div>

        <form id="djpb-genform">
          <textarea id="djpb-prompt" rows="3"
            placeholder="Describe the scene to generate…"></textarea>
          <label id="djpb-useref-row">
            <input type="checkbox" id="djpb-useref">
            Use references
            <span id="djpb-strength-wrap">
              — strength
              <input type="range" id="djpb-strength" min="20" max="85" value="60">
              <span id="djpb-strength-val">0.60</span>
            </span>
          </label>
          <div class="djpb-row">
            <button type="submit" class="djpb-btn djpb-primary">Create image</button>
            <button type="button" class="djpb-btn" id="djpb-gen-cancel">Cancel</button>
            <span id="djpb-genstatus" role="status"></span>
          </div>
        </form>

        <div id="djpb-gallery"></div>
      </aside>

      <div id="djpb-lightbox">
        <button id="djpb-lb-prev" type="button" title="Previous">‹</button>
        <figure id="djpb-lb-fig">
          <img id="djpb-lb-img" alt="Photobook image">
          <figcaption id="djpb-lb-cap"></figcaption>
        </figure>
        <button id="djpb-lb-next" type="button" title="Next">›</button>
        <button id="djpb-lb-close" type="button" title="Close (Esc)">✕</button>
      </div>`;
    document.body.appendChild(root);
    wireEvents();
  }

  function closeEverything() {
    if (!root) return;
    closeCaptionEditor();
    closeEl($("#djpb-lightbox"));
    closeEl($("#djpb-genform"));
    exitRemoveMode();
    exitPickMode();
    closeEl(panel());
  }

  function wireEvents() {
    $("#djpb-toggle").addEventListener("click", () => {
      if (isOpen(panel())) {
        closeEverything();
      } else {
        openEl(panel());
        renderReferenceBar();
        renderGallery();
      }
    });
    $("#djpb-close").addEventListener("click", closeEverything);
    $("#djpb-settings").addEventListener("click", () => ask({ type: "options:open" }));
    $("#djpb-albums").addEventListener("click", () => {
      if (typeof window.djpbOpenAlbum === "function") window.djpbOpenAlbum(currentSession);
      else ask({ type: "albums:open", sessionId: currentSession });
    });

    // Stored reference so destroyUi() can unbind it cleanly
    keydownHandler = (e) => {
      if (!root) return;
      if (e.key !== "Escape") {
        if (isOpen($("#djpb-lightbox")) && !captionEditor) {
          if (e.key === "ArrowLeft") stepLightbox(-1);
          if (e.key === "ArrowRight") stepLightbox(1);
        }
        return;
      }
      if (captionEditor) return closeCaptionEditor();
      if (isOpen($("#djpb-lightbox"))) return closeEl($("#djpb-lightbox"));
      if (isOpen($("#djpb-genform"))) return closeEl($("#djpb-genform"));
      if (pickMode) return exitPickMode();
      if ($("#djpb-gallery")?.classList.contains("removing")) return exitRemoveMode();
      if (isOpen(panel())) closeEverything();
    };
    document.addEventListener("keydown", keydownHandler);

    $("#djpb-file").addEventListener("change", async (e) => {
      for (const file of e.target.files) {
        const caption = file.name.replace(/\.[^.]+$/, "");
        await PhotobookDB.add(currentSession, await blobToDataUrl(file), {
          source: "upload",
          caption,
        });
      }
      e.target.value = "";
      renderGallery();
    });

    $("#djpb-ref-char").addEventListener("click", () => addPortraitRef("bot"));
    $("#djpb-ref-persona").addEventListener("click", () => addPortraitRef("user"));

    $("#djpb-ref-pick").addEventListener("click", () => {
      if (pickMode) return exitPickMode();
      enterPickMode();
    });

    $("#djpb-gen-toggle").addEventListener("click", () => {
      const form = $("#djpb-genform");
      if (isOpen(form)) {
        closeEl(form);
      } else {
        openEl(form);
        $("#djpb-prompt").focus();
      }
    });
    $("#djpb-gen-cancel").addEventListener("click", () => closeEl($("#djpb-genform")));

    $("#djpb-strength").addEventListener("input", (e) => {
      $("#djpb-strength-val").textContent = (e.target.value / 100).toFixed(2);
    });

    $("#djpb-genform").addEventListener("submit", async (e) => {
      e.preventDefault();
      const prompt = $("#djpb-prompt").value.trim();
      if (!prompt) return;
      const status = $("#djpb-genstatus");

      let references = [];
      if ($("#djpb-useref").checked) {
        const list = await PhotobookDB.listReferences(currentSession);
        references = list.map((r) => r.dataUrl);
        if (!references.length) {
          status.textContent = "No references added — use the References bar above.";
          setTimeout(() => (status.textContent = ""), 5000);
          return;
        }
      }

      status.textContent = "Generating…";
      try {
        const res = await ask({
          type: "generate",
          prompt,
          references,
          strength: Number($("#djpb-strength").value) / 100,
        });
        if (!res || !res.ok) throw new Error(res?.error || "Unknown error");
        await PhotobookDB.add(currentSession, res.dataUrl, {
          source: "generated",
          prompt,
          caption: prompt,
        });
        status.textContent = "Done ✓";
        renderGallery();
      } catch (err) {
        status.textContent = `Failed: ${err.message}`;
      }
      setTimeout(() => (status.textContent = ""), 6000);
    });

    $("#djpb-remove-toggle").addEventListener("click", () => {
      exitPickMode();
      const removing = $("#djpb-gallery").classList.toggle("removing");
      $("#djpb-remove-toggle").textContent = removing ? "Done" : "Remove";
    });

    $("#djpb-lb-close").addEventListener("click", () => closeEl($("#djpb-lightbox")));
    $("#djpb-lb-prev").addEventListener("click", () => stepLightbox(-1));
    $("#djpb-lb-next").addEventListener("click", () => stepLightbox(1));
    $("#djpb-lightbox").addEventListener("click", (e) => {
      if (e.target.id === "djpb-lightbox") closeEl($("#djpb-lightbox"));
    });
  }

  // =========================================================================
  // SECTION 4: REFERENCE BAR ENGINE
  // =========================================================================
  let pickMode = false;

  function enterPickMode() {
    exitRemoveMode();
    pickMode = true;
    $("#djpb-gallery")?.classList.add("picking");
    if ($("#djpb-ref-pick")) $("#djpb-ref-pick").textContent = "Cancel";
    flashHint("Click an image below to add it as a reference (Esc to cancel).", 0);
  }

  function exitPickMode() {
    if (!pickMode) return;
    pickMode = false;
    $("#djpb-gallery")?.classList.remove("picking");
    if ($("#djpb-ref-pick")) $("#djpb-ref-pick").textContent = "Pick from book";
    flashHint("", 0);
  }

  function exitRemoveMode() {
    const gallery = $("#djpb-gallery");
    if (!gallery) return;
    gallery.classList.remove("removing");
    if ($("#djpb-remove-toggle")) $("#djpb-remove-toggle").textContent = "Remove";
  }

  const MAX_REFS = 4;

  function flashHint(text, ms = 5000) {
    const hint = $("#djpb-ref-hint");
    if (!hint) return;
    hint.textContent = text;
    if (ms) setTimeout(() => (hint.textContent = ""), ms);
  }

  async function addPortraitRef(role) {
    try {
      const candidates = [];

      try {
        const portraits = await PhotobookDB.getPortraits(currentSession);
        const entry = portraits.find((p) => p.role === role);
        if (entry?.portrait) {
          const abs = absolutize(entry.portrait);
          if (abs) candidates.push({ url: abs, label: entry.name });
        }
      } catch { /* worker waking */ }

      const domUrls = findAvatarUrls();
      const fallbackLabel = role === "bot" ? "Character" : "Persona";
      if (role === "bot") {
        if (domUrls[0]) candidates.push({ url: domUrls[0], label: fallbackLabel });
      } else {
        for (const url of domUrls.slice(1)) {
          candidates.push({ url, label: fallbackLabel });
        }
      }

      if (!candidates.length) {
        flashHint(
          role === "user"
            ? "No persona picture found yet — open the side panel or send one chat message, then retry."
            : "Couldn't find the character picture — open the bot's side panel, or send a message first."
        );
        return;
      }

      const existing = await PhotobookDB.listReferences(currentSession);

      flashHint("Fetching picture…", 0);
      let lastErr = null;
      for (const c of candidates) {
        try {
          const res = await ask({ type: "fetchImage", url: c.url });
          if (!res || !res.ok) throw new Error(res?.error || "fetch failed");
          if (existing.some((r) => r.dataUrl === res.dataUrl)) {
            flashHint("That picture is already in the references.");
            return;
          }
          await PhotobookDB.addReference(
            currentSession,
            res.dataUrl,
            c.label || fallbackLabel
          );
          flashHint("");
          renderReferenceBar();
          return;
        } catch (err) {
          lastErr = err;
        }
      }
      throw lastErr || new Error("no candidate fetched");
    } catch (err) {
      flashHint(`Couldn't add it (${err.message}).`);
    }
  }

  function absolutize(url) {
    try {
      return new URL(url, location.href).href;
    } catch {
      return null;
    }
  }

  async function renderReferenceBar() {
    if (!root) return;
    let refs = [];
    try {
      refs = await PhotobookDB.listReferences(currentSession);
    } catch { /* worker waking */ }

    if ($("#djpb-refcount")) $("#djpb-refcount").textContent = String(refs.length);
    if ($("#djpb-useref")) $("#djpb-useref").checked = refs.length > 0;

    const atMax = refs.length >= MAX_REFS;
    for (const id of ["#djpb-ref-char", "#djpb-ref-persona", "#djpb-ref-pick"]) {
      if ($(id)) $(id).disabled = atMax && id !== "#djpb-ref-pick" ? true : atMax;
    }

    const strip = $("#djpb-refstrip");
    if (!strip) return;
    strip.innerHTML = "";
    if (!refs.length) {
      strip.innerHTML =
        '<span class="djpb-refempty">None yet — add the character, your persona, or a book image (up to 4).</span>';
      return;
    }
    refs.forEach((r) => {
      const cell = document.createElement("span");
      cell.className = "djpb-refcell";
      cell.title = r.label;
      const img = document.createElement("img");
      img.src = r.dataUrl;
      img.alt = r.label;
      const del = document.createElement("button");
      del.type = "button";
      del.className = "djpb-refdel";
      del.title = `Remove ${r.label}`;
      del.textContent = "✕";
      del.addEventListener("click", async () => {
        await PhotobookDB.removeReference(currentSession, r.index);
        renderReferenceBar();
      });
      cell.append(img, del);
      strip.appendChild(cell);
    });
  }

  function findAvatarUrls() {
    const byUrl = new Map();
    for (const img of document.querySelectorAll("img")) {
      if (root && root.contains(img)) continue;
      const src = img.currentSrc || img.src || "";
      if (!/imagedelivery\.net/i.test(src)) continue;
      const r = img.getBoundingClientRect();
      const area = r.width * r.height;
      if (area <= 0) continue;
      byUrl.set(src, Math.max(byUrl.get(src) || 0, area));
    }
    return [...byUrl.entries()]
      .sort((a, b) => b[1] - a[1])
      .map(([url]) => url);
  }

  // =========================================================================
  // SECTION 5: CAPTIONS, GALLERY & LIGHTBOX
  // =========================================================================
  let captionEditor = null;

  function openCaptionEditor(cell, item, capEl, imgEl) {
    closeCaptionEditor();
    const input = document.createElement("input");
    input.className = "djpb-capinput";
    input.type = "text";
    input.value = item.caption || "";
    input.placeholder = "Add a caption…";
    input.addEventListener("click", (e) => e.stopPropagation());
    input.addEventListener("keydown", async (e) => {
      e.stopPropagation();
      if (e.key === "Enter") {
        const caption = input.value.trim();
        try {
          await PhotobookDB.setCaption(item.id, caption);
          item.caption = caption;
          capEl.textContent = caption;
          imgEl.title = caption;
          cell.classList.toggle("has-caption", !!caption);
        } catch (err) {
          console.warn("[Photobook] Caption save failed:", err);
        }
        closeCaptionEditor();
      } else if (e.key === "Escape") {
        closeCaptionEditor();
      }
    });
    cell.appendChild(input);
    captionEditor = { input, cell };
    input.focus();
    input.select();
  }

  function closeCaptionEditor() {
    if (!captionEditor) return;
    captionEditor.input.remove();
    captionEditor = null;
  }

  let galleryCache = [];
  let lightboxIndex = 0;

  async function renderGallery() {
    const gallery = $("#djpb-gallery");
    if (!gallery) return;
    let records = [];
    try {
      records = await PhotobookDB.list(currentSession);
    } catch (err) {
      gallery.textContent = "";
      const note = document.createElement("p");
      note.className = "djpb-empty";
      note.textContent = `Couldn't load photos (${err.message}). Try reopening the panel.`;
      gallery.appendChild(note);
      return;
    }
    galleryCache = records;

    closeCaptionEditor();
    gallery.innerHTML = "";
    if (!galleryCache.length) {
      gallery.innerHTML =
        '<p class="djpb-empty">No images yet. Upload one or generate a scene to start this session\u2019s photobook.</p>';
      return;
    }
    galleryCache.forEach((g, i) => {
      const cell = document.createElement("figure");
      cell.className = "djpb-cell" + (g.caption ? " has-caption" : "");

      const img = document.createElement("img");
      img.src = g.dataUrl;
      img.loading = "lazy";
      img.alt = g.caption || "";
      img.title = g.caption || "";
      img.addEventListener("click", async () => {
        if (pickMode) {
          try {
            await PhotobookDB.addReference(currentSession, g.dataUrl, g.caption || "Book image");
          } catch (err) {
            flashHint(err.message);
          }
          exitPickMode();
          renderReferenceBar();
          return;
        }
        lightboxIndex = i;
        showLightbox();
      });

      const cap = document.createElement("figcaption");
      cap.className = "djpb-caption";
      cap.textContent = g.caption || "";

      const edit = document.createElement("button");
      edit.className = "djpb-editcap";
      edit.type = "button";
      edit.title = "Edit caption";
      edit.textContent = "✎";
      edit.addEventListener("click", (e) => {
        e.stopPropagation();
        openCaptionEditor(cell, g, cap, img);
      });

      const del = document.createElement("button");
      del.className = "djpb-delete";
      del.type = "button";
      del.title = "Remove image";
      del.textContent = "✕";
      del.addEventListener("click", async () => {
        await PhotobookDB.remove(g.id);
        renderGallery();
      });

      cell.append(img, cap, edit, del);
      gallery.appendChild(cell);
    });
  }

  function showLightbox() {
    const g = galleryCache[lightboxIndex];
    if (!g || !root) return;
    if ($("#djpb-lb-img")) $("#djpb-lb-img").src = g.dataUrl;
    if ($("#djpb-lb-cap")) $("#djpb-lb-cap").textContent = g.caption || "";
    openEl($("#djpb-lightbox"));
  }

  function stepLightbox(delta) {
    const n = galleryCache.length;
    if (!n || !root) return;
    lightboxIndex = (lightboxIndex + delta + n) % n;
    const g = galleryCache[lightboxIndex];
    if ($("#djpb-lb-img")) $("#djpb-lb-img").src = g.dataUrl;
    if ($("#djpb-lb-cap")) $("#djpb-lb-cap").textContent = g.caption || "";
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error("Couldn't read image"));
      r.readAsDataURL(blob);
    });
  }

  // =========================================================================
  // SECTION 6: BOOT
  // =========================================================================
  watchUrl();
  onNavigate();
})();