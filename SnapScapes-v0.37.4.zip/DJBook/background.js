// background.js — v0.5
//
// The service worker owns the photo store, the generation backends, and the
// prompt condenser. Message types:
//   {type:"db", op, args}                          → storage operations
//   {type:"condense", reply, sessionId}            → prose → prompt candidates
//   {type:"generate", prompt, negative, reference, strength}
//   {type:"fetchImage", url}                       → fetch any image as data URL
//   {type:"snap:arm", sessionId, prompt, returnUrl}→ prime the ChatGPT bridge
//   {type:"snap:peek"}                             → capture.js asks what's pending
//   {type:"snap:save", dataUrl, sessionId, caption}

let BOOT_ERROR = null;
try {
  importScripts("condense.js", "sheet.js");
} catch (err) {
  BOOT_ERROR = String(err?.message || err);
  console.error("[Photobook] startup failed — a helper script did not load:", err);
}

// ======================= storage =======================

const DB_NAME = "dj-photobook";
const DB_VERSION = 3;
const IMAGES = "images";
const SESSIONS = "sessions";

let dbPromise = null;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(IMAGES)) {
        const s = db.createObjectStore(IMAGES, { keyPath: "id", autoIncrement: true });
        s.createIndex("bySession", "sessionId", { unique: false });
      }
      if (!db.objectStoreNames.contains(SESSIONS)) {
        db.createObjectStore(SESSIONS, { keyPath: "sessionId" });
      }
    };
    r.onblocked = () =>
      reject(new Error("photobook database is blocked by another tab — close the album tab"));
    r.onsuccess = () => {
      const db = r.result;
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    r.onerror = () => reject(r.error);
  });
  dbPromise = dbPromise.catch((err) => { dbPromise = null; throw err; });
  return dbPromise;
}

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function store(name, mode) {
  const db = await openDb();
  return db.transaction(name, mode).objectStore(name);
}

async function dataUrlToBlob(dataUrl) {
  return (await fetch(dataUrl)).blob();
}

async function blobToDataUrl(blob) {
  const buf = await blob.arrayBuffer();
  return `data:${blob.type || "image/png"};base64,${arrayBufferToBase64(buf)}`;
}

const MAX_REFS = 4;

// A small JPEG of a reference, sized for the Snap card's chips (192px covers
// the hover preview at 1x and the 26px chip at any density). Generated once
// per reference and cached on the record, so chips open instantly after the
// first time. Falls back to the full image if OffscreenCanvas is unavailable.
const THUMB_PX = 192;

async function makeThumb(blob) {
  try {
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, THUMB_PX / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext("2d").drawImage(bmp, 0, 0, w, h);
    bmp.close?.();
    const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.75 });
    return blobToDataUrl(out);
  } catch {
    return blobToDataUrl(blob);   // tiny worst case: chip shows the full image
  }
}

/** Session record's references, with a `thumb` dataUrl on every entry.
 *  Backfills (and persists) thumbs for references saved before thumbs
 *  existed, so old chats get pictures on their chips too. */
async function refsWithThumbs(sessionId) {
  const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const refs = await refsOf(rec);
  let dirty = false;
  for (const r of refs) {
    if (!r.thumb && r.blob) {
      r.thumb = await makeThumb(r.blob);
      dirty = true;
    }
  }
  if (dirty && rec) {
    try {
      const rec2 = { ...rec, sessionId, references: refs };
      delete rec2.referenceBlob;
      await req((await store(SESSIONS, "readwrite")).put(rec2));
    } catch { /* cache miss next time; nothing lost */ }
  }
  return refs;
}

async function refsOf(rec) {
  if (!rec) return [];
  if (Array.isArray(rec.references)) return [...rec.references];
  if (rec.referenceBlob) return [{ blob: rec.referenceBlob, label: "Book ref" }];
  return [];
}

async function recordOut(rec) {
  return {
    id: rec.id,
    sessionId: rec.sessionId,
    caption: rec.caption || "",
    createdAt: rec.createdAt,
    source: rec.source || "",
    dataUrl: await blobToDataUrl(rec.blob),
  };
}

const dbOps = {
  async add({ sessionId, dataUrl, meta = {} }) {
    const blob = await dataUrlToBlob(dataUrl);
    const s = await store(IMAGES, "readwrite");
    return req(s.add({
      sessionId: sessionId || "unfiled",
      blob,
      caption: meta.caption || "",
      source: meta.source || "",
      prompt: meta.prompt || "",
      conditions: meta.conditions && typeof meta.conditions === "object"
        ? { ...meta.conditions }
        : undefined,
      createdAt: meta.createdAt || Date.now(),
    }));
  },

  async backdrop({ sessionId, knownId }) {
    if (!sessionId) return null;

    let target = null;
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const pinned = Boolean(rec?.backdropId) && rec.backdropId !== "none";
    if (rec?.backdropId === "none") return null;
    if (rec?.backdropId) {
      target = await req((await store(IMAGES, "readonly")).get(rec.backdropId)).catch(() => null);
    }
    if (!target) {
      const all = await req(
        (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId)));
      all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      target = all[all.length - 1] || null;
    }
    if (!target) return null;
    const conditions = target.conditions && typeof target.conditions === "object"
      ? { ...target.conditions }
      : {};
    const manualEffects = Array.isArray(target.manualEffects)
      ? [...target.manualEffects]
      : (target.manualEffects && typeof target.manualEffects === "object"
        ? {
            effects: Array.isArray(target.manualEffects.effects) ? [...target.manualEffects.effects] : [],
            intensity: target.manualEffects.intensity && typeof target.manualEffects.intensity === "object"
              ? { ...target.manualEffects.intensity }
              : {},
          }
        : null);
    if (knownId && String(target.id) === String(knownId)) {
      return { id: target.id, unchanged: true, conditions, manualEffects, pinned };
    }
    return {
      id: target.id,
      pinned,
      dataUrl: await blobToDataUrl(target.blob),
      conditions,
      manualEffects,
    };
  },

  async setEffects({ id, effects }) {
    const rec = await req((await store(IMAGES, "readonly")).get(id));
    if (!rec) throw new Error("Image not found");

    const allowed = new Set([
      "rain", "lightning", "snow", "fog",
      "embers", "fireflies", "petals", "lilacs",
      "vignette", "sunlight",
    ]);
    const clampIntensity = (value) => {
      const n = Number(value);
      if (!Number.isFinite(n)) return 3;
      return Math.max(1, Math.min(4, Math.round(n)));
    };

    if (effects === null || effects === undefined) {
      delete rec.manualEffects;
    } else if (Array.isArray(effects)) {
      rec.manualEffects = [...new Set(effects.filter((name) => allowed.has(name)))];
    } else if (effects && typeof effects === "object") {
      const names = [...new Set(
        (Array.isArray(effects.effects) ? effects.effects : []).filter((name) => allowed.has(name))
      )];
      const intensity = {};
      const source = effects.intensity && typeof effects.intensity === "object"
        ? effects.intensity
        : {};
      for (const name of names) intensity[name] = clampIntensity(source[name]);
      rec.manualEffects = { effects: names, intensity };
    } else {
      rec.manualEffects = [];
    }

    await req((await store(IMAGES, "readwrite")).put(rec));
    return {
      id: rec.id,
      conditions: rec.conditions && typeof rec.conditions === "object"
        ? { ...rec.conditions }
        : {},
      manualEffects: Array.isArray(rec.manualEffects)
        ? [...rec.manualEffects]
        : (rec.manualEffects && typeof rec.manualEffects === "object"
          ? {
              effects: Array.isArray(rec.manualEffects.effects) ? [...rec.manualEffects.effects] : [],
              intensity: rec.manualEffects.intensity && typeof rec.manualEffects.intensity === "object"
                ? { ...rec.manualEffects.intensity }
                : {},
            }
          : null),
    };
  },

  /** The Snapscape mode for a chat, without touching any image blobs:
   *  {mode:"follow"|"pinned"|"none", id, newestId}. "follow" is backdropId
   *  null/absent (the backdrop tracks the newest photo); "pinned" holds one;
   *  "none" is the explicit off state. newestId lets a UI pin "what is
   *  showing right now" when the user turns follow off. */
  async scapeInfo({ sessionId }) {
    if (!sessionId) return { mode: "follow", id: null, newestId: null };
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const all = await req(
      (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId))
    ).catch(() => []);
    all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    const newestId = all.length ? all[all.length - 1].id : null;
    if (rec?.backdropId === "none") return { mode: "none", id: null, newestId };
    if (rec?.backdropId) return { mode: "pinned", id: rec.backdropId, newestId };
    return { mode: "follow", id: null, newestId };
  },

  async setBackdrop({ sessionId, id }) {
    await dbOps.mergeSession({ sessionId, patch: { backdropId: id || null } });
    return { ok: true };
  },

  async list({ sessionId }) {
    const s = await store(IMAGES, "readonly");
    const recs = await req(s.index("bySession").getAll(IDBKeyRange.only(sessionId)));
    recs.sort((a, b) => a.createdAt - b.createdAt);
    return Promise.all(recs.map(recordOut));
  },

  async listAll() {
    const s = await store(IMAGES, "readonly");
    const recs = await req(s.getAll());
    recs.sort((a, b) => b.createdAt - a.createdAt);
    return Promise.all(recs.map(recordOut));
  },

  async remove({ id }) {
    const s = await store(IMAGES, "readwrite");
    return req(s.delete(id));
  },

  async setCaption({ id, caption }) {
    const rec = await req((await store(IMAGES, "readonly")).get(id));
    if (!rec) throw new Error("Image not found");
    rec.caption = caption;
    const s = await store(IMAGES, "readwrite");
    return req(s.put(rec));
  },

  async setReference({ sessionId, dataUrl }) {
    const blob = await dataUrlToBlob(dataUrl);
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const rec = { ...(prev || {}), sessionId, references: [{ blob, label: "Book ref" }] };
    delete rec.referenceBlob;
    const s = await store(SESSIONS, "readwrite");
    return req(s.put(rec));
  },

  async getReference({ sessionId }) {
    const refs = await refsOf(
      await req((await store(SESSIONS, "readonly")).get(sessionId))
    );
    return refs.length ? blobToDataUrl(refs[0].blob) : null;
  },

  async clearReference({ sessionId }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    if (!prev) return null;
    delete prev.referenceBlob;
    delete prev.references;
    const s = await store(SESSIONS, "readwrite");
    return req(s.put(prev));
  },

  async addReference({ sessionId, dataUrl, label }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const refs = await refsOf(prev);
    if (refs.length >= MAX_REFS) {
      throw new Error(`Reference limit is ${MAX_REFS} — remove one first.`);
    }
    const blob = await dataUrlToBlob(dataUrl);
    refs.push({
      blob,
      thumb: await makeThumb(blob),
      label: String(label || "reference").slice(0, 48),
    });
    const rec = { ...(prev || {}), sessionId, references: refs };
    delete rec.referenceBlob;
    const s = await store(SESSIONS, "readwrite");
    return req(s.put(rec));
  },

  async listReferences({ sessionId }) {
    const refs = await refsWithThumbs(sessionId);
    return Promise.all(
      refs.map(async (r, index) => ({
        index,
        // Auto-numbered labels are re-derived from position so they can't
        // drift after removals; hand-set labels pass through untouched.
        label: /^Book ref( \d+)?$/.test(r.label || "")
          ? `Book ref ${index + 1}`
          : (r.label || "reference"),
        dataUrl: await blobToDataUrl(r.blob),
        thumb: r.thumb || null,
      }))
    );
  },

  async removeReference({ sessionId, index }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    if (!prev) return null;
    const refs = await refsOf(prev);
    const at = Number(index);
    refs.splice(at, 1);
    const rec = { ...prev, sessionId, references: refs };
    delete rec.referenceBlob;
    const s = await store(SESSIONS, "readwrite");
    const put = await req(s.put(rec));

    // The saved picks are keyed book:0, book:1, … — shift everything above
    // the removed slot down one, or each remaining photo inherits the on/off
    // state of the photo that USED to sit at its index.
    try {
      const key = refPickKey(sessionId);
      const saved = (await chrome.storage.local.get({ [key]: null }))[key];
      if (saved && typeof saved === "object") {
        const next = {};
        for (const [k, v] of Object.entries(saved)) {
          const m = /^book:(\d+)$/.exec(k);
          if (!m) { next[k] = v; continue; }         // portrait keys stay put
          const i = Number(m[1]);
          if (i < at) next[k] = v;
          else if (i > at) next[`book:${i - 1}`] = v;
          // i === at: dropped with its photo
        }
        await chrome.storage.local.set({ [key]: next });
      }
    } catch { /* worst case: a chip defaults back to off */ }
    return put;
  },

  async getPortraits({ sessionId }) {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    return Object.values(rec?.sheet?.characters || {})
      .filter((c) => c.portrait)
      .map((c) => ({ name: c.name, role: c.role, portrait: c.portrait }));
  },

  async mergeSession({ sessionId, patch }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const s = await store(SESSIONS, "readwrite");
    return req(s.put({ ...(prev || {}), sessionId, ...patch }));
  },

  async setSheet({ sessionId, sheet }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const s = await store(SESSIONS, "readwrite");
    return req(s.put({ ...(prev || {}), sessionId, sheet }));
  },

  async getSheet({ sessionId }) {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    return rec?.sheet || { character: "", user: "", style: "" };
  },

  async listSessions() {
    const s = await store(IMAGES, "readonly");
    const recs = await req(s.getAll());
    const byId = new Map();
    for (const r of recs) {
      const cur = byId.get(r.sessionId) || { sessionId: r.sessionId, count: 0, latest: 0 };
      cur.count += 1;
      cur.latest = Math.max(cur.latest, r.createdAt || 0);
      byId.set(r.sessionId, cur);
    }
    return [...byId.values()].sort((a, b) => b.latest - a.latest);
  },
};

// ======================= config =======================

const DEFAULTS = {
  preset: "pollinations",
  endpoint: "",
  model: "",
  modelOpenRouter: "google/gemini-2.5-flash-image",
  width: 768,
  height: 768,
  steps: 25,
  condenser: "heuristic",
  condenserModelClaude: "claude-haiku-4-5-20251001",
  condenserModel: "gpt-5.4-nano",
  quality: "low",
  style: "stylized digital illustration, semi realistic anime inspired",
  bridge: "chatgpt",
};

(async () => {
  try {
    const { style } = await chrome.storage.sync.get({ style: null });
    if (style === "painterly digital art, cinematic composition") {
      await chrome.storage.sync.set({ style: DEFAULTS.style });
    }
  } catch { /* first run */ }
})();

const BRIDGE_URLS = {
  chatgpt: "https://chatgpt.com/",
  grok: "https://grok.com/",
  gemini: "https://gemini.google.com/",
};

async function getConfig() {
  const [synced, local] = await Promise.all([
    chrome.storage.sync.get(DEFAULTS),
    chrome.storage.local.get({ apiKey: "", apiKeyOpenRouter: "" }),
  ]);
  return {
    ...DEFAULTS,
    ...synced,
    apiKey: local.apiKey || "",
    apiKeyOpenRouter: local.apiKeyOpenRouter || "",
  };
}

// ======================= message router =======================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (p) => p
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  switch (msg?.type) {
    case "db": {
      const op = dbOps[msg.op];
      if (!op) {
        sendResponse({ ok: false, error: `Unknown db op "${msg.op}"` });
        return;
      }
      reply(op(msg.args || {}).then((result) => ({ result: result ?? null })));
      return true;
    }
    case "health":
      sendResponse({
        ok: true,
        boot: BOOT_ERROR,
        condenser: typeof PromptCondenser !== "undefined",
        sheet: typeof SheetBuilder !== "undefined",
        version: chrome.runtime.getManifest().version,
      });
      return true;
    case "config:summary":
      reply(configSummary());
      return true;
    case "options:open":
      reply((async () => { await chrome.runtime.openOptionsPage(); return {}; })());
      return true;
    case "albums:open":
      reply((async () => {
        const url = chrome.runtime.getURL("browse.html") +
          (msg.sessionId ? `?session=${encodeURIComponent(msg.sessionId)}` : "");
        await chrome.tabs.create({ url });
        return {};
      })());
      return true;
    case "payload:store":
      reply(storePayload(msg));
      return true;
    case "prompt:draft":
      reply(draftPrompt(msg));
      return true;
    case "albums:list":
      reply(listAlbums());
      return true;
    case "condense":
      reply(condenseReply(msg.reply, msg.sessionId));
      return true;
    case "generate":
      reply(generate(msg));
      return true;
    case "fetchImage":
      reply(fetchAsDataUrl(msg.url).then((dataUrl) => ({ dataUrl })));
      return true;
    case "snap:arm":
      reply(armSnap(msg, sender));
      return true;
    case "snap:peek":
      reply(peekSnap(sender.tab?.id));
      return true;
    case "snap:save":
      reply(saveSnap({ ...msg, tabId: sender.tab?.id }));
      return true;
    case "snap:refimage":
      reply(snapRefImage(msg.role));
      return true;
    case "snap:refpicks":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        return { sources: sid ? await snapRefPicks(sid) : [] };
      })());
      return true;
    case "snap:setrefpick":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        if (!sid) throw new Error("No chat to attach to");
        const key = refPickKey(sid);
        const saved = (await chrome.storage.local.get({ [key]: null }))[key] || {};
        const now = await snapRefPicks(sid);
        const next = {};
        for (const src of now) next[src.id] = src.on;
        next[msg.id] = msg.on === true;
        await chrome.storage.local.set({ [key]: { ...saved, ...next } });
        return { sources: await snapRefPicks(sid) };
      })());
      return true;
    case "snap:refimages":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        if (!sid) return { images: [] };
        const picks = (await snapRefPicks(sid)).filter((p) => p.on);
        const images = [];
        for (const src of picks) {
          try {
            const got = await snapRefDataUrl(sid, src);
            if (got?.dataUrl) images.push(got);
          } catch { /* unavailable */ }
        }
        return { images };
      })());
      return true;
    case "bridge:hello":
      noteBridgeTab(sender.tab?.id, msg.url, msg.bridge);
      reply(Promise.resolve({ noted: true }));
      return true;
    default:
      return;
  }
});

// ======================= sheet + drafting =======================

async function storePayload({ payload, lastReply, lastUserMsg }) {
  const built = Sheet.fromPayload(payload || {});
  if (!built.sessionId) throw new Error("Payload had no sessionId");

  const existing = await dbOps.getSheet({ sessionId: built.sessionId }).catch(() => null);
  if (existing?.characters && !Object.keys(built.characters || {}).length) {
    return { sessionId: built.sessionId };
  }
  const sheet = existing?.characters
    ? {
        ...built,
        characters: mergeCharacters(existing.characters, built.characters),
        lore: Object.keys(built.lore || {}).length ? built.lore : (existing.lore || {}),
        fallbackLocation: built.fallbackLocation || existing.fallbackLocation || "",
      }
    : built;

  const patch = { sheet, album: built.album?.title ? built.album : undefined };
  if (String(lastReply || "").trim()) patch.lastReply = String(lastReply);
  if (String(lastUserMsg || "").trim()) patch.lastUserMsg = String(lastUserMsg);
  for (const k of Object.keys(patch)) if (patch[k] === undefined) delete patch[k];

  await dbOps.mergeSession({ sessionId: built.sessionId, patch });
  await chrome.storage.local.set({ lastSession: built.sessionId });
  return { sessionId: built.sessionId };
}

function mergeCharacters(existing, incoming) {
  const out = { ...(existing || {}) };
  for (const [name, c] of Object.entries(incoming || {})) {
    const prev = out[name];
    if (prev?.edited) continue;
    if (!prev) { out[name] = c; continue; }
    const better = (c.appearance || "").length >= (prev.appearance || "").length ? c : prev;
    out[name] = { ...prev, ...better, portrait: c.portrait || prev.portrait || null };
  }
  return out;
}

async function draftPrompt(args) {
  try {
    return await buildDraft(args);
  } catch (err) {
    console.error("[Photobook] draft failed, using plain fallback:", err);
    const plain = collapseWs(String(args?.replyText || "")).slice(0, 400);
    return {
      drafts: [{
        label: "This moment",
        prose: plain
          ? `Create an image of this moment.\n\n${plain}`
          : "Create an image of this moment.",
        tags: "", negative: PromptCondenser.SD_NEGATIVE,
      }],
      scene: {}, portraits: [],
      replyClean: clipProse(tidyProse(String(args?.replyText || "")), 4000),
      hasSheet: false,
      degraded: err?.message || "draft error",
    };
  }
}

function stripAsides(t) {
  return String(t || "")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\([Oo][Oo][Cc][^)]*\)/g, " ")
    .replace(/\s+([.,!?])/g, "$1")
    .replace(/([.!?])\s*[.,]+/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

async function buildDraft({ sessionId, replyText, thinkText, nexus }) {
  const cfg = await getConfig();
  const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const sheet = rec?.sheet || { characters: {}, lore: {}, fallbackLocation: "" };

  const cleanReply = PromptCondenser.stripSnapSection
    ? PromptCondenser.stripSnapSection(replyText || "")
    : String(replyText || "");
  const combined = thinkText
    ? `<thinking>${thinkText}</thinking>\n${cleanReply}`
    : cleanReply;
  const { scene, visible } = Sheet.mineScene(combined);

  const userChar = Object.values(sheet.characters || {}).find((c) => c.role === "user");
  const rawAction = String(rec?.lastUserMsg || "")
    .replace(/\[[^\]]*\]/g, " ")
    .replace(/\([Oo][Oo][Cc][^)]*\)/g, " ")
    .replace(/[*_~`]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (rawAction.length > 4) {
    const who = userChar?.name ? `${userChar.name} (the player)` : "The player";
    scene.userAction = `${who} just: ${rawAction.slice(0, 240)}`;
  }
  const source = visible || cleanReply;
  const raw = PromptCondenser.condense(source, 8).candidates;
  let keptCandidates = raw;
  try {
    const filtered = raw.filter((m) => !PromptCondenser.isDirective(m.subject || ""));
    if (filtered.length) keptCandidates = filtered;
  } catch (err) {
    console.warn("[Photobook] directive filter skipped:", err?.message || err);
  }
  const strippedCandidates = keptCandidates
    .map((m) => ({ ...m, subject: stripAsides(m.subject) }))
    .filter((m) => m.subject);
  const all = strippedCandidates.length ? strippedCandidates : keptCandidates;
  let candidates = all.slice(0, 3);

  if (cfg.condenser === "llm" || cfg.condenser === "claude") {
    try {
      const upgraded = await draftWithModel(source, sheetToLegacy(sheet), cfg);
      if (upgraded.length) {
        candidates = upgraded;
        const fromModel = upgraded[0]?.characters || [];
        for (const p of fromModel) {
          const match = cast.find((n) =>
            String(n).toLowerCase().startsWith(String(p.name).split(/\s+/)[0].toLowerCase()));
          if (match) states[match] = p.doing;
        }
      }
    } catch (err) {
      console.warn("[Photobook] LLM condense failed, using heuristic:", err.message);
    }
  }

  if (!candidates.length) {
    const fallbackSubject =
      (rawAction.length > 8 ? rawAction : "") ||
      stripAsides(scene.now) ||
      stripAsides(collapseWs(source)).slice(0, 200) ||
      collapseWs(source).slice(0, 200);
    candidates = [{
      subject: fallbackSubject,
      action: [], setting: [], lighting: [], extras: [],
      label: "This moment", score: null, source: "fallback",
    }];
  }

  const cleanName = (n) => String(n || "")
    .replace(/[\[\]{}()<>"'`*_]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  const castSet = new Map();
  const addToCast = (name) => {
    const clean = cleanName(name);
    if (clean.length < 2) return;
    const key = clean.split(/\s+/)[0].toLowerCase();
    if (!castSet.has(key)) castSet.set(key, clean);
  };

  for (const c of Object.values(sheet.characters || {})) addToCast(c.name);
  for (const n of scene.who || []) addToCast(n);

  const hay = " " + String(source).toLowerCase() + " ";
  for (const c of Object.values(sheet.characters || {})) {
    const first = String(c.name || "").split(/\s+/)[0].toLowerCase();
    const safe = first.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (first.length > 2 && new RegExp(`[^a-z0-9]${safe}[^a-z0-9]`).test(hay)) {
      addToCast(c.name);
    }
  }

  if (!castSet.size) for (const k of Object.keys(sheet.characters || {})) addToCast(k);

  if (!castSet.size) {
    const counts = new Map();
    const STOP = new Set(["the", "he", "she", "they", "it", "his", "her", "their",
      "and", "but", "then", "there", "this", "that", "a", "an", "i", "you"]);
    for (const m of String(source).matchAll(/\b([A-Z][a-z]{2,})\b/g)) {
      const w = m[1];
      if (STOP.has(w.toLowerCase())) continue;
      counts.set(w, (counts.get(w) || 0) + 1);
    }
    [...counts.entries()]
      .filter(([, n]) => n >= 2)
      .sort((a, b2) => b2[1] - a[1])
      .slice(0, 3)
      .forEach(([w]) => addToCast(w));
  }

  const cast = [...castSet.values()];
  scene.where = cleanName(scene.where) || scene.where;
  scene.now = stripAsides(scene.now);
  scene.pressure = stripAsides(scene.pressure);
  const castWithGender = resolveCastGenders(sheet, cast, source, rawAction);
  const states = PromptCondenser.extractPose(source, castWithGender);

  if (rawAction.length > 4) {
    try {
      const mine = PromptCondenser.extractPose(rawAction, castWithGender);
      for (const [name, text] of Object.entries(mine)) {
        if (!states[name] && text) states[name] = text;
      }
    } catch (err) {
      console.warn("[Photobook] player-pose pass skipped:", err?.message || err);
    }
  }

  try {
    for (const [name, text] of Object.entries(states)) {
      if (PromptCondenser.isDirective(text)) delete states[name];
    }
  } catch (err) {
    console.warn("[Photobook] pose filter skipped:", err?.message || err);
  }

  const { splitSentences, stripMarkup, scoreSentence } = PromptCondenser._internals;
  const sentences = splitSentences(stripMarkup(source));
  for (const name of cast) {
    if (states[name]) continue;
    const short = String(name).split(/\s+/)[0].toLowerCase();
    if (short.length < 3) continue;
    const named = sentences.filter((s) => s.toLowerCase().includes(short));
    if (!named.length) continue;
    const rank = (s) =>
      scoreSentence(s).score + (sentences.indexOf(s) / Math.max(1, sentences.length - 1)) * 2;
    named.sort((a, b) => rank(b) - rank(a));
    states[name] = named[0];
  }

  scene.framing = PromptCondenser.detectDistance(source) || "";

  if (!scene.where && PromptCondenser.detectPlace) {
    scene.where = PromptCondenser.detectPlace(source, rawAction) || scene.where;
  }
  scene.props = PromptCondenser.findProps(source);

  const moodHit = PromptCondenser.detectMood(source, scene.pressure || "");
  if (moodHit) scene.mood = moodHit.mood;

  const sheetPlus = { ...sheet, characters: { ...(sheet.characters || {}) } };
  if (nexus) {
    const hadWho = (scene.who || []).length > 0;
    const firstOf = (s) => String(s).split(/\s+/)[0].toLowerCase();
    const inCast = (n) => cast.find((c) => {
      const a = firstOf(c), b = firstOf(n);
      return a === b || a.startsWith(b) || b.startsWith(a);
    });

    for (const [nexusName, desc] of Object.entries(nexus.descs || {})) {
      const key = inCast(nexusName) || nexusName;
      const known = Object.values(sheetPlus.characters)
        .some((c) => firstOf(c.name) === firstOf(key));
      if (!known) {
        sheetPlus.characters[key] = { name: key, appearance: desc, role: "side" };
      }
    }
    for (const [nexusName, state] of Object.entries(nexus.states || {})) {
      let clean = String(state || "");
      try {
        if (PromptCondenser.isDirective(clean)) continue;
        const kept = clean.split(/\s*,\s*/).filter((part) =>
          part.trim() && !PromptCondenser.isDirective(part));
        clean = kept.join(", ").trim();
      } catch { /* keep */ }
      if (!clean) continue;

      const match = inCast(nexusName);
      if (match) {
        if (!states[match]) states[match] = clean;
      } else if (!hadWho) {
        cast.push(nexusName);
        states[nexusName] = clean;
      }
    }
    const lines = nexus.sceneLines || [];
    if (!scene.where && lines.length) scene.where = lines[lines.length - 1];
    if (lines.length > 1) scene.time = lines[0];
  }

  const freshText = [source, thinkText || "", rawAction || "", scene.now || ""].join("\n");
  const staleText = [scene.where || "", (nexus?.sceneLines || []).join(" ")].join("\n");

  const fresh = PromptCondenser.detectConditions(freshText);
  const stale = PromptCondenser.detectConditions(staleText);

  const CARRY_MS = 45 * 60 * 1000;
  const stored = rec?.conditions || {};
  const sameScene = !stored.where || !scene.where ||
    stored.where.toLowerCase().slice(0, 24) === String(scene.where).toLowerCase().slice(0, 24);
  const recent = !stored.at || (Date.now() - stored.at) < CARRY_MS;
  const carried = sameScene && recent ? stored : {};

  const freshExclusiveAtmosphere = Boolean(fresh.fire || fresh.fireflies);
  scene.weather = fresh.weather ||
    (freshExclusiveAtmosphere ? "" : (carried.weather || stale.weather || ""));
  scene.time = scene.time || fresh.time || carried.time || stale.time || "";
  scene.dark = fresh.dark || carried.dark || false;
  scene.bright = fresh.bright || carried.bright || false;
  scene.fire = fresh.fire || (carried.fire === "steady" ? "steady" : false) ||
               (stale.fire === "steady" ? "steady" : false) || false;
  scene.fireflies = fresh.fireflies || false;
  scene.romance = fresh.romance || false;
  scene.garden = fresh.garden || stale.garden || false;

  if (fresh.weather || fresh.time || fresh.dark || fresh.bright || fresh.fire || fresh.fireflies ||
      fresh.romance || fresh.garden) {
    try {
      await dbOps.mergeSession({
        sessionId,
        patch: {
          conditions: {
            ...carried,
            ...fresh,
            where: scene.where || stored.where || "",
            fireflies: fresh.fireflies || false,
            romance: fresh.romance || false,
            fire: fresh.fire || (carried.fire === "steady" ? "steady" : false),
            at: Date.now(),
          },
        },
      });
    } catch { /* storage fallback */ }
  }
  for (const name of cast) {
    const known = Object.values(sheetPlus.characters)
      .some((c) => String(c.name).split(/\s+/)[0].toLowerCase()
                 === String(name).split(/\s+/)[0].toLowerCase());
    if (known) continue;
    const hit = Sheet.loreFor(sheet, name, "character") || Sheet.loreFor(sheet, name, null);
    if (hit?.text) {
      sheetPlus.characters[name] = {
        name, appearance: hit.text, portrait: hit.portrait || null, role: "side",
      };
    }
  }
  sheetPlus.lore = sheet.lore;

  scene.who = cast;

  let interaction = null;
  try {
    interaction = PromptCondenser.extractInteraction
      ? PromptCondenser.extractInteraction(source, castWithGender)
      : null;
  } catch (err) {
    console.warn("[Photobook] interaction pass skipped:", err?.message || err);
  }

  const drafts = candidates.map((moment) => ({
    label: moment.label,
    prose: Sheet.buildPrompt(sheetPlus, scene, moment, cfg.style, states, interaction),
    tags: PromptCondenser.assemble(moment, sheetToLegacy(sheet), "tags").prompt,
    negative: PromptCondenser.SD_NEGATIVE,
  }));

  const botPrompt = PromptCondenser.extractSnapSection
    ? (PromptCondenser.extractSnapSection(thinkText)
       || PromptCondenser.extractSnapSection(replyText))
    : null;
  if (botPrompt) {
    const style = String(cfg.style || "").trim();
    drafts.unshift({
      label: "From the bot",
      fromBot: true,
      prose: style ? `${botPrompt}\n\nStyle: ${style}` : botPrompt,
      tags: botPrompt,
      negative: PromptCondenser.SD_NEGATIVE,
    });
    drafts.length = Math.min(drafts.length, 3);
  }

  const portraits = Object.values(sheet.characters || {})
    .filter((c) => c.portrait)
    .map((c) => ({ name: c.name, url: c.portrait }));

  return {
    drafts, scene, portraits,
    replyClean: clipProse(tidyProse(source), 4000),
    hasSheet: Object.keys(sheet.characters || {}).length > 0,
  };
}

const MALE_RE = /\b(he|his|him|man|male|lord|commander|father|brother|son)\b/g;
const FEMALE_RE = /\b(she|her|hers|woman|female|lady|mother|sister|daughter|beauty)\b/g;

function tallyGender(hay) {
  const t = String(hay || "").toLowerCase();
  const m = (t.match(MALE_RE) || []).length;
  const f = (t.match(FEMALE_RE) || []).length;
  if (m > f) return "m";
  if (f > m) return "f";
  return null;
}

function guessGender(sheet, name) {
  const c = Object.values(sheet.characters || {})
    .find((x) => String(x.name).split(/\s+/)[0].toLowerCase()
              === String(name).split(/\s+/)[0].toLowerCase());
  const lore = Sheet.loreFor ? Sheet.loreFor(sheet, name, null) : null;
  return tallyGender(`${c?.appearance || ""} ${lore?.text || ""}`);
}

function resolveCastGenders(sheet, cast, source, userAction) {
  const out = cast.map((name) => ({ name, gender: guessGender(sheet, name) }));

  const prose = String(source || "");
  const sentences = prose.split(/(?<=[.!?])\s+/);

  for (const c of out) {
    if (c.gender) continue;
    const first = String(c.name).split(/\s+/)[0].toLowerCase();
    if (first.length < 3) continue;
    const mine = sentences.filter((x) => x.toLowerCase().includes(first));
    if (mine.length) c.gender = tallyGender(mine.join(" "));
  }

  const userName = Object.values(sheet.characters || {})
    .find((c) => c.role === "user")?.name;
  const you = userName && out.find((c) =>
    String(c.name).split(/\s+/)[0].toLowerCase()
      === String(userName).split(/\s+/)[0].toLowerCase());
  if (you && !you.gender) {
    const lead = String(userAction || "").match(/\b(he|his|him|she|her|hers)\b/i);
    if (lead) you.gender = /^h(e|is|im)$/i.test(lead[1]) ? "m" : "f";
  }

  const unknown = out.filter((c) => !c.gender);
  if (out.length === 2 && unknown.length === 1) {
    const known = out.find((c) => c.gender);
    const hasM = /\b(he|his|him)\b/i.test(prose);
    const hasF = /\b(she|her|hers)\b/i.test(prose);
    if (hasM && hasF) unknown[0].gender = known.gender === "m" ? "f" : "m";
  }
  return out;
}

function sheetToLegacy(sheet) {
  const chars = Object.values(sheet.characters || {});
  return {
    character: chars.filter((c) => c.role !== "user").map((c) => c.appearance).join(", "),
    user: chars.find((c) => c.role === "user")?.appearance || "",
    cast: chars.filter((c) => c.name).map((c) => ({
      name: c.name,
      role: c.role === "user" ? "user" : "char",
      appearance: String(c.appearance || "").slice(0, 200),
    })),
    style: "",
  };
}

function collapseWs(s) {
  return String(s).replace(/\s+/g, " ").trim();
}

function tidyProse(s) {
  return String(s || "")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function clipProse(text, max) {
  const t = String(text || "");
  if (t.length <= max) return t;
  const head = t.slice(0, max);
  const para = head.lastIndexOf("\n\n");
  if (para > max * 0.6) return head.slice(0, para).trim();
  const sentence = Math.max(head.lastIndexOf(". "), head.lastIndexOf("\u201d "),
                            head.lastIndexOf('" '));
  if (sentence > max * 0.6) return head.slice(0, sentence + 1).trim();
  return head.replace(/\s\S*$/, "").trim() + "\u2026";
}

async function listAlbums() {
  const [imageRecs, sessionRecs] = await Promise.all([
    req((await store(IMAGES, "readonly")).getAll()),
    req((await store(SESSIONS, "readonly")).getAll()),
  ]);

  const byId = new Map();
  for (const r of imageRecs) {
    const a = byId.get(r.sessionId) || { sessionId: r.sessionId, count: 0, latest: 0 };
    a.count += 1;
    a.latest = Math.max(a.latest, r.createdAt || 0);
    byId.set(r.sessionId, a);
  }
  for (const s of sessionRecs) {
    const a = byId.get(s.sessionId) || { sessionId: s.sessionId, count: 0, latest: 0 };
    a.title = s.album?.title || s.sheet?.album?.title || null;
    a.cover = s.album?.cover || null;
    byId.set(s.sessionId, a);
  }
  return { albums: [...byId.values()].sort((a, b) => b.latest - a.latest) };
}

// ======================= condenser =======================

async function condenseReply(text, sessionId) {
  const sheet = sessionId
    ? await dbOps.getSheet({ sessionId }).catch(() => ({}))
    : {};
  const cfg = await getConfig();

  const local = PromptCondenser.condense(text, 3);

  if (cfg.condenser === "llm" || cfg.condenser === "claude") {
    try {
      const candidates = await draftWithModel(text, sheet, cfg);
      if (candidates.length) return { candidates, sheet, source: "llm" };
    } catch (err) {
      console.warn("[Photobook] LLM condense failed, using heuristic:", err.message);
    }
  }
  return { candidates: local.candidates, sheet, source: "heuristic" };
}

async function draftWithModel(text, sheet, cfg) {
  const keys = await chrome.storage.local.get({ apiKey: "", apiKeyAnthropic: "" });
  if (cfg.condenser === "claude") {
    if (!keys.apiKeyAnthropic) return [];
    return claudeCondense(text, sheet, cfg, keys.apiKeyAnthropic);
  }
  if (!keys.apiKey) return [];
  return llmCondense(text, sheet, { ...cfg, apiKey: keys.apiKey });
}

async function claudeCondense(text, sheet, cfg, key) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: cfg.condenserModelClaude || "claude-haiku-4-5-20251001",
      max_tokens: 700,
      temperature: 0.4,
      system: PromptCondenser.llmInstruction(sheet),
      messages: [{ role: "user", content: String(text).slice(0, 8000) }],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    if (res.status === 401) throw new Error("Anthropic rejected the API key (401)");
    throw new Error(`Claude HTTP ${res.status}${body ? `: ${body.slice(0, 120)}` : ""}`);
  }
  const data = await res.json();
  const out = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  return PromptCondenser.parseLlmJson(out);
}

async function llmCondense(text, sheet, cfg) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.apiKey}`,
    },
    body: JSON.stringify({
      model: cfg.condenserModel,
      messages: [
        { role: "system", content: PromptCondenser.llmInstruction(sheet) },
        { role: "user", content: String(text).slice(0, 8000) },
      ],
      max_tokens: 500,
      temperature: 0.4,
    }),
  });
  if (!res.ok) throw new Error(`condenser HTTP ${res.status}`);
  const data = await res.json();
  return PromptCondenser.parseLlmJson(data.choices?.[0]?.message?.content || "");
}

// ======================= generation =======================

async function generate({ prompt, negative, reference, references, strength }) {
  const cfg = await getConfig();
  if (!prompt) throw new Error("No prompt");

  const refs = (Array.isArray(references) && references.length
    ? references
    : reference ? [reference] : []
  ).slice(0, MAX_REFS);

  switch (cfg.preset) {
    case "pollinations":
      return { dataUrl: await genPollinations(prompt, cfg), usedReference: false };
    case "a1111":
      return { dataUrl: await genA1111(prompt, negative, refs[0] || null, strength, cfg),
               usedReference: Boolean(refs[0]) };
    case "openrouter":
      return { dataUrl: await genOpenRouter(prompt, refs, cfg),
               usedReference: refs.length > 0 };
    case "openai":
      return { dataUrl: await genOpenAI(prompt, refs, cfg),
               usedReference: refs.length > 0 };
    default:
      throw new Error(`Unknown preset "${cfg.preset}"`);
  }
}

async function genPollinations(prompt, cfg) {
  const url =
    "https://image.pollinations.ai/prompt/" + encodeURIComponent(prompt) +
    `?width=${Number(cfg.width)}&height=${Number(cfg.height)}` +
    `&nologo=true&seed=${Math.floor(Math.random() * 1e9)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Pollinations returned ${res.status}`);
  const blob = await res.blob();
  if (!blob.type.startsWith("image/")) throw new Error("Pollinations returned no image");
  return blobToDataUrl(blob);
}

async function genA1111(prompt, negative, reference, strength, cfg) {
  const base = normalizeBase(cfg.endpoint || "http://127.0.0.1:7860");
  const common = {
    prompt,
    negative_prompt: negative || PromptCondenser.SD_NEGATIVE,
    width: Number(cfg.width),
    height: Number(cfg.height),
    steps: Number(cfg.steps),
  };
  const body = reference
    ? { ...common, init_images: [stripDataUrl(reference)],
        denoising_strength: clamp(Number(strength) || 0.6, 0.2, 0.85) }
    : common;
  const path = reference ? "/sdapi/v1/img2img" : "/sdapi/v1/txt2img";

  const res = await fetch(base + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Backend returned ${res.status}`);
  const data = await res.json();
  const b64 = data.images?.[0];
  if (!b64) throw new Error("Backend returned no image");
  return `data:image/png;base64,${b64}`;
}

async function genOpenAI(prompt, refs, cfg) {
  const base = normalizeBase(cfg.endpoint || "https://api.openai.com");
  const model = cfg.model || "gpt-image-1-mini";
  const size = `${Number(cfg.width)}x${Number(cfg.height)}`;
  if (!cfg.apiKey) throw new Error("No API key set — open the extension's Options page.");

  let res;
  if (refs.length) {
    const form = new FormData();
    form.append("model", model);
    form.append("prompt", prompt);
    form.append("quality", cfg.quality);
    if (refs.length === 1) {
      form.append("image", await dataUrlToBlob(refs[0]), "reference.png");
    } else {
      for (let i = 0; i < refs.length; i++) {
        form.append("image[]", await dataUrlToBlob(refs[i]), `reference-${i + 1}.png`);
      }
    }
    res = await fetch(`${base}/v1/images/edits`, {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.apiKey}` },
      body: form,
    });
  } else {
    res = await fetch(`${base}/v1/images/generations`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({ model, prompt, size, quality: cfg.quality, n: 1 }),
    });
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 400 && /safety|policy|moderation/i.test(text)) {
      throw new Error("That prompt was refused by the content filter. Try rewording, or switch backend in Options.");
    }
    throw new Error(`OpenAI returned ${res.status}${text ? `: ${text.slice(0, 140)}` : ""}`);
  }
  const data = await res.json();
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) throw new Error("OpenAI returned no image");
  return `data:image/png;base64,${b64}`;
}

async function genOpenRouter(prompt, refs, cfg) {
  const model = cfg.modelOpenRouter || "google/gemini-2.5-flash-image";
  if (!cfg.apiKeyOpenRouter) {
    throw new Error("No OpenRouter API key set — open the extension's Options page.");
  }

  const body = {
    model,
    prompt,
    size: `${Number(cfg.width)}x${Number(cfg.height)}`,
    n: 1,
  };
  if (refs.length) {
    body.input_references = refs.map((url) => ({
      type: "image_url",
      image_url: { url },
    }));
  }

  const res = await fetch("https://openrouter.ai/api/v1/images", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.apiKeyOpenRouter}`,
      "HTTP-Referer": "https://dreamjourneyai.com",
      "X-Title": "Dreamjourney Photobook",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 401) {
      throw new Error("OpenRouter rejected the API key (401). Check it in Options.");
    }
    if (res.status === 400 && /model/i.test(text)) {
      throw new Error(`OpenRouter didn't recognize the model "${model}". Check the slug on openrouter.ai/models.`);
    }
    throw new Error(`OpenRouter returned ${res.status}${text ? `: ${text.slice(0, 140)}` : ""}`);
  }

  const data = await res.json();
  const img = data.data?.[0];
  if (!img?.b64_json) throw new Error("OpenRouter returned no image");
  return `data:${img.media_type || "image/png"};base64,${img.b64_json}`;
}

// ======================= snap bridge =======================

async function configSummary() {
  const cfg = await getConfig();
  const keys = await chrome.storage.local.get({ apiKey: "", apiKeyOpenRouter: "" });
  const info = {
    pollinations: { label: "Pollinations", note: "free, basic quality", needsKey: false },
    a1111:        { label: "local SD",     note: "your own GPU",        needsKey: false },
    openai:       { label: "OpenAI",       note: "your API credit",     needsKey: true,
                    key: keys.apiKey },
    openrouter:   { label: "OpenRouter",   note: "your API credit",     needsKey: true,
                    key: keys.apiKeyOpenRouter },
  }[cfg.preset] || { label: cfg.preset, note: "", needsKey: false };

  return {
    preset: cfg.preset,
    bridge: cfg.bridge || "chatgpt",
    label: info.label,
    note: info.note,
    ready: !info.needsKey || Boolean(info.key),
    needsKey: Boolean(info.needsKey),
  };
}

async function noteBridgeTab(tabId, url, bridge) {
  if (!tabId) return;
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  bridgeTabs[tabId] = { url: url || "", bridge, seen: Date.now() };
  await chrome.storage.session.set({ bridgeTabs });
}

async function forgetBridgeTab(tabId) {
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  if (bridgeTabs[tabId]) {
    delete bridgeTabs[tabId];
    await chrome.storage.session.set({ bridgeTabs });
  }
}

async function tabForSession(sessionId, bridge) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  const claim = bridgeBySession[sessionId];
  if (!claim || claim.bridge !== bridge) return null;
  try { return await chrome.tabs.get(claim.id); } catch { return null; }
}

async function claimTabForSession(sessionId, tabId, bridge) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  for (const [sid, v] of Object.entries(bridgeBySession)) {
    if (v.id === tabId && sid !== sessionId) delete bridgeBySession[sid];
  }
  bridgeBySession[sessionId] = { id: tabId, bridge };
  await chrome.storage.session.set({ bridgeBySession });
}

async function claimedTabIds(exceptSessionId) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  return new Set(Object.entries(bridgeBySession)
    .filter(([sid]) => sid !== exceptSessionId)
    .map(([, v]) => v.id));
}

async function findLiveBridgeTab(bridge, exceptSessionId) {
  const taken = await claimedTabIds(exceptSessionId);
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  const all = Object.entries(bridgeTabs)
    .map(([id, v]) => ({ id: Number(id), ...v }))
    .filter((t) => t.bridge === bridge)
    .sort((a, b) => b.seen - a.seen);

  const order = [...all.filter((t) => !taken.has(t.id)), ...all.filter((t) => taken.has(t.id))];

  for (const t of order) {
    try {
      await chrome.tabs.get(t.id);
      return t;
    } catch {
      await forgetBridgeTab(t.id);
    }
  }
  return null;
}

chrome.tabs.onRemoved.addListener((id) => {
  forgetBridgeTab(id);
  clearSnapForTab(id).catch(() => {});
  releaseTabClaim(id).catch(() => {});
});

async function releaseTabClaim(tabId) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  let touched = false;
  for (const [sid, v] of Object.entries(bridgeBySession)) {
    if (v.id === tabId) { delete bridgeBySession[sid]; touched = true; }
  }
  if (touched) await chrome.storage.session.set({ bridgeBySession });
}

async function armSnap({ sessionId, prompt, returnUrl, replyText, conditions }) {
  const cfg = await getConfig();
  const snap = { sessionId, prompt, returnUrl, replyText: replyText || "",
                 conditions: conditions && typeof conditions === "object" ? { ...conditions } : {},
                 createdAt: Date.now() };
  await chrome.storage.session.set({ pendingSnap: snap });

  let tab = await tabForSession(sessionId, cfg.bridge);
  if (!tab) {
    const live = await findLiveBridgeTab(cfg.bridge, sessionId);
    if (live) {
      try {
        tab = await chrome.tabs.get(live.id);
        await claimTabForSession(sessionId, tab.id, cfg.bridge);
      } catch { tab = null; }
    }
  }
  const url = BRIDGE_URLS[cfg.bridge] || BRIDGE_URLS.chatgpt;
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* focus window */ }
    chrome.tabs.sendMessage(tab.id, { type: "snap:armed" }).catch(() => {});
  } else {
    tab = await chrome.tabs.create({ url });
    await claimTabForSession(sessionId, tab.id, cfg.bridge);
  }
  if (tab?.id) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    pendingByTab[tab.id] = snap;
    await chrome.storage.session.set({ pendingByTab });
  }

  return { snap, reused: Boolean(tab), opened: true };
}

async function peekSnap(tabId) {
  const pendingSnap = await snapForTab(tabId);
  if (!pendingSnap || Date.now() - pendingSnap.createdAt > 30 * 60 * 1000) {
    return { snap: null };
  }
  const rec = await req((await store(SESSIONS, "readonly"))
    .get(pendingSnap.sessionId)).catch(() => null);
  const chars = Object.values(rec?.sheet?.characters || {});
  return {
    snap: pendingSnap,
    charName: chars.find((c) => c.role === "bot")?.name || null,
    userName: chars.find((c) => c.role === "user")?.name || null,
  };
}

async function snapForTab(tabId) {
  if (tabId != null) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    const mine = pendingByTab[tabId];
    if (mine && Date.now() - mine.createdAt <= 30 * 60 * 1000) return mine;
  }
  const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
  return pendingSnap;
}

async function clearSnapForTab(tabId) {
  if (tabId != null) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    if (pendingByTab[tabId]) {
      delete pendingByTab[tabId];
      await chrome.storage.session.set({ pendingByTab });
    }
  }
  await chrome.storage.session.remove("pendingSnap");
}

async function saveSnap({ dataUrl, sessionId, caption, tabId }) {
  const pendingSnap = await snapForTab(tabId);
  const target = sessionId || pendingSnap?.sessionId || "unfiled";

  let note = caption || pendingSnap?.replyText || "";
  if (!note) {
    const rec = await req((await store(SESSIONS, "readonly")).get(target)).catch(() => null);
    note = String(rec?.lastReply || "")
      .replace(/```?\s*<thinking>[\s\S]*?<\/thinking>\s*```?/gi, "").trim();
    if (note) note = tidyProse(PromptCondenser.stripInstructions(note, 4000));
  }

  const id = await dbOps.add({
    sessionId: target,
    dataUrl,
    meta: {
      source: "captured",
      caption: note || pendingSnap?.prompt || "",
      prompt: pendingSnap?.prompt || "",
      conditions: pendingSnap?.conditions || {},
    },
  });
  await clearSnapForTab(tabId);

  // Tell the capture toast whether the Snapscape will pick this photo up on
  // its own (follow mode) or whether an explicit "Set as Snapscape" is the
  // only way it changes (pinned/none).
  let follow = true;
  if (target !== "unfiled") {
    const scape = await dbOps.scapeInfo({ sessionId: target }).catch(() => null);
    follow = !scape || scape.mode === "follow";
  }

  return { id, sessionId: target, follow, returnUrl: pendingSnap?.returnUrl || null };
}

async function lastSession() {
  const { lastSession } = await chrome.storage.local.get({ lastSession: null });
  return lastSession || "unfiled";
}

async function snapRefSources(sessionId) {
  const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const out = [];
  for (const role of ["bot", "user"]) {
    const c = Object.values(rec?.sheet?.characters || {}).find((x) => x.role === role && x.portrait);
    if (c) out.push({
      id: `portrait:${role}`, kind: "portrait", role, name: c.name,
      thumbUrl: c.portrait,   // site-hosted; the chat page can render it directly
    });
  }
  // Every book reference gets its own chip, each carrying a thumbnail of its
  // actual photo — the number says which slot, the picture says which image.
  // (Numbered labels replaced caption labels, which cut reply text mid-word
  // at 48 chars and produced duplicate-looking chips.)
  const refs = await refsWithThumbs(sessionId);
  refs.forEach((r, i) => out.push({
    id: `book:${i}`, kind: "book", index: i,
    name: refs.length > 1 ? `Book ref ${i + 1}` : "Book ref",
    thumb: r.thumb || null,
  }));
  return out;
}

const refPickKey = (sessionId) => `djpbSnapRefPick:${sessionId}`;

async function snapRefPicks(sessionId) {
  const sources = await snapRefSources(sessionId);
  const key = refPickKey(sessionId);
  const saved = (await chrome.storage.local.get({ [key]: null }))[key];
  return sources.map((src) => ({
    ...src,
    on: saved && typeof saved === "object" && src.id in saved
      ? saved[src.id] === true
      : src.kind === "portrait",
  }));
}

async function snapRefDataUrl(sessionId, src) {
  if (src.kind === "portrait") {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const c = Object.values(rec?.sheet?.characters || {})
      .find((x) => x.role === src.role && x.portrait);
    if (!c) return null;
    return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
  }
  const refs = await refsOf(await req((await store(SESSIONS, "readonly")).get(sessionId)));
  const hit = refs[src.index];
  if (!hit?.blob) return null;
  return { dataUrl: await blobToDataUrl(hit.blob), name: hit.label || "Book photo" };
}

async function snapRefImage(role) {
  const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
  const sid = pendingSnap?.sessionId || (await lastSession());
  if (role === "bot" || role === "user") {
    const rec0 = await req((await store(SESSIONS, "readonly")).get(sid));
    const c = Object.values(rec0?.sheet?.characters || {})
      .find((x) => x.role === role && x.portrait);
    if (!c) throw new Error(role === "bot"
      ? "No character portrait on file for this chat yet"
      : "No persona portrait on file for this chat yet");
    return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
  }
  const key = `djpbSnapRef:${sid}`;
  let choice = (await chrome.storage.local.get({ [key]: null }))[key];
  if (!choice || choice.kind === "none") {
    const rec0 = await req((await store(SESSIONS, "readonly")).get(sid));
    const chars = Object.values(rec0?.sheet?.characters || {});
    const auto = chars.find((c) => c.role === "bot" && c.portrait)
      || chars.find((c) => c.portrait);
    if (auto) choice = { kind: "portrait", name: auto.name };
    else if (await dbOps.getReference({ sessionId: sid })) choice = { kind: "session" };
    else throw new Error("No portrait or reference on file for this chat yet");
  }
  if (choice.kind === "session") {
    const dataUrl = await dbOps.getReference({ sessionId: sid });
    if (!dataUrl) throw new Error("The book reference is gone");
    return { dataUrl, name: "Book ref" };
  }
  const rec = await req((await store(SESSIONS, "readonly")).get(sid));
  const c = Object.values(rec?.sheet?.characters || {})
    .find((ch) => ch.name === choice.name);
  if (!c?.portrait) throw new Error(`No portrait on file for ${choice.name}`);
  return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
}

// ======================= right-click capture =======================

(async () => {
  try {
    if (navigator.storage?.persist && !(await navigator.storage.persisted())) {
      const ok = await navigator.storage.persist();
      console.info("[Photobook] persistent storage:", ok ? "granted" : "not granted");
    }
  } catch { /* storage fallback */ }
})();

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "djpb-save-image",
    title: "Save image to photobook",
    contexts: ["image"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== "djpb-save-image" || !info.srcUrl) return;
  try {
    const dataUrl = info.srcUrl.startsWith("data:")
      ? info.srcUrl
      : await fetchAsDataUrl(info.srcUrl);
    await saveSnap({ dataUrl, sessionId: null, caption: "" });
  } catch (err) {
    console.warn("[Photobook] Right-click save failed:", err.message);
  }
});

// ======================= helpers =======================

async function fetchAsDataUrl(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return blobToDataUrl(await res.blob());
}

function normalizeBase(endpoint) {
  return String(endpoint)
    .replace(/\/+$/, "")
    .replace(/\/v1\/images\/(generations|edits)$/i, "")
    .replace(/\/sdapi\/v1\/(txt2img|img2img)$/i, "")
    .replace(/\/v1$/i, "")
    .replace(/\/+$/, "");
}

function stripDataUrl(dataUrl) {
  const i = dataUrl.indexOf(",");
  return i >= 0 ? dataUrl.slice(i + 1) : dataUrl;
}

function clamp(n, lo, hi) {
  return Math.min(hi, Math.max(lo, n));
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}