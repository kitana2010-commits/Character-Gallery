// options.js — v0.6.
//
// The one rule that matters here: chrome.permissions.request() must run while
// the click gesture is still live. v0.4 awaited a storage write first, which
// consumed the gesture and made the request throw. Permissions first, always.

const $ = (id) => document.getElementById(id);

const DEFAULTS = {
  preset: "pollinations",
  endpoint: "",
  model: "gpt-image-1-mini",
  modelOpenRouter: "google/gemini-2.5-flash-image",
  width: 768,
  height: 768,
  steps: 25,
  quality: "low",
  style: "stylized digital illustration, semi realistic anime inspired",
  bridge: "chatgpt",
  condenser: "heuristic",
  condenserModel: "gpt-5.4-nano",
  condenserModelClaude: "claude-haiku-4-5-20251001",
  pageZoom: "auto",
  kbLiftOn: true,
};

function showBackendFields() {
  const preset = $("preset").value;
  for (const el of document.querySelectorAll(".backend")) el.classList.remove("visible");
  const active = document.getElementById(`backend-${preset}`);
  if (active) active.classList.add("visible");
}

function originPatternFor(preset, endpoint) {
  if (preset === "openai") return "https://api.openai.com/*";
  if (preset === "openrouter") return "https://openrouter.ai/*";
  if (preset === "a1111") {
    try {
      const u = new URL(endpoint || "http://127.0.0.1:7860");
      return `${u.protocol}//${u.hostname}${u.port ? ":" + u.port : ""}/*`;
    } catch {
      return "http://127.0.0.1/*";
    }
  }
  return null; // pollinations is granted in the manifest
}

async function load() {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  const { apiKey, apiKeyOpenRouter, apiKeyAnthropic } = await chrome.storage.local.get({
    apiKey: "",
    apiKeyOpenRouter: "",
    apiKeyAnthropic: "",
  });
  $("preset").value = cfg.preset;
  $("endpoint-a1111").value = cfg.preset === "a1111" ? cfg.endpoint : "";
  $("apiKey").value = apiKey;
  $("apiKeyOpenRouter").value = apiKeyOpenRouter;
  $("apiKeyAnthropic").value = apiKeyAnthropic;
  $("condenserModelClaude").value = cfg.condenserModelClaude || "claude-haiku-4-5-20251001";
  syncClaudeRow();
  $("modelOpenRouter").value = cfg.modelOpenRouter || "";
  $("model").value = cfg.model;
  $("quality").value = cfg.quality;
  $("width").value = cfg.width;
  $("height").value = cfg.height;
  $("steps").value = cfg.steps;
  $("style").value = cfg.style;
  $("bridge").value = cfg.bridge;
  $("condenser").value = cfg.condenser;
  $("pageZoom").value = cfg.pageZoom || "auto";
  $("kbLiftOn").checked = cfg.kbLiftOn !== false;
  chrome.storage.local.get({ djpbBackdropOn: true, djpbBackdropDim: 35, djpbFx: true })
    .then((v) => {
      $("bdOn").checked = v.djpbBackdropOn !== false;
      $("bdFx").checked = v.djpbFx !== false;
      $("bdDim").value = Number(v.djpbBackdropDim) || 35;
    })
    .catch(() => { $("bdOn").checked = true; $("bdDim").value = 35; });

  chrome.storage.local.get({ djpbAutoFill: true })
    .then((v) => { $("autoFill").checked = v.djpbAutoFill !== false; })
    .catch(() => { $("autoFill").checked = true; });
  showBackendFields();
}

function save() {
  const preset = $("preset").value;
  const endpoint = preset === "a1111" ? $("endpoint-a1111").value.trim() : "";
  const status = $("status");
  status.textContent = "";
  status.classList.remove("error");

  const finish = async (granted) => {
    if (granted === false) {
      status.textContent = "Permission declined — that backend can't be reached until it's granted.";
      status.classList.add("error");
      return;
    }
    await chrome.storage.sync.set({
      preset,
      endpoint,
      model: $("model").value.trim() || DEFAULTS.model,
      modelOpenRouter: $("modelOpenRouter").value.trim(),
      quality: $("quality").value,
      width: Number($("width").value) || DEFAULTS.width,
      height: Number($("height").value) || DEFAULTS.height,
      steps: Number($("steps").value) || DEFAULTS.steps,
      style: $("style").value.trim(),
      bridge: $("bridge").value,
      condenser: $("condenser").value,
      condenserModel: DEFAULTS.condenserModel,
      condenserModelClaude: $("condenserModelClaude").value.trim() || DEFAULTS.condenserModelClaude,
      pageZoom: $("pageZoom").value,
      kbLiftOn: $("kbLiftOn").checked,
    });
    await chrome.storage.local.set({
      apiKey: $("apiKey").value.trim(),
      apiKeyOpenRouter: $("apiKeyOpenRouter").value.trim(),
      apiKeyAnthropic: $("apiKeyAnthropic").value.trim(),
    });
    status.textContent = "Saved ✓";
    setTimeout(() => (status.textContent = ""), 2500);
  };

  const origin = originPatternFor(preset, endpoint);
  const drafting = $("condenser").value;
  const origins = new Set();
  if (origin) origins.add(origin);
  if (drafting === "llm" || preset === "openai") origins.add("https://api.openai.com/*");
  if (drafting === "claude") origins.add("https://api.anthropic.com/*");

  if (origins.size) {
    // Synchronous call inside the click gesture — no await before this line.
    chrome.permissions.request({ origins: [...origins] }, (granted) => {
      if (chrome.runtime.lastError) {
        status.textContent = chrome.runtime.lastError.message;
        status.classList.add("error");
        return;
      }
      finish(granted);
    });
  } else {
    finish(true);
  }
}

$("reset-pill").addEventListener("click", async () => {
  await chrome.storage.local.remove(["djpbPillPos", "djpbToastPos"]);
  const btn = $("reset-pill");
  btn.textContent = "Reset \u2713 — reload the tabs";
  setTimeout(() => (btn.textContent = "Reset positions"), 3000);
});

// Zoom is something you eyeball, so apply it the moment it changes rather
// than making the user save and reload to see the result.
$("pageZoom").addEventListener("change", () =>
  chrome.storage.sync.set({ pageZoom: $("pageZoom").value }));

$("kbLiftOn").addEventListener("change", () =>
  chrome.storage.sync.set({ kbLiftOn: $("kbLiftOn").checked }));

// Snapscapes settings live in local storage, alongside the other per-device
// preferences, and apply the moment they change.
$("bdOn").addEventListener("change", () =>
  chrome.storage.local.set({ djpbBackdropOn: $("bdOn").checked }));
$("bdFx").addEventListener("change", () =>
  chrome.storage.local.set({ djpbFx: $("bdFx").checked }));
$("bdDim").addEventListener("change", () =>
  chrome.storage.local.set({ djpbBackdropDim: Number($("bdDim").value) || 35 }));


$("autoFill").addEventListener("change", () =>
  chrome.storage.local.set({ djpbAutoFill: $("autoFill").checked }));

$("preset").addEventListener("change", showBackendFields);
$("save").addEventListener("click", save);
load();


/** Only show the Anthropic fields when Claude is the chosen drafter. */
function syncClaudeRow() {
  const row = document.getElementById("claude-row");
  if (row) row.hidden = document.getElementById("condenser").value !== "claude";
}
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("condenser")?.addEventListener("change", syncClaudeRow);
});


/** The "what is this" reader for polished prompts. Plain language on purpose:
 *  an API key is an unfamiliar idea for most people using this, and the
 *  setting is worthless if nobody can tell what it does. */
document.addEventListener("DOMContentLoaded", () => {
  const help = document.getElementById("help");
  if (!help) return;
  const card = document.getElementById("help-card");
  const open = () => {
    help.hidden = false;
    // Focus the card, not the Close button: the card scrolls, and focusing a
    // control at its foot scrolled "what this does" off the top — which is
    // the one part that has to be read first.
    if (card) { card.scrollTop = 0; card.focus(); }
  };
  const close = () => { help.hidden = true; document.getElementById("help-open")?.focus(); };
  document.getElementById("help-open")?.addEventListener("click", open);
  document.getElementById("help-close")?.addEventListener("click", close);
  help.addEventListener("click", (e) => { if (e.target === help) close(); });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !help.hidden) close();
  });
});
