// zoom.js — makes a phone stuck in "desktop mode" behave like a phone.
//
// Some mobile browsers only expose extensions in desktop mode (Lemur is the
// case that prompted this). Desktop mode hands the page a ~1000px viewport, so
// the site lays out for a monitor and renders at postage-stamp size.
//
// The fix is CSS zoom on the document element. Zoom is not magnification: it
// also DIVIDES the reported CSS viewport, so at 2.2x a 1080px viewport becomes
// ~490px and the site's own mobile breakpoints take over. Layout and legibility
// are fixed by the same lever, and our own UI scales with it for free.

(() => {
  const TARGET_WIDTH = 470;   // the CSS width we want the page to believe it has
  const MAX_ZOOM = 2.6;
  let applied = 1;            // the zoom we last set, so we can recover the true width

  /** The viewport width as it would be with no zoom applied. innerWidth is
   *  already divided by the zoom, so multiplying it back gives the real one. */
  function baseWidth() {
    return innerWidth * applied;
  }

  /** Desktop mode on a touch device is the signature we care about: a real
   *  desktop is not touch-first, and a phone in mobile mode is already narrow. */
 function looksLikeDesktopModeOnAPhone() {
  if (baseWidth() <= 900) return false;
  return window.isPhone(baseWidth());
}

  function wantedZoom(setting) {
    if (setting === "off") return 1;
    if (setting && setting !== "auto") return (Number(setting) || 100) / 100;
    if (!looksLikeDesktopModeOnAPhone()) return 1;
    return Math.min(MAX_ZOOM, Math.max(1, baseWidth() / TARGET_WIDTH));
  }

  // This now runs only on Dreamjourney. ChatGPT is left completely alone:
  // its own mobile layout is fine, and with the prompt and references inserted
  // automatically there is nothing there to read or type at desktop scale.

  async function apply() {
    let setting = "auto";
    try {
      ({ pageZoom: setting } = await chrome.storage.sync.get({ pageZoom: "auto" }));
    } catch { /* worker asleep; auto is a safe default */ }

    const z = wantedZoom(setting);
    // Re-applying a near-identical value on every resize would fight the
    // browser, and each apply changes innerWidth, which fires resize again.
    if (Math.abs(z - applied) < 0.03) return;

    applied = z;
    lastWidth = innerWidth;
    const root = document.documentElement;
    if (z === 1) root.style.removeProperty("zoom");
    else root.style.setProperty("zoom", String(Math.round(z * 100) / 100));
  }

  let t = null;
  let lastWidth = innerWidth;

  // The keyboard changes the window HEIGHT. Re-running the zoom maths then is
  // what made the page grow after tapping the message box — the layout was
  // fine on load and only drifted afterwards. Zoom depends on width alone, so
  // a height-only resize must be ignored completely.
  const debounced = () => {
    const widthChanged = Math.abs(innerWidth - lastWidth) > lastWidth * 0.05;
    if (!widthChanged) return;
    lastWidth = innerWidth;
    clearTimeout(t);
    t = setTimeout(apply, 250);
  };

  apply();
  addEventListener("resize", debounced);
  addEventListener("orientationchange", debounced);
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync" && changes.pageZoom) { applied = 1; apply(); }
    });
  } catch { /* no storage events available */ }
})();
