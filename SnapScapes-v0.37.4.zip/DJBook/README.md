# Dreamjourney Photobook v0.37.4

## SnapScapes2.1 color theme merge

This build starts from SnapScapes2.1 (extension v0.37.1) and incorporates the
backdrop color theme from the older DJBook build. The current album designs,
reference controls, Snap buttons, image capture, and other current features
remain in place.

With a backdrop active, its colors tint the chat bubbles, input bar, Snap
button, and extension menus. Click **Scape** to open the appearance controls:

- **Color theme:** switch backdrop-based colors on or off (default on). Off
  restores the default colors while keeping the backdrop, effects, and chat
  opacity. It also removes the colored fill and sweeping generation shine
  across the message input panel. The setting is remembered after refreshing
  or changing chats.
- **Horizontal Position:** move the backdrop crop left or right (default 50%).
- **Chat Box Opacity:** adjust the chat gradient from 0% to 90% (default 35%).
- **Color Vibrancy Boost:** adjust the sampled colors from 10% to 400%
  (default 180%). Disabled while Color theme is off; its saved value is kept.

Each slider also accepts a typed percentage. Preferences are remembered for
the DreamJourney site in the same browser profile. **Turn backdrops off** is
in this menu; turning Scape off or leaving a chat removes the theme. Pinned
backdrops still have an **Unpin image** action. The donor's separate avatar
and logo relocation changes are not part of this merge.

To update, extract this ZIP and copy the contents of its **DJBook** folder over
the files in your existing extension folder. In `chrome://extensions`, click
**Reload** on the existing extension, then refresh DreamJourney. Keep the
existing installation so its stored albums and settings remain available.

## Existing features

Everything from the approved feature map that doesn't require the site's
message DOM. Unzip over your extension folder (or load this folder fresh at
`chrome://extensions` → Load unpacked) and reload.

Nothing needs an API key. A fresh install generates via Pollinations
immediately, and "Send to ChatGPT" uses your existing subscription.

## What's in it

**The data layer (A1–A4, A7).** A MAIN-world script watches the site's own
`/api/chat` send and reads the body — character card, persona, lorebooks,
plot — once per message you send. History is stripped inside the page before
anything is stored; only the newest reply is kept, for the album's paste
button. The sheet builds itself: appearance from the card's `## Appearance`
section, `{{char}}`/`{{user}}` filled, portraits from the card art, album
title and cover from the plot. Hand edits to a sheet survive re-intercepts.

**The snap (B2, B3, most of B4).** A 📷 Snap pill sits above the 📖 toggle.
Click it: the newest reply is read, `WHO:`/`WHERE:`/`NOW:` mined from its
thinking block, the top 2–3 visual moments offered as chips, and the full
prompt assembled into one editable box. Three routes: **Generate** (backend
from Options), **Send to ChatGPT** (copies the prompt, arms the capture,
opens the tab — you paste and send, the image saves itself with a "back to
chat" link), and **Copy**. 📎 chips put each character's portrait on the
clipboard as an image for reference-pasting. Pure-dialogue replies fall back
to the `NOW:` line so a snap never comes back empty.

**The album (D1–D6, D7).** Open `browse.html` (link in Options). A shelf of
leather-bound books — covers from each plot's art, titles embossed, a photo
count, dust on albums untouched for a month. Open one: marbled endpaper with
the cast's portraits mounted and named, then one photo per page — a fixed
hand-mounted tilt, date stamp — with your note beneath in script on ruled
lines, autosaved, with **Paste latest reply**.
Pages turn in 3D; the fore-edge stack thins as you read; a ribbon bookmark
returns you to where you left off; arrow keys and swipe both work. Inside
the back cover, a paper sleeve holds unfiled right-click captures — click
one to mount it in this album. All of it reads IndexedDB directly: no photos
travel through messages anymore.

**Saving from ChatGPT.** Nothing is ever saved without a click. When a fresh
image finishes rendering, the bridge toast shows a **thumbnail** of it with a
**♥ Save to photobook** button; the button stays disabled until the image has
stopped changing, so a click can't grab a half-drawn frame. If the thumbnail
shows the wrong picture, ◀ ▶ step through the other fresh candidates — or
just wait, since the generation becomes the newest candidate when it lands.
Images inside a *user* turn (the references we pasted, echoed back by the
site) are never candidates at all: that is DOM position, not pixel
similarity, so a generation derived from its own reference can't be mistaken
for it.

**References from the album.** The Snap card's reference row takes up to four
photos. **＋ Album photo** (which now shows how many slots are used, e.g.
*2/4*) drops a strip of this chat's newest photos into the card — tap one and
it becomes a reference and switches on in the same motion; **tap it again to
remove it**. Photos in use wear a numbered badge that matches their chip, and
a header line counts the slots. Every chip — portraits and book refs alike —
now carries a **thumbnail of its actual photo**, and hovering a chip pops a
larger preview, so "Book ref 1" vs "Book ref 2" is never a guess. Thumbnails
are made once in the worker (192px JPEG) and cached on the reference, so the
card stays fast. Removing a ref now also re-keys the saved on/off states and
renumbers auto labels, so the remaining photos keep *their own* settings
instead of inheriting a neighbour's. The album's own "Use as ref" button was removed in v0.37.1 — references are picked from the Snap card, and the button was clutter inside the book. Each book chip still has a **×**, and
**📖 Photo Album** still opens the full album for browsing.

**Snapscapes (the chat backdrop).** The **"Always update Snapscape with new
gens"** checkbox lives in the Snap card, on by default. *On*, the backdrop
follows your newest photo per chat. *Off*, the current backdrop is pinned and
a **🖼 Set as Snapscape** button appears with each new result — in the Snap
card after Generate, and in the ChatGPT toast after a save. It maps onto the
album page's pin control's three states (follow / pinned / none), so the two
surfaces can never disagree.

**After Hours.** v0.37: the faint window grid is gone from the front page —
it read as graph paper against the neon — replaced by a single large pink
sign-glare behind the title with a cold cyan counter-glow low right, the
rest falling into black. Inside, the white diagonal rain streaks are gone
(they read as scratches, not weather); the neon gutter tube, street dots and
light pollution stay. Notes now sit in a NEON FRAME built with the
gradient-border technique from the user's card CSS: the ::after paints a
gradient across the box and a two-layer mask (padding-box + border-box,
composited with intersect) punches out the middle so only the border keeps
it. Recoloured to the binding's cyan-to-pink, full brightness, glow spilling
onto the page. Static — the source's cursor-following lens is left out.

**Roses.** v0.36 replaced the front page. The old one used a garland composed
here in code — a ring of small blooms at fixed positions — which read as
scattered blobs. It is now a SINGLE bloom drawn by the flower pen itself at
feature size, sitting in the lower-right corner so the page edge crops it,
on clean blush paper with room for the title and cast. The interior art is
untouched: the pen's own scatter, exactly as written. Notes there now sit on
the same frosted vellum slip Watercolor uses, so the art reads through
instead of being boxed out.

**The ribbon.** v0.34 gave every binding its own silk. Two hardcoded colours
used to leak through the theme system: the base ribbon faded into a plum
maroon (#5e1531) at the foot, and pulling it out swapped in a bright pink
(#d4487a) — so Deepwood ended in maroon and Emberfall flashed pink. Both are
gone. Each binding now declares its full background stack (Classic's twin
brass rules on oxblood, Arcana's amethyst fade with moon-silver rules,
Punk's black with a scream-red spine band, Aurora's aurora light running
down the length, Deepwood's grosgrain centre band, Emberfall charred-to-
ember, Red Flags' gold keylines, After Hours' neon tubes, Watercolor's
drifting wash, Roses' pink-to-plum), and `.active` simply brightens whatever
the binding is wearing. The word sits higher and larger (13.5px, up from 11px; After Hours keeps its
16px script). The earlier attempt to raise it barely moved because Chrome
vertically centres a button's content by default — the ribbon is a
<button>, so the word was being auto-centred in the silk regardless of its
margin. Explicit flex alignment (align-items: flex-start) is what actually
puts it near the head, and it reads "Favorites" with
the capital — an `uppercase` transform had been flattening it.

**The cast plate.** The dramatis personae portraits on the front page wear a
FIXED treatment, deliberately independent of the frame dial: loose photos
wear Kraft/Instant/Spray, the cast always wears its binding's own corners.
Each portrait is a square plate that crops (rather than letterboxes) the
image — which is also the bug fix: with `object-fit: contain` the `<img>` box
stayed wide while the visible picture shrank inside it, so corners anchored
to empty space instead of to the photograph. Corners now scale with the
plate instead of sitting at a fixed 26px. Per binding: brass pockets
(Classic), gold keyline with violet corner stars (Arcana), keyline-only in
each binding's own metal (Punk, Aurora, Deepwood), charred corners
(Emberfall), gold L-brackets (Red Flags), pink-and-cyan neon clips (After
Hours), and the Classic pocket recoloured per corner in the pens' own hues
(Watercolor, Roses). Clicking a portrait now opens it full-size.

**Album design.** 🎨 Design sets three things per album. *Binding* re-skins
the whole book through the variable system. v0.30 reshaped the roster:
Grimoire is now **Classic** (the old neutral default retired into it); Noir
and Sunny were retired, their slots taken by two *painted* bindings —
**Watercolor** and **Roses** — whose page backgrounds are generated once per
album by the two canvas pens supplied by the user (WaterColor blob engine;
arc-petal flower scatter), cached on the album, and never repainted: every
book is a one-off still. Their shelf covers wear the album's own painting
behind a linen scrim. v0.35 softened Watercolor: the pigment is diluted at
the source (lower alpha per pass — genuinely more water, not a pale film
over a bold painting), a bloom-out clears the middle of the page so writing
has paper to sit on while full colour stays at the borders where the pen
bleeds from, and notes sit on a frosted vellum slip that the wash still
reads through. Cached paintings carry an ART_VERSION so existing albums
repaint at the new dilution instead of keeping the old heavy pigment. Each
painted album also gets its own painted
FRONT PAGE: a second, distinct composition from the same pen — a title-page
wash for Watercolor, a bloom garland for Roses — bordering the endpaper and
leaving the centre clear for the cast. **Vendetta became Punk**: same id (saved albums keep
their clothes), same red-and-black cover and endpapers, but the interior
pages are now midnight-rock newsprint — hairline magazine rules, one
scream-red gutter rule, a barcode at the page foot, a lowercase typewriter
date. A new universal frame joins the dial: **Spray paint**, the
turbulence-displaced graffiti frame, available to every binding. Stored
themes migrate automatically (default→Classic, Sunny→Watercolor,
Noir→Roses). Gothic Romance became **Aurora** in v0.32
(same id, saved albums migrate seamlessly): the rose window and moths are
gone, replaced by a fantasy night galaxy built from the user's starfield
code — mardi-gras purple, white-smoke stars in layered cream halos (baked
static, never shimmering), a glowing crescent moon in every page's margin
and hung large over the endpaper sky, with the room lit by the code's own
elliptical gradient. The remaining roster — Arcana, Deepwood,
Emberfall — and two
bindings drawn from Eurielle's Gallery pages: **Red Flags** (oxblood pages
with a static blood vignette, gold corner ticks, a fading gold gutter rule
with the thorned heart at its centre, thorn stars near the fore-edge, black
oxblood calf cover with gold-tooled ticks) and **After Hours** (night-glass
pages with corner light pollution, static rain, a pink neon tube wired down
the gutter, street dots at the fore-edge, a wet-glass cover with a neon
title — and the favourites ribbon re-skinned as a vertical neon sign, same
element and behaviour, new material). *Handwriting*
picks the note face. *Frames* chooses how a photograph is mounted: kraft
corners, instant film, gilded, filmstrip, washi tape or postage — each a
different physical object rather than a recoloured border. Instant film
writes the date on its own chin (and the page's rubber stamp steps aside);
the filmstrip prints a frame number. The ❏ button under any photo overrides
the album's choice for that page alone, cycling through the six and back to
"Album frame". Both the album default and the per-photo overrides travel in
backups.

**Fixes (E1, E2).** Options requests permissions *before* any await, so the
gesture bug is gone; migration claims a flag before copying, so two open tabs
can't duplicate your photos; the API key lives in `storage.local`; the dead
branch in `onNavigate` is removed.

## Still needs the site's DOM (deferred, by design)

- **Per-message 📷 buttons and true inline results (B1/B4).** The pill snaps
  the *latest* reply using a heuristic (innermost big text blocks, then climb
  to swallow the thinking fence). If it grabs the wrong element, set an exact
  selector once and it's used forever:
  `chrome.storage.local.set({ djpbMessageSelector: ".their-message-class" })`
- **Lorebook entries (A5).** `indexLorebooks` handles the three likely shapes
  but it's unverified until `lorebooks[0]` is expanded. Side characters show
  "(no description on file)" until then — the line is editable in the box.
- **Generation queue (B5)** and sheet accretion (A6) — next round.

## First-run checklist

1. Load the extension, open a chat, **send one message** — that first send is
   what populates the sheet.
2. Hit 📷 Snap. Check the assembled prompt names your characters correctly.
3. Try Generate (Pollinations) once, then the ChatGPT route once.
4. Open the album from Options and turn some pages.
5. Hit 🎨 Design and try a binding and a frame; then ❏ under a photo to give
   that one page its own mounting.

## File inventory

`manifest.json` v0.6 · `intercept.js` (MAIN world) · `background.js` ·
`sheet.js` · `condense.js` · `snap.js` + `snap.css` · `capture.js` ·
`content.js` + `content.css` + `db.js` (v0.4, patched) · `backdrop.js` ·
`zoom.js` · `keyboard.js` · `mobile.js` ·
`browse.html/css/js` (rebuilt) · `fonts/` (bundled Alex Brush for the Handwritten pack) · `options.html/js` (rebuilt)
