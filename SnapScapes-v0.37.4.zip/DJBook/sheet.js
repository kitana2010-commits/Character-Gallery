// sheet.js — turns an intercepted /api/chat payload into an appearance sheet,
// and an appearance sheet + a snapped reply into a finished prompt.
//
// Every field name here comes from a real captured payload, not a guess.

const Sheet = (() => {

  // ---------- character cards ----------

  /** Cards on this site are markdown-sectioned and the convention is a
   *  "## Appearance" heading. Split on headings and take that section;
   *  fall back to the opening paragraph for cards that aren't sectioned. */
  function appearanceFrom(description) {
    const text = String(description || "").trim();
    if (!text) return "";

    const sections = text.split(/^##+\s+/m).filter(Boolean);
    const match = sections.find((s) => /^appearance\b/i.test(s));
    if (match) {
      return collapse(match.replace(/^appearance\s*/i, ""));
    }

    // Unsectioned card: first paragraph is nearly always the physical
    // description, since that's how people write these.
    return collapse(text.split(/\n\s*\n/)[0] || text).slice(0, 400);
  }

  function collapse(s) {
    return String(s).replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
  }

  /** Image prompts need what can be DRAWN, not the character card's entire
   *  psychological dossier. Some unsectioned / loosely sectioned cards put
   *  Appearance, attachment style, money, fame, relationships, etc. in one
   *  blob. Stop at common non-visual labels, then keep a tight visual budget. */
  function promptAppearance(text) {
    let t = collapse(text || "");
    if (!t) return "";

    // A leading colon is common on cards written as "Appearance: ..." after
    // the heading parser has stripped the word Appearance itself.
    t = t.replace(/^[:\-–—\s]+/, "");

    const meta = /\b(?:attachment\s+style|bank\s+account|fame|relationship\s+with|relationships?|opinion\s+on|love\s+language|personality|backstory|history|occupation|job|family|sexuality|likes?|dislikes?|habits?|goals?|motivation|skills?|abilities|powers?|voice|speech|behavior|behaviour|connections?)\s*:/i;
    const cut = t.search(meta);
    if (cut > 0) t = t.slice(0, cut).trim();

    // Prefer sentences that contain drawable traits. This drops nearby card
    // prose like "women love him" while preserving hair, eyes, clothes, scars,
    // tattoos, piercings, build, etc. Fall back to the opening sentence(s) for
    // unusually written cards that don't use our visual vocabulary.
    const sentences = t.split(/(?<=[.!?])\s+/).filter(Boolean);
    const visual = sentences.filter((sentence) => visualScore(sentence, "character") >= 1).slice(0, 2);
    if (visual.length) t = visual.join(" ");
    else t = sentences.slice(0, 2).join(" ") || t;

    // Hard ceiling even for cards with no labels. Past this point, image
    // models get less precise and we start feeding them prose they cannot draw.
    return clampWords(t, 48);
  }

  /** {{char}} and {{user}} are template placeholders. Left in, they reach the
   *  image model as literal braces. */
  function fill(text, names) {
    return String(text || "")
      .replace(/\{\{\s*char\s*\}\}/gi, names.char || "the character")
      .replace(/\{\{\s*user\s*\}\}/gi, names.user || "you");
  }

  /** Authors embed extra reference art in authorComment as markdown images. */
  function imagesFrom(markdown) {
    const out = [];
    const re = /!\[([^\]]*)\]\(([^)\s]+)/g;
    let m;
    while ((m = re.exec(String(markdown || "")))) {
      out.push({ label: m[1] || "reference", url: m[2] });
    }
    return out;
  }

  // ---------- build the sheet ----------

  /** @param payload the intercepted POST body for /api/chat */
  function fromPayload(payload) {
    const bot = payload.bot || {};
    const persona = payload.persona || {};
    const plot = payload.plot || {};
    const names = { char: bot.name || bot.chatname || "the character",
                    user: persona.name || "you" };

    return {
      sessionId: payload.sessionId,
      updatedAt: Date.now(),

      characters: {
        [names.char]: {
          name: names.char,
          appearance: fill(appearanceFrom(bot.description), names),
          portrait: bot.img_link || bot.imgsrc || null,
          role: "bot",
        },
        [names.user]: {
          name: names.user,
          appearance: fill(appearanceFrom(persona.description), names),
          portrait: persona.imglink || null,
          role: "user",
        },
      },

      // Keyed by lowercased trigger word. Filled from payload.lorebooks once
      // the entry shape is confirmed.
      lore: indexLorebooks(payload.lorebooks, names),

      album: {
        title: plot.title || bot.name || "Photobook",
        cover: plot.bglink || bot.bglink || null,
      },

      // Last-resort location only. plot describes the OPENING scene and goes
      // stale the moment the story moves; WHERE: in the thinking block is
      // regenerated every turn and always wins.
      fallbackLocation: fill(collapse(plot.introduction || plot.firstMessage || ""), names).slice(0, 300),

      extraRefs: imagesFrom(bot.authorComment),
    };
  }

  /** Real shape (verified against a live payload):
   *    lorebooks[].entries[] = { name, description, type, img_link,
   *                              keys: [{ keyText }] }
   *  keys are OBJECTS, not strings — treating them as strings yielded
   *  "[object Object]" and matched nothing, which is why lore never appeared. */
  function indexLorebooks(books, names) {
    const index = {};
    for (const book of books || []) {
      for (const entry of book.entries || []) {
        if (entry.hidden) continue;
        const text = loreText(entry.description, names, entry.type);
        if (!text) continue;
        const record = {
          entryName: entry.name || "",
          type: entry.type || "",          // "character" | "location"
          text,
          portrait: entry.img_link || null,
          weight: entry.weight || 0,
        };
        const keys = (entry.keys || []).map((k) =>
          typeof k === "string" ? k : k?.keyText).filter(Boolean);
        // The entry's own name is a trigger too ("Spite (Kellas's Horse)").
        for (const k of [...keys, firstWord(entry.name)]) {
          if (k) index[String(k).toLowerCase().trim()] = record;
        }
      }
    }
    return index;
  }

  function firstWord(name) {
    const m = String(name || "").match(/^[\w'\u2019]+/);
    return m ? m[0] : "";
  }

  // Words that describe how something LOOKS. Used to pick the drawable part of
  // a lore entry rather than trusting its first sentence — Brin's opens with
  // "longtime friend and occasional lover", which is history, not appearance.
  const VISUAL_WORDS = new Set([
    "tall", "short", "huge", "enormous", "massive", "small", "slender", "broad",
    "heavy", "heavily", "lean", "thin", "built", "muscled", "scarred", "scar",
    "hair", "eyes", "eye", "skin", "beard", "braid", "horns", "wings", "tail",
    "ears", "face", "jaw", "black", "white", "red", "blonde", "blond", "brown",
    "grey", "gray", "silver", "gold", "golden", "pale", "dark", "auburn",
    "copper", "green", "blue", "armor", "armour", "leathers", "cloak", "coat",
    "robes", "dress", "uniform", "boots", "sword", "blade", "axe", "bow",
    "tattoo", "tattoos", "piercing", "piercings", "eyeliner", "makeup", "smirk",
    "arms", "shoulders", "chest", "ribs", "lips", "mouth", "nose", "freckles",
    "warhorse", "horse", "hound", "dog", "wolf", "cat",
    "man", "woman", "warrior", "soldier", "knight", "beauty", "old", "young",
    "stallion", "mare", "beast", "creature", "winged", "clad", "wears",
  ]);

  // Places are drawable through different words than people are. "Lawless
  // territory dividing the Courts" is politics; "scarred tables, dirty floors"
  // is a picture. Scoring locations with the character list omitted them all.
  const PLACE_WORDS = new Set([
    "stone", "wood", "wooden", "timber", "walls", "wall", "floor", "floors",
    "roof", "ceiling", "beams", "rafters", "hearth", "fire", "fireplace",
    "torch", "torches", "lantern", "candle", "window", "windows", "door",
    "doors", "gate", "stairs", "narrow", "wide", "cramped", "vast", "crowded",
    "dirty", "filthy", "scarred", "worn", "old", "ruined", "abandoned",
    "dark", "dim", "smoky", "cold", "damp", "tables", "table", "benches",
    "bed", "furniture", "leather", "iron", "forest", "trees", "river", "road",
    "hills", "cliffs", "snow", "mud", "fields", "tents", "banners", "arches",
    "pillars", "courtyard", "yard", "stable", "stables", "pool", "bath",
    "cave", "tunnel", "cellar", "loft", "hall", "tavern", "barracks", "fort",
  ]);

  function visualScore(text, type) {
    const w = String(text).toLowerCase().match(/[a-z']+/g) || [];
    const list = type === "location" ? PLACE_WORDS : VISUAL_WORDS;
    let n = 0;
    for (const x of w) if (list.has(x)) n += 1;
    return n;
  }

  /** Lore prose carries markup meant for the writer, not an image model:
   *  underscore link markers (_Kellas), bold headers, and template tokens. */
  function loreText(description, names, type) {
    let t = fill(String(description || ""), names);
    t = t.replace(/\*\*([^*]+)\*\*/g, "$1")     // **Spite:** -> Spite:
         .replace(/(^|[\s(])_(?=[A-Za-z])/g, "$1") // _Kellas -> Kellas
         .replace(/^\s*[A-Z][\w'\u2019 ]{0,28}:\s*/, "") // drop leading "Spite:"
         .trim();
    // Search the WHOLE entry for the drawable sentence instead of trusting
    // position: appearance is often buried, and the opening is often history.
    const sentences = t.split(/(?<=[.!?])\s+/).filter((x) => x.trim().length > 8);
    let best = null;
    for (const sentence of sentences) {
      const score = visualScore(sentence, type);
      if (score >= 2 && (!best || score > best.score)) best = { sentence, score };
    }
    // Nothing drawable in the entry (pure personality, like Finn or Ronan) —
    // say nothing rather than describing a face from someone's temperament.
    if (!best) return "";

    return collapse(best.sentence)
      .replace(/,\s+(aptly|usually|which|who|after|though|because|since)\b.*$/i, "")
      .replace(/\s+(and|but)\s+[^,.]*$/i, "")
      .slice(0, 140);
  }

  /** Word-boundary lookup so "home"/"bath"/"horse" don't fire on substrings. */
  function loreFor(sheet, text, type) {
    const hay = " " + String(text || "").toLowerCase() + " ";
    let best = null;
    for (const [key, entry] of Object.entries(sheet.lore || {})) {
      if (key.length < 3) continue;
      if (type && entry.type !== type) continue;
      const re = new RegExp(`[^a-z0-9]${escapeRe(key)}[^a-z0-9]`, "i");
      if (!re.test(hay)) continue;
      if (!best || key.length > best.key.length) best = { key, entry };
    }
    return best ? best.entry : null;
  }

  function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  // ---------- scene mining ----------

  /** Pull WHO/WHERE/NOW from a reply's thinking block, then strip the block
   *  (and OOC notes) to leave the prose the condenser should read. The block
   *  is regenerated by the site every turn, so WHERE: is always current —
   *  unlike plot, which describes the opening scene and goes stale. */
  function mineScene(raw) {
    const text = String(raw || "");
    const block = text.match(/<thinking>([\s\S]*?)<\/thinking>/i);
    const scene = { who: [], where: "", now: "" };

    // The site renders the block as a "Thinking Process" widget with the tags
    // stripped, so mine the tagged block when present and fall back to
    // searching the whole text for the pipe-delimited header fields.
    const source = block ? block[1] : text;
    const field = (key) => {
      const m = source.match(new RegExp(`\\b${escapeRe(key)}:\\s*([^|\\n]+)`, "i"));
      return m ? m[1].trim() : "";
    };
    scene.who = field("WHO").split(/,\s*/).map((s) => s.trim()).filter(Boolean);
    scene.where = field("WHERE");
    scene.now = field("NOW");

    scene.pressure = field("PRESSURE");

    let visible = text
      .replace(/```?\s*<thinking>[\s\S]*?<\/thinking>\s*```?/gi, "")
      .replace(/<thinking>[\s\S]*?<\/thinking>/gi, "")
      .replace(/^\s*Thinking Process\s*(Show|Hide)?\s*$/gim, "")
      .replace(/^\s*(?:\[|\(\()[^\]\)]{0,200}(?:\]|\)\))\s*$/gm, "") // OOC lines
      .trim();

    // Structural pass: the site strips <thinking> tags and renders the block as
    // a widget, so tag removal alone leaves the template behind as plain text.
    // This finds where prose begins instead, and needs no template knowledge.
    visible = PromptCondenser.stripInstructions(visible);

    return { scene, visible };
  }

  // ---------- assemble the prompt ----------

  /**
   * @param sheet      from fromPayload()
   * @param scene      {who[], where, now} mined from the thinking block
   * @param moment     a candidate from PromptCondenser.condense()
   * @param style      house style string
   * @param states     {name: sentence} — each character's current pose/situation
   *
   * Pose and context outrank everything else: a right-looking character in the
   * wrong position is a worse picture than the reverse. So NOW: (which nearly
   * always states everyone's situation) joins the context, each character line
   * carries a "Right now" clause, and Context sits above Location.
   */
 function buildPrompt(sheet, scene, moment, style, states = {}, interaction = null) {
    const cast = (scene.who || []).length
      ? scene.who
      : Object.keys(sheet.characters);

    const lines = [];
    let interactionLead = "";
    let interactionLooks = "";
    const castCount = cast.length;
    lines.push(castCount === 1
      ? "Create an image of this character."
      : "Create an image of these characters.");
    lines.push("");

    if (interaction && interaction.text) {
      interactionLead = interaction.text;
      const looks = [];
      for (const c of Object.values(sheet.characters || {})) {
        if (!c.name || !c.appearance) continue;
        const first = String(c.name).split(/\s+/)[0];
        if (!new RegExp(`\\b${first.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i")
              .test(interaction.text)) continue;
        looks.push(`${first}: ${clampWords(c.appearance, 12)}`);
      }
      interactionLooks = looks.join(". ");
    }

    const used = new Set(); // never say the same sentence twice

    // Someone with no description anywhere would be drawn as an invented
    // stranger, so they become scene detail instead of a listed character.
    const described = [];
    const extras = [];
    for (const name of cast) {
      const c = lookupCharacter(sheet, name);
      const lore = c ? null : loreFor(sheet, name, null);
      const appearance = c?.appearance || lore?.text || "";
      if (appearance) {
        described.push({ name, appearance, state: states[name],
                         role: c ? c.role : "side" });
      }
      else if (states[name]) extras.push({ name, state: states[name] });
    }

    // Budgets keep the leads dominant. A side character described at the same
    // length as the protagonists steals attention from them, and a long prompt
    // dilutes everything — so extras get a dozen words and a hard count cap.
    const LEAD_POSE_WORDS = 20;
    const SIDE_APPEARANCE_WORDS = 10;
    const SIDE_POSE_WORDS = 7;
    const MAX_SIDE = 2;

    const leads = described.filter((p) => p.role !== "side");
    const sides = described.filter((p) => p.role === "side").slice(0, MAX_SIDE);

    lines.push("Characters:");
    for (const p of leads) {
      let line = `- ${p.name} — ${promptAppearance(p.appearance)}`;
      if (p.state && !used.has(p.state)) {
        if (!/[.!?]$/.test(line)) line += ".";
        line += ` Right now: ${clampWords(p.state, LEAD_POSE_WORDS)}`;
        used.add(p.state);
      }
      lines.push(line);
    }
    for (const p of sides) {
      let line = `- ${p.name} — ${clampWords(p.appearance, SIDE_APPEARANCE_WORDS)}`;
      if (p.state && !used.has(p.state)) {
        line += `, ${clampWords(p.state, SIDE_POSE_WORDS)}`;
        used.add(p.state);
      }
      lines.push(line);
    }
    lines.push("");

    if (extras.length) {
      lines.push("Also in frame: " + extras.slice(0, MAX_SIDE)
        .map((e) => clampWords(e.name + " (" + e.state.replace(/\.$/, "") + ")",
                               SIDE_POSE_WORDS + 3) + ")").join("; ")
        .replace(/\)\)/g, ")"));
      lines.push("");
      for (const e of extras) used.add(e.state);
    }

    const dot = (s) => (/[.!?\u2026]$/.test(s.trim()) ? s.trim() : s.trim() + ".");
    const ctxParts = [];
    if (scene.userAction) { ctxParts.push(dot(scene.userAction)); used.add(scene.userAction); }
    if (scene.now && !used.has(scene.now)) { ctxParts.push(dot(scene.now)); used.add(scene.now); }
    
    const norm = (t) => String(t).toLowerCase().replace(/[^a-z0-9 ]+/g, " ")
      .replace(/\s+/g, " ").trim();
    const alreadySaid = (t) => {
      const a = norm(t);
      if (!a) return true;
      for (const prev of used) {
        const b = norm(prev);
        if (!b) continue;
        if (b.includes(a) || a.includes(b)) return true;
      }
      return false;
    };
    if (moment?.subject && !alreadySaid(moment.subject)) {
      ctxParts.push(dot(moment.subject));
      used.add(moment.subject);
    }
    if (ctxParts.length) {
      let ctx = ctxParts.join(" ");
      const CTX_WORDS = 55;
      const words = ctx.split(/\s+/);
      if (words.length > CTX_WORDS) {
        ctx = words.slice(0, CTX_WORDS).join(" ").replace(/[,;:]$/, "") + "…";
      }
      lines.push(`Context: ${interactionLead ? `${interactionLead}. ${ctx}` : ctx}`);
      lines.push("");
      if (interactionLooks) { lines.push(interactionLooks); lines.push(""); }
      interactionLead = "";
      interactionLooks = "";
    }

    if (interactionLead) {
      lines.push(`Context: ${interactionLead}`);
      lines.push("");
      if (interactionLooks) { lines.push(interactionLooks); lines.push(""); }
      interactionLead = "";
    }

    const where = scene.where || sheet.fallbackLocation;
    if (where) {
      const lore = matchLore(sheet, where);
      const time = scene.time ? ` (${scene.time})` : "";
      lines.push(`Location: ${where}${time}${lore ? ` — ${lore}` : ""}`);
      lines.push("");
    }

    if (moment?.lighting?.length) {
      lines.push(`Lighting: ${moment.lighting.join(", ")}`);
      lines.push("");
    }

    if (scene.weather && scene.weather !== "clear") {
      lines.push(`Weather: ${scene.weather}`);
      lines.push("");
    }

    if (scene.props?.length) {
      lines.push(`Objects in the scene: ${scene.props.join(", ")}`);
      lines.push("");
    }

    if (scene.mood) {
      const m = PromptCondenser.MOOD_TEXT[scene.mood];
      if (m) {
        lines.push(`Mood: ${m.say}${scene.pressure ? ` (${scene.pressure})` : ""}`);
        if (m.deny) lines.push(m.deny);
        lines.push("");
      }
    }

    if (style) lines.push(`Style: ${style}`);

    return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  /** Trim to N words on a word boundary, no trailing punctuation stub. */
  function clampWords(text, n) {
    const w = String(text).trim().split(/\s+/);
    if (w.length <= n) return String(text).trim();
    let out = w.slice(0, n);
    // Drop trailing function words so a trimmed line doesn't end on "for".
    while (out.length && /^(for|and|but|the|a|an|with|of|to|in|on|at|as|before|while|that|his|her|their)$/i
             .test(out[out.length - 1])) out.pop();
    return out.join(" ").replace(/[,;:]$/, "");
  }

  /** Cards use full names, chat uses short ones ("Kellas Jarveth" / "Kellas"). */
  function lookupCharacter(sheet, name) {
    const chars = sheet.characters || {};
    if (chars[name]) return chars[name];
    const needle = String(name).toLowerCase();
    return Object.values(chars).find((c) => {
      const n = String(c.name).toLowerCase();
      return n.startsWith(needle) || needle.startsWith(n.split(" ")[0]);
    }) || null;
  }

  /** Lorebooks are keyword-triggered, so this is a lookup, not fuzzy matching. */
  function matchLore(sheet, text) {
    const hit = loreFor(sheet, text, "location") || loreFor(sheet, text, null);
    return hit ? hit.text : "";
  }

  return { fromPayload, buildPrompt, mineScene, appearanceFrom, fill, imagesFrom, matchLore, loreFor };
})();

if (typeof module !== "undefined" && module.exports) module.exports = Sheet;
