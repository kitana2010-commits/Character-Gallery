// backdrop.js — "snapscapes": the moment you just captured becomes the
// backdrop of the chat.

(() => {
  const SESSION_RE = /\/app\/session\/([0-9a-f-]{36})/i;
  const session = () => (location.pathname.match(SESSION_RE) || [])[1] || null;

  const ON_KEY = "djpbBackdropOn";
  let pinned = false;        // is a specific photo being held for this chat?
  const DIM_KEY = "djpbBackdropDim";

  const alive = () => {
    try { return Boolean(chrome.runtime?.id); } catch { return false; }
  };

  let enabled = true;
  let fxOn = true;          // weather animations
  let dim = 0.35;            // how much to darken; the text has its own panel
  let layer = null;
  let currentId = null;
  let currentDataUrl = null;
  let backdropRequest = 0;
  let currentConditions = {};
  let currentManualEffects = null; // null = session follows auto detection
  let fxPrefSession = null;
  let fxSessionManual; // undefined = not loaded, null = auto, object = custom
  let timer = null;
  let styleTag = null;

  let cachedDataUrl = null;
  let cachedCandidates = null;
  let themeRequest = 0;
  let colorThemeEnabled = readThemeNumber("djpb_color_theme", 1, 0, 1) !== 0;

  // Keep the donor's preference keys, including explicit zero opacity/position.
  function readThemeNumber(key, fallback, min, max) {
    try {
      const raw = localStorage.getItem(key);
      const value = raw === null || raw.trim() === "" ? fallback : Number(raw);
      return Number.isFinite(value) ? Math.max(min, Math.min(max, value)) : fallback;
    } catch { return fallback; }
  }

  function saveThemeNumber(key, value) {
    try { localStorage.setItem(key, String(value)); } catch { /* session only */ }
  }

  function syncDefaultComposer(opacityVal) {
    const useDefault = enabled && !colorThemeEnabled && Boolean(session());
    document.documentElement.classList.toggle("djpb-default-theme", useDefault);
    if (useDefault) {
      const opacity = opacityVal !== undefined && opacityVal !== null
        ? Math.max(0, Math.min(0.9, Number(opacityVal) || 0))
        : readThemeNumber("djpb_chat_opacity", 0.35, 0, 0.9);
      document.documentElement.style.setProperty("--djpb-default-opacity", String(opacity));
    } else {
      document.documentElement.style.removeProperty("--djpb-default-opacity");
    }
  }

  // =========================================================================
  // COLOR VIBRANCY & CHAT OPACITY ENGINE
  // =========================================================================

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h, s, l };
  }

  function hslToRgb(h, s, l) {
    let r, g, b;
    if (s === 0) { r = g = b = l; } else {
      const hue2rgb = (p, q, t) => {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1/6) return p + (q - p) * 6 * t;
        if (t < 1/2) return q;
        if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
        return p;
      };
      const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
      const p = 2 * l - q;
      r = hue2rgb(p, q, h + 1/3);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1/3);
    }
    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
  }

  function applyChatOpacity(opacityVal) {
    syncDefaultComposer(opacityVal);
    let styleEl = document.getElementById("djpb-opacity-style");
    if (!enabled || !currentDataUrl || !document.documentElement.classList.contains("djpb-bd-on")) {
      styleEl?.remove();
      return;
    }
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "djpb-opacity-style";
      (document.head || document.documentElement).appendChild(styleEl);
    }
    const val = opacityVal !== undefined && opacityVal !== null
      ? Math.max(0, Math.min(0.9, Number(opacityVal) || 0))
      : readThemeNumber("djpb_chat_opacity", 0.35, 0, 0.9);

    styleEl.textContent = `
      html.djpb-bd-on :is(.scrollchatmessages, [id^="message-"], form.chatform),
      html.djpb-bd-on :is(.scrollchatmessages, [id^="message-"], form.chatform) *:not([data-djpb-ui], [data-djpb-ui] *) {
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
      }
      
      /* 1. Make chat scroll area and outer message wrappers 100% transparent */
      html.djpb-bd-on .scrollchatmessages,
      html.djpb-bd-on :is(main, .chatclientclass) :is(div, section, article):has(.scrollchatmessages, [id^="message-"]):not([data-djpb-ui], [data-djpb-ui] *, [role="dialog"], [role="dialog"] *),
      html.djpb-bd-on :is(main, .chatclientclass) [id^="message-"],
      html.djpb-bd-on .scrollchatmessages div[class*="group"] {
        background-color: transparent !important;
        background: transparent !important;
        background-image: none !important;
        box-shadow: none !important;
      }

/* Target ONLY the inner text bubble with flat color/gradient (NO blur) */
      html.djpb-bd-on :is(main, .chatclientclass) div[id^="message-"] div:has(> .markdown),
      html.djpb-bd-on :is(main, .chatclientclass) div[class*="group"] div:has(> .markdown),
      html.djpb-bd-on .scrollchatmessages [class*="backdrop-blur"]:not([data-djpb-ui], [data-djpb-ui] *) {
        background: linear-gradient(135deg, rgba(var(--djpb-c1-rgb, 15, 10, 25), ${val}), rgba(var(--djpb-c2-rgb, 15, 10, 25), ${val})) !important;
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
      }

      /* Main Chat Input Bar Container */
      form.chatform {
        background: linear-gradient(135deg, rgba(var(--djpb-c1-rgb, 15, 10, 25), ${val}), rgba(var(--djpb-c2-rgb, 15, 10, 25), ${val})) !important;
        border-color: rgba(var(--djpb-c1-rgb, 139, 92, 246), 0.35) !important;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.12) !important;
      }

      /* Inner Message Textarea */
      form.chatform textarea.submittextarea {
        background: rgba(0, 0, 0, 0.35) !important;
        border-color: rgba(var(--djpb-c1-rgb, 139, 92, 246), 0.25) !important;
        color: #e9e4f5 !important;
      }

      /* Keep the message toolbar transparent; retain the current avatar layout. */
      html.djpb-bd-on .scrollchatmessages div.items-center.gap-x-2.w-full {
        background: transparent !important;
        background-color: transparent !important;
        background-image: none !important;
        box-shadow: none !important;
      }
    `;
  }

  function extractCandidatesFromImage(dataUrl) {
    return new Promise((resolve) => {
      const img = new Image();
      if (!dataUrl.startsWith("data:")) img.crossOrigin = "Anonymous";
      img.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          const ctx = canvas.getContext("2d");
          canvas.width = 50; canvas.height = 50;
          ctx.drawImage(img, 0, 0, 50, 50);
          const pixels = ctx.getImageData(0, 0, 50, 50).data;

          const candidates = [];
          for (let y = 0; y < 50; y++) {
            for (let x = 0; x < 50; x++) {
              const i = (y * 50 + x) * 4;
              if (pixels[i + 3] < 128) continue;
              const r = pixels[i], g = pixels[i + 1], b = pixels[i + 2];
              const hsl = rgbToHsl(r, g, b);
              if (hsl.l < 0.08 || hsl.l > 0.92) continue;
              const weight = 1 + Math.pow(hsl.s, 2) * 8;
              candidates.push({ ...hsl, weight });
            }
          }
          resolve({ candidates });
        } catch { resolve({ candidates: [] }); }
      };
      img.onerror = () => resolve({ candidates: [] });
      img.src = dataUrl;
    });
  }

  async function applyDynamicTheme(dataUrl) {
    syncDefaultComposer();
    const request = ++themeRequest;
    let styleEl = document.getElementById("djpb-dynamic-theme");
    if (!dataUrl || !colorThemeEnabled) {
      styleEl?.remove();
      cachedDataUrl = null;
      cachedCandidates = null;
      document.documentElement.style.removeProperty('--djpb-c1-rgb');
      document.documentElement.style.removeProperty('--djpb-c2-rgb');
      // Default colors still support the user's chat opacity and backdrop.
      if (dataUrl) applyChatOpacity();
      else document.getElementById("djpb-opacity-style")?.remove();
      return;
    }

    if (dataUrl !== cachedDataUrl || !cachedCandidates) {
      const res = await extractCandidatesFromImage(dataUrl);
      if (request !== themeRequest || !enabled || !colorThemeEnabled || currentDataUrl !== dataUrl) return;
      cachedDataUrl = dataUrl;
      cachedCandidates = res.candidates;
    }

    if (request !== themeRequest || !enabled || !colorThemeEnabled || currentDataUrl !== dataUrl) return;

    const vibrancyBoost = readThemeNumber("djpb_vibrancy", 1.8, 0.1, 4);

    let vivid = (cachedCandidates || []).filter(c => c.s >= 0.05);
    if (vivid.length < 5) vivid = cachedCandidates || [];

    let c1, c2;
    if (!vivid.length) {
      c1 = { r: 139, g: 92, b: 246 };
      c2 = { r: 236, g: 72, b: 153 };
    } else {
      vivid.sort((a, b) => b.weight - a.weight);
      const processHsl = (cand, boost) => {
        let newS = Math.min(1.0, Math.max(0.0, cand.s * boost));
        if (boost > 1.0 && cand.s < 0.3) newS = Math.min(1.0, newS + (boost - 1.0) * 0.15);
        let newL = Math.min(0.70, Math.max(0.35, cand.l));
        return hslToRgb(cand.h, newS, newL);
      };

      const top1 = { ...vivid[0] };
      c1 = processHsl(top1, vibrancyBoost);

      let top2 = top1;
      for (let i = 1; i < vivid.length; i++) {
        const hueDistance = Math.abs(top1.h - vivid[i].h);
        if (Math.min(hueDistance, 1 - hueDistance) > 0.10) {
          top2 = { ...vivid[i] };
          break;
        }
      }
      c2 = processHsl(top2, vibrancyBoost);
    }

    document.documentElement.style.setProperty('--djpb-c1-rgb', `${c1.r}, ${c1.g}, ${c1.b}`);
    document.documentElement.style.setProperty('--djpb-c2-rgb', `${c2.r}, ${c2.g}, ${c2.b}`);

    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "djpb-dynamic-theme";
      (document.head || document.documentElement).appendChild(styleEl);
    }

    const cardBg = `rgb(${Math.round(c1.r * 0.22 + 8)}, ${Math.round(c1.g * 0.22 + 8)}, ${Math.round(c1.b * 0.22 + 8)})`;
    const insetBg = `rgb(${Math.round(c1.r * 0.14 + 4)}, ${Math.round(c1.g * 0.14 + 4)}, ${Math.round(c1.b * 0.14 + 4)})`;
    const primaryGrad = `linear-gradient(135deg, rgb(${c1.r}, ${c1.g}, ${c1.b}), rgb(${c2.r}, ${c2.g}, ${c2.b}))`;
    const borderAccent = `rgba(${c1.r}, ${c1.g}, ${c1.b}, 0.45)`;
    const secBorder = `rgba(${c2.r}, ${c2.g}, ${c2.b}, 0.5)`;
    const accentColor = `rgb(${c2.r}, ${c2.g}, ${c2.b})`;
    const glowShadow = `0 2px 14px rgba(${c1.r}, ${c1.g}, ${c1.b}, 0.45)`;

    styleEl.textContent = `
      /* Toolbar & Floating Buttons */
      #djpb-snap-pill,
      #djpb-bd-toggle:not(.off),
      .djpb-primary {
        background: ${primaryGrad} !important;
        box-shadow: ${glowShadow} !important;
      }

      #djpb-bd-fx-toggle,
      #djpb-bd-solo-toggle {
        border-color: ${borderAccent} !important;
        background: ${insetBg} !important;
      }

      /* Popover Cards & Container Panels */
      #djpb-bd-menu,
      #djpb-snap,
      #djpb-fx-panel {
        background: ${cardBg} !important;
        border-color: ${borderAccent} !important;
      }

      /* Global Dynamic Inputs (Scene Effects & Scape Menu) */
      #djpb-fx-panel input[type="range"],
      #djpb-bd-menu input[type="range"],
      .djpb-slider-group input[type="range"] {
        accent-color: ${accentColor} !important;
      }

      #djpb-fx-panel input[type="checkbox"],
      #djpb-bd-menu input[type="checkbox"],
      .djpb-appear-master input,
      .djpb-appear-chip input,
      .djpb-refchip input,
      .djpb-details-master input {
        accent-color: ${accentColor} !important;
      }

      /* Appearance & Ref Chips */
      .djpb-appear-master,
      .djpb-appear-chip,
      .djpb-refchip {
        background: ${insetBg} !important;
        border-color: ${borderAccent} !important;
        color: #efe7ff !important;
      }

      /* Ref Action Buttons */
      .djpb-refalbum {
        background: linear-gradient(135deg, rgba(${c1.r}, ${c1.g}, ${c1.b}, 0.8), rgba(${c2.r}, ${c2.g}, ${c2.b}, 0.8)) !important;
        border: 1px solid rgba(255, 255, 255, 0.25) !important;
        color: #ffffff !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4) !important;
      }

      /* Scene Details Button */
      .djpb-details-btn {
        border-color: ${secBorder} !important;
        color: #e9e4f5 !important;
      }
      .djpb-details-btn.has {
        background: rgba(${c2.r}, ${c2.g}, ${c2.b}, 0.22) !important;
        border-color: ${accentColor} !important;
      }

      .djpb-slider-group {
        background: ${insetBg} !important;
        border-color: ${borderAccent} !important;
      }

    `;

    applyChatOpacity();
  }

  // ---------- the layer ----------

  function ensureLayer() {
    if (layer?.isConnected) return layer;
    layer = document.createElement("div");
    layer.id = "djpb-backdrop";
    layer.dataset.djpbUi = "1";
    layer.innerHTML =
      '<div class="djpb-bd-img" data-slot="a"></div>' +
      '<div class="djpb-bd-img" data-slot="b"></div>' +
      '<div class="djpb-bd-scrim"></div>';
    const host = document.body || document.documentElement;
    host.insertBefore(layer, host.firstChild);
    applyDim();
    return layer;
  }

  const cleared = [];   // [{el, prev}]

  function coversViewport(el) {
    const r = el.getBoundingClientRect();
    return r.width >= innerWidth * 0.9 && r.height >= innerHeight * 0.9;
  }

  function isSolid(el) {
    const bg = getComputedStyle(el).backgroundColor || "";
    if (!bg || bg === "transparent") return false;
    const m = bg.match(/rgba?\(([^)]+)\)/);
    if (!m) return true;
    const parts = m[1].split(",").map((n) => parseFloat(n));
    const alpha = parts.length > 3 ? parts[3] : 1;
    return alpha > 0.05;
  }

  function openWindow() {
    document.documentElement.classList.add("djpb-bd-on");

    for (const el of [document.documentElement, document.body]) {
      if (el && isSolid(el) && !cleared.some((c) => c.el === el)) {
        cleared.push({ el, prev: el.style.backgroundColor || "" });
        el.style.setProperty("background-color", "transparent", "important");
      }
    }

    let level = document.body ? [...document.body.children] : [];
    for (let depth = 0; depth < 6 && level.length; depth++) {
      const next = [];
      for (const el of level) {
        if (el.dataset?.djpbUi || el.id === "djpb-backdrop") continue;
        if (!coversViewport(el)) continue;
        if (isSolid(el) && !cleared.some((c) => c.el === el)) {
          cleared.push({ el, prev: el.style.backgroundColor || "" });
          el.style.setProperty("background-color", "transparent", "important");
        }
        next.push(...el.children);
      }
      level = next;
    }
  }

  function closeWindow() {
    backdropRequest++;
    currentDataUrl = null;
    applyDynamicTheme(null);
    closePinMenu();
    document.documentElement.classList.remove("djpb-bd-on");
    for (const { el, prev } of cleared) {
      if (prev) el.style.setProperty("background-color", prev);
      else el.style.removeProperty("background-color");
    }
    cleared.length = 0;
    styleTag?.remove();
    styleTag = null;
    layer?.remove();
    layer = null;
    currentId = null;
    currentConditions = {};
    currentManualEffects = null;
    closeEffectsPanel();
    document.getElementById("djpb-fx")?.remove();
    fxSignature = "";
  }

  // =========================================================================
  // SCENE & WEATHER EFFECTS ENGINE
  // =========================================================================

  // --- Effect Definitions & CSS Class Mappings ---
  const EFFECTS = {
    rain:      ["djpb-fx-rain"],
    lightning: ["djpb-fx-lightning"],
    snow:      ["djpb-fx-snow"],
    fog:       ["djpb-fx-smoke"],
    embers:    ["djpb-fx-embers"],
    fireflies: ["djpb-fx-fireflies"],
    petals:    ["djpb-fx-petals"],
    lilacs:    ["djpb-fx-lilacs"],
    vignette:  ["djpb-fx-vignette"],
    sunlight:  ["djpb-fx-sunlight"],
  };

  // --- Effect Control Panel Options ---
  const FX_OPTIONS = [
    { key: "rain", label: "Rain" },
    { key: "lightning", label: "Lightning" },
    { key: "snow", label: "Snow" },
    { key: "fog", label: "Fog" },
    { key: "embers", label: "Embers" },
    { key: "fireflies", label: "Fireflies" },
    { key: "petals", label: "Petals" },
    { key: "lilacs", label: "Lilacs" },
    { key: "vignette", label: "Darkness" },
    { key: "sunlight", label: "Sunlight" },
  ];

  // --- Auto-Detection Rules ---
function autoEffectNames(conditions = {}) {
    const names = [];
    if (conditions.weather === "rain") names.push("rain", "lightning");
    else if (conditions.weather === "snow") names.push("snow");
    else if (conditions.weather === "fog") names.push("fog");
    else if (conditions.fire) names.push("embers");
    else if (conditions.fireflies) names.push("fireflies");

    if (conditions.romance) names.push("petals");
    else if (conditions.garden) names.push("lilacs");

    const where = String(conditions.where || "");

    // 1. Darkness: Nighttime, dark flag, or enclosed/subterranean locations
    const isDarkLocation = /tunnel|cave|dungeon|cellar|basement|sewer|underground|abyss|vault|crypt|catacomb/i.test(where);
    if (conditions.time === "night" || conditions.dark || isDarkLocation) {
      names.push("vignette");
    }

    // 2. Sunlight: Daytime/bright AND verified outdoor locations
    const isOutdoorLocation = /outside|outdoor|forest|woods|field|beach|park|street|road|courtyard|garden|meadow|mountain|valley|clearing|patio|balcony|deck|roof|rooftop|sky|river|lake|ocean|desert|jungle|camp/i.test(where);
    const isIndoorLocation = /room|house|building|hall|office|bedroom|kitchen|living|cabin|tavern|inn|pub|shop|castle|interior|inside|hospital|apartment|dungeon|cellar|basement/i.test(where);

    const isDaytime = conditions.time === "day" || conditions.bright;
    const isKnownOutdoors = isOutdoorLocation || (conditions.outdoor && !isIndoorLocation);

    if (isDaytime && isKnownOutdoors) {
      names.push("sunlight");
    }

    return names;
  }

  // --- Intensity Scaling Helpers ---
  const DEFAULT_INTENSITY = 3;
  const MIN_INTENSITY = 1;
  const MAX_INTENSITY = 4;

  const clampIntensity = (value) => {
    const n = Number(value);
    if (!Number.isFinite(n)) return DEFAULT_INTENSITY;
    return Math.max(MIN_INTENSITY, Math.min(MAX_INTENSITY, Math.round(n)));
  };

  const dense = (small, mid, big) => (innerWidth < 600 ? small : innerWidth < 1100 ? mid : big);
  const countScale = (level) => ({ 1: 0.85, 2: 1.15, 3: 1.6, 4: 2.25 }[clampIntensity(level)] || 1);
  const sizeScale = (level) => ({ 1: 0.92, 2: 1.04, 3: 1.18, 4: 1.34 }[clampIntensity(level)] || 1);
  const durationScale = (level) => ({ 1: 1.08, 2: 0.96, 3: 0.84, 4: 0.72 }[clampIntensity(level)] || 1);
  const opacityScale = (level) => ({ 1: 0.85, 2: 1.04, 3: 1.22, 4: 1.44 }[clampIntensity(level)] || 1);
  const clampAlpha = (value) => Math.max(0.06, Math.min(1, value));
  const scaledDense = (level, small, mid, big) => Math.max(1, Math.round(dense(small, mid, big) * countScale(level)));

  // --- Color Palettes ---
  const PALETTES = {
    petals: [
      "radial-gradient(ellipse at 30% 25%, #b01530 0%, #6a0815 55%, #2a0610 95%)",
      "radial-gradient(ellipse at 30% 25%, #c01a35 0%, #7a1020 55%, #2a0610 95%)",
      "radial-gradient(ellipse at 30% 25%, #8b1428 0%, #4a0815 55%, #1a0408 95%)",
      "radial-gradient(ellipse at 30% 25%, #d62848 0%, #8b1428 55%, #3a0810 95%)",
    ],
    lilacs: [
      "radial-gradient(ellipse at 30% 25%, #d4b8e3 0%, #9b7dac 55%, #4a3a5a 95%)",
      "radial-gradient(ellipse at 30% 25%, #c9a8db 0%, #886a9d 55%, #3a2d4a 95%)",
      "radial-gradient(ellipse at 30% 25%, #b89bce 0%, #715a87 55%, #2d2238 95%)",
      "radial-gradient(ellipse at 30% 25%, #e0c8ec 0%, #a88cc0 55%, #5a4870 95%)",
    ],
    embers: [
      "radial-gradient(circle, #ffe080 0%, #ff9030 38%, #c04018 78%, transparent 100%)",
      "radial-gradient(circle, #ffd060 0%, #ff7028 40%, #a03010 82%, transparent 100%)",
      "radial-gradient(circle, #ffa040 0%, #d04010 48%, #601808 88%, transparent 100%)",
      "radial-gradient(circle, #ff5020 0%, #a03012 50%, #401808 90%, transparent 100%)",
    ],
    smoke: [
      "radial-gradient(circle, rgba(155,150,142,0.48) 0%, rgba(155,150,142,0.22) 40%, transparent 75%)",
      "radial-gradient(circle, rgba(130,128,124,0.42) 0%, rgba(130,128,124,0.20) 42%, transparent 78%)",
      "radial-gradient(circle, rgba(170,160,145,0.45) 0%, rgba(170,160,145,0.21) 45%, transparent 80%)",
      "radial-gradient(circle, rgba(108,106,102,0.40) 0%, rgba(108,106,102,0.18) 42%, transparent 76%)",
    ],
  };

  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  // --- Dynamic Particle & Animation Generators ---
  let lightningTimer = null;

  function buildRain(host, level = DEFAULT_INTENSITY) {
    host.innerHTML = "";
    const count = Math.max(8, Math.round((innerWidth < 600 ? 35 : innerWidth < 1100 ? 60 : 90) * countScale(level)));
    host.style.opacity = clampAlpha({ 1: 0.86, 2: 0.97, 3: 1, 4: 1 }[clampIntensity(level)] || 1).toFixed(2);
    for (let i = 0; i < count; i++) {
      const drop = document.createElement("div");
      drop.className = "drop";
      const width = 1.2 * ({ 1: 0.96, 2: 1.08, 3: 1.24, 4: 1.42 }[clampIntensity(level)] || 1);
      const duration = (Math.random() * 0.5 + 0.55) * ({ 1: 1.08, 2: 0.96, 3: 0.84, 4: 0.72 }[clampIntensity(level)] || 1);
      drop.style.left = Math.random() * 100 + "%";
      drop.style.width = width.toFixed(2) + "px";
      drop.style.height = ((Math.random() * 28 + 14) * ({ 1: 0.94, 2: 1.08, 3: 1.24, 4: 1.42 }[clampIntensity(level)] || 1)).toFixed(2) + "px";
      drop.style.animationDuration = duration.toFixed(2) + "s";
      drop.style.animationDelay = (Math.random() * 2) + "s";
      drop.style.opacity = clampAlpha((Math.random() * 0.5 + 0.5) * opacityScale(level)).toFixed(2);
      host.appendChild(drop);
    }
  }

  function startLightning(el, level = DEFAULT_INTENSITY) {
    clearTimeout(lightningTimer);
    const lvl = clampIntensity(level);
    const peak = ({ 1: 0.72, 2: 0.92, 3: 1, 4: 1 }[lvl] || 0.92).toString();
    const second = ({ 1: 0.5, 2: 0.76, 3: 0.88, 4: 1 }[lvl] || 0.76).toString();
    const brightness = ({ 1: 0.96, 2: 1.04, 3: 1.14, 4: 1.24 }[lvl] || 1.04).toString();
    el.style.setProperty("--djpb-lightning-peak", peak);
    el.style.setProperty("--djpb-lightning-second", second);
    el.style.setProperty("--djpb-lightning-brightness", brightness);
    const delayRanges = {
      1: [18000, 26000],
      2: [11000, 20000],
      3: [7000, 14000],
      4: [4500, 9000],
    };
    const [base, span] = delayRanges[lvl] || delayRanges[2];
    const next = () => {
      lightningTimer = setTimeout(() => {
        if (!el.isConnected) return;
        el.classList.add("flashing");
        setTimeout(() => el.classList.remove("flashing"), 2400);
        next();
      }, base + Math.random() * span);
    };
    next();
  }

  const BUILDERS = {
    "djpb-fx-rain": (host, level = DEFAULT_INTENSITY) => buildRain(host, level),
    "djpb-fx-lightning": (host, level = DEFAULT_INTENSITY) => startLightning(host, level),
    "djpb-fx-snow": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 40, 60, 80); i++) {
        const f = document.createElement("div");
        f.className = "flake";
        const dur = (9 + Math.random() * 12) * durationScale(level);
        const size = (2 + Math.random() * 5) * sizeScale(level);
        f.style.cssText =
          `left:${Math.random() * 100}%;width:${size}px;height:${size}px;` +
          `opacity:${clampAlpha((0.5 + Math.random() * 0.5) * opacityScale(level)).toFixed(2)};` +
          `filter:blur(${size < 3 ? "0.6px" : "0"});` +
          `animation: djpb-snow-fall ${dur}s linear ${-Math.random() * dur}s infinite;`;
        host.appendChild(f);
      }
    },
    "djpb-fx-smoke": (host, level = DEFAULT_INTENSITY) => {
      host.style.opacity = clampAlpha({ 1: 0.82, 2: 0.96, 3: 1, 4: 1 }[clampIntensity(level)] || 1).toFixed(2);
      for (let i = 0; i < scaledDense(level, 6, 10, 14); i++) {
        const w = document.createElement("div");
        w.className = "wisp";
        const dur = (40 + Math.random() * 30) * ({ 1: 1.1, 2: 0.98, 3: 0.88, 4: 0.78 }[clampIntensity(level)] || 1);
        const size = (320 + Math.random() * 250) * ({ 1: 0.88, 2: 1.04, 3: 1.22, 4: 1.38 }[clampIntensity(level)] || 1);
        w.style.cssText =
          `left:${Math.random() * 100}%;width:${size}px;height:${size}px;` +
          `background:${pick(PALETTES.smoke)};` +
          `animation: djpb-smoke-billow ${dur}s linear ${-Math.random() * dur}s infinite;`;
        host.appendChild(w);
      }
    },
    "djpb-fx-fireflies": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 14, 20, 26); i++) {
        const f = document.createElement("div");
        f.className = "firefly";
        const size = (3 + Math.random() * 3) * sizeScale(level);
        const drift = (22 + Math.random() * 18) * ({ 1: 1.06, 2: 0.96, 3: 0.86, 4: 0.76 }[clampIntensity(level)] || 1);
        const pulse = (3 + Math.random() * 4) * ({ 1: 1.1, 2: 0.96, 3: 0.84, 4: 0.74 }[clampIntensity(level)] || 1);
        f.style.cssText =
          `left:${Math.random() * 100}%;top:${10 + Math.random() * 75}%;` +
          `width:${size}px;height:${size}px;` +
          `animation: djpb-firefly-drift ${drift}s ease-in-out ${-Math.random() * drift}s infinite,` +
          ` djpb-firefly-pulse ${pulse}s ease-in-out ${-Math.random() * pulse}s infinite;`;
        host.appendChild(f);
      }
    },
    "djpb-fx-embers": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 18, 26, 34); i++) {
        const e = document.createElement("div");
        e.className = "ember";
        const dur = (11 + Math.random() * 10) * ({ 1: 1.08, 2: 0.96, 3: 0.84, 4: 0.72 }[clampIntensity(level)] || 1);
        const size = (3 + Math.random() * 4) * ({ 1: 0.9, 2: 1.08, 3: 1.26, 4: 1.44 }[clampIntensity(level)] || 1);
        e.style.cssText =
          `left:${Math.random() * 100}%;width:${size}px;height:${size}px;` +
          `background:${pick(PALETTES.embers)};` +
          `box-shadow: 0 0 ${size * (2 + 0.45 * clampIntensity(level))}px rgba(255, 130, 40, ${Math.min(0.95, 0.34 + 0.15 * clampIntensity(level))});` +
          `animation: djpb-ember-rise ${dur}s linear ${-Math.random() * (dur + 4)}s infinite;`;
        host.appendChild(e);
      }
    },
    "djpb-fx-petals": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 10, 14, 18); i++) {
        const p = document.createElement("div");
        p.className = "petal";
        const dur = (13 + Math.random() * 10) * ({ 1: 1.08, 2: 0.96, 3: 0.86, 4: 0.78 }[clampIntensity(level)] || 1);
        const size = (12 + Math.random() * 10) * ({ 1: 0.92, 2: 1.06, 3: 1.2, 4: 1.34 }[clampIntensity(level)] || 1);
        p.style.cssText =
          `left:${Math.random() * 100}%;width:${size}px;height:${size * 1.3}px;` +
          `background:${pick(PALETTES.petals)};` +
          `animation: djpb-petal-fall ${dur}s ease-in-out ${-Math.random() * (dur + 6)}s infinite;`;
        host.appendChild(p);
      }
    },
    "djpb-fx-lilacs": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 12, 18, 24); i++) {
        const p = document.createElement("div");
        p.className = "petal";
        const dur = (16 + Math.random() * 12) * ({ 1: 1.08, 2: 0.96, 3: 0.86, 4: 0.78 }[clampIntensity(level)] || 1);
        const size = (9 + Math.random() * 8) * ({ 1: 0.92, 2: 1.06, 3: 1.2, 4: 1.34 }[clampIntensity(level)] || 1);
        p.style.cssText =
          `left:${Math.random() * 100}%;width:${size}px;height:${size * 1.3}px;` +
          `background:${pick(PALETTES.lilacs)};` +
          `animation: djpb-petal-fall ${dur}s ease-in-out ${-Math.random() * (dur + 6)}s infinite;`;
        host.appendChild(p);
      }
    },
    "djpb-fx-sunlight": (host, level = DEFAULT_INTENSITY) => {
      for (let i = 0; i < scaledDense(level, 16, 26, 36); i++) {
        const mote = document.createElement("div");
        mote.className = "mote";
        const size = (2 + Math.random() * 3) * sizeScale(level);
        const dur = (7 + Math.random() * 9) * durationScale(level);
        mote.style.cssText =
          `left:${Math.random() * 100}%;top:${Math.random() * 100}%;` +
          `width:${size}px;height:${size}px;` +
          `animation: djpb-mote-float ${dur}s ease-in-out ${-Math.random() * dur}s infinite;`;
        host.appendChild(mote);
      }
    },
  };

  // --- Preference Normalization & Storage Helpers ---
  function normalizeManualEffects(manual) {
    if (manual === null || manual === undefined) return null;
    if (Array.isArray(manual)) {
      return {
        effects: [...new Set(manual.filter((name) => EFFECTS[name]))],
        intensity: {},
      };
    }
    if (typeof manual !== "object") return null;
    const effects = Array.isArray(manual.effects)
      ? [...new Set(manual.effects.filter((name) => EFFECTS[name]))]
      : [];
    const intensity = {};
    const source = manual.intensity && typeof manual.intensity === "object"
      ? manual.intensity
      : {};
    for (const name of effects) intensity[name] = clampIntensity(source[name]);
    return { effects, intensity };
  }

  const fxPrefKey = (sid) => `djpbFxPreference:${sid}`;

  async function loadFxPreference(sid, legacyManual = null) {
    if (!sid) return null;
    if (fxPrefSession === sid && fxSessionManual !== undefined) return fxSessionManual;

    fxPrefSession = sid;
    fxSessionManual = undefined;
    try {
      const key = fxPrefKey(sid);
      const saved = (await chrome.storage.local.get({ [key]: null }))[key];
      if (saved?.mode === "manual") {
        fxSessionManual = normalizeManualEffects(saved.effects) || { effects: [], intensity: {} };
        return fxSessionManual;
      }
      if (saved?.mode === "auto") {
        fxSessionManual = null;
        return null;
      }

      const legacy = normalizeManualEffects(legacyManual);
      if (legacy !== null) {
        fxSessionManual = legacy;
        await chrome.storage.local.set({ [key]: { mode: "manual", effects: legacy } });
        return fxSessionManual;
      }
    } catch { /* default to auto if storage is unavailable */ }

    fxSessionManual = null;
    return null;
  }

  async function saveFxPreference(sid, effects) {
    if (!sid) return;
    const key = fxPrefKey(sid);
    const normalized = normalizeManualEffects(effects);
    fxPrefSession = sid;
    fxSessionManual = normalized;
    await chrome.storage.local.set({
      [key]: normalized === null
        ? { mode: "auto" }
        : { mode: "manual", effects: normalized },
    });
  }

  function cloneManualEffects(manual = currentManualEffects) {
    const norm = normalizeManualEffects(manual);
    return norm ? { effects: [...norm.effects], intensity: { ...norm.intensity } } : null;
  }

  function manualFromAuto(conditions = currentConditions) {
    return { effects: autoEffectNames(conditions), intensity: {} };
  }

  function effectiveEffectNames(conditions = currentConditions, manual = currentManualEffects) {
    const norm = normalizeManualEffects(manual);
    const names = norm ? norm.effects : autoEffectNames(conditions);
    return [...new Set(names.filter((name) => EFFECTS[name]))];
  }

  function effectIntensity(name, manual = currentManualEffects) {
    const norm = normalizeManualEffects(manual);
    return clampIntensity(norm?.intensity?.[name] ?? DEFAULT_INTENSITY);
  }

  function effectSettings(conditions = currentConditions, manual = currentManualEffects) {
    return effectiveEffectNames(conditions, manual).map((name) => ({
      name,
      intensity: effectIntensity(name, manual),
    }));
  }

  // --- Rendering Pipeline ---
  let fxSignature = "";

  function applyEffects(conditions, manualEffects = currentManualEffects) {
    if (!enabled) {
      document.getElementById("djpb-fx")?.remove();
      fxSignature = "";
      return;
    }

    const seen = JSON.stringify({ conditions: conditions || {}, manualEffects });
    if (seen !== applyEffects.lastSeen) {
      applyEffects.lastSeen = seen;
      console.info(
        "[Photobook] scene effects:",
        currentManualEffects !== null ? effectiveEffectNames(conditions || {}, manualEffects) : autoEffectNames(conditions || {}),
        currentManualEffects !== null ? "(manual)" : "(auto)",
        fxOn ? "" : "(effects globally off)"
      );
    }

    const want = [];
    if (fxOn) {
      for (const setting of effectSettings(conditions || {}, manualEffects)) {
        want.push(setting);
      }
    }

    const signature = JSON.stringify(want.map(({ name, intensity }) => `${name}:${intensity}`));
    if (signature === fxSignature) return;
    fxSignature = signature;

    let host = document.getElementById("djpb-fx");
    if (!want.length) { host?.remove(); return; }

    if (!host) {
      host = document.createElement("div");
      host.id = "djpb-fx";
      host.dataset.djpbUi = "1";
      ensureLayer().appendChild(host);
    }
    clearTimeout(lightningTimer);
    host.innerHTML = "";
    for (const { name, intensity } of want) {
      for (const cls of EFFECTS[name] || []) {
        const el = document.createElement("div");
        el.className = cls;
        el.dataset.fxName = name;
        el.dataset.fxIntensity = String(intensity);
        host.appendChild(el);
        BUILDERS[cls]?.(el, intensity);
      }
    }
  }

  // =========================================================================
  // BACKDROP CONTROLLER & DOM DOCKING
  // =========================================================================

  function applyDim() {
    const scrim = layer?.querySelector(".djpb-bd-scrim");
    if (scrim) scrim.style.background = `rgba(6, 3, 14, ${dim})`;
  }

  async function show(dataUrl, isCurrent) {
    try {
      const preload = new Image();
      preload.src = dataUrl;
      if (typeof preload.decode === "function") await preload.decode();
      else await new Promise((resolve) => {
        preload.onload = resolve;
        preload.onerror = resolve;
      });
    } catch { /* direct paint */ }

    if (!isCurrent()) return false;
    const el = ensureLayer();
    const a = el.querySelector('[data-slot="a"]');
    const b = el.querySelector('[data-slot="b"]');
    const incoming = a.classList.contains("visible") ? b : a;
    const outgoing = incoming === a ? b : a;

    incoming.classList.remove("visible");
    incoming.style.backgroundImage = `url("${dataUrl}")`;
    incoming.style.backgroundPosition = `${readThemeNumber("djpb_focus_x", 50, 0, 100)}% 50%`;
    void incoming.offsetWidth;
    requestAnimationFrame(() => {
      incoming.classList.add("visible");
      outgoing.classList.remove("visible");
    });
    openWindow();
    return true;
  }

  async function poll() {
    if (!alive()) { clearInterval(timer); return; }
    const sid = session();
    if (!sid) { closeWindow(); updateToggle(); return; }
    if (!enabled) return;
    const request = ++backdropRequest;
    const isCurrent = () => request === backdropRequest && enabled && sid === session();
    try {
      const res = await PhotobookDB.backdrop(sid, currentId);
      if (!isCurrent()) return;
      if (!res) { pinned = false; closeWindow(); updateToggle(); return; }
      currentConditions = res.conditions && typeof res.conditions === "object"
        ? { ...res.conditions }
        : {};
      const manualEffects = await loadFxPreference(sid, res.manualEffects);
      if (!isCurrent()) return;
      currentManualEffects = manualEffects;

      pinned = res.pinned === true;
      if (res.unchanged) {
        applyEffects(currentConditions, currentManualEffects);
        refreshEffectsPanel();
        updateToggle();
        return;
      }
      if (!await show(res.dataUrl, isCurrent)) return;
      currentId = res.id;
      currentDataUrl = res.dataUrl;
      applyDynamicTheme(res.dataUrl);
      if (currentManualEffects !== null) {
        PhotobookDB.setEffects(currentId, cloneManualEffects(currentManualEffects)).catch(() => {});
      }
      applyEffects(currentConditions, currentManualEffects);
      updateToggle();
    } catch (err) {
      if (!poll.warned) {
        poll.warned = true;
        console.warn("[Photobook] backdrop lookup failed:", err?.message || err);
      }
    }
  }

  function start() {
    clearInterval(timer);
    timer = setInterval(poll, 2500);
    poll();
    setInterval(updateToggle, 2000);
  }

  // ---------- the toggle & docking ----------

  function findComposerToolbar() {
    const labels = ["nexus", "options"];
    const hits = [...document.querySelectorAll("button, [role='button']")].filter((el) => {
      const t = (el.textContent || "").trim().toLowerCase();
      return labels.some((l) => t === l || t.startsWith(l));
    });
    for (const hit of hits) {
      let n = hit.parentElement;
      for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
        const r = n.getBoundingClientRect();
        if (r.width < 120 || r.height > 140) continue;
        const style = getComputedStyle(n);
        if (style.display.includes("flex") || style.display.includes("grid") ||
            r.width > r.height * 2) return n;
      }
    }
    return null;
  }

  function findComposerBox() {
    const input = document.querySelector("textarea, input[placeholder*='message' i]")
      || document.querySelector("[contenteditable='true']");
    if (!input) return null;
    return input.closest("form") || input.parentElement;
  }

  const isNarrow = () => Math.min(innerWidth, innerHeight) < 820 || innerWidth < 820;

  function closeEffectsPanel() {
    document.getElementById("djpb-fx-panel")?.remove();
  }

  function positionEffectsPanel(panel, btn) {
    const r = btn.getBoundingClientRect();
    const width = 258;
    const gap = 8;
    const left = Math.max(8, Math.min(innerWidth - width - 8, r.right - width));
    panel.style.left = `${left}px`;

    const measured = panel.getBoundingClientRect().height || 350;
    const above = r.top - measured - gap;
    panel.style.top = `${above >= 8 ? above : Math.min(innerHeight - measured - 8, r.bottom + gap)}px`;
  }

  async function saveManualEffects(effects) {
    if (!currentId) return;
    try {
      const normalized = normalizeManualEffects(effects);
      await saveFxPreference(session(), normalized);
      const result = await PhotobookDB.setEffects(currentId, normalized);
      currentConditions = result?.conditions && typeof result.conditions === "object"
        ? { ...result.conditions }
        : currentConditions;
      currentManualEffects = normalized;
      fxSignature = "";
      applyEffects(currentConditions, currentManualEffects);
      refreshEffectsPanel();
    } catch (err) {
      console.warn("[Photobook] couldn't save scene effects:", err?.message || err);
    }
  }

  function refreshEffectsPanel() {
    const panel = document.getElementById("djpb-fx-panel");
    if (!panel) return;
    if (!enabled || !currentId) { closeEffectsPanel(); return; }

    const auto = currentManualEffects === null;
    const active = new Set(effectiveEffectNames(currentConditions, currentManualEffects));
    const autoBox = panel.querySelector('[data-fx-auto]');
    if (autoBox) autoBox.checked = auto;
    panel.classList.toggle("custom", !auto);

    for (const { key } of FX_OPTIONS) {
      const box = panel.querySelector(`[data-fx-name="${key}"]`);
      if (box) box.checked = active.has(key);
      const slider = panel.querySelector(`[data-fx-intensity="${key}"]`);
      if (slider) {
        slider.value = String(effectIntensity(key, currentManualEffects));
        slider.disabled = !active.has(key);
      }
      const level = panel.querySelector(`[data-fx-level="${key}"]`);
      if (level) {
        const labelMap = { 1: "Subtle", 2: "Normal", 3: "Strong", 4: "Max" };
        level.textContent = labelMap[effectIntensity(key, currentManualEffects)] || "Normal";
      }
    }

    const badge = panel.querySelector(".djpb-fx-mode");
    if (badge) badge.textContent = auto ? "Auto" : "Custom";
    const reset = panel.querySelector("[data-fx-reset]");
    if (reset) reset.disabled = auto;
    const note = panel.querySelector(".djpb-fx-global-note");
    if (note) note.hidden = fxOn;
  }

  function openEffectsPanel(btn) {
    if (!enabled || !session()) return;
    const existing = document.getElementById("djpb-fx-panel");
    if (existing) { existing.remove(); return; }

    const panel = document.createElement("div");
    panel.id = "djpb-fx-panel";
    panel.dataset.djpbUi = "1";

    if (!currentId) {
      panel.classList.add("empty");
      panel.innerHTML = `
        <div class="djpb-fx-panel-head">
          <strong>Scene effects</strong>
          <span class="djpb-fx-mode">Waiting</span>
        </div>
        <div class="djpb-fx-empty">Generate or load a Chatscape first. Your effect choices will stay with this chat.</div>`;
      (document.body || document.documentElement).appendChild(panel);
      positionEffectsPanel(panel, btn);
      return;
    }

    panel.innerHTML = `
      <div class="djpb-fx-panel-head">
        <strong>Scene effects</strong>
        <span class="djpb-fx-mode">Auto</span>
      </div>
      <label class="djpb-fx-row djpb-fx-auto-row">
        <span>Auto detect</span>
        <input type="checkbox" data-fx-auto>
      </label>
      <div class="djpb-fx-sep"></div>
      <div class="djpb-fx-grid">
        ${FX_OPTIONS.map(({ key, label }) => `
          <div class="djpb-fx-row">
            <label class="djpb-fx-row-main">
              <span>${label}</span>
              <input type="checkbox" data-fx-name="${key}">
            </label>
            <div class="djpb-fx-slider-wrap">
              <input type="range" min="1" max="4" step="1" value="3" data-fx-intensity="${key}">
              <span class="djpb-fx-level" data-fx-level="${key}">Strong</span>
            </div>
          </div>`).join("")}
      </div>
      <div class="djpb-fx-global-note" hidden>Effects are disabled in Photobook settings.</div>
      <button type="button" class="djpb-fx-reset" data-fx-reset>Reset to auto</button>`;

    (document.body || document.documentElement).appendChild(panel);
    refreshEffectsPanel();
    positionEffectsPanel(panel, btn);

    const autoBox = panel.querySelector('[data-fx-auto]');
    autoBox?.addEventListener("change", async () => {
      if (autoBox.checked) {
        await saveManualEffects(null);
      } else {
        await saveManualEffects(manualFromAuto(currentConditions));
      }
    });

    for (const { key } of FX_OPTIONS) {
      const box = panel.querySelector(`[data-fx-name="${key}"]`);
      const slider = panel.querySelector(`[data-fx-intensity="${key}"]`);
      const label = panel.querySelector(`[data-fx-level="${key}"]`);
      const syncSliderLabel = () => {
        if (!slider || !label) return;
        const labelMap = { 1: "Subtle", 2: "Normal", 3: "Strong", 4: "Max" };
        label.textContent = labelMap[clampIntensity(slider.value)] || "Normal";
      };
      slider?.addEventListener("input", syncSliderLabel);
      box?.addEventListener("change", async () => {
        const next = cloneManualEffects(currentManualEffects) || manualFromAuto(currentConditions);
        const names = new Set(next.effects);
        if (box.checked) {
          names.add(key);
          next.intensity[key] = clampIntensity(slider?.value);
        } else {
          names.delete(key);
          delete next.intensity[key];
        }
        next.effects = [...names];
        await saveManualEffects(next);
      });
      slider?.addEventListener("change", async () => {
        const next = cloneManualEffects(currentManualEffects) || manualFromAuto(currentConditions);
        const names = new Set(next.effects);
        names.add(key);
        next.effects = [...names];
        next.intensity[key] = clampIntensity(slider.value);
        if (box) box.checked = true;
        await saveManualEffects(next);
      });
      syncSliderLabel();
    }

    panel.querySelector("[data-fx-reset]")?.addEventListener("click", () => saveManualEffects(null));
  }

  function ensureEffectsButton(scapeButton, bar) {
    let fxBtn = document.getElementById("djpb-bd-fx-toggle");

    if (!enabled || !session()) {
      fxBtn?.remove();
      closeEffectsPanel();
      return;
    }

    if (!fxBtn) {
      fxBtn = document.createElement("button");
      fxBtn.id = "djpb-bd-fx-toggle";
      fxBtn.type = "button";
      fxBtn.dataset.djpbUi = "1";
      fxBtn.textContent = "✨";
      fxBtn.title = "Scene effects";
      fxBtn.setAttribute("aria-label", "Scene effects");
      fxBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        openEffectsPanel(fxBtn);
      });
      document.documentElement.appendChild(fxBtn);
    }

    if (bar) {
      fxBtn.classList.add("djpb-bd-inline");
      if (fxBtn.parentElement !== bar || fxBtn.previousElementSibling !== scapeButton) {
        scapeButton.insertAdjacentElement("afterend", fxBtn);
      }
    } else {
      fxBtn.classList.remove("djpb-bd-inline");
      if (fxBtn.parentElement !== document.documentElement) document.documentElement.appendChild(fxBtn);
    }

    updateSoloButton(bar, fxBtn);
  }

  function updateSoloButton(bar, fxBtn) {
    let solo = document.getElementById("djpb-bd-solo-toggle");

    if (!enabled || !session() || !currentId) {
      solo?.remove();
      if (document.documentElement.classList.contains("djpb-bd-solo")) setSolo(false);
      return;
    }

    if (!solo) {
      solo = document.createElement("button");
      solo.id = "djpb-bd-solo-toggle";
      solo.type = "button";
      solo.dataset.djpbUi = "1";
      solo.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        setSolo(!document.documentElement.classList.contains("djpb-bd-solo"));
      });
      document.documentElement.appendChild(solo);
    }
    paintSoloButton(solo);

    if (bar && fxBtn) {
      solo.classList.add("djpb-bd-inline");
      if (solo.previousElementSibling !== fxBtn) fxBtn.insertAdjacentElement("afterend", solo);
    } else {
      solo.classList.remove("djpb-bd-inline");
      if (solo.parentElement !== document.documentElement) document.documentElement.appendChild(solo);
    }
  }

  function paintSoloButton(solo) {
    const on = document.documentElement.classList.contains("djpb-bd-solo");
    solo.textContent = on ? "◲" : "◱";
    solo.title = on
      ? "Click anywhere, or press Esc, to bring the chat back"
      : "Hide the chat and just look at the scene";
    solo.setAttribute("aria-label", solo.title);
    solo.setAttribute("aria-pressed", on ? "true" : "false");
    solo.classList.toggle("active", on);
  }

  let soloDismiss = null;

  function armSoloDismiss() {
    disarmSoloDismiss();
    soloDismiss = (e) => {
      const t = e.target;
      if (t instanceof Element && t.closest("[data-djpb-ui]")) return;
      setSolo(false);
    };
    document.addEventListener("pointerdown", soloDismiss, true);
  }

  function disarmSoloDismiss() {
    if (!soloDismiss) return;
    document.removeEventListener("pointerdown", soloDismiss, true);
    soloDismiss = null;
  }

  function setSolo(on) {
    document.documentElement.classList.toggle("djpb-bd-solo", on);
    if (on) armSoloDismiss();
    else disarmSoloDismiss();
    const solo = document.getElementById("djpb-bd-solo-toggle");
    if (solo) paintSoloButton(solo);
  }

  async function setEnabled(next) {
    enabled = next;
    try {
      await chrome.storage.local.set({ [ON_KEY]: enabled });
    } catch { /* not persisted */ }
    if (enabled) { currentId = null; poll(); }
    else closeWindow();
    updateToggle();
  }

  function closePinMenu() {
    document.getElementById("djpb-bd-menu")?.remove();
  }

  function togglePinMenu(btn) {
    if (document.getElementById("djpb-bd-menu")) { closePinMenu(); return; }

    const currentOpacity = readThemeNumber("djpb_chat_opacity", 0.35, 0, 0.9);
    const currentVibrancy = readThemeNumber("djpb_vibrancy", 1.8, 0.1, 4);
    const currentFocusX = readThemeNumber("djpb_focus_x", 50, 0, 100);

    const opacityPct = Math.round(currentOpacity * 100);
    const vibrancyPct = Math.round(currentVibrancy * 100);

    const menu = document.createElement("div");
    menu.id = "djpb-bd-menu";
    menu.dataset.djpbUi = "1";
    menu.setAttribute("role", "menu");

    menu.innerHTML = `
      <label class="djpb-theme-toggle" for="djpb-scape-color-theme">
        <span>Color theme<small>Off uses default colors</small></span>
        <input type="checkbox" role="switch" id="djpb-scape-color-theme" aria-label="Color theme">
        <span class="djpb-theme-switch" aria-hidden="true"></span>
      </label>

      <div class="djpb-slider-group">
        <label for="djpb-scape-focus-x">
          <span>Horizontal Position</span>
          <span class="djpb-val-box">
            <input type="number" id="djpb-focus-x-num" aria-label="Horizontal Position percent" class="djpb-num-input" min="0" max="100" value="${currentFocusX}">%
          </span>
        </label>
        <input type="range" id="djpb-scape-focus-x" min="0" max="100" step="1" value="${currentFocusX}">
      </div>

      <div class="djpb-slider-group">
        <label for="djpb-scape-opacity">
          <span>Chat Box Opacity</span>
          <span class="djpb-val-box">
            <input type="number" id="djpb-opacity-num" aria-label="Chat Box Opacity percent" class="djpb-num-input" min="0" max="90" value="${opacityPct}">%
          </span>
        </label>
        <input type="range" id="djpb-scape-opacity" min="0" max="90" step="1" value="${opacityPct}">
      </div>

      <div class="djpb-slider-group">
        <label for="djpb-scape-vibrancy">
          <span>Color Vibrancy Boost</span>
          <span class="djpb-val-box">
            <input type="number" id="djpb-vibrancy-num" aria-label="Color Vibrancy Boost percent" class="djpb-num-input" min="10" max="400" value="${vibrancyPct}">%
          </span>
        </label>
        <input type="range" id="djpb-scape-vibrancy" min="10" max="400" step="1" value="${vibrancyPct}">
      </div>
      
      <div class="djpb-bd-menu-actions"></div>
    `;

    const actions = menu.querySelector(".djpb-bd-menu-actions");

    const addRow = (label, hint, onPick) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "djpb-bd-menu-row";
      b.setAttribute("role", "menuitem");
      b.innerHTML = `<span>${label}</span><small>${hint}</small>`;
      b.addEventListener("click", async (e) => {
        e.stopPropagation();
        closePinMenu();
        await onPick();
      });
      actions.appendChild(b);
    };

    if (pinned) {
      addRow("Unpin image", "go back to following your snaps", async () => {
        const sid = session();
        if (!sid) return;
        await PhotobookDB.setBackdrop(sid, null);
        pinned = false;
        currentId = null;
        poll();
        updateToggle();
      });
    }

    addRow("Turn backdrops off", "no backdrop in any chat", async () => {
      await setEnabled(false);
    });

    document.documentElement.appendChild(menu);

    // Position Popover
    const r = btn.getBoundingClientRect();
    const mh = menu.offsetHeight || 220;
    const below = window.innerHeight - r.bottom;
    menu.style.left = `${Math.max(8, Math.min(r.left, window.innerWidth - menu.offsetWidth - 8))}px`;
    menu.style.top = below > mh + 12
      ? `${r.bottom + 6}px`
      : `${Math.max(8, r.top - mh - 6)}px`;

    // --- Synchronized Controls ---

    // 1. Horizontal Position
    const focusRange = menu.querySelector("#djpb-scape-focus-x");
    const focusNum = menu.querySelector("#djpb-focus-x-num");
    const updateFocus = (val) => {
      const clamped = Math.max(0, Math.min(100, Number(val) || 0));
      focusRange.value = clamped;
      focusNum.value = clamped;
      saveThemeNumber("djpb_focus_x", clamped);
      document.querySelectorAll("#djpb-backdrop .djpb-bd-img")
        .forEach((el) => (el.style.backgroundPosition = `${clamped}% 50%`));
    };
    focusRange.addEventListener("input", (e) => updateFocus(e.target.value));
    focusNum.addEventListener("input", (e) => updateFocus(e.target.value));

    // 2. Chat Box Opacity (1% precision)
    const opacityRange = menu.querySelector("#djpb-scape-opacity");
    const opacityNum = menu.querySelector("#djpb-opacity-num");
    const updateOpacity = (val) => {
      const clamped = Math.max(0, Math.min(90, Number(val) || 0));
      opacityRange.value = clamped;
      opacityNum.value = clamped;
      const floatVal = (clamped / 100).toFixed(2);
      saveThemeNumber("djpb_chat_opacity", floatVal);
      applyChatOpacity(floatVal);
    };
    opacityRange.addEventListener("input", (e) => updateOpacity(e.target.value));
    opacityNum.addEventListener("input", (e) => updateOpacity(e.target.value));

    // 3. Color Vibrancy (1% precision)
    const vibrancyRange = menu.querySelector("#djpb-scape-vibrancy");
    const vibrancyNum = menu.querySelector("#djpb-vibrancy-num");
    const updateVibrancy = (val) => {
      const clamped = Math.max(10, Math.min(400, Number(val) || 100));
      vibrancyRange.value = clamped;
      vibrancyNum.value = clamped;
      const floatVal = (clamped / 100).toFixed(2);
      saveThemeNumber("djpb_vibrancy", floatVal);
      if (currentDataUrl) applyDynamicTheme(currentDataUrl);
    };
    vibrancyRange.addEventListener("input", (e) => updateVibrancy(e.target.value));
    vibrancyNum.addEventListener("input", (e) => updateVibrancy(e.target.value));

    const themeToggle = menu.querySelector("#djpb-scape-color-theme");
    const syncThemeControls = () => {
      themeToggle.checked = colorThemeEnabled;
      vibrancyRange.disabled = !colorThemeEnabled;
      vibrancyNum.disabled = !colorThemeEnabled;
    };
    themeToggle.addEventListener("change", () => {
      colorThemeEnabled = themeToggle.checked;
      saveThemeNumber("djpb_color_theme", colorThemeEnabled ? 1 : 0);
      syncThemeControls();
      applyDynamicTheme(currentDataUrl);
    });
    syncThemeControls();

    const away = (e) => {
      if (!menu.contains(e.target) && e.target !== btn) {
        closePinMenu();
        document.removeEventListener("click", away, true);
      }
    };
    setTimeout(() => document.addEventListener("click", away, true), 0);
  }

  function updateToggle() {
    syncDefaultComposer();
    let btn = document.getElementById("djpb-bd-toggle");
    if (!session()) {
      btn?.remove();
      document.getElementById("djpb-bd-fx-toggle")?.remove();
      document.getElementById("djpb-bd-solo-toggle")?.remove();
      if (document.documentElement.classList.contains("djpb-bd-solo")) setSolo(false);
      closeEffectsPanel();
      closePinMenu();
      return;
    }
    if (!btn) {
      btn = document.createElement("button");
      btn.id = "djpb-bd-toggle";
      btn.type = "button";
      btn.dataset.djpbUi = "1";
      btn.addEventListener("click", async (e) => {
        if (enabled) {
          e.stopPropagation();
          togglePinMenu(btn);
          return;
        }
        closePinMenu();
        await setEnabled(true);
      });
      document.documentElement.appendChild(btn);
    }

    // Mobile: dock inside the input bar row
    if (isNarrow()) {
      const box = findComposerBox();
      if (box) {
        btn.classList.remove("djpb-bd-inline");
        btn.classList.add("djpb-bd-inline-send");
        if (btn.parentElement !== box) {
          box.appendChild(btn);
        }
        btn.setAttribute("aria-haspopup", enabled ? "menu" : "false");
        btn.textContent = "🌄";
        btn.classList.toggle("off", !enabled);
        btn.title = !enabled ? "Snapscapes off. Tap to turn on." : "Snapscapes on. Tap for appearance options.";
        ensureEffectsButton(btn, box);
        return;
      }
    }

    // Desktop: dock in composer toolbar
    const bar = findComposerToolbar();
    if (bar && btn.parentElement !== bar) {
      btn.classList.remove("djpb-bd-inline-send");
      btn.classList.add("djpb-bd-inline");
      bar.appendChild(btn);
    } else if (!bar && (btn.classList.contains("djpb-bd-inline") || btn.classList.contains("djpb-bd-inline-send"))) {
      btn.classList.remove("djpb-bd-inline", "djpb-bd-inline-send");
      document.documentElement.appendChild(btn);
    }

    btn.textContent = enabled ? "🌄 Scape" : "🌄 Scape off";
    btn.classList.toggle("off", !enabled);
    btn.setAttribute("aria-haspopup", enabled ? "menu" : "false");
    btn.title = !enabled
      ? "Snapscapes off. Click to turn back on."
      : pinned
        ? "This chat is holding a pinned image. Click for options."
        : "Snapscapes on — the chat's backdrop follows your snaps. Click for appearance options.";

    ensureEffectsButton(btn, bar);
  }

  // ---------- boot ----------

  (async () => {
    try {
      const v = await chrome.storage.local.get({ [ON_KEY]: true, [DIM_KEY]: 35, djpbFx: true });
      enabled = v[ON_KEY] !== false;
      fxOn = v.djpbFx !== false;
      dim = Math.min(0.85, Math.max(0, (Number(v[DIM_KEY]) || 35) / 100));
    } catch { /* defaults */ }

    document.addEventListener("click", (e) => {
      const panel = document.getElementById("djpb-fx-panel");
      const btn = document.getElementById("djpb-bd-fx-toggle");
      if (panel && !panel.contains(e.target) && e.target !== btn) closeEffectsPanel();
    }, true);
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      closeEffectsPanel();
      closePinMenu();
      if (document.documentElement.classList.contains("djpb-bd-solo")) setSolo(false);
    });

    updateToggle();
    if (enabled) start();

    chrome.storage.onChanged.addListener((c, area) => {
      if (area !== "local") return;
      if (c[ON_KEY]) {
        enabled = c[ON_KEY].newValue !== false;
        if (enabled) { currentId = null; start(); } else { clearInterval(timer); closeWindow(); }
        updateToggle();
      }
      if (c.djpbFx) {
        fxOn = c.djpbFx.newValue !== false;
        fxSignature = "";
        if (!fxOn) document.getElementById("djpb-fx")?.remove();
        else if (enabled && currentId) applyEffects(currentConditions, currentManualEffects);
        refreshEffectsPanel();
      }
      const sid = session();
      if (sid && c[fxPrefKey(sid)]) {
        const pref = c[fxPrefKey(sid)].newValue;
        fxPrefSession = sid;
        fxSessionManual = pref?.mode === "manual"
          ? (normalizeManualEffects(pref.effects) || { effects: [], intensity: {} })
          : null;
        currentManualEffects = fxSessionManual;
        fxSignature = "";
        if (enabled && currentId) applyEffects(currentConditions, currentManualEffects);
        refreshEffectsPanel();
      }
      if (c[DIM_KEY]) {
        dim = Math.min(0.85, Math.max(0, (Number(c[DIM_KEY].newValue) || 35) / 100));
        applyDim();
      }
    });

    let lastSession = session();
    setInterval(() => {
      const now = session();
      if (now === lastSession) return;
      lastSession = now;
      currentId = null;
      fxPrefSession = null;
      fxSessionManual = undefined;
      closeWindow();
      if (enabled && now) poll(); else updateToggle();
    }, 1200);
  })();
})();
