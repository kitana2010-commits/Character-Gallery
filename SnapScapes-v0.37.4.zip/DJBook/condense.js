// condense.js — turns a long roleplay reply into an image prompt.
//
// Loaded two ways:
//   - service worker:  importScripts("condense.js")
//   - content script:  listed before content.js in the manifest
// Both get a global `PromptCondenser`.
//
// The heuristic pass is free, offline, and never refuses. If an LLM backend is
// configured the worker can upgrade the result, but the shape is identical
// either way so callers don't branch.
//
// Output shape (the "scene"):
//   { subject, action, setting, lighting, extras[], source, score }
// Assemblers turn a scene + an appearance sheet into a backend-specific prompt.

const PromptCondenser = (() => {
  // ---------- lexicons ----------
  // Scoring is deliberately crude. It only has to rank sentences against each
  // other within one reply, not understand them.

  const LIGHTING = [
    "light", "lights", "sunlight", "moonlight", "candlelight", "lamplight",
    "firelight", "torchlight", "glow", "glowing", "shadow", "shadows", "dim",
    // "dark" and "golden" live in COLOR instead: they modify hair and cloth far
    // more often than they describe a light source.
    "bright", "darkness", "dusk", "dawn", "twilight", "neon",
    "sunset", "sunrise", "gloom", "haze", "hazy", "flicker", "flickering",
    "shimmer", "silhouette", "backlit", "overcast", "gleam", "glare",
  ];

  const SETTING = [
    "room", "hall", "hallway", "forest", "street", "tavern", "kitchen",
    "bedroom", "garden", "courtyard", "beach", "shore", "mountain", "city",
    "alley", "castle", "ship", "deck", "cafe", "café", "library", "office",
    "rooftop", "roof", "bridge", "river", "lake", "field", "meadow", "cave",
    "temple", "shrine", "market", "balcony", "window", "windows", "door",
    "doorway", "table", "chair", "couch", "bed", "floor", "wall", "ceiling",
    "stairs", "staircase", "rain", "snow", "fog", "mist", "wind", "storm",
    "cloud", "clouds", "sky", "tree", "trees", "grass", "stone", "water",
    "fire", "fireplace", "counter", "booth", "platform", "station", "train",
    "car", "road", "path", "gate", "fence", "yard", "porch", "hill", "cliff",
    // tavern/interior vocabulary — common in roleplay, absent from v1
    "tavern", "inn", "hearth", "mug", "tankard", "cup", "bench", "stool",
    "rafters", "beam", "lantern", "candle", "barrel", "bar", "booth", "plate",
    // vehicle interiors: scenes happen in them and they were unreachable
    "seat", "backseat", "dashboard", "windshield", "truck", "van", "cab", "carriage",
  ];

  const APPEARANCE = [
    "hair", "eyes", "eye", "face", "skin", "lips", "mouth", "hands", "hand",
    "shoulders", "shoulder", "arms", "arm", "smile", "smirk", "frown", "dress",
    "shirt", "coat", "jacket", "armor", "armour", "robe", "robes", "cloak",
    "boots", "gloves", "scarf", "jeans", "uniform", "blouse", "collar",
    "sleeve", "sleeves", "hood", "mask", "glasses", "necklace", "ring",
    "tattoo", "scar", "scars", "freckles", "beard", "braid", "ponytail",
    "curls", "jaw", "throat", "neck", "wrist", "fingers", "chest", "back",
    "hem", "buttons", "belt", "boot", "heels", "apron", "sweater", "hoodie",
    "forearms", "forearm", "elbow", "elbows", "knuckles", "brow", "chin",
    "grin", "scowl", "teeth", "stubble", "knee", "thigh", "waist", "hip",
  ];

  const COLOR = [
    "red", "blue", "green", "black", "white", "gold", "golden", "silver",
    "crimson", "emerald", "violet", "amber", "grey", "gray", "brown", "pale",
    "blonde", "blond", "auburn", "copper", "ivory", "scarlet", "azure",
    "teal", "olive", "rust", "cream", "charcoal", "navy", "burgundy",
  ];

  const VISUAL_VERBS = [
    "stands", "stood", "standing", "sits", "sat", "sitting", "leans",
    "leaned", "leaning", "kneels", "knelt", "kneeling", "walks", "walked",
    "walking", "runs", "ran", "running", "turns", "turned", "turning",
    "reaches", "reached", "reaching", "holds", "held", "holding", "grips",
    "gripped", "raises", "raised", "lowers", "lowered", "tilts", "tilted",
    "crosses", "crossed", "steps", "stepped", "lies", "lying", "crouches",
    "crouched", "gestures", "points", "pointed", "embraces", "grasps",
    "draws", "drew", "lifts", "lifted", "bows", "bowed", "presses", "pressed",
    "pulls", "pulled", "pushes", "pushed", "tucks", "tucked", "brushes",
    "settles", "settled", "rests", "rested", "glances", "glanced",
  ];

  // Sentences built around these are interior monologue — invisible to a camera.
  const INTERIOR = [
    "thought", "thinks", "thinking", "wonder", "wonders", "wondered",
    "realize", "realizes", "realized", "remember", "remembers", "remembered",
    "knew", "knows", "believe", "believes", "believed", "hope", "hoped",
    "decide", "decides", "decided", "understand", "understood", "wish",
    "wished", "recall", "recalled", "imagine", "imagined", "suppose",
    "supposed", "meant", "means", "seemed", "seems", "considered", "assumed",
    "feels", "felt", "wanted", "wants", "needed", "needs",
  ];

  const SD_NEGATIVE =
    "text, watermark, signature, extra limbs, extra fingers, deformed hands, " +
    "bad anatomy, blurry, lowres, jpeg artifacts, cropped, out of frame";

  const inSet = (() => {
    const sets = new Map();
    return (list) => {
      if (!sets.has(list)) sets.set(list, new Set(list));
      return sets.get(list);
    };
  })();

  // ---------- text prep ----------

  /** Strip spoken dialogue. Speech tells you nothing about how a frame looks.
   *  Double quotes only — a single-quote rule would treat the gap between two
   *  contractions ("she'd ... wasn't") as a quotation and eat the paragraph. */
  function stripDialogue(text) {
    return text
      .replace(/\u201C[^\u201D]*\u201D/g, " ") // curly “…”
      .replace(/"[^"]*"/g, " ")                // straight "…"
      .replace(/\s+/g, " ")
      .trim();
  }

  /** Roleplay markup: *actions* and _emphasis_ are content, not syntax. */
  function stripMarkup(text) {
    return text
      // Tags, not just markdown. A pronoun wrapped in one ("<b>He</b> knelt")
      // no longer starts the sentence, so subject resolution failed and the
      // clause was dropped with no owner.
      .replace(/<\/?[a-z][^>]*>/gi, " ")
      .replace(/[*_~`]+/g, " ")
      .replace(/^\s*[->#]+\s*/gm, " ")
      .replace(/\[[^\]]*\]\([^)]*\)/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  /** Split first, strip speech per sentence. Doing it the other way round
   *  leaves lowercase fragments ("she said, ...") that the splitter then
   *  welds onto the previous sentence. */
  /** Strip speech across the WHOLE text before splitting. Per-sentence
   *  stripping can't see a quotation that spans sentences ("A," he said. "B.")
   *  and leaves half of it behind. dropTags() cleans the resulting seams. */
  function splitSentences(text) {
    return stripDialogue(text)
      .split(/(?<=[.!?\u2026])\s+(?=["\u201C(]?[A-Z])/)
      .map(dropTags)
      .filter((s) => s.length > 12);
  }

  const SPEECH_VERBS =
    "said|says|offered|repeated|replied|asked|answered|murmured|muttered|" +
    "whispered|added|continued|snapped|called|shouted|breathed|sighed|told";

  /** Removing a quotation leaves its attribution behind ("he offered.").
   *  Those fragments are grammatical debris, not description. */
  function dropTags(sentence) {
    let s = sentence;
    // A lowercase clause after a full stop is the tail of a removed quotation.
    s = s.replace(/\.\s+[a-z][^.!?]*[.!?]?\s*$/, ".");
    // Bare attribution at either end.
    s = s.replace(new RegExp(`^\\s*(he|she|they|i)\\s+(${SPEECH_VERBS})\\b[^.!?]*[.!?]?`, "i"), "");
    s = s.replace(new RegExp(`[,\\s]+(he|she|they|i)\\s+(${SPEECH_VERBS})\\b[^.!?]*$`, "i"), ".");
    return s.replace(/^[\s,;:]+/, "").replace(/\s+/g, " ").trim();
  }

  function words(sentence) {
    return sentence.toLowerCase().match(/[a-zàéèêöüñ']+/g) || [];
  }

  // ---------- scoring ----------

  // Objects a character holds, wears or uses. The prose is full of them and the
  // scorer was blind to all of it — "he lifted the bottle, took a pull, and set
  // it down beside the spreading red stain" is a picture, and it scored 3.8.
  const PROPS = `bottle cup glass flask tankard goblet bowl plate knife dagger blade sword
    axe spear bow arrow shield helm gauntlet glove gloves belt buckle strap sheath scabbard
    lantern candle torch lamp book ledger letter scroll parchment quill pen map key ring
    necklace pendant chain bracelet crown circlet cloak coat shift dress gown shirt tunic
    trousers boots shoes veil mask hood scarf apron basket sack satchel bag pouch rope
    reins saddle bridle brush comb mirror bandage cloth rag towel needle thread coin purse
    pipe cigarette bread cheese apple stew kettle pot pan broom shovel hammer nail`
    .split(/\s+/).filter(Boolean);

  // A prop only counts when someone is doing something with it.
  const HANDLING = /\b(held|holding|lifted|lift|raised|carried|carrying|clutched|clutching|gripped|gripping|drew|drawing|wielded|wore|wearing|wrapped|set|placed|took|taking|pulled|pulling|pressed|offered|handed|dropped|threw|swung|tossed|poured|filled|opened|closed|unbuckled|buckled|tied|untied)\b/i;

  // "he said" / "she asked" carry no picture; a sentence that is mostly
  // attribution shouldn't outrank one that describes something.
  const ATTRIBUTION = /\b(said|asked|replied|answered|murmured|muttered|whispered|shouted|called|added|repeated|continued)\b/i;

  /** Objects being handled in this text, for the prompt's own use. */
  function findProps(text) {
    const found = [];
    const lower = String(text).toLowerCase();
    for (const p of PROPS) {
      const re = new RegExp(`\\b${p}s?\\b`);
      if (!re.test(lower)) continue;
      // Only if something is being done with it somewhere in the sentence.
      const sentence = String(text).split(/(?<=[.!?])\s+/)
        .find((s) => re.test(s.toLowerCase()));
      if (sentence && HANDLING.test(sentence)) found.push(p);
    }
    return [...new Set(found)].slice(0, 6);
  }

  /** How far apart people are — a FACT the prose states, not a camera angle.
   *
   *  An earlier version inferred shot types from eyelines ("looked up at him"
   *  -> low angle, "over his shoulder" -> OTS). That was inventing
   *  cinematography out of ordinary narration: this is a novel, not a script,
   *  and those phrases describe where characters are, not where a camera is.
   *  What IS stated plainly is distance, and without it every image comes back
   *  as the same mid-shot no matter how close the writing puts people. So this
   *  keeps only unambiguous distance, and phrases it as the scene. */
  const DISTANCE = [
    [/\b(inches from|breath (against|on) (her|his)|close enough (to|that)|nose to nose|against (her|his) (mouth|lips|throat|ear))\b/i,
      "the two are close enough to touch"],
    // "in the distance" used to live here. It matched "sirens somewhere in the
    // distance" — a SOUND being far off, not the characters — and turned two
    // people in the front seats of a car into a wide establishing shot. The
    // rest of this list names a place the distance is measured across, which
    // is what makes them safe.
    [/\b(across the (yard|room|hall|field|street|square|clearing)|from the (doorway|archway|far side)|the length of the (room|hall|yard))\b/i,
      "seen from across the space, the setting visible around them"],
  ];

  /** Contact is a better distance signal than any phrase lookup: if one of
   *  them has hold of the other, the camera cannot be across the room. */
  const CONTACT = /\b(caught|catching|grabbed|grabbing|seized|seizing|closed around|closing around|gripped|gripping|held|holding|took hold|pulled (her|him|them) (close|in|toward)|hand (came up|closed)|fingers (closed|closing)|wrist|forearm|collar|lapel|shoulder|waist|throat|chin|jaw)\b/i;
  const CONTACT_TARGET = /\b(her|his|their|the) (wrist|arm|forearm|hand|shoulder|collar|lapel|waist|throat|chin|jaw|hair)\b/i;

  /** Where the scene is, read from ANY sentence rather than only the most
   *  visual one. Prose states a setting once and then assumes it, so the
   *  sentence naming the room is rarely the sentence worth drawing — "sitting
   *  in the front seat of the car" loses to a punch every time, and the whole
   *  prompt then goes out with no location at all. */
  // "across the bridge of the nose" is anatomy, not a location. Any setting
  // word followed by "of his/her/the <body part>" is describing a person.
  const ANATOMY = /\b(nose|face|jaw|cheek|cheekbone|brow|chin|throat|neck|hand|foot|back|shoulder|ribs|spine|skull|eye|ear|mouth|teeth|wrist|arm|leg|knee|hip|chest)\b/i;
  const PLACE_PHRASE = new RegExp(
    "\\b(?:in|inside|on|at|aboard|across|through|behind|beneath|under|beside|near|from)\\s+" +
    "(?:the|a|an|his|her|their|its)\\s+" +
    "(?:[a-z]+\\s+){0,3}(" + SETTING.join("|") + ")s?\\b", "i");

  function detectPlace(...texts) {
    for (const text of texts) {
      const sentences = splitSentences(stripMarkup(String(text || "")));
      for (const raw of sentences) {
        if (isDirective(raw)) continue;
        const m = raw.match(PLACE_PHRASE);
        if (!m) continue;
        // Reject "the bridge of the nose" and friends.
        const after = raw.slice(m.index + m[0].length, m.index + m[0].length + 24);
        if (/^\s+of\s+(the|his|her|their)\s/i.test(after) && ANATOMY.test(after)) continue;
        if (ANATOMY.test(m[0])) continue;
        // Keep the phrase, not just the noun: "the front seat of the car"
        // reads better to an image model than "car".
        let phrase = m[0].replace(
          /^\s*\b(?:in|inside|on|at|aboard|across|through|behind|beneath|under|beside|near|from)\s+/i, "");
        // "the front seat" does not say car; "the front seat of the car" does.
        const tail = after.match(/^\s+of\s+(?:the|a|an)\s+([a-z]+)/i);
        if (tail && SETTING.includes(tail[1].toLowerCase())) phrase += ` of the ${tail[1]}`;
        return phrase.replace(/\s+/g, " ").trim();
      }
    }
    return null;
  }

  /** A prompt the roleplay model wrote for itself.
   *
   *  Card authors can add a section to the thinking template shaped like:
   *
   *      SNAP:
   *      [a concise image prompt for this scene]
   *
   *  The model has the whole conversation, so it knows who "he" is, what they
   *  were wearing six replies ago, and which detail actually matters — none of
   *  which the keyword pass can ever see. When the section is absent this
   *  returns null and nothing changes.
   *
   *  Deliberately forgiving about the exact shape: the header may lose its
   *  colon or its hashes to markdown rendering, and the brackets may be
   *  missing entirely. Anything that survives is better than nothing. */
  // Loosened regex to allow optional list prefixes (e.g., "c)", "1.", "-") 
  // and inline text on the same line.
  const SNAP_HEADER = /^[ \t]*(?:[a-z0-9][\).]\s*)?#{0,6}[ \t]*SNAP[ \t]*:?[ \t]*/im;

  function extractSnapSection(text) {
    const raw = String(text || "");
    if (!raw) return null;

    let found = null;
    const lines = raw.split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (!SNAP_HEADER.test(line)) continue;

      // Capture any inline text after "SNAP:" on the same line
      const headerMatch = line.match(/^[ \t]*(?:[a-z0-9][\).]\s*)?#{0,6}[ \t]*SNAP[ \t]*:?[ \t]*(.*)$/i);
      const inlineText = headerMatch ? headerMatch[1].trim() : "";

      const body = [];
      if (inlineText) body.push(inlineText);

      // If the prompt isn't fully self-contained in brackets on line i, check subsequent lines
      const isSelfContained = inlineText.startsWith("[") && inlineText.endsWith("]");
      if (!isSelfContained) {
        for (let j = i + 1; j < lines.length; j++) {
          const l = lines[j];
          if (/^[ \t]*#{1,6}[ \t]*\S/.test(l)) break;      // next heading
          if (!l.trim() && body.length) break;              // blank after content
          if (!l.trim()) continue;
          body.push(l.trim());
          if (body[0].startsWith("[") && l.trim().endsWith("]")) break;
        }
      }

      if (body.length) found = body.join(" ");
    }
    if (!found) return null;

    let out = found.trim();
    const bracket = out.match(/^\[([\s\S]*)\]$/);
    if (bracket) out = bracket[1];
    out = out.replace(/\s+/g, " ").trim();

    if (out.length < 12 || out.length > 1200) return null;
    if (/^(none|n\/a|no snap|skip)\b/i.test(out)) return null;
    return out;
  }

  function stripSnapSection(text) {
    const raw = String(text || "");
    if (!SNAP_HEADER.test(raw)) return raw;
    const lines = raw.split(/\r?\n/);
    const keep = [];
    for (let i = 0; i < lines.length; i++) {
      if (!SNAP_HEADER.test(lines[i])) { keep.push(lines[i]); continue; }

      const headerMatch = lines[i].match(/^[ \t]*(?:[a-z0-9][\).]\s*)?#{0,6}[ \t]*SNAP[ \t]*:?[ \t]*(.*)$/i);
      const inlineText = headerMatch ? headerMatch[1].trim() : "";
      const isSelfContained = inlineText.startsWith("[") && inlineText.endsWith("]");

      if (isSelfContained) continue; // Remove just this line if the entire prompt was inline

      let j = i + 1;
      let sawBody = Boolean(inlineText);
      while (j < lines.length) {
        const l = lines[j];
        if (/^[ \t]*#{1,6}[ \t]*\S/.test(l)) break;
        if (!l.trim() && sawBody) break;
        if (l.trim()) sawBody = true;
        j += 1;
      }
      i = j - 1;
    }
    return keep.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function detectDistance(text) {
    for (const [re, say] of DISTANCE) if (re.test(text)) return say;
    // Two people touching are, necessarily, close.
    const t = String(text || "");
    if (CONTACT.test(t) && CONTACT_TARGET.test(t)) {
      return "close two-shot, the two within arm's reach";
    }
    return null;
  }

  /** Weather and time of day, which prose states ONCE and then assumes. */
  const WEATHER = [
    [/\b(rain|raining|rained|rainfall|downpour|drizzle|storm|storming|thunder|thunderstorm|lightning|lightening|squall|deluge)\b/i, "rain"],
    [/\b(snow|snowing|blizzard|sleet|frost|frozen)\b/i, "snow"],
    [/\b(fog|mist|misty|haze)\b/i, "fog"],
    [/\b(wind|gale|gust|windy)\b/i, "wind"],
    [/\b(sun|sunlight|sunny|clear sky|blazing)\b/i, "clear"],
  ];
  const TIMEOFDAY = [
    [/\b(dawn|sunrise|first light|daybreak)\b/i, "dawn"],
    [/\b(morning|midmorning)\b/i, "morning"],
    [/\b(noon|midday|afternoon)\b/i, "day"],
    [/\b(dusk|sunset|twilight|evening|gloaming)\b/i, "dusk"],
    [/\b(night|midnight|dark|moonlight|starlight|ninth bell)\b/i, "night"],
  ];

  // Not weather, but the strongest light source in most scenes — and the one
  // people most want to see moving.
  // A hearth burns all evening; an explosion is over in a second. Treating
  // both as "there is fire here" left embers rising for the rest of the chat
  // after a single blast.
  const FIRE_STEADY = /\b(firelight|hearth|fireplace|brazier|bonfire|campfire|torchlight|forge|candlelit|burning low)\b/i;
  const FIRE_BURST = /\b(explod\w*|blast|detonat\w*|fireball|erupt\w*|went up in flames|caught fire|burst into flames)\b/i;
  // Broad on purpose. Fire is the one atmosphere that should fire readily:
  // a hearth, a torch, a burning building — any of them make embers plausible.
  const FIRELIGHT = /\b(fire|fires|fiery|flame|flames|flaming|aflame|ablaze|blaze|blazing|inferno|burning|burned|burnt|alight|ember|embers|smoulder\w*|smolder\w*|scorch\w*|torch|torches|coals?)\b/i;

  // Not weather — mood and place. These pick the atmosphere the same way the
  // user's own site does per character.
  const FIREFLIES = /\b(fireflies|firefly|lightning bugs?|lightening bugs?|glow-?worms?)\b/i;
  const ROMANCE = /\b(kissed?|kissing|first kiss|made love|held her close|held him close|in his arms|in her arms|tenderly|nuzzled|entwined|cradled (her|his) face|forehead against)\b/i;
  const GARDEN = /\b(garden|orchard|greenhouse|conservatory|rose ?bed|flower ?beds?|blossoms?|arbou?r|courtyard garden|herb garden)\b/i;

  // Weather detection, by CONSTRUCTION rather than by keyword.
  //
  // Blacklisting metaphors one phrasing at a time was a losing game: prose
  // rains debris, blows, arrows, fire, wreckage — and hails wood and stone.
  // Every fix covered the phrasing we'd just seen and missed the next one.
  //
  // So invert it. A weather word only counts when it appears in a shape that
  // is unambiguously about weather: as the SUBJECT of a weather verb, inside a
  // prepositional phrase, with a weather adjective, or as a bare participle.
  // "a hail of shattered wood" and "the rain of wreckage" fit none of those,
  // and neither will the next metaphor, because the rule is about grammar
  // instead of vocabulary.
  const WEATHER_LITERAL = [
    // "rain hammered the roof", "snow drifted past the window"
    [/\b(rain|snow|sleet|hail|fog|mist)\s+(fell|falls|hammer\w*|drum\w*|lash\w*|batter\w*|drift\w*|swirl\w*|roll\w*|hung|hangs|thicken\w*|cover\w*|blanket\w*|came down)\b/i, 0],
    // "it was raining", "it started to snow", "it began to rain" — the
    // infinitive form needs its own room ("started TO snow").
    [/\b(it|sky|clouds?|weather)\s+(\w+\s+){0,3}(rain|snow|hail|drizzl)(s|ing|ed|e)?\b/i, 0],
    // "in the rain", "through the snow", "out in the storm"
    [/\b(in|through|under|out in|into|beneath)\s+the\s+(rain|snow|sleet|hail|fog|mist|storm|downpour|blizzard)\b/i, 0],
    // "pouring rain", "driving snow", "heavy fog"
    [/\b(pouring|driving|steady|light|heavy|freezing|icy|thick|dense|cold)\s+(rain|snow|sleet|hail|fog|mist|drizzle)\b/i, 0],
    // Bare participles can only be weather — nothing else "rains" as a state.
    // (The earlier version required a subject before them, so "it had been
    // raining since dawn" was rejected.)
    [/\b(raining|snowing|drizzling|sleeting|hailing|pouring down|thunderstorm|downpour|blizzard|squall)\b/i, 0],
    // Fog and mist are nouns with no metaphorical falling sense, so their
    // plain presence is enough — "the fog had not lifted", "mist clung to
    // the water".
    [/\b(fog|mist|haze)\b(?!\s+of\b)/i, 0],
    // "the storm broke", "a storm was coming"
    [/\b(storm|thunder|lightning|lightening)\b(?!\s+of\b)/i, 0],
    // "soaked to the skin", "rain-slick cobbles"
    [/\b(rain-?slick|rain-?soaked|snow-?covered|fog-?bound|drenched by the rain)\b/i, 0],
  ];

  // Inflections matter: \brain\b does not match "raining", so a sentence could
  // pass the construction test and then resolve to no kind at all.
  const WEATHER_KIND = [
    [/\b(snow\w*|sleet\w*|blizzard\w*)\b/i, "snow"],
    [/\b(fog\w*|mist\w*|haz\w*)\b/i, "fog"],
    [/\b(rain\w*|drizzl\w*|downpour|storm\w*|thunder\w*|lightning|lightening|squall\w*|pour\w*|hail\w*)\b/i, "rain"],
  ];

  // A precipitation verb can describe OTHER things falling: "flames were
  // raining down", "it rained debris", "arrows hailed down". The literal
  // weather patterns above must never see those verbs, or the generic
  // "it ... rained" / bare "raining" rules mistake the metaphor for weather.
  //
  // Do this by masking only the figurative verb, not by blacklisting the
  // object (fire, arrows, glass, frogs, whatever prose invents next). A real
  // weather use has either impersonal "it" or no material subject, and if a
  // precipitation verb takes a direct object, that object is the giveaway.
  const PRECIP_SAFE_TAIL = new Set([
    "again", "all", "although", "and", "around", "as", "at", "before", "because",
    "briefly", "but", "by", "constantly", "continuously", "down", "earlier",
    "everywhere", "for", "from", "hard",
    "harder", "heavily", "here", "inside", "intermittently", "into", "later",
    "lightly", "nonstop", "now", "off", "on", "outside", "overnight", "over",
    "or", "relentlessly", "since", "softly", "steadily", "still", "straight",
    "suddenly", "then", "there", "though", "through", "throughout", "today", "tonight",
    "until", "upon", "when", "while", "yesterday",
    // Common literal-rain idioms / nouns. Without these, "rained buckets"
    // would be treated like "rained fire", which is technically grammatical
    // and practically annoying.
    "buckets", "cats", "drops", "droplets", "sheets", "water",
  ]);

  function maskFigurativePrecipitation(sentence) {
    let s = String(sentence || "");

    // A material/noun subject + progressive precipitation is figurative:
    // "embers were raining down", "glass was hailing onto the street".
    // Literal English uses impersonal "it was raining" instead.
    s = s.replace(
      /\b((?!it\b)[a-z][\w'-]*(?:\s+and\s+[a-z][\w'-]*)?\s+(?:was|were|is|are|had been|has been)\s+)(raining|drizzling|hailing|snowing|sleeting)\b/gi,
      "$1falling"
    );

    // Inflected precipitation verb taking a direct object: "it rained fire",
    // "it rained down debris". Adverbs/prepositions remain literal weather.
    s = s.replace(
      /\b(rains|rained|raining|drizzles|drizzled|drizzling|hails|hailed|hailing|snows|snowed|snowing)\b(\s+down\b)?(?:\s+([a-z][\w'-]*))?/gi,
      (whole, verb, down, next) => {
        if (!next || PRECIP_SAFE_TAIL.has(next.toLowerCase())) return whole;
        return `falls${down || ""} ${next}`;
      }
    );

    // Root form after an infinitive/modal: "started to rain ash",
    // "could rain sparks". Same direct-object rule, same reason.
    s = s.replace(
      /\b((?:to|can|could|would|might|may|will|should|shall|did|does)\s+)(rain|drizzle|hail|snow)\b(\s+down\b)?(?:\s+([a-z][\w'-]*))?/gi,
      (whole, lead, verb, down, next) => {
        if (!next || PRECIP_SAFE_TAIL.has(next.toLowerCase())) return whole;
        return `${lead}fall${down || ""} ${next}`;
      }
    );

    return s;
  }

  /** Weather only if the text says so in a weather-shaped way. */
  function detectWeather(text) {
    // Resolve construction AND kind inside the same sentence. The old code
    // tested the construction against all text, then looked for the kind in
    // all text too, so an unrelated "snow" elsewhere could hijack a real
    // rain sentence. Weather effects should not be selected by keyword soup.
    const sentences = stripDialogue(String(text || ""))
      .split(/(?<=[.!?\u2026])\s+|[\r\n]+/)
      .map((s) => s.trim())
      .filter(Boolean);

    for (const original of sentences) {
      const t = maskFigurativePrecipitation(original);
      const hit = WEATHER_LITERAL.some(([re]) => re.test(t));
      if (!hit) continue;
      for (const [re, kind] of WEATHER_KIND) if (re.test(t)) return kind;
    }
    return "";
  }

  function detectConditions(rawText) {
    const text = String(rawText || "");
    const out = {};
    if (FIREFLIES.test(text)) out.fireflies = true;
    if (ROMANCE.test(text)) out.romance = true;
    if (GARDEN.test(text)) out.garden = true;
    const w = detectWeather(text);
    if (w) out.weather = w;
    for (const [re, v] of TIMEOFDAY) if (re.test(text)) { out.time = v; break; }
    if (FIRE_STEADY.test(text)) out.fire = "steady";
    else if (FIRE_BURST.test(text)) out.fire = "burst";
    else if (FIRELIGHT.test(text)) out.fire = "steady";

    // If this turn explicitly uses figurative precipitation around fire, do
    // not let a previously-carried rain state beat the fresh ember effect.
    // "clear" is already the extension's no-particle weather sentinel and is
    // omitted from the generated prompt. Literal weather above still wins.
    if (!w && out.fire && maskFigurativePrecipitation(text) !== text) {
      out.weather = "clear";
    }
    return out;
  }

  /** Is this a direction to the WRITING model rather than something that
   *  happened in the story?
   *
   *  "move shit forward" and "End when an action, dialogue, or event genuinely
   *  requires Euri's response" both reached the image prompt as a character's
   *  pose. The earlier filter only caught SHOUTED directives, so ordinary
   *  sentence-case instructions sailed through. The reliable tell isn't
   *  capitals — it's meta-vocabulary: real prose describes people and places,
   *  instructions talk about responses, scenes, dialogue and plots as objects. */
  const META = /\b(response|reply|replies|dialogue|narration|narrate|prose|output|format|plot|pacing|scene beat|word count|paragraph|instruction|rule|guideline|user|assistant|persona card|character sheet|in character|out of character|continuity|agency|pacing|stakes)\b/i;
  const IMPERATIVE = /^\s*(end|start|begin|write|keep|avoid|do not|don't|never|always|make sure|remember|focus|continue|stop|move|use|include|describe|respond|reply|maintain|ensure|aim|try|let|allow|push|drive|advance|preserve|prioritise|prioritize)\b/i;

  function isDirective(sentence) {
    const s = String(sentence).trim();
    if (!s) return false;
    // Imperative opening plus meta-vocabulary: almost always an instruction.
    if (IMPERATIVE.test(s) && META.test(s)) return true;
    // "End when X requires Y's response" — conditional instruction.
    if (/^\s*(end|stop|continue)\b[^.]*\bwhen\b/i.test(s) && META.test(s)) return true;
    // Crude but common: an imperative with no proper noun and no past tense.
    if (IMPERATIVE.test(s) && !/[A-Z][a-z]{2,}/.test(s.slice(1)) &&
        !/\b\w+(ed|了)\b/.test(s)) return true;
    return false;
  }

  function scoreSentence(sentence, names = []) {
    const w = words(sentence);
    if (!w.length) return { score: -Infinity, hits: {} };

    const hits = { lighting: [], setting: [], appearance: [], color: [], verbs: [] };
    let interior = 0;

    for (const word of w) {
      if (inSet(LIGHTING).has(word)) hits.lighting.push(word);
      if (inSet(SETTING).has(word)) hits.setting.push(word);
      if (inSet(APPEARANCE).has(word)) hits.appearance.push(word);
      if (inSet(COLOR).has(word)) hits.color.push(word);
      if (inSet(VISUAL_VERBS).has(word)) hits.verbs.push(word);
      if (inSet(INTERIOR).has(word)) interior += 1;
    }

    // Props being handled: concrete, drawable, and previously ignored.
    const lower = sentence.toLowerCase();
    const props = PROPS.filter((p) => new RegExp(`\\b${p}s?\\b`).test(lower));
    const handled = props.length && HANDLING.test(sentence) ? props.length : 0;

    // A named character anchors who is actually in frame.
    const named = names.some((n) => {
      const first = String(n).split(/\s+/)[0].toLowerCase();
      return first.length > 2 && lower.includes(first);
    }) ? 1 : 0;

    // Mostly speech attribution and little else.
    const attribution = ATTRIBUTION.test(sentence) ? 1 : 0;

    let score =
      hits.appearance.length * 2.5 +
      hits.setting.length * 2.0 +
      hits.lighting.length * 2.0 +
      hits.color.length * 1.5 +
      hits.verbs.length * 1.5 +
      handled * 1.8 +
      named * 1.2 -
      attribution * 1.5 -
      interior * 3.0;

    // Concrete detail tends to be mid-length. Very short lines are usually
    // beats ("She paused."); very long ones ramble across several ideas.
    if (w.length < 6) score -= 2;
    if (w.length > 45) score -= (w.length - 45) * 0.08;

    // Density matters more than raw count in a long sentence.
    const density = (score > 0 ? score : 0) / Math.sqrt(w.length);
    score += density;

    return { score, hits, length: w.length };
  }


  // ---------- instruction stripping ----------
  // Templates always sit at the TOP and prose at the bottom, so we find where
  // prose begins rather than parsing any particular template. Works for models
  // with no thinking block at all.

  const INSTRUCTION_LINE = [
    /^#{1,6}\s/,                       // ## CORE RULES
    /^\s*[-*\u2022]\s/,                 // - bullets
    /^\s*\*\s/,
    /^[A-Z][A-Z \t'"\u2019]{6,}:/,       // SCREAM: / NOW: style shouting
    /^(NOW|WHO|WHERE|PRESSURE|THREADS|SCENE|OUTPUT|FINAL OUTPUT|CORE RULES|NARRATIVE LENS)\b\s*:/i,
    // Directive keywords count ONLY in shouting case: prose starts sentences
    // with "Never mind…" / "Always the same…" / "Write to me…" all the time,
    // and one false hit here used to delete everything above it.
    /^\s*(DO NOT|DON'T|NEVER|ALWAYS|KEEP IT|END WHEN|AVOID)\s+[A-Z]/,
    /\bWrite\s+[A-Z][\w']*(\s+[A-Z][\w']*)?['\u2019]s\s+(response|reply|reaction)/i,
    /\{\{(user|char)\}\}/i,
  ];

  /** A line that is mostly capitals is a directive, not narration. */
  function isShouting(line) {
    const letters = line.replace(/[^A-Za-z]/g, "");
    if (letters.length < 12) return false;
    const caps = line.replace(/[^A-Z]/g, "").length;
    return caps / letters.length > 0.7;
  }

  function isInstruction(line) {
    const t = line.trim();
    if (!t) return false;
    if (isShouting(t)) return true;
    return INSTRUCTION_LINE.some((re) => re.test(t));
  }

  /**
   * Remove any instruction/template preamble.
   * @param {string} text
   * @param {number} tailChars cap for very long replies (0 = no cap)
   */
  /** Names arrive from the site and can contain regex metacharacters — a bot
   *  called "[kellas" produced /\b[kellas\b/ and the whole draft failed with
   *  "Unterminated character class". Anything interpolated into a pattern has
   *  to be escaped first. */
  function escapeRe(s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  /** Does this name appear as a whole word? Escaped, and wrapped so that a
   *  pathological name degrades to a plain substring check instead of throwing
   *  and failing the entire draft. */
  function nameAppears(haystack, name) {
    try {
      return new RegExp(`\\b${escapeRe(name)}\\b`, "i").test(haystack);
    } catch {
      return haystack.includes(String(name).toLowerCase());
    }
  }

  function stripInstructions(text, tailChars = 2500) {
    const lines = String(text || "").split(/\r?\n/);

    // Everything up to and including the LAST instruction line is preamble —
    // but ONLY if the region above it is actually dense with instructions.
    // A template block is many directive lines in a row; one stray match in
    // the middle of real prose is not a reason to delete half the reply.
    let cut = -1;
    const limit = Math.floor(lines.length * 0.75);
    for (let i = 0; i < lines.length; i++) {
      if (i <= limit && isInstruction(lines[i])) cut = i;
    }
    if (cut >= 0) {
      const above = lines.slice(0, cut + 1).filter((l) => l.trim());
      const hits = above.filter(isInstruction).length;
      if (hits < 3 && hits / Math.max(1, above.length) < 0.3) cut = -1;
    }
    let kept = lines.slice(cut + 1);

    // Belt and braces: drop any surviving directive lines.
    kept = kept.filter((l) => !isInstruction(l));

    let out = kept.join("\n").replace(/\n{3,}/g, "\n\n").trim();

    // Monster replies: keep the tail, on a paragraph boundary.
    if (tailChars && out.length > tailChars) {
      const slice = out.slice(out.length - tailChars);
      const brk = slice.indexOf("\n");
      out = (brk > 0 ? slice.slice(brk + 1) : slice).trim();
    }
    return out;
  }

  // ---------- pose extraction ----------

  const BODY = [
    "hand", "hands", "arm", "arms", "shoulder", "shoulders", "head", "chin",
    "jaw", "gaze", "eyes", "eye", "face", "mouth", "lips", "knee", "knees",
    "hip", "back", "chest", "throat", "neck", "fingers", "wrist", "elbow",
    "foot", "feet", "leg", "legs", "palm", "thumb", "brow", "body", "weight",
  ];
  const ORIENT = [
    "toward", "towards", "against", "beside", "behind", "over", "under",
    "close", "closer", "away", "back", "down", "up", "across", "around",
    "between", "onto", "into", "near", "flush", "apart", "opposite",
  ];
  const POSTURE_VERBS = [
    // base forms matter: "didn't move closer" / "didn't reach for her" are the
    // most informative clauses in a restraint scene and were being missed
    "move", "moves", "reach", "reaches", "touch", "touches", "lean", "lean",
    "shift", "turn", "pull", "push", "hold", "sit", "stand", "step", "look",
    "shivering", "shivered", "trembling", "trembled", "huddled", "curled",
    "wrapped", "tucked", "flinched", "stiffened", "relaxed",
    "stood", "stand", "standing", "sat", "sitting", "sits", "leaned", "leaning",
    "knelt", "kneeling", "crouched", "lay", "lying", "turned", "turning",
    // Violent and protective action. The list was built for quiet scenes, so
    // an explosion lost its most drawable clauses: "he shoved her against the
    // wall", "covered her with his own body", "braced over her" all failed the
    // physical test and never reached the prompt.
    "shoved", "shove", "shoving", "shielded", "shielding", "covered", "covering",
    "braced", "bracing", "yanked", "hauled", "dragged", "dragging", "pinned",
    "crowded", "crowding", "slammed", "threw", "thrown", "tackled", "grabbed",
    "gripped", "clutched", "caught", "blocked", "ducked", "dove", "rolled",
    "scrambled", "staggered", "stumbled", "collapsed", "fell", "knocked",
    "punched", "struck", "swung", "kicked", "hit", "raised", "lowered",
    "shifted", "tilted", "tucked", "pulled", "pushed", "reached", "gripped",
    "held", "holding", "wrapped", "slipped", "lifted", "dropped", "settled",
    "rested", "crossed", "folded", "curled", "pressed", "brushed", "loomed",
    "crowded", "stepped", "moved", "faced", "watched", "looked", "glanced",
    "slumped", "perched", "braced", "hunched", "straightened",
  
    // Motion and posture the original list missed — a player writing "She
    // whipped around and started smacking him" got no pose at all, because
    // none of those verbs were here. Movement only: no injury or damage
    // vocabulary, which image hosts routinely refuse.
    "whipped", "whirled", "spun", "swung", "swinging", "smacked", "smacking",
    "slapped", "slapping", "hitting", "lunged", "ducked", "dodged", "twisted",
    "wrenched", "yanked", "hauled", "flung", "thrust", "jabbed", "swatted",
    "recoiled", "flinched", "staggered", "stumbled", "braced", "clutched",
    "clutching", "seized", "seizing", "shielded", "blocked", "wrestled",
    "hoisted", "scooped", "spinning", "turning", "twisting", "raising",
    "blinked", "blinking",
  
    // Position within a vehicle or seat — "who is driving" is scene content,
    // and none of it was here.
    "driving", "drove", "steering", "steered", "riding", "rode", "seated",
    "sitting", "sat", "slouched", "hunched", "sprawled", "perched", "kneeling",
    "crouched", "buckled", "reversing", "parked", "idling",
    // Expression. BODY already has eyes/jaw/mouth; these are the verbs that
    // turn them into something drawable.
    "narrowed", "widened", "tightened", "clenched", "flushed", "paled",
    "glared", "glaring", "scowled", "scowling", "smiled", "smiling",
    "grinned", "grinning", "frowned", "frowning", "winced", "wincing",
    "grimaced", "smirked", "sneered", "beamed", "trembled", "shaking",
  ];
  const NEGATORS = /\b(didn'?t|did not|doesn'?t|does not|never|no longer|without|wouldn'?t|refused to|made no)\b/i;

  /** Split a sentence into clauses — pose lives in clauses, not sentences. */
  function clauses(sentence) {
    return String(sentence)
      // Subordinating conjunctions START A NEW CLAUSE, and very often a new
      // SUBJECT: "Kellas stood there ... until she turned down a narrow alley"
      // was kept as one clause, so her movement was recorded as his pose.
      .split(/,\s+(?=\w)|\s+(?:and|but|then|while|as|until|before|after|when|once|so|because|though|although|unless)\s+|;\s*/i)
      .map((c) => c.trim())
      .filter((c) => c.length > 6);
  }

  /** Things a camera cannot photograph: speech, interiority, and backstory.
   *  These are dropped no matter how they are phrased. */
  const NOT_VISIBLE = /\b(said|says|asked|asks|replied|answered|murmured|muttered|whispered|shouted|yelled|called out|added|admitted|agreed|thought|thinks|wondered|remembered|recalled|realized|realised|decided|knew|understood|hoped|wished|meant|supposed|figured|felt like|as if|used to|had been|had always|would have|years ago|reminded (him|her|them))\b/i;

  /** Opens with a thing rather than a person, so it is describing the room,
   *  not the character. "The headlights swung across the road" is not a pose,
   *  and was being filed under whoever spoke last. */
  const IMPERSONAL = /^(the|a|an|it|there|that|this|these|those)\b/i;

  /** Plainly about a person: starts with them, or with something of theirs.
   *  Enough on its own to keep a clause whose verb we do not recognise. */
  const PERSONAL_SUBJECT = /^(he|she|they|his|her|their|him|hers|both of them|one of them)\b/i;

  function isPhysical(clause) {
    const w = words(clause);
    const has = (list) => w.some((x) => inSet(list).has(x));
    return (has(BODY) && (has(ORIENT) || has(POSTURE_VERBS))) || has(POSTURE_VERBS);
  }

  /**
   * Merge every physical clause about each character into one posture string.
   * Pronouns are resolved to the last named character of that gender, because
   * roleplay names someone once and then says "he" for six sentences.
   *
   * @param {string} prose  instruction-free text
   * @param {Array} cast    [{name, gender}] gender: "m"|"f"|null
   */
/** The single most drawable thing in a reply: one person doing something TO
 *  another. "Lark slapping Zeke across the face" is a picture; two separate
 *  poses describing the same scuffle are a roster the image model has to
 *  reassemble, and often doesn't.
 *
 *  A clause qualifies when its subject resolves to one cast member and it
 *  also contains a pronoun or name belonging to a DIFFERENT one. That is what
 *  makes it an interaction rather than a pose. */
  const OBJECT_PRONOUN = /\b(him|her|them|his|hers|their|theirs)\b/i;

  function extractInteraction(prose, cast = []) {
    const sentences = splitSentences(stripMarkup(prose));
    const males = cast.filter((c) => c.gender === "m");
    const females = cast.filter((c) => c.gender === "f");
    const lastM = males.length === 1 ? males[0] : null;
    const lastF = females.length === 1 ? females[0] : null;
    // No early return on unknown genders: a name in the prose resolves without
    // one, and plenty of cards carry no gendered words to guess from.
    const named = (word) => cast.find((c) =>
      word === String(c.name).split(/\s+/)[0].toLowerCase()) || null;

    const whoIs = (word, other) => {
      const w = word.toLowerCase();
      if (/^(he|him|his)$/.test(w)) {
        if (lastM) return lastM;
      } else if (/^(she|her|hers)$/.test(w)) {
        if (lastF) return lastF;
      } else {
        return named(w);
      }
      // A two-hander with unknown genders: a pronoun that is not the person
      // already acting can only be the other one.
      if (other && cast.length === 2) {
        return cast.find((c) => c.name !== other.name) || null;
      }
      return null;
    };

    let best = null;
    let prevSubject = null;
    let prevPronoun = null;

    for (const sentence of sentences) {
      if (isDirective(sentence)) continue;
      for (const cl of clauses(sentence)) {
        // The splitter leaves the conjunction on the front of the clause
        // ("and his hand came up"), so the first word was "and" and the actor
        // never resolved — which silently lost most interactions.
        const clean = cl.trim()
          .replace(/^[,;:\s]+|[,;:\s]+$/g, "")
          .replace(/^(?:and|but|then|so|yet|or)\s+/i, "");
        if (clean.split(/\s+/).length < 3) continue;
        if (NOT_VISIBLE.test(clean)) continue;

        // Who is acting.
        const lead = clean.match(/^\s*([A-Za-z]+)\b/);
        let actor = lead ? whoIs(lead[1]) : null;
        // Which pronoun refers to the actor. With unknown genders this is the
        // only way to tell "she" from "him" — filling both gender slots with
        // the same person produced "Lark's Zeke slapped Zeke".
        let actorPronoun = lead && /^(he|him|his|she|her|hers)$/i.test(lead[1])
          ? lead[1].toLowerCase() : null;
        if (!actor && !IMPERSONAL.test(clean)) {
          actor = prevSubject;
          actorPronoun = actorPronoun || prevPronoun;
        }
        if (actor) { prevSubject = actor; prevPronoun = actorPronoun; }
        if (!actor) continue;

        // Who is being acted on: any later pronoun or name that is NOT them.
        let target = null;
        for (const m of clean.slice(lead ? lead[0].length : 0)
                             .matchAll(/\b([A-Za-z]+)\b/g)) {
          const who = whoIs(m[1], actor);
          if (who && who.name !== actor.name) { target = who; break; }
        }
        if (!target) continue;
        if (!OBJECT_PRONOUN.test(clean) &&
            !clean.toLowerCase().includes(String(target.name).split(/\s+/)[0].toLowerCase())) {
          continue;
        }

        const score = scoreSentence(clean).score + clean.split(/\s+/).length * 0.05;
        if (!best || score > best.score) best = { actor, target, text: clean, score, actorPronoun };
      }
    }
    if (!best) return null;

    // Resolve the pronouns to names: the image model has no conversation to
    // work out who "her" is, which is the whole reason a roster was needed.
    // Resolve pronouns by GENDER, not by role. "her palm" belongs to whoever
    // is female, whether that is the actor or the target — assuming every
    // possessive belonged to the target produced "Lark pressed Zeke's palm
    // against Zeke's chest", which is two people wearing one body.
    const firstOf = (c) => String(c.name).split(/\s+/)[0];
    const actor = firstOf(best.actor);
    const byGender = { m: null, f: null };
    for (const c of cast) {
      if (c.gender === "m" && !byGender.m) byGender.m = firstOf(c);
      if (c.gender === "f" && !byGender.f) byGender.f = firstOf(c);
    }
    // Unknown genders in a two-hander: whichever pronoun is not the actor's
    // belongs to the other person, so both slots can still be filled.
    if (cast.length === 2 && (!byGender.m || !byGender.f)) {
      const other = cast.find((c) => c.name !== best.actor.name);
      const mine = best.actorPronoun;
      if (other && mine) {
        // The actor's own pronoun points at the actor; the other one at the
        // other person. Assigning both to "the other" made one body do
        // everything.
        if (/^(he|him|his)$/.test(mine)) {
          byGender.m = byGender.m || actor;
          byGender.f = byGender.f || firstOf(other);
        } else {
          byGender.f = byGender.f || actor;
          byGender.m = byGender.m || firstOf(other);
        }
      } else if (other) {
        if (!byGender.m) byGender.m = firstOf(other);
        if (!byGender.f) byGender.f = firstOf(other);
      }
    }

    // "caught her by the collar" is an object, not a possessive: a possessive
    // is followed by a noun, never by a preposition.
    const NOT_A_NOUN = /^(by|in|on|at|to|from|with|and|but|for|of|into|onto|over|under|across|back|away|out|up|down|again|there|hard|slowly|first|then)\b/i;

    let text = best.text.replace(/\b(his|her|their|him|them|she|he|they)\b(\s*)([a-z']*)/gi,
      (whole, pron, gap, next) => {
        const p = pron.toLowerCase();
        const who = /^(he|him|his)$/.test(p) ? byGender.m
                  : /^(she|her|hers)$/.test(p) ? byGender.f
                  : null;
        if (!who) return whole;
        const possessive = /^(his|her|their)$/.test(p) && next && !NOT_A_NOUN.test(next);
        // A possessive belonging to the actor reads better left alone:
        // "Lark pressed her palm" beats "Lark pressed Lark's palm".
        if (possessive && who === actor) return whole;
        return possessive ? `${who}'s${gap}${next}` : `${who}${gap}${next}`;
      });

    // A clause can open with a body part rather than a person — "fingers
    // closing around her wrist" says nothing about WHOSE fingers.
    if (!new RegExp(`\\b${escapeRe(actor)}\\b`, "i").test(text)) {
      text = /^[a-z]+ing\b/i.test(text) ? `${actor} ${text}` : `${actor}'s ${text}`;
    }
    return { ...best, text: text.replace(/\s+/g, " ").trim() };
  }

  function extractPose(prose, cast = []) {
    const sentences = splitSentences(stripMarkup(prose));
    const out = {};
    const negated = {};
    for (const c of cast) { out[c.name] = []; negated[c.name] = []; }

    // Seed pronouns from the cast: the player's character is often never named
    // in the prose at all (only "she"), so waiting for a name means she never
    // gets a pose. With one character of a gender, the pronoun is unambiguous.
    const males = cast.filter((c) => c.gender === "m");
    const females = cast.filter((c) => c.gender === "f");
    let lastM = males.length === 1 ? males[0] : null;
    let lastF = females.length === 1 ? females[0] : null;
    let prevSubject = null;

    const byFirst = new Map();
    for (const c of cast) byFirst.set(String(c.name).split(/\s+/)[0].toLowerCase(), c);

    for (const sentence of sentences) {
      // Who is this sentence about?
      let subject = null;
      const lower = sentence.toLowerCase();
      for (const [first, c] of byFirst) {
        if (first.length > 2 && nameAppears(lower, first)) {
          subject = c;
          if (c.gender === "m") lastM = c;
          if (c.gender === "f") lastF = c;
          break;
        }
      }
      if (!subject) {
        // Only a LEADING pronoun names the subject. "Didn't reach for her"
        // contains "her" as the object — carrying the previous subject forward
        // attributes it to the man doing the not-reaching, which is correct.
        const lead = lower.match(/^\s*(he|his|him|she|her|hers|they)\b/);
        if (lead) subject = /^h(e|is|im)$/.test(lead[1]) ? lastM : lastF;
        else if (!/^\s*[a-z]*\s*(the|a|an|it|there)\b/.test(lower)) subject = prevSubject;
      }
      prevSubject = subject || prevSubject;

      // Each clause can have its OWN subject. A sentence-level subject meant
      // that "Kellas stood there ... until she turned down a narrow alley"
      // filed her movement under his pose — and left her with none.
      // A sentence can open impersonally — "The third caught him across the
      // cheekbone" — and still carry the most drawable clause in the reply:
      // "his hand came up on instinct ... fingers closing around her wrist".
      // Bailing out on the nameless opening threw every one of those away,
      // which is why a pronoun-heavy reply produced no poses at all even when
      // the genders were known.
      let clauseSubject = subject && out[subject.name] ? subject : null;
      for (const cl of clauses(sentence)) {
        const clean = cl
          .replace(/^(and|but|then|while|as|until|before|after|when|once|so|because|though|although|unless)\s+/i, "")
          .trim();
        if (!clean) continue;

        const cLower = clean.toLowerCase();
        let owner = null;

        // SUBJECT POSITION decides ownership, not mere presence. "He shoved
        // Euri against the wall" is HIS action; taking any name found in the
        // clause filed it under her, because her name is the object.
        //
        // 1. A name at the very start is the subject.
        for (const [first, cc] of byFirst) {
          if (first.length > 2 && new RegExp(`^${escapeRe(first)}\\b`, "i").test(clean)) {
            owner = cc;
            break;
          }
        }
        // 2. Otherwise a leading pronoun — "until she turned down a narrow alley".
        if (!owner) {
          const lead = cLower.match(/^(he|his|him|she|her|hers|they)\b/);
          if (lead) owner = /^h(e|is|im)$/.test(lead[1]) ? lastM : lastF;
        }
        // 3. Only if the clause has no subject of its own does a name
        //    elsewhere in it count.
        if (!owner && !/^(and|but|then|so)\b/i.test(clean)) {
          for (const [first, cc] of byFirst) {
            if (first.length > 2 && nameAppears(cLower, first)) { owner = cc; break; }
          }
        }
        if (owner) clauseSubject = owner;

        const target = clauseSubject && out[clauseSubject.name]
          ? clauseSubject
          : (subject && out[subject.name] ? subject : null);
        if (!target) continue;
        // Splitting on conjunctions leaves tails like "as flaming timber" —
        // a fragment with no action in it, which reads as noise in a prompt.
        if (clean.split(/\s+/).length < 3) continue;

        // An ALLOWLIST was the ceiling on this whole feature. Requiring a
        // verb from POSTURE_VERBS meant any action written with a word nobody
        // had thought to add was thrown away in silence — and prose invents
        // verbs endlessly. Every round of "it missed what was happening" was
        // this line.
        //
        // Inverted: a clause that plainly belongs to a person is kept whether
        // or not its verb is recognised, and only clauses that are definitely
        // not a picture get dropped. The lexicon still runs, so a known
        // physical verb passes even without an explicit subject.
        if (NOT_VISIBLE.test(clean)) continue;          // speech, thought, memory
        if (IMPERSONAL.test(clean) && !isPhysical(clean)) continue;  // scenery
        if (!isPhysical(clean) && !PERSONAL_SUBJECT.test(clean)) continue;

        if (NEGATORS.test(clean)) negated[target.name].push(clean);
        else out[target.name].push(clean);
      }
    }

    const merged = {};
    for (const c of cast) {
      const pos = dedupeClauses(out[c.name]).slice(0, 4);
      const neg = dedupeClauses(negated[c.name]).slice(0, 2);
      const parts = [...pos, ...neg]
        .map((p) => p.replace(/[.,;:]+$/, "").trim())
        .filter(Boolean);
      if (parts.length) merged[c.name] = parts.join(", ").replace(/\s+/g, " ");
    }
    return merged;
  }

  function dedupeClauses(list) {
    const seen = [];
    for (const c of list) {
      if (!seen.some((s) => jaccard(words(s), words(c)) > 0.55)) seen.push(c);
    }
    return seen;
  }

  // ---------- mood ----------

  // Ambiguous words are deliberately absent. "cold", "hard" and "dark" describe
  // weather, stone and hair at least as often as they describe anger — counting
  // them labelled a scene about sharing body heat as hostile.
  const MOODS = {
    hostile: ["glare", "glared", "glaring", "snapped", "snarled", "spat", "slammed",
      "shoved", "grabbed", "loomed", "crowded", "furious", "fury", "rage",
      "tightened", "threat", "threatening", "sneer", "contempt", "hissed",
      "barked", "seized", "forced", "shouted", "struck", "slapped", "bared"],
    tender: ["gentle", "gently", "soft", "softly", "warmth", "smiled",
      "smile", "tucked", "brushed", "murmured", "kissed", "stroked", "cradled",
      "comfort", "careful", "carefully", "leaned into", "against his chest"],
    restrained: ["didn't move", "did not move", "didn't reach", "did not reach",
      "didn't touch", "no longer", "without touching", "hesitated",
      "stripped of romance", "no expectation", "your choice", "let her decide",
      "kept his distance", "held back", "restraint", "not going to do anything"],
    somber: ["quiet", "silence", "silent", "tired", "weary", "grief", "empty",
      "hollow", "dark", "heavy", "slow", "still"],
    playful: ["grinned", "grin", "laughed", "laugh", "smirk", "smirked", "teased",
      "snorted", "joked", "wry", "amused"],
    // There was no mood for violence at all, so an explosion fell through to
    // the romance axis: "he didn't move" scored as RESTRAINED and the prompt
    // told the model nobody was touching, while he was shielding her with his
    // body. Danger has to be able to win.
    danger: ["explosion", "exploded", "blast", "shrapnel", "screaming", "screams",
      "wreckage", "rubble", "debris", "blood", "bleeding", "gash", "wound",
      "shattered", "burning", "smoke", "collapsed", "gunfire", "shot",
      "stabbed", "struck him", "struck her", "thrown", "slammed", "dust"],
  };

  /** Vote across the prose; authors state mood loudly and repeatedly. */
  function detectMood(prose, pressure = "") {
    const hay = (String(prose) + " " + String(pressure)).toLowerCase();
    const scores = {};
    for (const [mood, list] of Object.entries(MOODS)) {
      scores[mood] = list.reduce(
        (n, w) => n + (hay.split(w).length - 1) * (w.includes(" ") ? 2 : 1), 0);
    }
    // Multi-word restraint phrases are unambiguous, so they count double.
    scores.restrained *= 2;

    // Violence outranks everything else. In a scene with an explosion, what
    // the characters' hands are doing romantically is not the story, and a
    // "nobody is touching" line actively contradicts the prose.
    if (scores.danger >= 2) {
      return { mood: "danger", score: scores.danger, second: null };
    }
    const ranked = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    const [top, score] = ranked[0];
    // A weak signal is worse than none: a wrong mood line actively misdirects.
    if (score < 3) return null;
    const runner = ranked[1];
    return { mood: top, score, second: runner && runner[1] >= score * 0.7 ? runner[0] : null };
  }

  // A mood sets the temper of the picture. It must not put THINGS in it:
  // "dust and debris, alarm" was a fixed string on the danger bucket, so a
  // scuffle inside a car came back with rubble and sirens the writing never
  // mentioned — and the image model duly drew them. Posture and expression
  // are safe because they belong to whoever is already in frame; props and
  // scenery are not, and are left to the character and object lines.
  const MOOD_TEXT = {
    hostile: { say: "tense and hostile — hard expressions, aggressive body language",
               deny: "This is NOT a romantic, affectionate or playful moment." },
    restrained: { say: "charged but restrained — deliberate distance, nobody reaching out",
                  deny: "They are NOT embracing, kissing or holding hands." },
    tender: { say: "quiet and close — relaxed, warm body language", deny: "" },
    somber: { say: "subdued and heavy — tired, quiet, low energy", deny: "" },
    playful: { say: "loose and amused — easy posture, wry expressions", deny: "" },
    // No deny line: in a disaster, closeness is protective, not romantic, and
    // telling the model "they are NOT embracing" would fight the scene.
    danger: { say: "violent and urgent — sudden movement, braced posture", deny: "" },
  };

  // ---------- public: condense ----------

  /**
   * Rank the visual moments in a reply.
   * @param {string} reply raw message text
   * @param {number} max how many candidate moments to return
   * @returns {{candidates: Array, best: Object|null}}
   */
  function condense(reply, max = 3) {
    const clean = stripMarkup(String(reply || ""));
    const sentences = splitSentences(clean);

    // Below the floor a "moment" is just a beat of prose with one stray noun.
    // Offering it as a candidate wastes a click and produces a bad image.
    const FLOOR = 4;
    const scored = sentences
      .map((text, i) => ({ text, index: i, ...scoreSentence(text) }))
      .map((s) => ({
        ...s,
        // Recency bonus: the current moment lives at the END of a reply.
        // Earlier sentences describe how the scene got here.
        score: s.score + (s.index / Math.max(1, sentences.length - 1)) * 2.5,
      }))
      .filter((s) => Number.isFinite(s.score) && s.score >= FLOOR)
      .sort((a, b) => b.score - a.score);

    // Three candidates should be three different moments, not one moment
    // described three ways. Word overlap alone let that through — the same
    // scuffle narrated with different nouns scores low on Jaccard while
    // still being the same beat — so distance through the reply matters too.
    // Strict pass first, then relax to fill the slots rather than offering
    // fewer choices.
    const picked = [];
    const take = (minGap, maxOverlap) => {
      for (const cand of scored) {
        if (picked.length >= max) return;
        if (picked.includes(cand)) continue;
        const tooSimilar = picked.some((p) =>
          jaccard(words(p.text), words(cand.text)) > maxOverlap);
        const tooClose = picked.some((p) => Math.abs(p.index - cand.index) < minGap);
        if (!tooSimilar && !tooClose) picked.push(cand);
      }
    };
    take(2, 0.3);    // spread out and clearly distinct
    take(1, 0.4);    // adjacent is fine if it is a different beat
    take(0, 0.55);   // last resort: fill the slots

    const candidates = picked.map(toScene);
    return { candidates, best: candidates[0] || null };
  }

  function jaccard(a, b) {
    const A = new Set(a);
    const B = new Set(b);
    if (!A.size || !B.size) return 0;
    let shared = 0;
    for (const x of A) if (B.has(x)) shared += 1;
    return shared / (A.size + B.size - shared);
  }

  function toScene(s) {
    const uniq = (arr) => [...new Set(arr)];
    return {
      // The sentence itself is already natural language — better prose than
      // anything we'd reassemble from keywords.
      subject: s.text.replace(/\s+/g, " ").trim(),
      action: uniq(s.hits.verbs).slice(0, 4),
      setting: uniq(s.hits.setting).slice(0, 5),
      lighting: uniq(s.hits.lighting).slice(0, 4),
      extras: uniq([...s.hits.appearance, ...s.hits.color]).slice(0, 8),
      score: Math.round(s.score * 10) / 10,
      source: "heuristic",
      /** One-line label for a picker chip. */
      label: shorten(s.text, 52),
    };
  }

  function shorten(text, n) {
    const t = text.replace(/\s+/g, " ").trim();
    return t.length <= n ? t : t.slice(0, n - 1).replace(/\s\S*$/, "") + "…";
  }

  // ---------- public: assemble ----------

  /**
   * Build a backend-specific prompt.
   * @param {Object} scene from condense()
   * @param {Object} sheet {character, user, style} free-text appearance blocks
   * @param {"tags"|"prose"} style tags for SD/Pollinations, prose for GPT Image
   */
  function assemble(scene, sheet = {}, style = "tags") {
    if (!scene) return { prompt: "", negative: SD_NEGATIVE };
    const character = (sheet.character || "").trim();
    const user = (sheet.user || "").trim();
    const styleNote = (sheet.style || "").trim();

    if (style === "prose") {
      // GPT Image and friends reward full sentences and punish tag soup.
      const who = [character, user].filter(Boolean).join(" and ");
      const parts = [];
      if (who) parts.push(`${who}.`);
      parts.push(scene.subject);
      if (scene.lighting.length) parts.push(`Lighting: ${scene.lighting.join(", ")}.`);
      if (styleNote) parts.push(styleNote);
      return { prompt: parts.join(" ").replace(/\s+/g, " ").trim(), negative: "" };
    }

    // Stable Diffusion: comma tags, front-loaded, capped near CLIP's 75 tokens.
    const tags = [];
    if (character) tags.push(character);
    if (user) tags.push(user);
    tags.push(...scene.action, ...scene.extras, ...scene.setting, ...scene.lighting);
    if (styleNote) tags.push(styleNote);

    const seen = new Set();
    const deduped = [];
    for (const raw of tags) {
      const tag = String(raw).trim().toLowerCase();
      if (!tag || seen.has(tag)) continue;
      seen.add(tag);
      deduped.push(String(raw).trim());
    }

    return { prompt: capTokens(deduped.join(", "), 70), negative: SD_NEGATIVE };
  }

  /** Rough CLIP budget. A word is close enough to a token for a cap. */
  function capTokens(text, limit) {
    const parts = text.split(", ");
    const out = [];
    let count = 0;
    for (const part of parts) {
      const n = part.split(/\s+/).length;
      if (count + n > limit) break;
      out.push(part);
      count += n;
    }
    return out.join(", ");
  }

  /** Prompt for the optional LLM upgrade. Kept here so both passes agree. */
  function llmInstruction(sheet = {}) {
    // The old version of this told the model nothing about WHO was in the
    // scene. Roleplay prose says "he" and "she" for pages at a time, so a
    // model reading it blind cannot attribute a single action — the same
    // failure the keyword pass has, for the same reason. Naming the cast and
    // asking for per-character state is the whole point of paying for this.
    const cast = Array.isArray(sheet.cast) ? sheet.cast : [];
    const lines = [
      "You read roleplay prose and describe the PICTURE of the moment it depicts.",
      "",
      "Return ONLY JSON. No markdown fences, no commentary:",
      '{"candidates":[{',
      '  "label":"three or four words",',
      '  "subject":"one sentence naming what is in frame",',
      '  "characters":[{"name":"exact name from the cast","doing":"posture, what their hands and face are doing, where they are"}],',
      '  "setting":["where this is happening"],',
      '  "lighting":["light sources or time of day, only if the passage says"],',
      '  "extras":["objects visibly in frame"]',
      "}]}",
      "",
      "Give 2-3 candidates. Each must be a DIFFERENT moment from the passage —",
      "not the same beat reworded. Prefer moments that are far apart in the text.",
      "",
    ];

    if (cast.length) {
      lines.push("The people in this scene:");
      for (const c of cast) {
        const who = c.role === "user" ? " (the player's own character)" : "";
        lines.push(`- ${c.name}${who}${c.appearance ? ` — ${c.appearance}` : ""}`);
      }
      lines.push("");
      lines.push("The passage will mostly say 'he', 'she' and 'they' instead of names.");
      lines.push("Work out who each pronoun refers to and use the exact names above.");
      lines.push("Only list a character under \"characters\" if the passage actually");
      lines.push("shows them doing something. Do not invent a pose for someone offstage.");
      lines.push("");
    }

    lines.push(
      "Rules:",
      "- Describe only what a camera would see. No dialogue, thoughts, memories or backstory.",
      "- Say who is doing what: who is holding, driving, standing, kneeling, reaching.",
      "- Faces count: a clenched jaw or a glare is visible and worth recording.",
      "- Position matters: seated, behind, above, across from, pressed against.",
      "- No camera direction. Do not write shot types, angles, framing or lens language.",
      "- Never add a person, object, or place the passage does not mention.",
      "- If clothing is described, include it under that character's \"doing\".",
      "- Keep every field short. This becomes an image prompt, not a summary.",
    );
    return lines.filter((l) => l !== undefined).join("\n");
  }

  function parseLlmJson(text) {
    const clean = String(text || "").replace(/```json|```/g, "").trim();
    const data = JSON.parse(clean);
    const list = Array.isArray(data.candidates) ? data.candidates : [];
    return list.map((c) => ({
      subject: String(c.subject || "").trim(),
      characters: Array.isArray(c.characters)
        ? c.characters
            .map((p) => ({ name: String(p?.name || "").trim(), doing: String(p?.doing || "").trim() }))
            .filter((p) => p.name && p.doing)
        : [],
      action: toArray(c.action),
      setting: toArray(c.setting),
      lighting: toArray(c.lighting),
      extras: toArray(c.extras),
      label: shorten(String(c.label || c.subject || "Moment"), 52),
      score: null,
      source: "llm",
    })).filter((c) => c.subject);
  }

  function toArray(v) {
    if (Array.isArray(v)) return v.map(String).filter(Boolean).slice(0, 8);
    if (typeof v === "string" && v.trim()) return v.split(/,\s*/).slice(0, 8);
    return [];
  }

  return {
    isDirective,
    findProps,
    extractInteraction,
    extractSnapSection,
    stripSnapSection,
    detectPlace,
    detectDistance,
    detectConditions,
    condense,
    assemble,
    stripInstructions,
    extractPose,
    detectMood,
    MOOD_TEXT,
    llmInstruction,
    parseLlmJson,
    SD_NEGATIVE,
    _internals: { stripDialogue, stripMarkup, splitSentences, scoreSentence , findProps },
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = PromptCondenser;
