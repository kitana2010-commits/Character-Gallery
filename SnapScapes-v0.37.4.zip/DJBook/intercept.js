// intercept.js — runs in the page's MAIN world.
//
// This is the only way to see the site's own network calls. A normal content
// script lives in an isolated world with its own `window`, so patching fetch
// there catches nothing the page does. The manifest must declare:
//
//   { "matches": [...], "js": ["intercept.js"], "world": "MAIN",
//     "run_at": "document_start" }
//
// document_start matters: the app's bundle grabs a reference to fetch early,
// and patching after that point misses everything.
//
// It reads only outbound bodies for one endpoint, and hands them to the
// isolated world by postMessage. It never modifies a request or a response.

(() => {
  const ENDPOINT = "/api/chat";
  const TAG = "djpb:payload";

  function publish(bodyText) {
    try {
      const data = JSON.parse(bodyText);
      if (!data?.sessionId) return;
      // Strip history before it leaves this script — the sheet needs the
      // character, persona, lorebook and plot, not the conversation. Keep only
      // the newest assistant message: the album's "paste latest reply" button.
      const { messages, thinkingTemplate, ...rest } = data;
      const list = Array.isArray(messages) ? messages : [];
      const lastReply = list
        .filter((m) => m?.role === "assistant" && typeof m.content === "string")
        .at(-1)?.content || "";
      // The player's own newest message: what THEY just did is often stated
      // nowhere else, and pose/context lives or dies on it.
      const lastUserMsg = list
        .filter((m) => m?.role === "user" && typeof m.content === "string")
        .at(-1)?.content || "";
      window.postMessage(
        { source: TAG, payload: rest, lastReply, lastUserMsg,
          hasTemplate: Boolean(thinkingTemplate) },
        window.location.origin
      );
    } catch {
      // Not JSON, or a shape we don't recognise. Ignore.
    }
  }

  // ---- reading RESPONSES, not just requests ----
  // The outbound POST only exists once the user sends something, which is why
  // a freshly-opened chat had no character sheet until you typed. The site
  // loads the same bot/persona/lorebook data when the chat OPENS, so we look
  // at inbound JSON too and take it from there. We never modify a response —
  // only a clone is read.

  const MAX_BODY = 3_000_000; // don't parse anything absurd

  /** Does this object look like the chat context we build a sheet from? */
  function looksLikeContext(o) {
    if (!o || typeof o !== "object") return false;
    const hasCast = o.bot || o.character || o.persona;
    const hasWorld = o.lorebooks || o.plot || o.lorebook;
    return Boolean(hasCast && (hasWorld || o.sessionId || o.id));
  }

  /** The payload is often wrapped ({data:{...}}, {session:{...}}). Look a few
   *  levels down rather than guessing the site's envelope. */
  function findContext(node, depth = 0) {
    if (!node || typeof node !== "object" || depth > 3) return null;
    if (looksLikeContext(node)) return node;
    for (const value of Array.isArray(node) ? node : Object.values(node)) {
      const hit = findContext(value, depth + 1);
      if (hit) return hit;
    }
    return null;
  }

  function sessionFromUrl() {
    const m = location.pathname.match(/\/session\/([0-9a-f-]{8,})/i);
    return m ? m[1] : "";
  }

  function publishResponse(bodyText) {
    try {
      if (!bodyText || bodyText.length > MAX_BODY) return;
      if (bodyText[0] !== "{" && bodyText[0] !== "[") return;
      const ctx = findContext(JSON.parse(bodyText));
      if (!ctx) return;
      const payload = { ...ctx };
      // Responses often omit the id the request carried; the URL always has it.
      if (!payload.sessionId) payload.sessionId = ctx.id || sessionFromUrl();
      if (!payload.sessionId) return;
      delete payload.messages;      // history never leaves the page
      window.postMessage(
        { source: TAG, payload, lastReply: "", lastUserMsg: "", hasTemplate: false },
        window.location.origin
      );
    } catch {
      // Not the shape we're after.
    }
  }

  function isApiUrl(url) {
    try {
      const u = new URL(url, location.href);
      return u.origin === location.origin && /\/api\//.test(u.pathname);
    } catch {
      return false;
    }
  }

  const nativeFetch = window.fetch;
  window.fetch = function (input, init) {
    // Read once, not once per branch. Still guarded: this IS the page's fetch,
    // so anything that throws here takes the site's networking down with it —
    // and `input` is whatever the app passed, which may be an exotic object
    // with a throwing `url` getter.
    let url = "";
    try {
      url = typeof input === "string" ? input : input?.url || "";
    } catch { /* leave it empty; the request still goes through untouched */ }

    try {
      const method = (init?.method || input?.method || "GET").toUpperCase();
      if (method === "POST" && url.includes(ENDPOINT)) {
        const body = init?.body;
        if (typeof body === "string") publish(body);
      }
    } catch {
      // Never let instrumentation break the host app's request.
    }

    const p = nativeFetch.apply(this, arguments);
    try {
      if (isApiUrl(url)) {
        p.then((res) => {
          try {
            const type = res.headers?.get?.("content-type") || "";
            if (!/json/i.test(type)) return;
            res.clone().text().then(publishResponse).catch(() => {});
          } catch { /* never disturb the app's own handling */ }
        }).catch(() => {});
      }
    } catch { /* as above */ }
    return p;
  };

  // Some bundles use XHR for the same endpoint. Cover both.
  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__djpb = { method: String(method).toUpperCase(), url: String(url) };
    return open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this.__djpb?.method === "POST" &&
          this.__djpb.url.includes(ENDPOINT) &&
          typeof body === "string") {
        publish(body);
      }
    } catch { /* as above */ }
    try {
      if (this.__djpb && isApiUrl(this.__djpb.url)) {
        this.addEventListener("load", () => {
          try {
            if (this.responseType && this.responseType !== "text") return;
            publishResponse(this.responseText);
          } catch { /* ignore */ }
        });
      }
    } catch { /* ignore */ }
    return send.apply(this, arguments);
  };
})();
