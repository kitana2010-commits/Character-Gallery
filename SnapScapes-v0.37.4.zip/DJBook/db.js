// db.js — v0.4: thin proxy to the service worker, which owns the real
// IndexedDB (extension origin). This lets the browse page and the content
// script share one photo store. All images travel as data URLs in messages.

const PhotobookDB = (() => {
  async function call(op, args = {}) {
    const res = await chrome.runtime.sendMessage({ type: "db", op, args });
    if (!res || !res.ok) throw new Error(res?.error || "Storage error");
    return res.result;
  }

  return {
    /** Add an image (data URL). Returns the new record id. */
    add: (sessionId, dataUrl, meta = {}) => call("add", { sessionId, dataUrl, meta }),

    /** All images for a session, oldest first: [{id, dataUrl, caption, createdAt, source}] */
    list: (sessionId) => call("list", { sessionId }),

    /** Delete one image by record id. */
    remove: (id) => call("remove", { id }),

    /** Set/replace the caption on an image. */
    setCaption: (id, caption) => call("setCaption", { id, caption }),

    /** Reference images per session (data URLs in/out), up to 4. */
    setReference: (sessionId, dataUrl) => call("setReference", { sessionId, dataUrl }),
    getReference: (sessionId) => call("getReference", { sessionId }),
    clearReference: (sessionId) => call("clearReference", { sessionId }),
    addReference: (sessionId, dataUrl, label) =>
      call("addReference", { sessionId, dataUrl, label }),
    listReferences: (sessionId) => call("listReferences", { sessionId }),
    removeReference: (sessionId, index) =>
      call("removeReference", { sessionId, index }),

    /** The image that belongs behind this chat. Pass the id already on screen
     *  to get {unchanged:true} instead of the whole picture again. */
    backdrop: (sessionId, knownId) => call("backdrop", { sessionId, knownId }),
    setBackdrop: (sessionId, id) => call("setBackdrop", { sessionId, id }),

    /** Snapscape state: {mode:"follow"|"pinned"|"none", id, newestId}. */
    scapeInfo: (sessionId) => call("scapeInfo", { sessionId }),

    /** Per-image scene effect override. null = use auto-detected effects; otherwise pass either a legacy array or {effects, intensity}. */
    setEffects: (id, effects) => call("setEffects", { id, effects }),

    /** [{name, role: "bot"|"user", portrait}] from the captured sheet. */
    getPortraits: (sessionId) => call("getPortraits", { sessionId }),
  };
})();
