window.isPhone = function (viewportWidth) {
  const touch = navigator.maxTouchPoints > 0 || "ontouchstart" in window;
  const coarse = Boolean(matchMedia?.("(pointer: coarse)")?.matches);
  if (!touch && !coarse) return false;
  if ((devicePixelRatio || 1) < 1.5) return false;
  const shortSide = Math.min(screen?.width || 0, screen?.height || 0);
  if (!shortSide || shortSide > 1100) return false;
  const vw = viewportWidth || innerWidth;
  return vw <= 900 || vw >= shortSide * 1.8;
};