// snap.js — "snap a pic of this moment." v0.6.1
//
// The camera lives IN each message's toolbar, next to the bookmark: we find
// the site's icon row, clone its first button (so the camera inherits the
// site's exact classes, hover states and transitions), and swap the icon.
// A floating pill appears only as a fallback if no toolbar can be found.
//
// The "Thinking Process" widget is usually collapsed, and collapsed content
// is invisible to innerText — but not to textContent. So each snap reads the
// widget's textContent separately and sends it alongside the visible prose.
//
// Manual override if the heuristics ever grab the wrong element:
//   chrome.storage.local.set({ djpbMessageSelector: ".their-message-class" })

(() => {
  const SESSION_RE = /\/app\/session\/([0-9a-f-]{36})/i;
  const session = () => (location.pathname.match(SESSION_RE) || [])[1] || null;

  const CAMERA_SVG =
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" ' +
    'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>' +
    '<circle cx="12" cy="13" r="4"/></svg>';

  let card = null;
  let drafts = [];
  let active = 0;
  let snappedReply = "";   // the prose behind this snap — becomes the album note
  // Snapshot the effect state returned with THIS draft. Session-level ambience
  // can be updated by unrelated payload traffic before the image is saved; the
  // effect belongs to the image being created, so carry it with the snap.
  let snappedConditions = {};

  // ---------- toolbar discovery ----------

  /** Icon rows: an element whose direct-ish children are 3+ buttons and whose
   *  visible text is basically nothing (icons only). */
  function findToolbars() {
    const rows = [];
    for (const el of document.body.querySelectorAll("div, footer, section")) {
      if (el.closest("#djpb-root, #djpb-snap, [data-djpb-ui]")) continue;
      const buttons = el.querySelectorAll(":scope > button, :scope > * > button");
      if (buttons.length < 3 || buttons.length > 10) continue;
      if ((el.textContent || "").trim().length > 12) continue; // icons, not menus
      const r = el.getBoundingClientRect();
      if (r.height === 0 || r.height > 80) continue;
      rows.push({ row: el, buttons });
    }
    return rows;
  }

  /** The message a toolbar belongs to: climb until the container holds real
   *  prose (and stop before swallowing the whole conversation). */
  function messageFor(row) {
    let node = row.parentElement;
    for (let i = 0; i < 5 && node && node !== document.body; i++) {
      const len = (node.textContent || "").trim().length;
      if (len >= 180) return node;
      node = node.parentElement;
    }
    return null;
  }

  function injectCameras() {
    const sid = session();
    if (!sid) return 0;
    let count = 0;
    for (const { row, buttons } of findToolbars()) {
      count += 1;
      if (row.querySelector("[data-djpb-camera]")) continue;
      const msg = messageFor(row);
      if (!msg) continue;

      // Clone the site's own button so the camera dresses like the site.
      const template = buttons[0];
      const camera = template.cloneNode(true);
      camera.dataset.djpbCamera = "1";
      camera.dataset.djpbUi = "1";
      camera.removeAttribute("id");
      camera.title = "Snap a pic of this moment";
      camera.innerHTML = CAMERA_SVG;
      camera.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        snapMessage(msg);
      });
      // Next to the bookmark — the left-most button in the row.
      template.insertAdjacentElement("afterend", camera);
    }
    return count;
  }

  // ---------- text extraction ----------

  /** The thinking widget: outermost descendant whose text starts with the
   *  "Thinking Process" header and that isn't the whole message. */
  function thinkingWidgetIn(msg) {
    const msgLen = (msg.textContent || "").length;
    for (const el of msg.querySelectorAll("*")) {
      const t = (el.textContent || "").trim();
      if (!t.startsWith("Thinking Process")) continue;
      if (t.length >= msgLen * 0.98) continue; // that's the container itself
      return el; // document order → outermost wrapper first
    }
    return null;
  }

  function extractFrom(msg) {
    const widget = thinkingWidgetIn(msg);
    // textContent reads through the collapsed state; innerText would not.
    const thinkText = widget
      ? widget.textContent.replace(/^\s*Thinking Process\s*(Show|Hide)?/i, "").trim()
      : "";

    // Read from the LIVE node, never a clone: a detached clone has no layout,
    // and without layout innerText degrades to textContent — every paragraph
    // collapses into one solid block. This is why auto-saved notes lost their
    // spacing while payload-sourced text kept it.
    const blocks = [...msg.querySelectorAll("p")]
      .filter((p) => !widget || !widget.contains(p))
      .filter((p) => !p.closest("[data-djpb-ui]") && !p.closest("button"));
    let prose;
    if (blocks.length >= 2) {
      prose = blocks.map((p) => (p.innerText || "").trim()).filter(Boolean).join("\n\n");
    } else {
      prose = String(msg.innerText || msg.textContent || "");
      if (widget) {
        const w = (widget.innerText || "").trim(); // collapsed: header only
        if (w) prose = prose.replace(w, " ");
      }
      prose = prose.replace(/^\s*Thinking Process\s*(Show|Hide)?\s*/i, " ").trim();
    }

    return { prose: prose.trim(), thinkText };
  }

  async function fallbackLatest() {
    const { djpbMessageSelector } = await chrome.storage.local.get({ djpbMessageSelector: "" });
    if (djpbMessageSelector) {
      const nodes = document.querySelectorAll(djpbMessageSelector);
      const last = nodes[nodes.length - 1];
      if (last) return extractFrom(last);
    }
    const MIN = 180;
    let best = null;
    for (const el of document.body.querySelectorAll("div, p, section, article")) {
      if (el.closest("#djpb-root, #djpb-snap, [data-djpb-ui]")) continue;
      const len = (el.innerText || "").trim().length;
      if (len < MIN) continue;
      if ([...el.children].some((c) => (c.innerText || "").trim().length >= len * 0.9)) continue;
      best = el;
    }
    if (!best) return { prose: "", thinkText: "" };
    let node = best;
    for (let i = 0; i < 4; i++) {
      const parent = node.parentElement;
      if (!parent || parent === document.body) break;
      if ((parent.textContent || "").length <= (node.textContent || "").length * 1.25) break;
      node = parent;
    }
    return extractFrom(node);
  }

  // ---------- snapping ----------

  async function snapMessage(msg) {
    openCard();
    setStatus("Reading the scene…");
    runDraft(extractFrom(msg));
  }

  async function snapLatest() {
    // Pressing Snap while the card is open closes it. The card's ✕ is small
    // and the button you just pressed is the obvious thing to press again.
    if (card) { closeCard(); return; }
    openCard();
    setStatus("Reading the scene…");
    runDraft(await fallbackLatest());
  }

  // The last text we drafted from, so Retry repeats THAT snap rather than
  // silently jumping to the newest reply.
  let lastSource = null;

  async function runDraft(source) {
    // Retry calls this with no argument. Destructuring the parameter directly
    // threw "Cannot destructure property 'prose' of 'undefined'", so every
    // Retry press failed instead of retrying.
    if (source) lastSource = source;
    else source = lastSource || await fallbackLatest();

    const { prose = "", thinkText = "" } = source || {};
    const sid = session();
    if (!sid) return;
    if ((prose + thinkText).trim().length < 40) {
      setStatus("Couldn't read a reply here — you can still type a prompt below.", true);
      drafts = [{ label: "Manual", prose: "", tags: "", negative: "" }];
      renderDrafts();
      return;
    }
    // MV3 workers can hang or drop a message during cold start — a brand-new
    // chat's first snap is perfectly timed to hit it. The request gets a
    // deadline and one silent retry, so "Reading the scene…" can never be
    // forever: it either answers or turns into a Retry button.
    const draftMsg = () => {
      const panel = findNexusPanel();
      return chrome.runtime.sendMessage({
        type: "prompt:draft",
        sessionId: sid,
        replyText: prose,
        thinkText,
        nexus: panel ? scrapeNexus(panel) : null,
      });
    };
    const withDeadline = (p, ms) => Promise.race([
      p,
      new Promise((resolve) => setTimeout(() => resolve({ __timeout: true }), ms)),
    ]);

    let res;
    try {
      res = await withDeadline(draftMsg(), 6000);
      if (res?.__timeout) {
        setStatus("Taking longer than usual — retrying…");
        res = await withDeadline(draftMsg(), 8000);
      }
      if (res?.__timeout) {
        res = { ok: false,
                error: "the extension's worker didn't answer — hit Retry (no page reload needed)" };
      }
    } catch (err) {
      res = { ok: false,
              error: isConnectionError(err.message) ? RELOAD_HINT : err.message };
    }
    if (!res?.ok) {
      const dead = isConnectionError(res?.error) || !contextAlive() ||
                   !(await workerAlive());
      setStatus(dead ? RELOAD_HINT : `Drafting failed: ${res?.error || "unknown error"}`, true);
      const chips = card?.querySelector("#djpb-snap-chips");
      if (chips) {
        chips.innerHTML = "";
        const again = document.createElement("button");
        again.type = "button";
        again.className = "djpb-chip";
        again.textContent = "↻ Retry";
        again.addEventListener("click", () => { setStatus("Reading the scene…"); runDraft(); });
        chips.appendChild(again);
        if (dead) {
          const reload = document.createElement("button");
          reload.type = "button";
          reload.className = "djpb-chip";
          reload.textContent = "⟳ Reload page";
          reload.addEventListener("click", () => location.reload());
          chips.appendChild(reload);
        }
      }
      return;
    }

    // A worker answer that is ok but missing its drafts array used to throw
    // inside renderDrafts — and it throws AFTER the status line is set, so the
    // card was left with no prompt and no Retry button. Fall back to the same
    // manual draft used when there is no readable reply.
    drafts = Array.isArray(res.drafts) && res.drafts.length
      ? res.drafts
      : [{ label: "Manual", prose: "", tags: "", negative: "" }];
    snappedReply = res.replyClean || "";
    snappedConditions = {
      weather: res.scene?.weather || "",
      fire: res.scene?.fire || false,
      fireflies: Boolean(res.scene?.fireflies),
      romance: Boolean(res.scene?.romance),
      garden: Boolean(res.scene?.garden),
    };

    active = 0;
    clearResult();   // a new scene shouldn't carry the previous preview
    // A degraded draft is the more important message: it means the drafting
    // itself failed, not merely that the sheet is late. It used to be written
    // first and then overwritten by the no-sheet warning, which sent us
    // looking in the wrong place.
    if (res.degraded) console.warn("[Photobook] draft degraded:", res.degraded);
    setStatus(res.degraded
      ? "Something went wrong building the prompt — this is a plain fallback. Edit it and send."
      : res.hasSheet
      ? ""
      : "⚠ Still reading this chat's characters — wait a second and hit ↻ Retry. Sending one message always works too.",
      Boolean(res.degraded) || !res.hasSheet);
    renderDrafts();
    if (!res.hasSheet) {
      // The chat's own load response usually fills this in a moment later, so
      // retrying is genuinely likely to work — offer it rather than leaving
      // "send a message first" as the only apparent cure.
      const chips = card.querySelector("#djpb-snap-chips");
      const retry = document.createElement("button");
      retry.type = "button";
      retry.className = "djpb-chip";
      retry.textContent = "↻ Retry";
      retry.title = "Check again for this chat's character sheet";
      retry.addEventListener("click", () => { setStatus("Reading the scene…"); runDraft(); });
      chips.appendChild(retry);
    }
    initRefs(res.portraits || []);
  }

  // ---------- the drafting card ----------

  function openCard() {
    if (card) { card.remove(); card = null; }
    card = document.createElement("div");
    card.id = "djpb-snap";
    card.dataset.djpbUi = "1";
    card.innerHTML = `
      <header>
        <strong>Snap this moment</strong>
        <span class="djpb-headbtns">
          <button type="button" id="djpb-snap-settings" title="Settings">⚙</button>
          <button type="button" id="djpb-snap-close" title="Close">✕</button>
        </span>
      </header>
      <div id="djpb-snap-status" role="status"></div>
      <div id="djpb-snap-chips"></div>
      <textarea id="djpb-snap-prompt" rows="7" spellcheck="false"
        placeholder="The assembled prompt appears here — edit anything."></textarea>
      <div id="djpb-snap-refs"></div>
      <div id="djpb-snap-detailsbar"></div>
      <label id="djpb-snap-scape" title="On: every new gen becomes this chat's backdrop. Off: the backdrop stays put until you set one yourself.">
        <input type="checkbox" id="djpb-snap-scape-box" checked>
        <span>Always update Snapscape with new gens</span>
      </label>
      <div id="djpb-snap-firstrun" hidden>
        <strong>Two ways to get a picture</strong>
        <p><b>Send to ChatGPT</b> — best quality, uses the ChatGPT you already
           have. Paste, send, and the image saves itself.</p>
        <p><b>Generate</b> — instant and built in, but the free image service is
           basic. Point it at a better one in <b>⚙</b> if you have a key.</p>
        <button type="button" id="djpb-snap-gotit">Got it</button>
      </div>
      <div class="djpb-snap-row">
        <button type="button" class="djpb-btn djpb-primary" id="djpb-snap-send">Send to ChatGPT</button>
        <button type="button" class="djpb-btn" id="djpb-snap-gen">Generate</button>
        <button type="button" class="djpb-btn" id="djpb-snap-copy">Copy</button>
      </div>`;
    document.body.appendChild(card);

    card.querySelector("#djpb-snap-close").addEventListener("click", closeCard);
    card.querySelector("#djpb-snap-settings").addEventListener("click", () =>
      openSettings());
    card.querySelector("#djpb-snap-gen").addEventListener("click", generate);
    card.querySelector("#djpb-snap-gotit").addEventListener("click", () => {
      card.querySelector("#djpb-snap-firstrun").hidden = true;
      chrome.storage.local.set({ djpbSeenIntro: true });
    });
    describeButtons();
    card.querySelector("#djpb-snap-send").addEventListener("click", sendToBridge);
    initScapeToggle();
    card.querySelector("#djpb-snap-copy").addEventListener("click", copyPrompt);
    card.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Escape") closeCard();
    });
    armOutsideClick();
  }

  /** Click anywhere off the card to dismiss it.
   *
   *  pointerdown, not click: where the press STARTS is the intent. Selecting
   *  text in the prompt and releasing past the card's edge would otherwise
   *  count as clicking away and close it mid-edit.
   *
   *  Anything of ours that lives outside the card still counts as inside —
   *  the scene-details panel is appended to <html>, so a plain containment
   *  test would treat every click in it as a click away. */
  let outsideClick = null;

  function armOutsideClick() {
    disarmOutsideClick();
    outsideClick = (e) => {
      if (!card) return disarmOutsideClick();
      const t = e.target;
      if (card.contains(t)) return;
      if (t instanceof Element && t.closest("#djpb-details, [data-djpb-ui], #djpb-snap")) return;
      closeCard();
    };
    // Capture phase: the site stops propagation on plenty of its own handlers.
    document.addEventListener("pointerdown", outsideClick, true);
  }

  function disarmOutsideClick() {
    if (!outsideClick) return;
    document.removeEventListener("pointerdown", outsideClick, true);
    outsideClick = null;
  }

  function closeCard() {
    disarmOutsideClick();
    card?.remove();
    card = null;
  }

  function setStatus(text, isError) {
    const el = card?.querySelector("#djpb-snap-status");
    if (!el) return;
    el.textContent = text;
    el.classList.toggle("error", Boolean(isError));
  }

  /** Buttons that say what they'll actually do. "Generate" alone told the user
   *  nothing about which service, what it costs, or whether it's even set up —
   *  so a fresh install's first click went to the free basic backend and the
   *  result got blamed on the extension. */
  async function describeButtons() {
    let cfg = null;
    try {
      const res = await chrome.runtime.sendMessage({ type: "config:summary" });
      if (res?.ok) cfg = res;
    } catch { /* worker asleep — leave the plain labels */ }
    if (!cfg || !card) return;

    const gen = card.querySelector("#djpb-snap-gen");
    const send = card.querySelector("#djpb-snap-send");
    if (send) {
      const name = { chatgpt: "ChatGPT", grok: "Grok", gemini: "Gemini" }[cfg.bridge] || "ChatGPT";
      send.textContent = `Send to ${name}`;
      send.title = `Opens ${name} with the prompt copied. Best quality, no API key needed.`;
    }
    if (gen) {
      if (cfg.ready) {
        gen.textContent = `Generate (${cfg.label})`;
        gen.title = `Generates here using ${cfg.label} — ${cfg.note}. Change it in ⚙.`;
        gen.disabled = false;
      } else {
        // Never let a click fail with a raw error when we can say so up front.
        gen.textContent = `Generate — needs setup`;
        gen.title = `${cfg.label} needs an API key. Open ⚙ to add one, or use the bridge instead.`;
        gen.disabled = true;
      }
    }

    const intro = card.querySelector("#djpb-snap-firstrun");
    if (intro) {
      const { djpbSeenIntro } = await chrome.storage.local.get({ djpbSeenIntro: false });
      intro.hidden = Boolean(djpbSeenIntro);
    }
  }

  /** One stepper, not three chips.
   *
   *  The chips showed the first 52 characters of each candidate — and since
   *  the candidates come from one reply about the same people, they all began
   *  the same way and the part that differed was the part cut off. Three
   *  unreadable buttons stacked up and ate the card. The prompt below is the
   *  real preview: it updates as you step, and you can read all of it. */
  function renderDrafts() {
    const bar = card.querySelector("#djpb-snap-chips");
    bar.innerHTML = "";
    if (drafts.length <= 1) { applyAppearanceChoices(); return; }

    const step = (delta) => {
      active = (active + delta + drafts.length) % drafts.length;
      renderDrafts();
    };

    const prev = document.createElement("button");
    prev.type = "button";
    prev.className = "djpb-step";
    prev.textContent = "‹";
    prev.title = "Previous moment";
    prev.setAttribute("aria-label", "Previous moment");
    prev.addEventListener("click", () => step(-1));

    const label = document.createElement("span");
    label.className = "djpb-step-label";
    label.textContent = `Moment ${active + 1} of ${drafts.length}`;

    const next = document.createElement("button");
    next.type = "button";
    next.className = "djpb-step";
    next.textContent = "›";
    next.title = "Next moment";
    next.setAttribute("aria-label", "Next moment");
    next.addEventListener("click", () => step(1));

    bar.append(prev, label, next);
    applyAppearanceChoices();
  }

  // ---------- prompt appearance toggles + automatic references ----------
  // Portrait references now get auto-used behind the scenes. The old
  // None/Liam/Sadie picker became dead UI, so this area now controls whether
  // each portrait-backed character's APPEARANCE text is included in the prompt.

  let refOptions = [];
  let appearanceNames = [];
  let appearanceState = {};
  let includeAppearance = true; // global user preference; survives closing/reopening Snap

  async function initRefs(portraits) {
    const sid = session();
    refOptions = portraits.map((p) => ({ kind: "portrait", name: p.name, url: p.url }));
    try {
      for (const r of await PhotobookDB.listReferences(sid) || []) {
        refOptions.push({ kind: "session", name: r.label, dataUrl: r.dataUrl });
      }
    } catch { /* worker waking; the extra references just don't appear */ }

    appearanceNames = portraits.map((p) => p.name);
    const key = `djpbSnapAppearance:${sid}`;
    const savedPrefs = await chrome.storage.local.get({
      [key]: null,
      djpbSnapIncludeAppearance: true,
    });
    const saved = savedPrefs[key] || null;
    includeAppearance = savedPrefs.djpbSnapIncludeAppearance !== false;
    appearanceState = {};
    for (const name of appearanceNames) appearanceState[name] = saved?.[name] !== false;
    await loadDetails();
    renderRefs();
  }

  // ---------- sticky details ----------
  // Typed once, carried into every snap for this chat until changed. Beats
  // guessing clothing out of prose: the prompt is only as right as the last
  // sentence that happened to mention a jacket.

  const DETAIL_MAX = 120;          // per field — these ride on EVERY prompt
  const DETAIL_BUDGET = 320;       // total added characters before we grumble
  let details = { clothing: {}, off: {}, extras: {}, enabled: true };

  const detailsKey = () => `djpbSnapDetails:${session()}`;

  async function loadDetails() {
    try {
      const v = await chrome.storage.local.get({ [detailsKey()]: null });
      const d = v[detailsKey()];
      details = {
        clothing: d?.clothing && typeof d.clothing === "object" ? d.clothing : {},
        off: d?.off && typeof d.off === "object" ? d.off : {},
        extras: d?.extras && typeof d.extras === "object" ? d.extras : {},
        enabled: d?.enabled !== false,
      };
    } catch { details = { clothing: {}, off: {}, extras: {}, enabled: true }; }
  }

  async function persistDetails() {
    try { await chrome.storage.local.set({ [detailsKey()]: details }); } catch { /* non-fatal */ }
  }

  // The master switch mutes everything at once. It deliberately does not
  // touch the per-field ticks, so turning it back on restores exactly the
  // set that was there before.
  const detailsEnabled = () => details.enabled !== false;
  const detailOn = (key) => detailsEnabled() && details.off[key] !== true;
  const trimField = (v) => String(v || "").replace(/\s+/g, " ").trim().slice(0, DETAIL_MAX);

  function activeClothing(name) {
    return detailOn(`clothing:${name}`) ? trimField(details.clothing[name]) : "";
  }
  function activeExtra(key) {
    return detailOn(`extra:${key}`) ? trimField(details.extras[key]) : "";
  }

  function anyDetailText() {
    for (const name of appearanceNames) if (trimField(details.clothing[name])) return true;
    for (const k of ["present", "objects", "time", "lighting", "location"]) {
      if (trimField(details.extras[k])) return true;
    }
    return false;
  }

  function detailsLength() {
    let n = 0;
    for (const name of appearanceNames) n += activeClothing(name).length;
    for (const k of ["present", "objects", "time", "lighting", "location"]) n += activeExtra(k).length;
    return n;
  }

  // Garment words, so a pinned outfit can displace a contradicting one rather
  // than fighting it inside the prompt. Ordering does not settle a conflict on
  // the image backends that pool the whole prompt at once.
  const GARMENT = /\b(dress|shirt|t-shirt|tee|coat|jacket|armou?r|robes?|cloak|boots?|gloves?|scarf|jeans|uniform|blouse|collar|sleeves?|hood|mask|apron|sweater|hoodie|heels|belt|trousers|pants|skirt|vest|tunic|cape|shorts|socks|stockings|tie|hat|cap|scarves|clothes|clothing|outfit|wearing|dressed)\b/i;

  /** Drop only the clauses that describe clothes, keeping hair, eyes, build.
   *  Returns null when too little survives to be worth keeping. */
  function stripGarments(text) {
    const parts = String(text || "").split(/\s*[;,]\s*/).filter(Boolean);
    if (!parts.length) return null;
    const kept = parts.filter((p) => !GARMENT.test(p));
    if (!kept.length || kept.join(" ").length < String(text).length * 0.4) return null;
    return kept.join(", ");
  }

  function promptWithAppearanceChoices(basePrompt) {
    const masterBox = card?.querySelector('#djpb-snap-appear-all');
    const includeAll = masterBox ? masterBox.checked : includeAppearance;
    const allowed = new Set(
      includeAll
        ? appearanceNames.filter((name) => appearanceState[name] !== false)
        : []
    );

    let inCharacters = false;
    return String(basePrompt || "").split("\n").map((line) => {
      if (/^Characters:\s*$/i.test(line)) { inCharacters = true; return line; }
      if (inCharacters && /^\s*$/.test(line)) { inCharacters = false; return line; }
      if (!inCharacters || !line.startsWith('- ')) return line;

      const idx = line.indexOf(' — ');
      if (idx < 0) return line;
      const name = line.slice(2, idx).trim();
      if (!appearanceNames.includes(name) || allowed.has(name)) return line;

      const rest = line.slice(idx + 3).trim();
      const rightNowIdx = rest.indexOf('Right now:');
      if (rightNowIdx >= 0) {
        return `- ${name} — ${rest.slice(rightNowIdx).trim()}`;
      }
      return `- ${name}`;
    }).join("\n");
  }

  async function persistAppearanceState() {
    await chrome.storage.local.set({ [`djpbSnapAppearance:${session()}`]: appearanceState });
  }

  function promptWithDetails(text) {
    const lines = String(text || "").split("\n");
    const out = [];
    let inCharacters = false;
    let sawLocation = false;

    const time = activeExtra("time");
    const locDetail = activeExtra("location");
    const lighting = activeExtra("lighting");

    for (const line of lines) {
      if (/^Characters:\s*$/i.test(line)) { inCharacters = true; out.push(line); continue; }
      if (inCharacters && /^\s*$/.test(line)) { inCharacters = false; out.push(line); continue; }

      // Location gets refined, not replaced — the scene still moves.
      if (/^Location:/i.test(line)) {
        sawLocation = true;
        let l = line;
        // A pinned time of day replaces the detected "(day)" rather than
        // sitting beside it contradicting it.
        if (time) {
          l = /\(([^)]*)\)/.test(l) ? l.replace(/\(([^)]*)\)/, `(${time})`) : `${l} (${time})`;
        }
        if (locDetail) l = `${l} — ${locDetail}`;
        out.push(l);
        continue;
      }

      if (inCharacters && line.startsWith("- ")) {
        const idx = line.indexOf(" — ");
        const name = (idx < 0 ? line.slice(2) : line.slice(2, idx)).trim();
        const worn = activeClothing(name);
        if (!worn) { out.push(line); continue; }

        // One source of truth for clothes: pull any garment clauses out of the
        // appearance text so both cannot reach the model at once.
        let kept = line;
        if (idx >= 0) {
          const rest = line.slice(idx + 3);
          const rightNow = rest.indexOf("Right now:");
          const appearance = rightNow >= 0 ? rest.slice(0, rightNow).trim() : rest.trim();
          const tail = rightNow >= 0 ? rest.slice(rightNow).trim() : "";
          if (appearance && GARMENT.test(appearance)) {
            const cleaned = stripGarments(appearance);
            kept = cleaned
              ? `- ${name} — ${[cleaned, tail].filter(Boolean).join(" ")}`
              : (tail ? `- ${name} — ${tail}` : `- ${name}`);
          }
        }
        out.push(kept);
        out.push(`  Clothing: ${worn}`);
        continue;
      }

      out.push(line);
    }

    let text2 = out.join("\n");

    /** Scene lines belong above Style, which is always the trailing block.
     *  Appending instead put Lighting after it, where it read as part of the
     *  art direction. */
    const insertBeforeStyle = (body, block) => {
      if (!block.length) return body;
      const at = body.search(/^Style:/mi);
      if (at < 0) return `${body}\n${block.join("\n")}`;
      return `${body.slice(0, at)}${block.join("\n")}\n\n${body.slice(at)}`;
    };

    // Not every reply yields a Location line — some come back with Composition
    // and Mood instead. When it is missing, the pinned setting has to make one
    // of its own or it is silently thrown away.
    const scene = [];
    if (!sawLocation && (locDetail || time)) {
      if (locDetail) scene.push(`Location: ${locDetail}${time ? ` (${time})` : ""}`);
      else scene.push(`Time of day: ${time}`);
    }
    if (lighting) scene.push(`Lighting: ${lighting}`);

    if (scene.length) {
      if (sawLocation && lighting) {
        // Keep Lighting tucked under the Location line it describes.
        const loc = text2.search(/^Location:.*$/mi);
        const nl = text2.indexOf("\n", loc);
        const at = nl < 0 ? text2.length : nl;
        text2 = `${text2.slice(0, at)}\nLighting: ${lighting}${text2.slice(at)}`;
      } else {
        text2 = insertBeforeStyle(text2, scene);
      }
    }

    // Extra beats sit with the characters they belong to.
    const present = activeExtra("present");
    const objects = activeExtra("objects");
    const add = [];
    if (present) add.push(`Also present: ${present}`);
    if (objects) add.push(`In frame: ${objects}`);
    if (add.length) {
      const ctx = text2.search(/^Context:/mi);
      text2 = ctx >= 0
        ? `${text2.slice(0, ctx)}${add.join("\n")}\n\n${text2.slice(ctx)}`
        : insertBeforeStyle(text2, add);
    }
    return text2;
  }

  function applyAppearanceChoices() {
    const ta = card?.querySelector('#djpb-snap-prompt');
    if (!ta) return;
    ta.value = promptWithDetails(promptWithAppearanceChoices(drafts[active]?.prose || ''));
    renderDetailsBar();
  }

  function renderDetailsBar() {
    const bar = card?.querySelector("#djpb-snap-detailsbar");
    if (!bar) return;
    const used = detailsLength();
    let n = 0;
    for (const name of appearanceNames) if (activeClothing(name)) n += 1;
    for (const k of ["present", "objects", "time", "lighting", "location"]) if (activeExtra(k)) n += 1;

    bar.innerHTML = "";

    if (n || detailsLength() || anyDetailText()) {
      const master = document.createElement("label");
      master.className = "djpb-details-master";
      master.title = "Use your saved details in this prompt";
      master.innerHTML = `<input type="checkbox" id="djpb-snap-details-all" ${detailsEnabled() ? "checked" : ""}>`;
      bar.appendChild(master);
      master.querySelector("input").addEventListener("change", async (e) => {
        details.enabled = e.target.checked;
        await persistDetails();
        applyAppearanceChoices();
        const panel = document.getElementById("djpb-details");
        if (panel) syncDetailsPanel(panel);
      });
    }

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "djpb-details-btn" + (n ? " has" : "");
    btn.textContent = !detailsEnabled() && anyDetailText()
      ? "✎ Details (off)"
      : n ? `✎ Details (${n})` : "✎ Add details";
    btn.title = "Clothing, location, lighting — kept for this chat until you change them";
    btn.addEventListener("click", openDetailsPanel);
    bar.appendChild(btn);

    const meter = document.createElement("span");
    if (!detailsEnabled() && anyDetailText()) {
      meter.className = "djpb-details-meter muted";
      meter.textContent = "details off — nothing added";
      bar.appendChild(meter);
    } else if (n) {
      meter.className = "djpb-details-meter" + (used > DETAIL_BUDGET ? " over" : "");
      meter.textContent = used > DETAIL_BUDGET
        ? `+${used} chars on every snap — trim if you can`
        : `+${used} chars on every snap`;
      bar.appendChild(meter);
    }
  }

  function openDetailsPanel() {
    document.getElementById("djpb-details")?.remove();

    const wrap = document.createElement("div");
    wrap.id = "djpb-details";
    wrap.dataset.djpbUi = "1";
    wrap.innerHTML = `
      <div id="djpb-details-card" role="dialog" aria-modal="true" aria-label="Scene details">
        <header>
          <strong>Scene details</strong>
          <button type="button" id="djpb-details-close" title="Close">✕</button>
        </header>
        <p class="djpb-details-lede">These stay with this chat and go into every snap
           until you change them or untick the box. Keep them short — long prompts
           get muddier, not better.</p>
        <label class="djpb-details-allrow">
          <input type="checkbox" id="djpb-details-all">
          <span>Use these details</span>
        </label>
        <div id="djpb-details-fields"></div>
        <footer>
          <span id="djpb-details-count"></span>
          <button type="button" id="djpb-details-done">Done</button>
        </footer>
      </div>`;
    document.documentElement.appendChild(wrap);

    const fields = wrap.querySelector("#djpb-details-fields");

    const addField = (key, label, value, placeholder) => {
      const row = document.createElement("label");
      row.className = "djpb-details-row";
      const on = detailOn(key);
      // Same reason as the appearance chips: `key` and `label` both embed a
      // character name straight from the card.
      const head = document.createElement("span");
      head.className = "djpb-details-head";
      const tick = document.createElement("input");
      tick.type = "checkbox";
      tick.checked = on;
      tick.dataset.off = key;
      const cap = document.createElement("span");
      cap.textContent = label;
      head.append(tick, cap);
      row.appendChild(head);
      const input = document.createElement("input");
      input.type = "text";
      input.maxLength = DETAIL_MAX;
      input.value = value || "";
      input.placeholder = placeholder;
      input.disabled = !on;
      input.dataset.field = key;
      row.appendChild(input);
      fields.appendChild(row);
      return input;
    };

    for (const name of appearanceNames) {
      addField(`clothing:${name}`, `${name} — clothing`, details.clothing[name],
        "red plaid jacket, black t-shirt, ripped jeans");
    }
    addField("extra:present", "Other characters", details.extras.present,
      "a stray dog by the pumps");
    addField("extra:objects", "Objects in frame", details.extras.objects,
      "cigarette pack, cracked coffee pot");
    addField("extra:time", "Time of day", details.extras.time, "late afternoon");
    addField("extra:lighting", "Lighting", details.extras.lighting,
      "low sun through dusty glass");
    addField("extra:location", "Location detail", details.extras.location,
      "rain streaking the windows");

    const allBox = wrap.querySelector("#djpb-details-all");
    allBox.checked = detailsEnabled();
    allBox.addEventListener("change", async () => {
      details.enabled = allBox.checked;
      await persistDetails();
      syncDetailsPanel(wrap);
      applyAppearanceChoices();
    });

    const refreshCount = () => {
      const used = detailsLength();
      const el = wrap.querySelector("#djpb-details-count");
      el.textContent = `+${used} characters on every snap`;
      el.classList.toggle("over", used > DETAIL_BUDGET);
    };

    const write = (key, value) => {
      if (key.startsWith("clothing:")) details.clothing[key.slice(9)] = value;
      else details.extras[key.slice(6)] = value;
    };

    fields.addEventListener("input", (e) => {
      const key = e.target.dataset.field;
      if (!key) return;
      write(key, trimField(e.target.value));
      refreshCount();
      applyAppearanceChoices();
      persistDetails();
    });
    fields.addEventListener("change", (e) => {
      const key = e.target.dataset.off;
      if (!key) return;
      details.off[key] = !e.target.checked;
      const input = fields.querySelector(`[data-field="${CSS.escape(key)}"]`);
      if (input) input.disabled = !e.target.checked || !detailsEnabled();
      refreshCount();
      applyAppearanceChoices();
      persistDetails();
    });

    const close = () => wrap.remove();
    wrap.querySelector("#djpb-details-close").addEventListener("click", close);
    wrap.querySelector("#djpb-details-done").addEventListener("click", close);
    wrap.addEventListener("click", (e) => { if (e.target === wrap) close(); });
    wrap.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Escape") close();
    });
    refreshCount();
    syncDetailsPanel(wrap);
    fields.querySelector("input[type=text]:not([disabled])")?.focus();
  }

  /** Master off greys the whole list without unticking anything, so the
   *  per-field choices survive being switched back on. */
  function syncDetailsPanel(wrap) {
    const on = detailsEnabled();
    const allBox = wrap.querySelector("#djpb-details-all");
    if (allBox) allBox.checked = on;
    wrap.querySelectorAll(".djpb-details-row").forEach((row) => {
      const tick = row.querySelector("[data-off]");
      const input = row.querySelector("[data-field]");
      if (tick) tick.disabled = !on;
      if (input) input.disabled = !on || tick?.checked === false;
      row.classList.toggle("muted", !on);
    });
    const count = wrap.querySelector("#djpb-details-count");
    if (count) {
      const used = detailsLength();
      count.textContent = on ? `+${used} characters on every snap` : "Details are off — nothing is added";
      count.classList.toggle("over", on && used > DETAIL_BUDGET);
    }
  }

  /** Which photos get attached to the prompt. Portraits are ticked by default
   *  — the behaviour every existing chat already has — and an album photo sent
   *  over with "Use as ref" appears here to be ticked instead of, or as well
   *  as, them. Once a chat has three good references there is rarely a reason
   *  to keep sending both portraits every time. */
  async function renderRefPicks() {
    const row = card?.querySelector('#djpb-snap-refpicks');
    if (!row) return;
    let sources = [];
    try {
      const res = await chrome.runtime.sendMessage({ type: 'snap:refpicks' });
      sources = res?.ok && Array.isArray(res.sources) ? res.sources : [];
    } catch { /* worker waking */ }

    row.innerHTML = '';
    if (!sources.length) return;

    const label = document.createElement('span');
    label.className = 'djpb-appear-note';
    const on = sources.filter((s) => s.on).length;
    label.textContent = on
      ? `Ref photos attached (${on}):`
      : 'No ref photos will be attached:';
    row.appendChild(label);

    for (const src of sources) {
      const chip = document.createElement('label');
      chip.className = 'djpb-appear-chip djpb-refchip' + (src.on ? ' on' : '');
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.checked = src.on === true;
      chip.appendChild(box);

      // The picture IS the identity: without it, "Book ref 1" and "Book ref 2"
      // are indistinguishable. Hovering zooms it so similar shots read apart.
      const thumbSrc = src.kind === 'portrait' ? src.thumbUrl : src.thumb;
      if (thumbSrc) {
        const img = document.createElement('img');
        img.src = thumbSrc;
        img.alt = '';
        img.draggable = false;
        attachRefPreview(chip, thumbSrc);
        chip.appendChild(img);
      }

      const text = document.createElement('span');
      text.textContent = src.kind === 'portrait'
        ? `${src.name} pfp`
        : src.name;
      chip.appendChild(text);
      if (src.kind === 'book') {
        chip.title = 'A photo you added as a reference';
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'djpb-refchip-x';
        rm.textContent = '\u00d7';
        rm.title = 'Remove this reference';
        rm.addEventListener('click', async (e) => {
          e.preventDefault();          // don't toggle the checkbox underneath
          rm.disabled = true;
          try {
            await PhotobookDB.removeReference(session(), src.index);
            await refreshBookRefOptions();
          } catch { /* the re-render shows the truth */ }
          renderRefPicks();
          syncAlbumStrip();   // badge numbers shift when a slot frees up
        });
        chip.appendChild(rm);
      }
      box.addEventListener('change', async () => {
        box.disabled = true;
        try {
          await chrome.runtime.sendMessage(
            { type: 'snap:setrefpick', id: src.id, on: box.checked });
        } catch { /* ignore; the next open re-reads the truth */ }
        renderRefPicks();
      });
      row.appendChild(chip);
    }

    // Pick the book ref right here: a strip of this chat's newest photos
    // drops down in the card. One tap sets it AND switches it on — no trip
    // through the album, no separate toggle to find afterwards.
    const pick = document.createElement('button');
    pick.type = 'button';
    pick.className = 'djpb-refalbum';
    const bookCount = sources.filter((x) => x.kind === 'book').length;
    pick.textContent = bookCount
      ? `＋ Album photo (${bookCount}/${MAX_BOOK_REFS})`
      : '＋ Album photo';
    pick.title = 'Choose photos from this chat as book refs';
    pick.addEventListener('click', () => toggleAlbumStrip(row));
    row.appendChild(pick);

    // Straight to the album to choose (or change) that one photo. The card is
    // modal over the chat, so leaving it open behind the album just buries it.
    const go = document.createElement('button');
    go.type = 'button';
    go.className = 'djpb-refalbum';
    // Deliberately the old Nexus tab's wording and colours: this is the same
    // door, moved somewhere people can always find it.
    go.textContent = '📖 Photo Album';
    go.title = sources.some((x) => x.kind === 'book')
      ? "Open the album \u2014 use a photo's \u201cUse as ref\u201d to change the book ref"
      : "Open the album \u2014 use a photo's \u201cUse as ref\u201d to set the book ref";
    go.addEventListener('click', () => {
      const sid = session();
      closeCard();
      if (typeof openAlbumOverlay === 'function') openAlbumOverlay(sid);
    });
    row.appendChild(go);
  }

  /** One floating preview for the whole card: hover any chip's thumbnail and
   *  a bigger copy appears above it, so near-identical shots can be told
   *  apart without leaving the card. Hover-only by design — on touch, the
   *  strip's 56px thumbnails are the legible surface. */
  function attachRefPreview(el, src) {
    el.addEventListener('mouseenter', () => {
      if (!card) return;
      let pv = card.querySelector('#djpb-refpreview');
      if (!pv) {
        pv = document.createElement('img');
        pv.id = 'djpb-refpreview';
        pv.alt = '';
        card.appendChild(pv);
      }
      pv.src = src;
      // The card scrolls internally; absolute children sit in scrolled
      // content coordinates, so the scroll offset has to be added back.
      const c = card.getBoundingClientRect();
      const r = el.getBoundingClientRect();
      const x = r.left - c.left + card.scrollLeft;
      const y = r.top - c.top + card.scrollTop;
      pv.style.left = `${Math.max(8, Math.min(x, c.width - 168))}px`;
      pv.style.top = `${y}px`;
      pv.classList.add('show');
    });
    el.addEventListener('mouseleave', () => {
      card?.querySelector('#djpb-refpreview')?.classList.remove('show');
    });
  }

  /** Rebuild refOptions' book entries from storage, so the Generate path and
   *  the worker's picks can't drift apart after an add or remove. */
  async function refreshBookRefOptions() {
    try {
      const refs = await PhotobookDB.listReferences(session()) || [];
      refOptions = refOptions.filter((o) => o.kind !== 'session');
      for (const r of refs) {
        refOptions.push({ kind: 'session', name: r.label, dataUrl: r.dataUrl });
      }
    } catch { /* worker waking; next card open reloads the truth */ }
  }

  // Mirrors MAX_REFS in the worker; the strip header and the (n/4) counter
  // read it, and the worker still enforces the real cap on add.
  const MAX_BOOK_REFS = 4;

  /** The inline album strip: newest photos of this chat. Tap a photo to ADD
   *  it as a book ref (and enable it) — tap it again to remove it. Photos in
   *  use wear a numbered badge matching their "Book ref n" chip, so the strip
   *  doubles as a legend for which chip is which picture. */
  async function toggleAlbumStrip(row) {
    const existing = card?.querySelector('#djpb-snap-albumstrip');
    if (existing) { existing.remove(); return; }
    const strip = document.createElement('div');
    strip.id = 'djpb-snap-albumstrip';
    strip.textContent = 'Loading photos…';
    row.after(strip);

    let photos = [];
    try {
      photos = await PhotobookDB.list(session()) || [];
    } catch { /* worker waking */ }
    if (!strip.isConnected) return;   // closed while loading
    if (!photos.length) {
      strip.textContent = 'No photos in this chat\u2019s album yet.';
      setTimeout(() => strip.remove(), 3000);
      return;
    }

    strip.textContent = '';
    const head = document.createElement('div');
    head.className = 'djpb-strip-head';
    strip.appendChild(head);

    // Newest first, capped — a strip of 12 thumbnails is a picker, a strip of
    // 200 is a memory problem.
    for (const p of photos.slice(-12).reverse()) {
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'djpb-albumstrip-cell';
      cell._dataUrl = p.dataUrl;   // matched against stored refs by content

      const img = document.createElement('img');
      img.src = p.dataUrl;
      img.className = 'djpb-albumstrip-thumb';
      img.alt = '';
      img.draggable = false;

      const badge = document.createElement('span');
      badge.className = 'djpb-albumstrip-badge';

      cell.append(img, badge);
      cell.addEventListener('click', async () => {
        cell.disabled = true;
        try {
          const refs = await PhotobookDB.listReferences(session()) || [];
          const hit = refs.find((r) => r.dataUrl === p.dataUrl);
          if (hit) {
            // Second tap takes it back out — no hunting for the chip's ×.
            await PhotobookDB.removeReference(session(), hit.index);
          } else {
            await PhotobookDB.addReference(
              session(), p.dataUrl, `Book ref ${refs.length + 1}`);
            await chrome.runtime.sendMessage(
              { type: 'snap:setrefpick', id: `book:${refs.length}`, on: true });
          }
          await refreshBookRefOptions();
          renderRefPicks();   // strip stays open — keep tapping
        } catch (err) {
          // Almost always the 4-ref cap; the message says exactly that.
          flashStripNote(strip, err?.message || "Couldn't add that one");
        }
        cell.disabled = false;
        syncAlbumStrip();
      });
      strip.appendChild(cell);
    }
    syncAlbumStrip();
  }

  /** Re-read the stored refs and repaint the open strip's badges and header.
   *  Safe to call any time; does nothing when the strip is closed. */
  async function syncAlbumStrip() {
    const strip = card?.querySelector('#djpb-snap-albumstrip');
    if (!strip) return;
    let refs = [];
    try {
      refs = await PhotobookDB.listReferences(session()) || [];
    } catch { /* worker waking; keep what's painted */ }
    if (!strip.isConnected) return;

    const byUrl = new Map(refs.map((r) => [r.dataUrl, r.index]));
    for (const cell of strip.querySelectorAll('.djpb-albumstrip-cell')) {
      const idx = byUrl.get(cell._dataUrl);
      const used = idx !== undefined;
      cell.classList.toggle('picked', used);
      const badge = cell.querySelector('.djpb-albumstrip-badge');
      if (badge) badge.textContent = used ? String(idx + 1) : '';
      cell.title = used
        ? `Book ref ${idx + 1} — tap to remove`
        : 'Tap to add as a book ref';
    }
    const head = strip.querySelector('.djpb-strip-head');
    if (head) {
      head.textContent = refs.length
        ? `Tap to add · tap again to remove — ${refs.length} of ${MAX_BOOK_REFS} slots used`
        : `Tap a photo to attach it as a reference (up to ${MAX_BOOK_REFS})`;
    }
  }

  function flashStripNote(strip, text) {
    let note = strip.querySelector('.djpb-strip-note');
    if (!note) {
      note = document.createElement('span');
      note.className = 'djpb-strip-note';
      strip.appendChild(note);
    }
    note.textContent = text;
    setTimeout(() => note?.remove(), 3500);
  }

  function renderRefs() {
    const wrap = card?.querySelector("#djpb-snap-refs");
    if (!wrap) return;
    wrap.innerHTML = "";
    if (!appearanceNames.length) return;

    const master = document.createElement('label');
    master.className = 'djpb-appear-master';
    master.innerHTML = `<input type="checkbox" id="djpb-snap-appear-all" ${includeAppearance ? 'checked' : ''}> <span>Include appearance</span>`;
    wrap.appendChild(master);

    for (const name of appearanceNames) {
      // Built as nodes, not as an HTML string. A character name comes from
      // the site's card, so a name containing a quote used to break out of
      // the attribute and could carry an event handler or an <img onerror>
      // into the page.
      const item = document.createElement('label');
      item.className = 'djpb-appear-chip';
      const box = document.createElement('input');
      box.type = 'checkbox';
      box.dataset.appearName = name;
      box.checked = appearanceState[name] !== false;
      const text = document.createElement('span');
      text.textContent = name;
      item.append(box, document.createTextNode(' '), text);
      wrap.appendChild(item);
    }

    const refRow = document.createElement('div');
    refRow.id = 'djpb-snap-refpicks';
    wrap.appendChild(refRow);
    renderRefPicks();

    const masterBox = wrap.querySelector('#djpb-snap-appear-all');
    const syncDisabled = () => {
      const on = masterBox?.checked !== false;
      wrap.querySelectorAll('[data-appear-name]').forEach((box) => { box.disabled = !on; });
      wrap.querySelectorAll('.djpb-appear-chip').forEach((chip) => chip.classList.toggle('disabled', !on));
    };
    masterBox?.addEventListener('change', async () => {
      includeAppearance = masterBox.checked;
      await chrome.storage.local.set({ djpbSnapIncludeAppearance: includeAppearance });
      syncDisabled();
      applyAppearanceChoices();
    });
    wrap.querySelectorAll('[data-appear-name]').forEach((box) => {
      box.addEventListener('change', async () => {
        appearanceState[box.dataset.appearName] = box.checked;
        await persistAppearanceState();
        applyAppearanceChoices();
      });
    });
    syncDisabled();
    applyAppearanceChoices();
  }

  async function allReferenceDataUrls() {
    const out = [];
    for (const opt of refOptions) {
      try {
        if (opt.dataUrl) out.push(opt.dataUrl);
        else if (opt.url) {
          const res = await chrome.runtime.sendMessage({ type: 'fetchImage', url: opt.url });
          if (res?.ok && res.dataUrl) out.push(res.dataUrl);
        }
      } catch { /* skip a broken reference instead of failing the snap */ }
    }
    return out;
  }

  // ---------- routes ----------

  const currentPrompt = () => card.querySelector("#djpb-snap-prompt").value.trim();

  async function generate() {
    const prompt = currentPrompt();
    if (!prompt) return setStatus("Prompt is empty.", true);
    const sid = session();
    setStatus("Generating…");
    card.querySelector("#djpb-snap-gen").disabled = true;
    try {
      const references = await allReferenceDataUrls();
      const res = await chrome.runtime.sendMessage({
        type: "generate",
        prompt,
        negative: drafts[active]?.negative || "",
        references,
        strength: 0.6,
      });
      if (!res?.ok) throw new Error(res?.error || "unknown error");
      const newId = await PhotobookDB.add(sid, res.dataUrl, {
        source: "generated",
        prompt,                                   // kept, but not the note
        caption: snappedReply || drafts[active]?.label || "",
        conditions: snappedConditions,
      });
      showResult(res.dataUrl);
      const wrap = card.querySelector("#djpb-snap-resultwrap");
      if (wrap) offerSetScape(wrap, newId);
      setStatus(references.length && !res.usedReference
        ? "Saved ✓ — heads up: this backend is text-only, so the references weren't used."
        : "Saved to this session's album ✓");
    } catch (err) {
      setStatus(explainFailure(err.message), true);
    }
    card.querySelector("#djpb-snap-gen").disabled = false;
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Older/locked-down setups: the deprecated path still works on a click.
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
  }

  async function sendToBridge() {
    const prompt = currentPrompt();
    if (!prompt) return setStatus("Prompt is empty.", true);
    try {
      await copyText(prompt); // copied BEFORE the tab opens — paste is all that's left
      const res = await chrome.runtime.sendMessage({
        type: "snap:arm",
        sessionId: session(),
        prompt,
        replyText: snappedReply,   // travels with the arming, becomes the note
        conditions: snappedConditions, // exact ambience for this generated Chatscape
        returnUrl: location.href,
      });
      // The bridge is armed and the prompt is copied. Close Snap immediately
      // so it is not still sitting there when the user comes back from ChatGPT.
      closeCard();
    } catch (err) {
      setStatus(`Couldn't arm the bridge: ${err.message}`, true);
    }
  }

  /** Raw backend errors read as "the extension is broken". Say what to do. */
  function explainFailure(msg) {
    const m = String(msg || "").toLowerCase();
    if (m.includes("api key") || m.includes("401") || m.includes("unauthor")) {
      return "That image service needs an API key — add one in ⚙, or use Send to ChatGPT instead.";
    }
    if (m.includes("429") || m.includes("rate")) {
      return "The image service is rate-limiting right now. Wait a moment, or use Send to ChatGPT.";
    }
    if (m.includes("failed to fetch") || m.includes("network")) {
      return "Couldn't reach the image service. Check your connection, or use Send to ChatGPT.";
    }
    if (m.includes("permission")) {
      return "That backend needs permission — open ⚙ and press Save to grant it.";
    }
    return `Generate failed: ${msg}. Send to ChatGPT is the no-setup route if this keeps happening.`;
  }

  async function copyPrompt() {
    try {
      await navigator.clipboard.writeText(currentPrompt());
      setStatus("Copied ✓");
    } catch (err) {
      setStatus(`Copy failed: ${err.message}`, true);
    }
  }


  // ---------- Snapscape follow toggle ----------
  // Mapped straight onto the backdrop's existing three states, so it can
  // never disagree with a pin made from the album page:
  //   checked   ⇔ backdropId null   (follow the newest photo — the default)
  //   unchecked ⇔ backdropId pinned (new gens leave the backdrop alone)

  let scapeFollow = true;

  async function initScapeToggle() {
    const box = card?.querySelector("#djpb-snap-scape-box");
    if (!box) return;
    const sid = session();
    try {
      const info = await PhotobookDB.scapeInfo(sid);
      scapeFollow = info?.mode === "follow";
    } catch { scapeFollow = true; /* worker waking; default stands */ }
    box.checked = scapeFollow;

    box.addEventListener("change", async () => {
      box.disabled = true;
      try {
        if (box.checked) {
          // Back to following the story.
          await PhotobookDB.setBackdrop(sid, null);
          scapeFollow = true;
        } else {
          // Pin what is showing right now, so the next gen can't move it.
          // No photos yet → the explicit "none" state, same idea.
          const info = await PhotobookDB.scapeInfo(sid);
          await PhotobookDB.setBackdrop(sid, info?.id || info?.newestId || "none");
          scapeFollow = false;
        }
      } catch {
        box.checked = scapeFollow; // write failed — show the truth
      }
      box.disabled = false;
    });
  }

  /** The "make THIS one the backdrop" button for a freshly generated photo,
   *  shown only when follow mode is off (otherwise it already happened). */
  function offerSetScape(wrap, newId) {
    if (scapeFollow || !newId) return;
    wrap.querySelector(".djpb-setscape")?.remove();
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "djpb-btn djpb-setscape";
    btn.textContent = "🖼 Set as Snapscape";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      btn.textContent = "Setting…";
      try {
        await PhotobookDB.setBackdrop(session(), newId);
        btn.textContent = "✓ Snapscape set";
      } catch {
        btn.textContent = "Couldn't set it";
        btn.disabled = false;
      }
    });
    wrap.appendChild(btn);
  }

  /** The result is already saved to the album by the time it appears here, so
   *  this preview is a courtesy — and it needs a way out. Without one the only
   *  escape from an unwanted generation was closing the whole card. */
  function showResult(dataUrl) {
    let wrap = card.querySelector("#djpb-snap-resultwrap");
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.id = "djpb-snap-resultwrap";

      const img = document.createElement("img");
      img.id = "djpb-snap-result";

      const close = document.createElement("button");
      close.type = "button";
      close.id = "djpb-snap-resultclose";
      close.textContent = "✕";
      close.title = "Dismiss this preview (the photo stays in your album)";
      close.addEventListener("click", clearResult);

      wrap.append(img, close);
      card.insertBefore(wrap, card.querySelector(".djpb-snap-row"));
    }
    wrap.querySelector("#djpb-snap-result").src = dataUrl;
    wrap.hidden = false;
  }

  function clearResult() {
    const wrap = card?.querySelector("#djpb-snap-resultwrap");
    if (!wrap) return;
    wrap.remove();          // free the data URL with it
    setStatus("");
  }

  // ---------- fallback pill ----------

  let pillRaf = null;
  let composerBox = null;
  let pillPos = null;      // {xPct, yPct} once the user has placed it
  let pillDragged = false;  // suppresses the click that ends a drag
  let pillDragging = false; // true only while a finger is actually moving it

  const PILL_POS_KEY = "djpbPillPos";

  /** Stored as viewport fractions, not pixels: a phone that rotates or a
   *  window that resizes should keep the button roughly where it was put,
   *  rather than stranding it off-screen. */
  async function loadPillPos() {
    try {
      const v = await chrome.storage.local.get({ [PILL_POS_KEY]: null });
      pillPos = v[PILL_POS_KEY];
    } catch { pillPos = null; }
  }

  function placePill(pill) {
    if (!pillPos) return false;
    const w = pill.offsetWidth || 90;
    const h = pill.offsetHeight || 40;
    const x = Math.min(Math.max(pillPos.xPct * innerWidth, 4), innerWidth - w - 4);
    const y = Math.min(Math.max(pillPos.yPct * innerHeight, 4), innerHeight - h - 4);
    pill.style.left = `${Math.round(x)}px`;
    pill.style.top = `${Math.round(y)}px`;
    pill.style.right = "auto";
    pill.style.bottom = "auto";
    return true;
  }

  /** Long-press to move, tap to open. Distance thresholds were the wrong
   *  model: they made every tap a guess, and a slightly sloppy tap could
   *  nudge the button instead of opening the card. Holding is unambiguous —
   *  nobody holds a button for half a second by accident. */
  const HOLD_MS = 450;

  function makeDraggable(pill) {
    let hold = null;     // timer until drag mode begins
    let origin = null;   // pointer + element position at press
    pill.style.touchAction = "none";

    const stopHold = () => { clearTimeout(hold); hold = null; };

    pill.addEventListener("pointerdown", (e) => {
      // Docked in the site's toolbar it is an ordinary button. Long-press
      // there was starting a drag and swallowing the tap.
      if (pill.classList.contains("djpb-inline")) return;
      const r = pill.getBoundingClientRect();
      origin = { px: e.clientX, py: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top };
      pillDragging = false;
      pillDragged = false;
      try { pill.setPointerCapture(e.pointerId); } catch { /* fine */ }
      hold = setTimeout(() => {
        pillDragging = true;
        pill.classList.add("djpb-dragging");
        // A short buzz confirms the switch on phones that support it.
        try { navigator.vibrate?.(15); } catch { /* optional */ }
      }, HOLD_MS);
    });

    pill.addEventListener("pointermove", (e) => {
      if (!origin) return;
      if (!pillDragging) {
        // Moving before the hold completes means this was a tap or a scroll.
        if (Math.hypot(e.clientX - origin.px, e.clientY - origin.py) > 12) stopHold();
        return;
      }
      e.preventDefault();
      const w = pill.offsetWidth, h = pill.offsetHeight;
      const x = Math.min(Math.max(e.clientX - origin.dx, 4), innerWidth - w - 4);
      const y = Math.min(Math.max(e.clientY - origin.dy, 4), innerHeight - h - 4);
      pill.style.left = `${Math.round(x)}px`;
      pill.style.top = `${Math.round(y)}px`;
      pill.style.right = "auto";
      pill.style.bottom = "auto";
    });

    const end = (e) => {
      stopHold();
      if (!origin) return;
      origin = null;
      try { pill.releasePointerCapture(e.pointerId); } catch { /* fine */ }
      if (!pillDragging) return;          // a tap: the click handler runs
      pillDragging = false;
      pillDragged = true;                 // swallow the click this release fires
      pill.classList.remove("djpb-dragging");
      const r = pill.getBoundingClientRect();
      pillPos = { xPct: r.left / innerWidth, yPct: r.top / innerHeight };
      chrome.storage.local.set({ [PILL_POS_KEY]: pillPos });
      setTimeout(() => { pillDragged = false; }, 60);
    };
    pill.addEventListener("pointerup", end);
    pill.addEventListener("pointercancel", end);

    // Only a completed drag eats the click; a plain tap always opens the card.
    pill.addEventListener("click", (e) => {
      if (pillDragged) { e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
  }

  /** Phones lay the app out as one narrow column and the on-screen keyboard
   *  resizes the viewport constantly, so measuring another element and
   *  tracking it every frame is both wrong and expensive. Below this width we
   *  pin our controls to the viewport instead. */
  const isNarrow = () => Math.min(innerWidth, innerHeight) < 820 || innerWidth < 820;

  function ensurePill(show) {
    let pill = document.getElementById("djpb-snap-pill");
    if (!show) {
      pill?.remove();
      cancelAnimationFrame(pillRaf);
      pillRaf = null;
      return;
    }
    if (!pill) {
      pill = document.createElement("button");
      pill.id = "djpb-snap-pill";
      pill.type = "button";
      pill.dataset.djpbUi = "1";
      pill.title = "Snap the latest reply — hold to move";
      pill.textContent = "📷 Snap";
      pill.addEventListener("click", snapLatest);
      makeDraggable(pill);
      document.documentElement.appendChild(pill);
      loadPillPos().then(() => placePill(pill));
    }
    dockOrFloat(pill);
    keepCardClear();
    if (!pillRaf) trackPill(pill);
  }

  /** Sit inside the site's control row when one exists and the user hasn't
   *  chosen a spot of their own. The site re-renders that row, so this is
   *  re-checked on every scan and simply re-appends when it disappears. */
function dockOrFloat(pill) {
    if (pillPos) {                       // a placement the user chose wins
      if (pill.classList.contains("djpb-inline") || pill.classList.contains("djpb-inline-send")) {
        pill.classList.remove("djpb-inline", "djpb-inline-send");
        document.documentElement.appendChild(pill);
      }
      return;
    }

    // On mobile, dock right next to the Send button in the input bar
    if (isNarrow()) {
      const box = findComposerBox();
      const sendBtn = box?.querySelector("button, [role='button']");
      if (sendBtn && sendBtn.parentElement) {
        pill.classList.remove("djpb-inline");
        pill.classList.add("djpb-inline-send");
        if (pill.parentElement !== sendBtn.parentElement) {
          sendBtn.parentElement.insertBefore(pill, sendBtn);
        }
        pill.textContent = "📷";
        return;
      }
    }

    // Desktop: dock in the composer toolbar
    const bar = findComposerToolbar();
    if (bar) {
      if (pill.parentElement !== bar) {
        pill.classList.remove("djpb-inline-send");
        pill.classList.add("djpb-inline");
        bar.appendChild(pill);
      }
      pill.textContent = "📷 Snap";
      return;
    }

    if (pill.classList.contains("djpb-inline") || pill.classList.contains("djpb-inline-send") || !pill.isConnected) {
      pill.classList.remove("djpb-inline", "djpb-inline-send");
      pill.textContent = "📷 Snap";
      document.documentElement.appendChild(pill);
    }
  }

  /** Dock the pill just left of the message composer, riding along if the
   *  layout shifts. Falls back to the bottom-left corner if no composer. */
  function trackPill(pill) {
    let tick = 0;
    const step = () => {
      if (!pill.isConnected) { pillRaf = null; return; }
      tick += 1;
      // Docked in the site's own row: the site positions it, we don't.
      if (pill.classList.contains("djpb-inline")) {
        pillRaf = requestAnimationFrame(step);
        return;
      }
      // While a drag is in progress the finger owns the position — re-applying
      // the stored spot here is what made the pill immovable after the first
      // move, since every frame yanked it back.
      if (pillDragging) {
        pillRaf = requestAnimationFrame(step);
        return;
      }
      // Once the user has placed it, nothing moves it but them.
      if (pillPos) {
        placePill(pill);
        pillRaf = requestAnimationFrame(step);
        return;
      }
      if (isNarrow()) {
        // Pinned above the composer's usual height, out of the thumb path.
        // Above the composer and its toolbar row, which is what it used to
        // sit on top of. Draggable from here if it still isn't right.
        pill.style.left = "12px";
        pill.style.top = "auto";
        pill.style.bottom = "calc(env(safe-area-inset-bottom, 0px) + 132px)";
        pillRaf = requestAnimationFrame(step);
        return;
      }
      if (!composerBox?.isConnected || tick % 60 === 1) composerBox = findComposerBox();
      if (composerBox) {
        const r = composerBox.getBoundingClientRect();
        if (r.width > 0) {
          pill.style.left = `${Math.max(6, r.left - pill.offsetWidth - 14)}px`;
          pill.style.top = `${r.top + 10}px`;
          pill.style.bottom = "auto";
        }
      } else {
        pill.style.left = "16px";
        pill.style.top = "auto";
        pill.style.bottom = "64px";
      }
      pillRaf = requestAnimationFrame(step);
    };
    pillRaf = requestAnimationFrame(step);
  }

  /** The row holding the site's own composer controls. Docking into it beats
   *  any floating position: it's where the user already looks for buttons, it
   *  can't cover the send button, and it survives layout changes because the
   *  site is doing the layout. */
  /** A content script keeps running after its extension is updated or reloaded,
   *  but its link to the extension is dead — every sendMessage then fails with
   *  "Receiving end does not exist". Only a page reload recovers it, so say so
   *  rather than showing a cryptic error or a button that does nothing. */
  function contextAlive() {
    try { return Boolean(chrome.runtime?.id); } catch { return false; }
  }

  /** Is the worker actually answering? A plain sendMessage should WAKE a
   *  stopped worker; if even a ping fails, it isn't running at all — which is
   *  a different problem from a slow start, and needs a different fix. */
  async function workerAlive(ms = 2500) {
    if (!contextAlive()) return false;
    try {
      const res = await Promise.race([
        chrome.runtime.sendMessage({ type: "config:summary" }),
        new Promise((r) => setTimeout(() => r(null), ms)),
      ]);
      return Boolean(res);
    } catch {
      return false;
    }
  }

  function isConnectionError(msg) {
    const m = String(msg || "").toLowerCase();
    return m.includes("receiving end does not exist") ||
           m.includes("could not establish connection") ||
           m.includes("extension context invalidated") ||
           m.includes("message port closed");
  }

  // This fires whenever the background worker can't be reached. An update is
  // only ONE of the causes — a worker that crashed on startup, or a mobile
  // browser that won't wake a stopped one, look identical from here. So the
  // message lists the two fixes in the order most likely to work, rather than
  // asserting a cause we can't actually know.
  const RELOAD_HINT =
    "Can't reach the extension's background service.\n" +
    "1) Reload this page and try again.\n" +
    "2) Still failing? Open your browser's Extensions page, press \u21bb on " +
    "Dreamjourney Photobook, then reload this page.";

  /** Open Settings without needing the worker: a content script can build the
   *  options URL itself, which still works when the worker is asleep. */
  function openSettings() {
    try {
      if (!contextAlive()) { setStatus(RELOAD_HINT, true); return; }
      const w = window.open(chrome.runtime.getURL("options.html"), "_blank");
      if (w) return;
    } catch { /* fall through to the worker */ }
    try {
      chrome.runtime.sendMessage({ type: "options:open" }).catch(() => {
        setStatus("Couldn't open Settings — reload the page and try again.", true);
      });
    } catch {
      setStatus(RELOAD_HINT, true);
    }
  }

  function findComposerToolbar() {
    const labels = ["nexus", "options"];
    const hits = [...document.querySelectorAll("button, [role='button']")].filter((el) => {
      const t = (el.textContent || "").trim().toLowerCase();
      return labels.some((l) => t === l || t.startsWith(l));
    });
    if (!hits.length) return null;

    // The row is the nearest ancestor that holds one of these AND lays out
    // horizontally, so our button sits beside them rather than under.
    for (const hit of hits) {
      let n = hit.parentElement;
      for (let i = 0; i < 4 && n; i++, n = n.parentElement) {
        const r = n.getBoundingClientRect();
        if (r.width < 120 || r.height > 140) continue;
        const style = getComputedStyle(n);
        if (style.display.includes("flex") || style.display.includes("grid") || r.width > r.height * 2) {
          return n;
        }
      }
    }
    return hits[0].parentElement || null;
  }

function findComposerBox() {
    const input = document.querySelector("textarea, input[placeholder*='message' i]")
      || document.querySelector("[contenteditable='true']");
    if (!input) return null;
    return input.closest("form") || input.parentElement;
  }

  // ---------- Nexus integration ----------
  // The site's Memory Nexus panel maintains live per-character state lines and
  // a current-scene block — better pose data than any heuristic. When the
  // panel is open we (a) dock a Photo Album tab against its edge and (b)
  // harvest those lines into the snap.

  /** Keep the snap card clear of the Nexus drawer.
   *
   *  The card lives at the right edge, which is where the drawer opens — so
   *  the drawer covered it, including its ✕, and the only way out was to close
   *  the drawer first. Rather than fight the site over stacking order (whose
   *  z-index we don't control), step aside: while the drawer is open the card
   *  sits to the left of it, fully visible and closable.
   *
   *  On phones the card is a full-width bottom sheet, so there is nothing to
   *  move and this does nothing. */
  function keepCardClear() {
    if (!card) return;
    if (isNarrow()) { card.style.removeProperty("right"); return; }

    const panel = findNexusPanel();
    if (!panel || !panel.isConnected) { card.style.removeProperty("right"); return; }

    // Only step aside for a drawer that is ACTUALLY OPEN. The element can sit
    // in the DOM while closed — hidden, collapsed, or slid off-screen — and
    // shifting for it pushed the card sideways permanently, sometimes right
    // off the edge of the window.
    const cs = getComputedStyle(panel);
    const r = panel.getBoundingClientRect();
    const visible =
      cs.display !== "none" &&
      cs.visibility !== "hidden" &&
      parseFloat(cs.opacity || "1") > 0.05 &&
      r.width > 40 && r.height > 40 &&
      r.right > 0 && r.left < innerWidth;          // actually on screen
    if (!visible) { card.style.removeProperty("right"); return; }

    const z = parseFloat(document.documentElement.style.zoom || "1");
    const scale = Number.isFinite(z) && z > 0.1 ? z : 1;
    const width = r.width / scale;
    if (!width) { card.style.removeProperty("right"); return; }

    // Never push the card past the left edge, whatever the drawer's width.
    const cardWidth = card.offsetWidth || 420;
    const maxRight = Math.max(18, innerWidth - cardWidth - 12);
    const want = Math.min(Math.round(width + 18), Math.round(maxRight));
    card.style.setProperty("right", `${want}px`, "important");
  }

  function findNexusPanel() {
    if (!document.body.textContent.includes("Memory Nexus")) return null;
    const leaf = [...document.querySelectorAll("h1,h2,h3,strong,div,span,p")]
      .find((e) => e.childElementCount === 0 && /^Memory Nexus/i.test((e.textContent || "").trim()));
    if (!leaf) return null;
    // OUTERMOST plausible ancestor — the drawer itself, not an inner column.
    // (Taking the first match docked the tab over the panel's content.)
    let n = leaf;
    let best = null;
    for (let i = 0; i < 10 && n.parentElement; i++) {
      n = n.parentElement;
      const r = n.getBoundingClientRect();
      if (r.width >= 280 && r.width <= 680 && r.height > innerHeight * 0.5) best = n;
    }
    return best;
  }

 function updateNexusTab() {
    document.getElementById("djpb-nexus-tab")?.remove();
  }

  /** Text-leaf pattern matching against the panel's layout: a "Current scene"
   *  header followed by short lines, and "in scene" badges with the name just
   *  before and the italic state line just after (skipping "aka …" rows). */
  function scrapeNexus(panel) {
    const out = { sceneLines: [], states: {}, descs: {} };
    const leafs = [...panel.querySelectorAll("*")]
      .filter((e) => !e.children.length)
      .map((e) => (e.textContent || "").trim())
      .filter(Boolean);

    const cs = leafs.findIndex((t) => /^current scene$/i.test(t));
    if (cs >= 0) {
      out.sceneLines = leafs.slice(cs + 1, cs + 4)
        .filter((t) => t.length > 2 && t.length < 90).slice(0, 2);
    }

    leafs.forEach((t, i) => {
      if (!/^in scene$/i.test(t)) return;
      const name = leafs[i - 1];
      if (!name || name.length > 40) return;
      const q = leafs.slice(i + 1, i + 5)
        .filter((s) => s && !/^aka\s/i.test(s) && s.length > 6 && s.length < 400);
      // Layout: short italic state line first, longer description after. If the
      // first qualifying line is long, it IS the description (no state shown).
      if (!q.length) return;
      if (q[0].length <= 180) {
        out.states[name] = q[0];
        if (q[1]) out.descs[name] = q[1];
      } else {
        out.descs[name] = q[0];
      }
    });

    return (out.sceneLines.length || Object.keys(out.states).length) ? out : null;
  }

  // (tab creation and positioning live in updateNexusTab/trackTab above)

  // ---------- in-page album overlay ----------
  // browse.html iframed over the site (declared web-accessible), so the whole
  // leather-book album runs in place instead of a new tab.

  /** A phone, as opposed to anything that merely supports touch.
   *  Touch alone matched desktops and touchscreen laptops, which is what
   *  zoomed those machines. A phone has a small, dense panel — and in desktop
   *  mode it claims a viewport far wider than that panel. */

  function openAlbumOverlay(sessionId) {
    if (window.isPhone()) {
      chrome.runtime.sendMessage({ type: "albums:open", sessionId }).catch(() => {});
      return;
    }
    if (document.getElementById("djpb-overlay")) return;
    const overlay = document.createElement("div");
    overlay.id = "djpb-overlay";
    overlay.dataset.djpbUi = "1";

    const frame = document.createElement("iframe");
    frame.id = "djpb-overlay-frame";
    frame.allow = "web-share";   // the album's Share button needs this
    // The parent may be zoomed (desktop-mode phones), but zoom does NOT shrink
    // an iframe's internal viewport — inside, the album still measures ~1080px
    // and lays out for a monitor. Passing the real dimensions lets it correct
    // itself; without this its mobile breakpoints never fire.
    frame.src = chrome.runtime.getURL("browse.html") +
      `?embed=1${sessionId ? `&session=${encodeURIComponent(sessionId)}` : ""}` +
      `&vw=${Math.round(innerWidth)}&vh=${Math.round(innerHeight)}`;

    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeAlbumOverlay(); // backdrop click
    });
    overlay.append(frame); // exactly ONE ✕, and it lives inside the album

    // The overlay lives inside a page that may be zoomed, where 100vh does NOT
    // reliably mean "one screen" — the frame ended up taller than the display,
    // which is why the album sat above the visible area. Measured pixels from
    // the parent's own coordinate space always mean one screen.
    const sizeOverlay = () => {
      overlay.style.width = `${innerWidth}px`;
      overlay.style.height = `${innerHeight}px`;
      frame.style.width = `${innerWidth}px`;
      frame.style.height = `${innerHeight}px`;
    };
    sizeOverlay();
    overlay.__djpbResize = () => setTimeout(sizeOverlay, 120);
    addEventListener("resize", overlay.__djpbResize);
    addEventListener("orientationchange", overlay.__djpbResize);
    // Mount on <html>, not <body>: sites that inert body children while a
    // modal is open can't reach it there.
    document.documentElement.appendChild(overlay);
    console.info("[Photobook] Album overlay opened");
  }

  function closeAlbumOverlay() {
    const overlay = document.getElementById("djpb-overlay");
    if (!overlay) return;
    if (overlay.__djpbResize) {
      removeEventListener("resize", overlay.__djpbResize);
      removeEventListener("orientationchange", overlay.__djpbResize);
    }
    overlay.remove();
  }

  window.addEventListener("message", (e) => {
    if (e.data?.source !== "djpb-album") return;
    if (e.data.cmd === "close") closeAlbumOverlay();
    if (e.data.cmd === "latest-reply") {
      // The album asks the CHAT PAGE for the newest reply, because the copy in
      // storage comes from the outgoing request — written before the reply it
      // asks about existed, so it's always one behind.
      (async () => {
        let text = "";
        try {
          const { prose } = await fallbackLatest();
          text = prose || "";
        } catch { /* fall through with empty; the album keeps its fallback */ }
        document.getElementById("djpb-overlay-frame")?.contentWindow?.postMessage(
          { source: "djpb-host", cmd: "latest-reply", text }, "*");
      })();
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && document.getElementById("djpb-overlay")) {
      e.stopPropagation();
      closeAlbumOverlay();
    }
  }, true);

  // Shared with content.js (same isolated world): the panel's 📚 button.
  window.djpbOpenAlbum = openAlbumOverlay;

  // ---------- boot ----------

  let scanQueued = false;
  function scan() {
    scanQueued = false;
    if (!session()) {
      ensurePill(false);
      document.getElementById("djpb-nexus-tab")?.remove();
      return;
    }
    injectCameras();
    ensurePill(true); // the docked pill is the primary snap control now
    updateNexusTab();
  }

  new MutationObserver(() => {
    if (scanQueued) return;
    scanQueued = true;
    setTimeout(scan, 250); // let the streamed message finish mounting
  }).observe(document.documentElement, { childList: true, subtree: true });

  scan();
  setInterval(scan, 2000); // SPA-navigation safety net
})();
