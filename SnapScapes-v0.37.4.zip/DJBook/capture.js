// capture.js — the bridge back from an image site into the photobook. v0.6.4
//
// Never types anything the user didn't ask for, never submits, never drives
// the page, and NEVER saves on its own. It watches a tab the user is actively
// using, shows a thumbnail of the image it believes was just generated, and
// saves only when the ♥ Save to photobook button is pressed.
//
// Why no auto-save: saving without a click required telling the pasted
// reference apart from the generation by perceptual hash, and a generation
// that is DERIVED from its reference defeats that comparison in both
// directions (refs saved as gens, gens skipped as refs). A human looking at
// a thumbnail is the only reliable discriminator — so the human clicks.

(() => {
  const SEEN = new WeakSet();
  // Element identity is not enough on ChatGPT: scrolling a long conversation
  // remounts <img> nodes, so a picture from three turns ago arrives as a
  // brand-new element and looks freshly generated. Srcs survive remounting;
  // element references do not.
  const SEEN_SRC = new Set();
  // Everything already on the page the moment a snap was armed. Whatever the
  // model draws for THIS snap cannot be in here.
  let armedSrcs = null;
  const FRESH = [];        // images that appeared after load, newest last
  const MIN_EDGE = 256;    // avatars, icons and inline logos are smaller
  let initialScanDone = false;
  let castNames = { charName: null, userName: null };
  let toastMinimized = false; // persistent collapse state for mobile

  // ---------- image detection ----------

  function isCandidate(img) {
    if (SEEN.has(img)) return false;
    if (img.closest("[data-djpb-ui]")) return false;

    const src = img.currentSrc || img.src || "";
    if (!src) return false;
    if (src.startsWith("data:image/svg")) return false;

    const r = img.getBoundingClientRect();
    const w = Math.max(r.width, img.naturalWidth || 0);
    const h = Math.max(r.height, img.naturalHeight || 0);
    if (w < MIN_EDGE || h < MIN_EDGE) return false;

    if (img.closest("header, nav, [role='banner']")) return false;
    return true;
  }

  function scan() {
    for (const img of document.images) {
      if (!isCandidate(img)) continue;
      SEEN.add(img);
      const src0 = img.currentSrc || img.src || "";
      if (src0) SEEN_SRC.add(src0);
      const fresh = initialScanDone;
      if (img.complete && img.naturalWidth) onImage(img, fresh);
      else img.addEventListener("load", () => onImage(img, fresh), { once: true });
    }
  }

  async function onImage(img, fresh) {
    if (!fresh) return;

    const srcNow = img.currentSrc || img.src || "";
    if (srcNow) SEEN_SRC.add(srcNow);
    FRESH.push(img);

    let snap = null;
    try {
      const res = await chrome.runtime.sendMessage({ type: "snap:peek" });
      snap = res?.ok ? res.snap : null;
    } catch { /* worker mid-restart */ }

    // Armed: make sure the watcher is running. A watcher already going for
    // THIS snap is left alone — it re-reads the candidate list every tick, so
    // restarting would only reset the settle counter for no reason.
    if (snap && !(watch && watch.snap?.createdAt === snap.createdAt)) {
      startSettleWatch(snap);
    }
  }

  /** ChatGPT renders generated images progressively: the element and its src
   *  are replaced several times as the picture sharpens. The watcher tracks
   *  the newest fresh candidate, shows it as a thumbnail in the toast, and
   *  enables the ♥ save button only once the src has held still — so a click
   *  can't grab a half-baked frame. Nothing is ever saved without the click.
   *
   *  The reference echo appears at send time; the generation lands much
   *  later and becomes the newest candidate on its own. If the default pick
   *  is ever wrong, ◀ ▶ steps through the other fresh images. */
  const SKIPPED = new Set(); // srcs already saved this session — don't re-offer

  let watch = null; // { iv, snap, baseline, offset, lastSrc, stable, shownSrc }

  function stopWatch() {
    if (watch?.iv) clearInterval(watch.iv);
    watch = null;
  }

  /** (Re)start watching for THIS snap. Re-arming replaces the whole watcher,
   *  baseline included — the old version early-returned if one was already
   *  running, so a second snap saved with the FIRST snap's prompt, session,
   *  and baseline still in the interval's closure. */
  function startSettleWatch(snap) {
    stopWatch();
    const baseline = armedSrcs || new Set();
    watch = { snap, baseline, offset: 0, lastSrc: null, stable: 0, shownSrc: null, iv: null };

    let ticks = 0;
    watch.iv = setInterval(() => {
      ticks += 1;
      if (ticks > 400) { stopWatch(); return; } // ~5 min cap

      const list = candidates(watch.baseline);
      if (!list.length) return;
      const idx = Math.min(watch.offset, list.length - 1);
      const img = list[idx];
      const src = img.currentSrc || img.src || "";

      if (src === watch.lastSrc && img.complete && img.naturalWidth >= MIN_EDGE) {
        watch.stable += 1;
      } else {
        watch.stable = 0;
        watch.lastSrc = src;
      }

      const ready = watch.stable >= 4; // unchanged ~3s → done rendering
      // Redraw the toast only when something the user can see changed.
      const key = `${src}|${ready ? 1 : 0}|${idx}|${list.length}`;
      if (key !== watch.shownSrc) {
        watch.shownSrc = key;
        showSaveToast(img, ready, idx, list.length);
      }
    }, 800);
  }

  /** An image sitting inside a USER turn is an attachment echo — the
   *  reference we pasted, bounced back by the site. A generation only ever
   *  renders in an assistant turn, so these are never candidates at all.
   *  This is DOM position, not pixel similarity: it cannot mistake a gen
   *  for its reference the way the old fingerprint comparison could. If a
   *  site ever renames its markers, detection returns false and behaviour
   *  degrades to "the echo shows in the picker", never to a lost image. */
  function isUserUpload(img) {
    // ChatGPT / chat.openai.com label every message with its author.
    if (img.closest('[data-message-author-role="user"]')) return true;
    // Gemini renders the user's turn inside a <user-query> element.
    if (img.closest("user-query")) return true;
    // Attachment previews waiting in the composer live inside the send form;
    // no site renders a finished generation inside a <form>. This is what
    // made re-arming offer to save your own references: auto-fill pastes
    // them again, the new blob: previews postdate the new baseline, and
    // with no generation on screen yet they were the only candidates.
    if (img.closest("form")) return true;
    return false;
  }

  /** Fresh, connected, unsaved images, newest first. blob:/data: previews on
   *  ChatGPT are the local pasted uploads, not generations — they stay out of
   *  slot 0 but remain reachable through ◀ ▶ in case the default is wrong. */
  function candidates(baseline) {
    const onChatGPT = /(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/.test(location.hostname);
    const out = [];
    const local = [];
    // Prune disconnected elements while we're here so FRESH can't grow forever.
    for (let i = FRESH.length - 1; i >= 0; i--) {
      if (!FRESH[i].isConnected) { FRESH.splice(i, 1); continue; }
      const img = FRESH[i];
      const src = img.currentSrc || img.src || "";
      if (SKIPPED.has(src)) continue;
      if (baseline && baseline.has(src)) continue; // predates this snap
      if (isUserUpload(img)) continue;             // our own reference, echoed
      if (img.naturalWidth < MIN_EDGE && img.complete) continue;
      if (src.startsWith("blob:") || src.startsWith("data:")) {
        // On ChatGPT these are always local upload previews — generations
        // come from the CDN — so they are not candidates at all. Elsewhere
        // they trail the list, in case a site serves its gens locally.
        if (onChatGPT) continue;
        local.push(img);
      } else {
        out.push(img);
      }
    }
    return dedupe(out.concat(local));
  }

  /** One generation arrives as SEVERAL elements: ChatGPT remounts the <img>
   *  while it sharpens and leaves crossfade layers stacked in place — so a
   *  single finished picture read as "(3/3)" in the picker. Collapse the
   *  stack: same src is the same picture, and two candidates whose rendered
   *  boxes overlap almost completely are the same picture on screen whatever
   *  their srcs say. Newest-first order means the freshest layer survives. */
  function dedupe(list) {
    const out = [];
    const seenSrc = new Set();
    for (const img of list) {
      const src = img.currentSrc || img.src || "";
      if (src && seenSrc.has(src)) continue;
      const r = img.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) continue; // hidden crossfade leftover
      const stacked = out.some((o) => {
        const q = o.getBoundingClientRect();
        const ix = Math.max(0, Math.min(r.right, q.right) - Math.max(r.left, q.left));
        const iy = Math.max(0, Math.min(r.bottom, q.bottom) - Math.max(r.top, q.top));
        return ix * iy > 0.8 * Math.min(r.width * r.height, q.width * q.height);
      });
      if (stacked) continue;
      if (src) seenSrc.add(src);
      out.push(img);
    }
    return out;
  }

  /** The save toast: thumbnail of the current pick, ◀ ▶ when there is more
   *  than one, and the ♥ button — disabled with a spinner note until the
   *  image has finished rendering. */
  function showSaveToast(img, ready, idx, count) {
    const snap = watch?.snap;
    const actions = [];

    if (count > 1) {
      actions.push({ label: "◀", small: true, fn: () => {
        if (!watch) return;
        watch.offset = (idx + 1) % count;   // older
        watch.stable = 0; watch.lastSrc = null; watch.shownSrc = null;
      } });
      actions.push({ label: "▶", small: true, fn: () => {
        if (!watch) return;
        watch.offset = (idx - 1 + count) % count; // newer
        watch.stable = 0; watch.lastSrc = null; watch.shownSrc = null;
      } });
    }

    actions.push({
      label: "Save to photobook", heart: true, disabled: !ready,
      fn: async (btn) => {
        btn.disabled = true;
        const label = btn.querySelector("[data-djpb-label]") || btn;
        label.textContent = "Saving…";
        try {
          await capture(img, snap);
        } catch { /* capture() already toasts the failure */ }
      },
    });

    const msg = ready
      ? (count > 1 ? `This one? (${idx + 1}/${count})` : "Ready when you are:")
      : "Still rendering…";
    toast(msg, null, actions, img.currentSrc || img.src || "");
  }

  function showArmedToast(message, snap) {
    const attach = (role, who) => ({
      label: `⤵ Attach ${who} ref`,
      fn: async (btn) => {
        const original = btn.textContent;
        btn.textContent = "…";
        try {
          const res = await chrome.runtime.sendMessage({ type: "snap:refimage", role });
          if (!res?.ok || !res.dataUrl) throw new Error(res?.error || "no reference");
          const blob = await (await fetch(res.dataUrl)).blob();
          btn.textContent = (await insertImage(blob, res.name)) ? "✓ attached" : "couldn't attach";
        } catch {
          btn.textContent = "not available";
        }
        setTimeout(() => (btn.textContent = original), 3000);
      },
    });

    toast(message, null, [
      { label: "⤵ Put prompt in the box", fn: async (btn) => {
          const ok = insertPrompt(snap?.prompt || "");
          btn.textContent = ok ? "✓ in the box — hit send" : "couldn't find the box";
          setTimeout(() => (btn.textContent = "⤵ Put prompt in the box"), 3000);
        } },
      attach("bot", castNames.charName || "char"),
      attach("user", castNames.userName || "your"),
      { label: "💾 Save newest image", fn: async (btn) => {
          // The same list the picker uses, newest first. The old version
          // filtered document.images through isCandidate(), which rejects
          // anything already in SEEN — and scan() puts every image there, so
          // this was always empty and always said "no image found".
          const img = candidates(armedSrcs || new Set())[0] || null;
          if (!img) {
            btn.textContent = "no image found";
            setTimeout(() => (btn.textContent = "💾 Save newest image"), 2500);
            return;
          }
          btn.textContent = "saving…";
          try {
            const res = await chrome.runtime.sendMessage({ type: "snap:peek" });
            await capture(img, res?.ok ? res.snap : snap);
            btn.textContent = "✓ saved";
          } catch {
            btn.textContent = "failed";
          }
          setTimeout(() => (btn.textContent = "💾 Save newest image"), 2500);
        } },
    ]);
  }

  // ---------- capture ----------

  async function toDataUrl(img) {
    const src = img.currentSrc || img.src;

    try {
      const res = await fetch(src);
      if (res.ok) {
        const blob = await res.blob();
        if (blob.type.startsWith("image/") || src.startsWith("blob:")) {
          return await blobToDataUrl(blob);
        }
      }
    } catch { /* fall through */ }

    try {
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      canvas.getContext("2d").drawImage(img, 0, 0);
      return canvas.toDataURL("image/png");
    } catch { /* fall through */ }

    const res = await chrome.runtime.sendMessage({ type: "fetchImage", url: src });
    if (!res?.ok) throw new Error(res?.error || "couldn't read that image");
    return res.dataUrl;
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = () => reject(new Error("read failed"));
      r.readAsDataURL(blob);
    });
  }

  async function capture(img, snap, preDataUrl) {
    try {
      const dataUrl = preDataUrl || await toDataUrl(img);
      const res = await chrome.runtime.sendMessage({
        type: "snap:save",
        dataUrl,
        sessionId: snap?.sessionId || null,
        caption: snap?.replyText || "",
      });
      if (!res?.ok) throw new Error(res?.error || "save failed");

      // With the bridge tab reused across snaps, this image stays on the page.
      // Mark it saved so it never shows up as a candidate again.
      SKIPPED.add(img.currentSrc || img.src || "");
      stopWatch();

      const savedMsg = res.sessionId === "unfiled"
        ? "Saved to Unfiled ♥"
        : "Saved to photobook ♥";
      // Snapscape in follow mode picks the new photo up on its own; pinned
      // gets an explicit button so the save didn't silently change nothing.
      const actions = [];
      if (res.follow === false && res.sessionId && res.sessionId !== "unfiled") {
        actions.push({ label: "🖼 Set as Snapscape", fn: async (btn) => {
          btn.disabled = true;
          btn.textContent = "Setting…";
          try {
            const r = await chrome.runtime.sendMessage({
              type: "db", op: "setBackdrop",
              args: { sessionId: res.sessionId, id: res.id },
            });
            btn.textContent = r?.ok ? "✓ Snapscape set" : "couldn't set it";
          } catch {
            btn.textContent = "couldn't set it";
          }
        } });
      }
      toast(savedMsg, res.returnUrl, actions.length ? actions : null);
    } catch (err) {
      console.warn("[Photobook] Capture failed:", err);
      toast(`Couldn't save: ${err.message}`);
      throw err;
    }
  }

  // ---------- toast & dragging ----------

  const TOAST_POS_KEY = "djpbToastPos";
  let toastPos = null;
  let toastPosLoaded = false;

  async function loadToastPos() {
    if (toastPosLoaded) return;
    toastPosLoaded = true;
    try {
      const v = await chrome.storage.local.get({ [TOAST_POS_KEY]: null });
      toastPos = v[TOAST_POS_KEY];
      if (toastPos && toastEl) placeToast(toastEl);
    } catch { /* defaults apply */ }
  }

  const narrow = () => innerWidth < 820;

  function placeToast(el) {
    if (!toastPos) {
      el.style.left = "auto";
      el.style.top = "auto";
      el.style.right = narrow() ? "10px" : "20px";
      el.style.bottom = narrow()
        ? "calc(env(safe-area-inset-bottom, 0px) + 150px)"
        : "20px";
      return;
    }
    const w = el.offsetWidth || 300;
    const h = el.offsetHeight || 60;
    const x = Math.min(Math.max(toastPos.xPct * innerWidth, 4), innerWidth - w - 4);
    const y = Math.min(Math.max(toastPos.yPct * innerHeight, 4), innerHeight - h - 4);
    Object.assign(el.style, {
      left: `${Math.round(x)}px`, top: `${Math.round(y)}px`,
      right: "auto", bottom: "auto",
    });
  }

  function makeToastDraggable(el) {
    let origin = null;
    let dragging = false;
    el.style.touchAction = "none";

    el.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button, a, input, textarea")) return;
      const r = el.getBoundingClientRect();
      origin = { px: e.clientX, py: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top };
      dragging = false;
      try { el.setPointerCapture(e.pointerId); } catch { /* fine */ }
    });

    el.addEventListener("pointermove", (e) => {
      if (!origin) return;
      const dist = Math.hypot(e.clientX - origin.px, e.clientY - origin.py);
      if (!dragging && dist > 5) {
        dragging = true;
        el.style.opacity = "0.92";
        el.style.cursor = "grabbing";
      }
      if (!dragging) return;
      e.preventDefault();
      const w = el.offsetWidth, h = el.offsetHeight;
      const x = Math.min(Math.max(e.clientX - origin.dx, 4), innerWidth - w - 4);
      const y = Math.min(Math.max(e.clientY - origin.dy, 4), innerHeight - h - 4);
      Object.assign(el.style, {
        left: `${Math.round(x)}px`, top: `${Math.round(y)}px`,
        right: "auto", bottom: "auto",
      });
    });

    const end = (e) => {
      if (!origin) return;
      origin = null;
      try { el.releasePointerCapture(e.pointerId); } catch { /* fine */ }
      el.style.opacity = "1";
      el.style.cursor = "grab";
      if (!dragging) return;
      dragging = false;
      const r = el.getBoundingClientRect();
      toastPos = { xPct: r.left / innerWidth, yPct: r.top / innerHeight };
      chrome.storage.local.set({ [TOAST_POS_KEY]: toastPos });
    };
    el.addEventListener("pointerup", end);
    el.addEventListener("pointercancel", end);
  }

  let toastEl = null;

  /** The heartbeat lives in a real stylesheet because inline styles can't
   *  carry keyframes. Injected once, tiny, and only animates the ♥. */
  let heartCss = null;
  function ensureHeartCss() {
    if (heartCss?.isConnected) return;
    heartCss = document.createElement("style");
    heartCss.dataset.djpbUi = "1";
    heartCss.textContent = `
      @keyframes djpb-heartbeat {
        0%, 100% { transform: scale(1); }
        10%      { transform: scale(1.25); }
        20%      { transform: scale(1); }
        30%      { transform: scale(1.15); }
        40%      { transform: scale(1); }
      }
      @keyframes djpb-heartpop {
        0%   { transform: scale(1); }
        45%  { transform: scale(1.6) rotate(-8deg); }
        100% { transform: scale(1); }
      }
      .djpb-heart { display: inline-block; animation: djpb-heartbeat 1.6s ease-in-out infinite; }
      button:disabled .djpb-heart { animation: none; opacity: .6; }
      .djpb-heart.pop { animation: djpb-heartpop .5s ease-out 1; }
    `;
    (document.head || document.documentElement).appendChild(heartCss);
  }

  function toast(message, returnUrl, actions, thumbSrc) {
    toastEl?.remove();
    ensureHeartCss();
    toastEl = document.createElement("div");
    toastEl.dataset.djpbUi = "1";
    Object.assign(toastEl.style, {
      position: "fixed", zIndex: 2147483001,
      display: "flex", flexDirection: "column", gap: "10px",
      maxWidth: "min(420px, 92vw)",
      font: "13px/1.3 system-ui, sans-serif", color: "#e9e4f5",
      background: "#1f1830", border: "1px solid #3a2b55",
      borderRadius: "12px", padding: "10px 12px",
      boxShadow: "0 8px 30px rgba(0,0,0,.5)",
      cursor: "grab", userSelect: "none", webkitUserSelect: "none",
    });

    const headRow = document.createElement("div");
    Object.assign(headRow.style, {
      display: "flex", alignItems: "center", justifyContent: "space-between",
      gap: "8px", width: "100%",
    });

    const gripAndText = document.createElement("div");
    Object.assign(gripAndText.style, {
      display: "flex", alignItems: "center", gap: "8px", flex: "1 1 auto", minWidth: "0",
    });

    const grip = document.createElement("span");
    grip.textContent = "⠿";
    Object.assign(grip.style, { color: "#8b78af", fontSize: "15px", cursor: "grab", touchAction: "none" });
    grip.title = "Drag to move";

    const text = document.createElement("span");
    text.textContent = message;
    Object.assign(text.style, {
      whiteSpace: "normal", wordBreak: "break-word", flex: "1 1 auto",
    });

    // The thumbnail is the whole trick: the user can SEE whether this is the
    // generation or the reference echo before anything is saved. It sits in
    // the head row so it stays visible when the panel is minimized.
    if (thumbSrc) {
      const thumb = document.createElement("img");
      thumb.src = thumbSrc;
      thumb.alt = "";
      Object.assign(thumb.style, {
        width: "52px", height: "52px", objectFit: "cover",
        borderRadius: "10px", border: "2px solid #3a2b55",
        flex: "none", pointerEvents: "none",
      });
      gripAndText.append(grip, thumb, text);
    } else {
      gripAndText.append(grip, text);
    }

    const minBtn = document.createElement("button");
    minBtn.type = "button";
    minBtn.textContent = toastMinimized ? "＋" : "—";
    minBtn.title = toastMinimized ? "Expand bridge panel" : "Minimize bridge panel";
    Object.assign(minBtn.style, {
      font: "600 12px/1 system-ui, sans-serif", color: "#b7a8d8",
      background: "rgba(255,255,255,0.08)", border: "1px solid #3a2b55",
      borderRadius: "6px", padding: "4px 8px", cursor: "pointer", flexShrink: "0",
    });

    headRow.append(gripAndText, minBtn);
    toastEl.appendChild(headRow);

    const actionsWrap = document.createElement("div");
    Object.assign(actionsWrap.style, {
      display: toastMinimized ? "none" : "flex",
      alignItems: "center", gap: "8px", flexWrap: "wrap", width: "100%",
    });

    for (const a of actions || []) {
      const btn = document.createElement("button");
      btn.type = "button";
      if (a.disabled) btn.disabled = true;
      Object.assign(btn.style, {
        font: "600 12px/1 system-ui, sans-serif", color: "#fff",
        background: a.heart
          ? "linear-gradient(135deg,#f472b6,#fb7185)"
          : "linear-gradient(135deg,#8b5cf6,#ec4899)",
        border: "none", borderRadius: "999px",
        padding: a.small
          ? (narrow() ? "11px 13px" : "7px 10px")
          : (narrow() ? "11px 14px" : "7px 11px"),
        minHeight: narrow() ? "42px" : "auto",
        cursor: a.disabled ? "default" : "pointer",
        opacity: a.disabled ? "0.55" : "1",
        display: "inline-flex", alignItems: "center", gap: "6px",
      });
      if (a.heart) {
        const heart = document.createElement("span");
        heart.className = "djpb-heart";
        heart.textContent = "♥";
        const label = document.createElement("span");
        label.dataset.djpbLabel = "1";
        label.textContent = a.label;
        btn.append(heart, label);
        btn.addEventListener("click", () => {
          heart.classList.add("pop"); // a little celebration on the way out
          a.fn(btn);
        });
      } else {
        btn.textContent = a.label;
        btn.addEventListener("click", () => a.fn(btn));
      }
      actionsWrap.appendChild(btn);
    }

    const safeReturn = /^https?:\/\//i.test(String(returnUrl || "")) ? returnUrl : null;
    if (safeReturn) {
      const back = document.createElement("a");
      back.href = safeReturn;
      back.textContent = "Back to chat";
      Object.assign(back.style, {
        color: "#c4b5fd", fontWeight: "600", textDecoration: "none",
        whiteSpace: "nowrap",
      });
      actionsWrap.appendChild(back);
    }

    if (actions?.length || safeReturn) {
      toastEl.appendChild(actionsWrap);
    } else {
      minBtn.style.display = "none";
    }

    minBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toastMinimized = !toastMinimized;
      minBtn.textContent = toastMinimized ? "＋" : "—";
      minBtn.title = toastMinimized ? "Expand bridge panel" : "Minimize bridge panel";
      actionsWrap.style.display = toastMinimized ? "none" : "flex";
      if (toastEl) placeToast(toastEl);
    });

    document.body.appendChild(toastEl);
    placeToast(toastEl);
    makeToastDraggable(toastEl);
    loadToastPos();

    if (!actions?.length) {
      setTimeout(() => toastEl?.remove(), returnUrl ? 12000 : 5000);
    }
  }

  // ---------- announcing this tab ----------

  const BRIDGE = /grok\.com$/i.test(location.hostname) ? "grok"
    : /gemini\.google\.com$/i.test(location.hostname) ? "gemini"
    : "chatgpt";

  const alive = () => {
    try { return Boolean(chrome.runtime?.id); } catch { return false; }
  };

  async function announce() {
    if (!alive()) return;
    try {
      await chrome.runtime.sendMessage(
        { type: "bridge:hello", url: location.href, bridge: BRIDGE });
    } catch { /* worker asleep */ }
  }

  announce();

  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) { lastHref = location.href; announce(); }
  }, 1000);

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type !== "snap:armed") return;
    armedSrcs = new Set(SEEN_SRC);
    for (const img of document.images) {
      const src = img.currentSrc || img.src || "";
      if (src) armedSrcs.add(src);
    }
    (async () => {
      try {
        const res = await chrome.runtime.sendMessage({ type: "snap:peek" });
        if (res?.ok && res.snap) {
          castNames = { charName: res.charName, userName: res.userName };
          const auto = await autoFillEnabled();
          showArmedToast(auto
            ? "📖 Filling the box for you…"
            : "📖 Armed — use the buttons below, then send.", res.snap);
          if (auto) autoFill(res.snap, (msg) => showArmedToast(msg, res.snap));
        }
      } catch { /* worker mid-restart */ }
    })();
  });

  function preventFocusZoom() {
    try {
      const style = document.createElement("style");
      style.dataset.djpbUi = "1";
      style.textContent = `
        #prompt-textarea, textarea, input[type="text"], [contenteditable="true"] {
          font-size: max(16px, 1em) !important;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    } catch { /* page behaves as before */ }
  }

  function findComposer() {
    return document.querySelector("#prompt-textarea") ||
           document.querySelector("main [contenteditable='true']") ||
           document.querySelector("form textarea") ||
           document.querySelector("textarea");
  }

  function insertPrompt(text) {
    const box = findComposer();
    if (!box) return false;
    box.focus();
    if (box.isContentEditable) {
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
      if (!box.textContent.trim()) {
        box.textContent = text;
        box.dispatchEvent(new InputEvent("input", { bubbles: true }));
      }
    } else {
      const setter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, "value")?.set;
      setter ? setter.call(box, text) : (box.value = text);
      box.dispatchEvent(new Event("input", { bubbles: true }));
    }
    return true;
  }

  async function insertImage(blob, name) {
    const box = findComposer();
    if (!box) return false;
    const dt = new DataTransfer();
    dt.items.add(new File([blob], name || "reference.png", { type: blob.type || "image/png" }));
    box.focus();
    const ev = new ClipboardEvent("paste", {
      clipboardData: dt, bubbles: true, cancelable: true,
    });
    box.dispatchEvent(ev);
    return true;
  }

  let filledFor = null;

  async function autoFillEnabled() {
    try {
      const { djpbAutoFill } = await chrome.storage.local.get({ djpbAutoFill: true });
      return djpbAutoFill !== false;
    } catch {
      return true;
    }
  }

  async function waitForComposer(ms = 8000) {
    const started = Date.now();
    while (Date.now() - started < ms) {
      const box = findComposer();
      if (box) return box;
      await new Promise((r) => setTimeout(r, 250));
    }
    return null;
  }

  async function autoFill(snap, announce) {
    if (!snap?.prompt) return;
    const stamp = String(snap.createdAt || snap.prompt.slice(0, 40));
    if (filledFor === stamp) return;
    filledFor = stamp;

    if (!(await autoFillEnabled())) return;

    const box = await waitForComposer();
    if (!box) return;

    if (!insertPrompt(snap.prompt)) return;

    let attached = 0;
    let picked = [];
    try {
      const res = await chrome.runtime.sendMessage({ type: "snap:refimages" });
      picked = res?.ok && Array.isArray(res.images) ? res.images : [];
    } catch { /* worker mid-restart */ }

    for (const ref of picked) {
      try {
        const blob = await (await fetch(ref.dataUrl)).blob();
        if (await insertImage(blob, ref.name)) {
          attached += 1;
          await new Promise((r) => setTimeout(r, 700));
        }
      } catch { /* skip unavailable ref */ }
    }

    if (announce) {
      const what = attached
        ? `Prompt and ${attached} reference${attached === 1 ? "" : "s"} are in the box`
        : "Prompt is in the box";
      announce(`✓ ${what} — just hit send.`);
    }
  }

  // ---------- boot ----------

  (async () => {
    scan();
    initialScanDone = true;

    try {
      const res = await chrome.runtime.sendMessage({ type: "snap:peek" });
      if (res?.ok && res.snap) {
        castNames = { charName: res.charName, userName: res.userName };
        const auto = await autoFillEnabled();
        showArmedToast(auto
          ? "📖 Filling the box for you…"
          : "📖 Watching — use the buttons below, then send.", res.snap);
        if (auto) autoFill(res.snap, (msg) => showArmedToast(msg, res.snap));
      }
    } catch { /* worker asleep */ }

    preventFocusZoom();

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") setTimeout(scan, 400);
    });

    new MutationObserver(scan).observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  })();
})();