// browse.js — the album.
//
// This page shares the extension origin with the service worker, so it opens
// the same IndexedDB directly: no photos travel through messages (the v0.4
// browse page shipped every image as base64 — this reads blobs and hands the
// <img> an object URL, which is the difference between instant and seconds).
//
// Page model per album:
//   0            endpaper (cast portraits)
//   1..N         one photo per page
//   N+1          back pocket (unfiled loose photos)

(() => {
  const DB_NAME = "dj-photobook";
  const DB_VERSION = 3;

  const $ = (id) => document.getElementById(id);
  const urlCache = new Map(); // image id -> object URL, revoked on album close
  const extraUrls = [];       // one-off object URLs (title image), same lifecycle

  // Each album picks its world. The variables cascade from body[data-theme]
  // in the reader and from .book-cover[data-theme] on the shelf.
  const THEMES = [
    ["grimoire", "Classic"],
    ["arcana", "Arcana"],
    ["vendetta", "Punk"],
    ["gothic", "Aurora"],
    ["forest", "Deepwood"],
    ["ember", "Emberfall"],
    ["redflags", "Red Flags"],
    ["afterhours", "After Hours"],
    ["watercolor", "Watercolor"],
    ["roses", "Roses"],
  ];
  // Retired bindings map onto their replacements so no stored album ever
  // loses its clothes: the old neutral default and Grimoire are now one
  // binding called Classic; Sunny's slot went to Watercolor and Noir's to
  // Roses; Vendetta kept its id (saved albums!) and became Punk.
  const LEGACY_THEMES = { default: "grimoire", scrapbook: "watercolor", noir: "roses" };
  const normTheme = (t) => LEGACY_THEMES[t] || t || "grimoire";
  // Each album picks its world. The variables cascade from body[data-theme]
  // in the reader and from .book-cover[data-theme] on the shelf.
  // Six ways to mount a photograph — each a different physical object, not a
  // border colour. Per-album default, per-photo override (rec.frame).
  const FRAMES = [
    ["corners", "Kraft corners"],
    ["instant", "Instant film"],
    ["gilded",  "Gilded"],
    ["film",    "Filmstrip"],
    ["tape",    "Washi tape"],
    ["stamp",   "Postage"],
    ["spray",   "Spray paint"],
  ];
  const frameLabel = (id) => (FRAMES.find(([f]) => f === id) || FRAMES[0])[1];

  const applyTheme = (t) => {
    if (!t || t === "default") delete document.body.dataset.theme;
    else document.body.dataset.theme = t;
  };
  const FONTS = [
    ["default", "Theme's pick"],
    ["hand", "Handwritten"],
    ["print", "Print"],
    ["typewriter", "Typewriter"],
    ["elegant", "Elegant"],
    ["marker", "Marker"],
  ];
  const applyFont = (f) => {
    if (!f || f === "default") delete document.body.dataset.font;
    else document.body.dataset.font = f;
  };

  let db = null;
  let album = null;   // {sessionId, title, photos[], sheet, lastReply, unfiled[]}
  let pageIndex = 0;
  let turning = false;
  let favoritesOnly = false;

  // ---------- storage ----------

  function openDb() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, DB_VERSION);
      r.onupgradeneeded = () => {
        // Mirror the worker's schema exactly, in case this page runs first.
        const d = r.result;
        if (!d.objectStoreNames.contains("images")) {
          const s = d.createObjectStore("images", { keyPath: "id", autoIncrement: true });
          s.createIndex("bySession", "sessionId", { unique: false });
        }
        if (!d.objectStoreNames.contains("sessions")) {
          d.createObjectStore("sessions", { keyPath: "sessionId" });
        }
      };
      r.onblocked = () =>
        reject(new Error("the photobook database is busy in another tab"));
      r.onsuccess = () => {
        r.result.onversionchange = () => r.result.close();
        resolve(r.result);
      };
      r.onerror = () => reject(r.error);
    });
  }

  const req = (r) => new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const tx = (name, mode = "readonly") => db.transaction(name, mode).objectStore(name);

  function photoUrl(rec) {
    if (!urlCache.has(rec.id)) urlCache.set(rec.id, URL.createObjectURL(rec.blob));
    return urlCache.get(rec.id);
  }

  function releaseUrls() {
    for (const url of urlCache.values()) URL.revokeObjectURL(url);
    urlCache.clear();
    for (const url of extraUrls) URL.revokeObjectURL(url);
    extraUrls.length = 0;
  }

  // ---------- shelf ----------

  async function renderShelf() {
    releaseUrls();
    album = null;
    favoritesOnly = false;
    applyTheme("default"); // the room is neutral; each cover wears its own
    applyFont("default");
    $("reader").hidden = true;
    $("shelf").hidden = false;

    const [images, sessions] = await Promise.all([
      req(tx("images").getAll()),
      req(tx("sessions").getAll()),
    ]);

    const byId = new Map();
    for (const r of images) {
      const a = byId.get(r.sessionId) || { sessionId: r.sessionId, count: 0, latest: 0, coverRec: null };
      a.count += 1;
      if ((r.createdAt || 0) >= a.latest) { a.latest = r.createdAt || 0; a.coverRec = r; }
      a.byId = a.byId || new Map();
      a.byId.set(r.id, r);
      byId.set(r.sessionId, a);
    }
    for (const s of sessions) {
      const a = byId.get(s.sessionId);
      if (!a) continue; // a sheet with no photos yet isn't a book on the shelf
      a.title = s.customTitle || s.album?.title || s.sheet?.album?.title || null;
      a.cover = s.album?.cover || null;
      a.coverId = s.coverId || null;      // a photo the user picked
      a.theme = normTheme(s.theme);
      a.pageArt = s.pageArt || null;
      a.blurb = s.blurb || "";
      a.coverBlob = s.coverBlob || null;   // an image the user supplied
    }

    const row = $("shelf-row");
    row.innerHTML = "";
    const albums = [...byId.values()]
      .filter((a) => a.sessionId !== "unfiled")
      .sort((x, y) => y.latest - x.latest);

    $("shelf-empty").hidden = albums.length > 0;

    const MONTH = 30 * 24 * 3600 * 1000;
    for (const a of albums) {
      const cover = document.createElement("div");
      cover.className = "book-cover" + (Date.now() - a.latest > MONTH ? " dusty" : "");
      cover.dataset.theme = a.theme;
      // Watercolor and Roses covers show the album's own cached painting
      // behind a linen scrim, so every book on the shelf is one of a kind.
      if (a.pageArt?.dataUrl && a.pageArt.theme === a.theme) {
        const scrim = a.theme === "roses"
          ? "linear-gradient(rgba(253, 246, 242, 0.58), rgba(253, 246, 242, 0.78))"
          : "linear-gradient(rgba(252, 250, 244, 0.6), rgba(252, 250, 244, 0.8))";
        if (a.theme === "watercolor" || a.theme === "roses") {
          cover.style.background = `${scrim}, url("${a.pageArt.dataUrl}") center / cover`;
        }
      }

      // The whole board opens the album, except the intro strip, which edits.
      // A <button> can't legally contain another, so the hit target is its own
      // layer underneath rather than a wrapper around everything.
      const hit = document.createElement("button");
      hit.className = "cover-hit";
      hit.type = "button";
      hit.setAttribute("aria-label", `Open ${a.title || "this album"}`);

      // A book is boards + spine + a page block, not a rectangle with a
      // picture on it. These three carry the object; the rest is printing.
      const spine = document.createElement("span");
      spine.className = "cover-spine";
      spine.setAttribute("aria-hidden", "true");

      const pages = document.createElement("span");
      pages.className = "cover-pages";
      pages.setAttribute("aria-hidden", "true");

      const plate = document.createElement("span");
      plate.className = "cover-plate";   // the recess the photograph sits in

      const art = document.createElement("img");
      art.className = "cover-art";
      art.alt = "";
      // Prefer the plot's background art; fall back to the newest photo.
      // Priority: the photo the user chose, then the site's own cover art,
      // then whatever arrived most recently.
      // Priority: an image the user supplied, then a photo they picked from
      // the album, then the site's own art, then the newest photo.
      const chosen = a.coverId && a.byId ? a.byId.get(a.coverId) : null;
      if (a.coverBlob) {
        const u = URL.createObjectURL(a.coverBlob);
        extraUrls.push(u);
        art.src = u;
      } else {
        art.src = chosen ? photoUrl(chosen)
                         : (a.cover || (a.coverRec ? photoUrl(a.coverRec) : ""));
      }

      const title = document.createElement("span");
      title.className = "cover-title";
      title.textContent = a.title || `Session ${a.sessionId.slice(0, 8)}`;

      const count = document.createElement("span");
      count.className = "cover-count";
      count.textContent = `${a.count} ✦`;

      // A line in the owner's own words. Two albums from the same character
      // look identical on the shelf; this is what tells them apart.
      const blurb = document.createElement("button");
      blurb.className = "cover-blurb" + (a.blurb ? "" : " empty");
      blurb.type = "button";
      blurb.textContent = a.blurb || "Add a note…";
      blurb.title = "Click to describe this album";
      blurb.addEventListener("click", (e) => {
        e.stopPropagation();
        editBlurb(a, blurb);
      });

      plate.appendChild(art);
      cover.append(hit, spine, pages, title, plate, blurb, count);
      hit.addEventListener("click", () => openAlbum(a.sessionId));

      // Wrapper, because a delete control can't legally nest inside a button.
      const slot = document.createElement("div");
      slot.className = "book-slot";
      const del = document.createElement("button");
      del.className = "book-del";
      del.type = "button";
      del.textContent = "✕";
      del.title = "Delete this album";
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        const name = a.title || `Session ${a.sessionId.slice(0, 8)}`;
        const ok = await askConfirm({
          title: `Delete “${name}”?`,
          body: a.count === 1
            ? "This removes the album and its one photo."
            : `This removes the album and all ${a.count} photos in it.`,
          warn: "This can't be undone. Save the album to a file first if you want to keep it.",
          yes: "Delete album",
        });
        if (!ok) return;
        const store = tx("images", "readwrite");
        for (const rec of images.filter((r) => r.sessionId === a.sessionId)) {
          await req(store.delete(rec.id));
        }
        // The session record holds the title, theme and cast — clear it too.
        await req(tx("sessions", "readwrite").delete(a.sessionId)).catch(() => {});
        renderShelf();
      });
      const pick = document.createElement("button");
      pick.className = "book-cover-btn";
      pick.type = "button";
      pick.textContent = "🖼";
      pick.title = "Choose this album's cover image";
      pick.setAttribute("aria-label", `Choose a cover image for ${a.title || "this album"}`);
      pick.addEventListener("click", (e) => {
        e.stopPropagation();
        chooseCover(a);
      });

      slot.append(cover, pick, del);
      row.appendChild(slot);
    }
  }

  /** An in-page replacement for confirm().
   *
   *  Two reasons it isn't the native one: Chrome blocks alert/confirm/prompt
   *  inside cross-origin frames, and the album opens as an extension frame
   *  over the chat — so in the overlay the native call returns false without
   *  ever asking, and the delete silently did nothing. This also lets a
   *  destructive answer look destructive.
   *
   *  Cancel takes focus, so a stray Enter keeps the photos. */
  function askConfirm({ title, body, warn, yes = "Delete", no = "Keep it", alt = null, danger = true }) {
    return new Promise((resolve) => {
      const wrap = $("confirm");
      const yesBtn = $("confirm-yes");
      const noBtn = $("confirm-no");
      const altBtn = $("confirm-alt");
      altBtn.hidden = !alt;
      if (alt) altBtn.textContent = alt;
      $("confirm-title").textContent = title;
      $("confirm-body").textContent = body || "";
      $("confirm-body").hidden = !body;
      $("confirm-warn").textContent = warn || "";
      $("confirm-warn").hidden = !warn;
      yesBtn.textContent = yes;
      noBtn.textContent = no;
      yesBtn.classList.toggle("danger", danger);

      const finish = (answer) => {
        wrap.hidden = true;
        yesBtn.onclick = noBtn.onclick = altBtn.onclick = wrap.onclick = null;
        document.removeEventListener("keydown", onKey, true);
        resolve(answer);
      };
      const onKey = (e) => {
        if (e.key === "Escape") { e.stopPropagation(); finish(false); }
      };

      yesBtn.onclick = () => finish(true);
      altBtn.onclick = () => finish("alt");
      noBtn.onclick = () => finish(false);
      wrap.onclick = (e) => { if (e.target === wrap) finish(false); };
      document.addEventListener("keydown", onKey, true);

      wrap.hidden = false;
      noBtn.focus();
    });
  }

  /** Any image the user likes, not only a photo already in the album. Stored
   *  as a blob on the session record so it survives backup and restore like
   *  everything else. Downscaled on the way in: a cover is shown at 200px, so
   *  a 12MP phone photo would be dead weight in every backup from then on. */
  async function chooseCover(a) {
    const has = Boolean(a.coverBlob);
    const answer = await askConfirm({
      title: `Cover for “${a.title || "this album"}”`,
      body: has
        ? "Pick a different image, or go back to using a photo from the album."
        : "Pick any image from your computer. It replaces the photo currently shown on this book.",
      yes: "Choose an image…",
      no: "Cancel",
      alt: has ? "Use an album photo" : null,
      danger: false,
    });
    if (answer === "alt") {
      const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
      await req(tx("sessions", "readwrite")
        .put({ ...(prev || {}), sessionId: a.sessionId, coverBlob: null }));
      renderShelf();
      return;
    }
    if (answer !== true) return;

    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const blob = await shrinkForCover(file);
        const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, coverBlob: blob }));
        renderShelf();
      } catch (err) {
        console.warn("[Photobook] cover failed:", err);
      }
    };
    input.click();
  }

  /** Covers are displayed at 200px wide in a 4:3 window. 900px on the long
   *  edge is generous for a retina screen and keeps the file small. */
  async function shrinkForCover(file) {
    const bmp = await createImageBitmap(file);
    const cap = 900;
    const scale = Math.min(1, cap / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
    bmp.close?.();
    const out = await new Promise((r) => canvas.toBlob(r, "image/jpeg", 0.88));
    return out && out.size < file.size ? out : file;
  }

  /** Kept short on purpose: it has to read at cover size, and a paragraph
   *  would swallow the art it sits under. */
  const BLURB_MAX = 200;

  function editBlurb(a, btn) {
    const box = document.createElement("textarea");
    box.className = "cover-blurb-edit";
    box.value = a.blurb || "";
    box.maxLength = BLURB_MAX;
    box.rows = 3;
    box.placeholder = "A line to tell this album apart…";

    let done = false;
    const save = async () => {
      if (done) return;
      done = true;
      const text = box.value.trim().slice(0, BLURB_MAX);
      if (text !== (a.blurb || "")) {
        const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, blurb: text }));
        a.blurb = text;
      }
      box.replaceWith(btn);
      btn.textContent = a.blurb || "Add a note…";
      btn.classList.toggle("empty", !a.blurb);
    };

    box.addEventListener("keydown", (e) => {
      e.stopPropagation();               // arrow keys page the book otherwise
      if (e.key === "Escape") { done = true; box.replaceWith(btn); }
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); save(); }
    });
    box.addEventListener("click", (e) => e.stopPropagation());
    box.addEventListener("blur", save);

    btn.replaceWith(box);
    box.focus();
    box.select();
  }

  // ---------- album ----------

  async function openAlbum(sessionId) {
    const switchingAlbum = !album || album.sessionId !== sessionId;
    if (switchingAlbum) favoritesOnly = false;
    const [photos, sessionRec, unfiled] = await Promise.all([
      req(tx("images").index("bySession").getAll(IDBKeyRange.only(sessionId))),
      req(tx("sessions").get(sessionId)),
      req(tx("images").index("bySession").getAll(IDBKeyRange.only("unfiled"))),
    ]);
    photos.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

    album = {
      sessionId,
      photos,
      unfiled,
      sheet: sessionRec?.sheet || null,
      lastReply: sessionRec?.lastReply || "",
      titleBlob: sessionRec?.titleBlob || null,
      endNote: sessionRec?.endNote || "",
      theme: normTheme(sessionRec?.theme),
      pageArt: sessionRec?.pageArt || null,
      coverId: sessionRec?.coverId || null,
      backdropId: sessionRec?.backdropId || null,
      font: sessionRec?.font || "default",
      frame: sessionRec?.frame || "corners",
      title: sessionRec?.customTitle || sessionRec?.album?.title
        || sessionRec?.sheet?.album?.title || `Session ${sessionId.slice(0, 8)}`,
    };

    applyTheme(album.theme);
    ensurePageArt(album).catch(() => {});
    applyFont(album.font);
    updateBackdropMode?.();
    $("shelf").hidden = true;
    $("reader").hidden = false;
    requestAnimationFrame(fitBook);   // measure once the reader is laid out

    const { [`djpbBookmark:${sessionId}`]: saved } =
      await chrome.storage.local.get({ [`djpbBookmark:${sessionId}`]: 0 });
    pageIndex = Math.min(saved || 0, pageCount() - 1);

    renderPage($("page-live"), pageIndex);
    updateChrome();
  }

  const visiblePhotos = () => favoritesOnly
    ? album.photos.filter((rec) => rec.favorite === true)
    : album.photos;
  const pageCount = () => visiblePhotos().length + 2; // endpaper + photos + pocket

  function updateChrome() {
    const photos = visiblePhotos();
    const n = pageCount();
    $("page-count").textContent =
      pageIndex === 0 ? (favoritesOnly ? `♥ FAVORITES · ${photos.length}` : album.title.toUpperCase())
      : pageIndex === n - 1 ? (favoritesOnly ? "END OF FAVORITES" : "BACK POCKET")
      : `${pageIndex} / ${photos.length}${favoritesOnly ? " ♥" : ""}`;
    // The ribbon IS the favourites tab now — a bookmark you can actually
    // pull on, rather than a button competing with it for the same idea.
    const favCount = album.photos.filter((r) => r.favorite).length;
    const ribbon = $("ribbon");
    ribbon.classList.toggle("active", favoritesOnly);
    ribbon.dataset.count = favCount || "";
    ribbon.title = favoritesOnly
      ? "Back to the whole album"
      : favCount ? `${favCount} favourite${favCount === 1 ? "" : "s"}` : "Heart a photo to start a favourites page";

    // Fore-edge thins as you read through the book.
    const remaining = Math.max(0, n - 1 - pageIndex);
    $("fore-edge").style.width = `${Math.min(12, 3 + remaining * 1.6)}px`;

    $("ribbon").hidden = false;   // always reachable: it is the tab, not a marker
    $("edge-prev").disabled = pageIndex === 0;
    $("edge-next").disabled = pageIndex === n - 1;
    chrome.storage.local.set({ [`djpbBookmark:${album.sessionId}`]: pageIndex });
  }

  // ---------- pages ----------

  function renderPage(host, index) {
    host.innerHTML = "";
    const inner = document.createElement("div");
    inner.className = "page-inner";

    if (index === 0) renderEndpaper(inner);
    else if (index === pageCount() - 1) renderPocket(inner);
    else renderPhotoPage(inner, visiblePhotos()[index - 1]);

    host.appendChild(inner);
  }

  function renderEndpaper(inner) {
    inner.classList.add("endpaper");
    if (favoritesOnly) inner.classList.add("favorites-endpaper");
    const h = document.createElement("h2");
    h.textContent = favoritesOnly ? "Favorite memories" : album.title;
    h.title = favoritesOnly ? "Heart a photo to keep it here" : "Click to rename this album";
    if (!favoritesOnly) h.addEventListener("click", () => {
      const input = document.createElement("input");
      input.className = "rename";
      input.value = album.title;
      input.maxLength = 60;
      const save = async () => {
        const name = input.value.trim();
        if (name && name !== album.title) {
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, customTitle: name }));
          album.title = name;
        }
        input.replaceWith(h);
        h.textContent = album.title;
        updateChrome();
      };
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") save();
        if (e.key === "Escape") input.replaceWith(h);
        e.stopPropagation();
      });
      input.addEventListener("blur", save);
      h.replaceWith(input);
      input.focus();
      input.select();
    });
    inner.appendChild(h);

    // A tooled rule under the title, the way a title page carries one.
    const rule = document.createElement("div");
    rule.className = "endpaper-rule";
    rule.setAttribute("aria-hidden", "true");
    rule.innerHTML = "<span></span><i>\u2766</i><span></span>";
    inner.appendChild(rule);

    if (favoritesOnly) {
      const favs = visiblePhotos();
      const msg = document.createElement("p");
      msg.className = "favorites-intro";
      msg.textContent = favs.length
        ? `${favs.length} hearted photo${favs.length === 1 ? "" : "s"}. Flip forward to revisit them.`
        : "No favorites yet. Heart any photo in the album and it will appear here.";
      inner.appendChild(msg);
      return;
    }

    const cast = document.createElement("div");
    cast.className = "cast";
    const characters = Object.values(album.sheet?.characters || {});
    for (const c of characters.slice(0, 2)) {
      if (!c.portrait) continue;
      const fig = document.createElement("figure");
      const mount = castPortrait(c.portrait, c.name, -1.2 + Math.random() * 2.4);
      const cap = document.createElement("figcaption");
      cap.textContent = c.name;
      fig.append(mount, cap);
      cast.appendChild(fig);
    }
    if (!cast.children.length) {
      const note = document.createElement("p");
      note.style.cssText = "color:#4b3a5e;font-style:italic;text-align:center";
      note.textContent = "Send a message in this chat and the cast appears here on its own.";
      cast.appendChild(note);
    }
    if (cast.children.length) {
      const label = document.createElement("p");
      label.className = "cast-label";
      label.textContent = characters.length > 1 ? "the cast" : "our cast";
      inner.appendChild(label);
    }
    inner.appendChild(cast);

    // A line of provenance between the cast and the plate: it fills the
    // gap the larger portraits left, and tells you what you are holding.
    if (album.photos.length) {
      const dates = album.photos.map((r) => r.createdAt || 0).filter(Boolean);
      const first = new Date(Math.min(...dates));
      const meta = document.createElement("p");
      meta.className = "endpaper-meta";
      const n = album.photos.length;
      meta.textContent = `${n} photograph${n === 1 ? "" : "s"} · begun ` +
        first.toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
      inner.appendChild(meta);
    }

    // Title image below the cast — yours to choose — plus a small inscription.
    const slot = document.createElement("div");
    slot.className = "title-slot";
    const pick = document.createElement("input");
    pick.type = "file";
    pick.accept = "image/*";
    pick.hidden = true;
    pick.addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const prev = await req(tx("sessions").get(album.sessionId));
      await req(tx("sessions", "readwrite")
        .put({ ...(prev || {}), sessionId: album.sessionId, titleBlob: file }));
      album.titleBlob = file;
      renderPage($("page-live"), 0);
    });
    if (album.titleBlob) {
      const url = URL.createObjectURL(album.titleBlob);
      extraUrls.push(url);
      const mount = mountPhoto(url, "Title image", 0.8, album.frame, "");
      mount.classList.add("title-mount");
      mount.title = "Click to change the title image";
      mount.querySelector("img.photo").style.cursor = "pointer";
      mount.querySelector("img.photo").addEventListener("click", () => pick.click());
      slot.appendChild(mount);
    } else {
      const add = document.createElement("button");
      add.type = "button";
      add.className = "title-add";
      add.textContent = "Add a title image";
      add.addEventListener("click", () => pick.click());
      slot.appendChild(add);
    }
    slot.appendChild(pick);

    const inscription = document.createElement("textarea");
    inscription.className = "inscription";
    inscription.rows = 2;
    inscription.placeholder = "Write something on the first page…";
    inscription.value = album.endNote || "";
    let t = null;
    inscription.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(async () => {
        album.endNote = inscription.value.trim();
        const prev = await req(tx("sessions").get(album.sessionId));
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: album.sessionId, endNote: album.endNote }));
      }, 500);
    });
    inscription.addEventListener("keydown", (e) => e.stopPropagation());
    slot.appendChild(inscription);
    inner.appendChild(slot);
  }

  function renderPhotoPage(inner, rec) {
    const url = photoUrl(rec);

    // Deterministic tilt per photo: mounted by hand, but never shifting.
    const tilt = ((rec.id * 137) % 30) / 10 - 1.5;

    const chinFor = (frame) => {
      if (frame === "instant") {
        return new Date(rec.createdAt || Date.now())
          .toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
      }
      if (frame === "film") {
        const n = (visiblePhotos().indexOf(rec) + 1) || 1;
        return `\u2116 ${String(n).padStart(2, "0")}`;
      }
      return "";
    };

    const effFrame = () => rec.frame || album.frame || "corners";
    const mount = mountPhoto(url, rec.caption || "", tilt, effFrame(), chinFor(effFrame()));
    const heart = document.createElement("button");
    heart.type = "button";
    heart.className = "favorite-heart" + (rec.favorite ? " active" : "");
    heart.textContent = rec.favorite ? "♥" : "♡";
    heart.title = rec.favorite ? "Remove from favorites" : "Add to favorites";
    heart.setAttribute("aria-label", heart.title);
    heart.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      rec.favorite = !rec.favorite;
      await req(tx("images", "readwrite").put(rec));
      heart.classList.toggle("active", rec.favorite);
      heart.textContent = rec.favorite ? "♥" : "♡";
      heart.title = rec.favorite ? "Remove from favorites" : "Add to favorites";
      heart.setAttribute("aria-label", heart.title);
      updateChrome();
      if (favoritesOnly && !rec.favorite) {
        pageIndex = Math.min(pageIndex, pageCount() - 1);
        renderPage($("page-live"), pageIndex);
        updateChrome();
      }
    });
    mount.querySelector(".print").appendChild(heart);
    mount.querySelector("img.photo").addEventListener("click", () => {
      $("lightbox-img").src = url;
      $("lightbox").hidden = false;
    });
    inner.appendChild(mount);

    const stamp = document.createElement("span");
    stamp.className = "datestamp";
    stamp.textContent = new Date(rec.createdAt || Date.now())
      .toLocaleDateString(undefined, { year: "numeric", month: "short", day: "2-digit" })
      .toUpperCase();
    inner.appendChild(stamp);

    // The note beneath: the reply that made this moment, or your own words.
    const note = document.createElement("div");
    note.className = "note";
    const ta = document.createElement("textarea");
    ta.placeholder = "Write something under this photo…";
    ta.value = rec.caption || "";

    const tools = document.createElement("div");
    tools.className = "note-tools";
    const paste = document.createElement("button");
    paste.type = "button";
    paste.textContent = "Paste latest reply";
    paste.title = "Fill the note with the newest reply from this chat";

    const cover = document.createElement("button");
    cover.type = "button";
    // Show at a glance which photo is currently the cover.
    cover.textContent = album.coverId === rec.id ? "✓ cover" : "Make cover";
    cover.title = "Show this photo on the album's cover";
    cover.addEventListener("click", async () => {
      const prev = await req(tx("sessions").get(album.sessionId));
      const already = prev?.coverId === rec.id;
      await req(tx("sessions", "readwrite").put({
        ...(prev || {}),
        sessionId: album.sessionId,
        coverId: already ? null : rec.id,     // tapping again clears it
      }));
      album.coverId = already ? null : rec.id;
      cover.textContent = already ? "Make cover" : "✓ cover";
      setTimeout(() => (cover.textContent = album.coverId === rec.id ? "✓ cover" : "Make cover"), 1800);
    });

    // Pin this photo behind the chat instead of letting the newest snap win.
    const backdrop = document.createElement("button");
    backdrop.type = "button";
    const pinLabel = () =>
      album.backdropId === rec.id ? "✓ Backdrop — tap to unpin" : "Set as backdrop";
    backdrop.textContent = pinLabel();
    backdrop.title = "Show this photo behind the chat on Dreamjourney";
    backdrop.addEventListener("click", async () => {
      const already = album.backdropId === rec.id;
      album.backdropId = already ? null : rec.id;
      // req() is for IndexedDB requests; a runtime message is already a promise.
      await chrome.runtime.sendMessage({
        type: "db", op: "setBackdrop",
        args: { sessionId: album.sessionId, id: album.backdropId },
      });
      backdrop.textContent = pinLabel();
      updateBackdropMode?.();
    });

    // The frame dial. rec.frame null means "wear the album's frame".
    const frameBtn = document.createElement("button");
    frameBtn.type = "button";
    frameBtn.className = "frame-dial";
    const frameText = () => rec.frame
      ? `\u274f ${frameLabel(rec.frame)}`
      : `\u274f Album frame`;
    frameBtn.textContent = frameText();
    frameBtn.title = "Change how this photo is mounted";
    frameBtn.addEventListener("click", async () => {
      const order = [null, ...FRAMES.map(([id]) => id)];
      const next = order[(order.indexOf(rec.frame || null) + 1) % order.length];
      rec.frame = next;
      if (next === null) delete rec.frame;
      await req(tx("images", "readwrite").put(rec));
      // Redress the mount where it stands.
      const f = effFrame();
      mount.dataset.frame = f;
      mount.querySelector(".chin").textContent = chinFor(f);
      mount.classList.remove("redress");
      void mount.offsetWidth;                 // restart the settle animation
      mount.classList.add("redress");
      frameBtn.textContent = frameText();
    });

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "danger";
    remove.textContent = "Take out";
    remove.title = "Remove this photo from the album (deletes it)";
    remove.addEventListener("click", async () => {
      if (!await askConfirm({ title: "Take this photo out?", body: "It leaves the album and is deleted.", warn: "This can't be undone.", yes: "Delete photo", })) return;
      await req(tx("images", "readwrite").delete(rec.id));
      const url = urlCache.get(rec.id);
      if (url) { URL.revokeObjectURL(url); urlCache.delete(rec.id); }
      // Keep the reader open at the same spot (clamped if this was the last page).
      await chrome.storage.local.set({ [`djpbBookmark:${album.sessionId}`]: Math.max(0, pageIndex - 1) });
      openAlbum(album.sessionId);
    });

    const savedTag = document.createElement("span");
    savedTag.className = "saved";

    paste.addEventListener("click", async () => {
      // Ask the chat page for the reply as it stands RIGHT NOW. The stored
      // copy comes from the outgoing request, which is written before the
      // reply it describes exists — so it's permanently one message behind.
      savedTag.textContent = "fetching\u2026";
      const live = await requestHostLatest();
      savedTag.textContent = "";
      const text = live || album.lastReply || "";
      if (!text) {
        savedTag.textContent = "no reply available yet";
        return;
      }
      // The note is the visible prose, not the machinery around it.
      ta.value = text
        .replace(/```?\s*<thinking>[\s\S]*?<\/thinking>\s*```?/gi, "")
        .replace(/^\s*Thinking Process\s*(Show|Hide)?\s*$/gim, "")
        .trim();
      saveNote();
    });

    let saveTimer = null;
    const saveNote = () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(async () => {
        rec.caption = ta.value.trim();
        await req(tx("images", "readwrite").put(rec));
        savedTag.textContent = "saved ✎";
        setTimeout(() => (savedTag.textContent = ""), 1800);
      }, 500);
    };
    ta.addEventListener("input", saveNote);

    // "Use as ref" lived here; references are set from the Snap card's
    // chip row instead, which is where the picking happens anyway.
    tools.append(backdrop, cover, frameBtn, paste, remove, savedTag);
    note.append(ta, tools);
    inner.appendChild(note);
  }

  function renderPocket(inner) {
    if (favoritesOnly) {
      inner.classList.add("pocket", "favorites-pocket");
      const h = document.createElement("h2");
      h.textContent = "End of favorites";
      const p = document.createElement("p");
      p.className = "favorites-intro";
      p.textContent = "Switch back to All photos to keep flipping through the full album.";
      inner.append(h, p);
      return;
    }
    inner.classList.add("pocket");
    const h = document.createElement("h2");
    h.textContent = "Loose photos";
    inner.appendChild(h);

    const sleeve = document.createElement("div");
    sleeve.className = "sleeve";
    album.unfiled.forEach((rec, i) => {
      const b = document.createElement("div");
      b.className = "loose";
      b.style.setProperty("--tilt", `${(i % 3) - 1}deg`);

      const img = document.createElement("img");
      img.src = photoUrl(rec);
      img.alt = "";
      img.title = "Add to this album";
      img.addEventListener("click", async () => {
        rec.sessionId = album.sessionId;
        await req(tx("images", "readwrite").put(rec));
        openAlbum(album.sessionId); // re-read; the photo now has a page
      });

      const x = document.createElement("button");
      x.type = "button";
      x.className = "loose-x";
      x.textContent = "✕";
      x.title = "Throw this loose photo away";
      x.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!await askConfirm({ title: "Throw this photo away?", body: "It is deleted from the back pocket.", warn: "This can't be undone.", yes: "Delete photo", })) return;
        await req(tx("images", "readwrite").delete(rec.id));
        const url = urlCache.get(rec.id);
        if (url) { URL.revokeObjectURL(url); urlCache.delete(rec.id); }
        openAlbum(album.sessionId);
      });

      b.append(img, x);
      sleeve.appendChild(b);
    });
    inner.appendChild(sleeve);
  }

  // ======================= painted pages =======================
  // Watercolor and Roses pages are PAINTED, not styled: the two canvas pens
  // the user supplied run once, invisibly, to completion, and the finished
  // still is cached on the album and mounted as the page background. Every
  // album gets its own one-off painting (the pens are random by nature);
  // after that first render the page never changes and nothing ever moves.

  /** The WaterColor engine (verbatim geometry: wiggled sine/cosine walk,
   *  midpoint subdivision to 3000 points, multi-pass hard-light fills at
   *  decaying alpha). The original painted across animation frames; here the
   *  passes run synchronously so only the finished wash is ever seen. */
  function paintWatercolor(W, H, end) {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fdfcf7";
    ctx.fillRect(0, 0, W, H);

    const twoPI = 2 * Math.PI;
    const randomWiggle = (w) => (Math.random() * w) * (Math.random() < 0.5 ? -1 : 1);
    let hue = -25;
    const randomColor = () => {
      hue = Math.floor((hue % 360) + 25 + 15 * Math.random());
      return `hsl(${hue}, 50%, 55%)`;
    };

    function Blob(o) {
      Object.assign(this, { speed: 0.3, maxPoints: 3000, maxRender: 5, scale: false }, o);
      if (!this.fill) this.fill = randomColor();
      for (let c = 1; c <= this.maxRender; c++) this.draw(c);
    }
    Blob.prototype = {
      buildPoints() {
        const wiggle = this.size * 0.15;
        let rotation = 0, x = -this.size, y = 0;
        const horizontal = Math.random() > 0.5, start = [x, y];
        this.points = [start];
        for (; rotation < twoPI; rotation += this.speed) {
          x += this.size * this.speed * Math.sin(rotation) * (horizontal ? 1 : 0.7) + randomWiggle(wiggle);
          y += this.size * this.speed * Math.cos(rotation) * (horizontal ? 0.7 : 1) + randomWiggle(wiggle);
          this.points.push([x, y]);
        }
        this.points.push(start);
        this.originalPoints = this.points;
        return this.points;
      },
      expandPoints() {
        if (!this.points) return this.buildPoints();
        if (this.points.length > this.maxPoints) return false;
        const wiggle = this.size * 0.05;
        const p = [];
        for (let i = 0, len = this.points.length - 1; i < len; i++) {
          const [x, y] = this.points[i];
          const [x2, y2] = this.points[i + 1];
          p.push([x, y],
            [((x2 + x) / 2) + randomWiggle(wiggle), ((y2 + y) / 2) + randomWiggle(wiggle)],
            [x2, y2]);
        }
        this.points = p;
        return true;
      },
      draw(c) {
        while (this.expandPoints()) { /* subdivide to full softness */ }
        const itr = c / this.maxRender;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.globalCompositeOperation = "hard-light";
        ctx.globalAlpha = 0.17 - (itr * 0.07);   // diluted: see ART_VERSION
        ctx.translate(this.x, this.y);
        if (this.scale) ctx.scale(1 + itr * 0.2, 1 + itr * 0.2);
        ctx.beginPath();
        ctx.moveTo(this.points[0][0], this.points[0][1]);
        for (let i = 0, len = this.points.length; i < len; i++) {
          ctx.lineTo(this.points[i][0], this.points[i][1]);
        }
        ctx.closePath();
        ctx.fillStyle = this.fill;
        ctx.fill();
        this.points = this.originalPoints;
      },
    };

    // Two compositions from the same engine. The interior page is the pen's
    // opening move: ten huge washes ringing the perimeter, colour bleeding
    // across the whole sheet. The ENDPAPER is a title-page wash: the same
    // ring, but small blooms that stain only the borders and leave the
    // centre cream for the cast portraits.
    const hw = W / 2, hh = H / 2;
    const count = end ? 14 : 10;
    for (let i = 0, len = count; i < len; i++) {
      new Blob({
        size: end ? W * (0.26 + Math.random() * 0.08) : W * (0.7 + Math.random() * 0.1),
        x: hw + (Math.cos((i / len) * twoPI) * hw),
        y: hh + (Math.sin((i / len) * twoPI) * hh),
      });
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    return cv.toDataURL("image/jpeg", 0.85);
  }

  /** The flowers pen, near-verbatim: arc-petal roses in three colours, ring
   *  opacity climbing toward the heart, scattered on a lazy sine drift. Only
   *  window.innerWidth/Height became the page's own size. */
  function paintRoses(W, H, end) {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fffaf6";
    ctx.fillRect(0, 0, W, H);

    const flowers = [
      { color: "#fd97ad", radius: 80, variable: 600, amount: 12 },
      { color: "#e165a8", radius: 60, variable: 720, amount: 18 },
      { color: "#efc2ab", radius: 40, variable: 800, amount: 9 },
    ];
    const getRandomNum = (v) => Math.round((Math.random() * v) - (Math.random() * v));
    const radians = (deg) => (deg * Math.PI) / 180;
    const findPointOnCircle = (ox, oy, r, deg) => {
      const a = radians(deg);
      return { x: r * Math.cos(a) + ox, y: r * Math.sin(a) + oy };
    };
    function arcPetal(x0, y0, radius, startAngle, endAngle, petalWidth) {
      const s = findPointOnCircle(x0, y0, radius, startAngle);
      const e = findPointOnCircle(x0, y0, radius, endAngle);
      const cp1 = findPointOnCircle(x0, y0, radius, startAngle + 35);
      const cp2 = findPointOnCircle(x0, y0, radius, endAngle - 35);
      const cb1 = findPointOnCircle(x0, y0, radius * petalWidth, startAngle + 50);
      const cb2 = findPointOnCircle(x0, y0, radius * petalWidth, endAngle - 50);
      ctx.moveTo(s.x, s.y);
      ctx.bezierCurveTo(cp1.x, cp1.y, cp2.x, cp2.y, e.x, e.y);
      ctx.bezierCurveTo(cb2.x, cb2.y, cb1.x, cb1.y, s.x, s.y);
    }
    function watercolorFlower(startx, starty, radius0, color) {
      const thickness = 1.4, amt = 30, ringamt = 4.5;
      const angleincrement = 360 / ringamt;
      let opacity = 10, radius = radius0;
      const radiusincrement = radius / amt;
      ctx.fillStyle = color;
      for (let i = 0; i < amt; i++) {
        const startAngle = i * angleincrement;
        const midAngle = startAngle + 90;
        const endAngle = startAngle + 180;
        ctx.beginPath();
        const origin = findPointOnCircle(startx, starty, radius, midAngle);
        arcPetal(origin.x, origin.y, radius, startAngle, endAngle, thickness);
        ctx.filter = `opacity(${opacity}%)`;
        ctx.fill();
        ctx.closePath();
        radius -= radiusincrement;
        opacity += 5;
      }
      opacity = 20;
      const decrement = radius0 / 4;
      let layerradius = radius0;
      for (let l = 0; l < 4; l++) {
        ctx.beginPath();
        ctx.arc(startx, starty, layerradius, 0, Math.PI * 2);
        ctx.filter = `opacity(${opacity}%)`;
        ctx.fill();
        ctx.closePath();
        opacity += 10;
        layerradius -= decrement;
      }
    }
    function randomFlowers(variableamt, amount, color, radius) {
      const xdist = (W * 1.1) / amount;
      const ydist = (H * 2.5) / amount;
      for (let y = 0; y < amount; y++) {
        const inc = Math.sin(y / amount);
        const curY = (inc * y) * ydist;
        const curX = (inc * y) * xdist;
        watercolorFlower(
          curX + getRandomNum(variableamt),
          curY + getRandomNum(variableamt),
          radius + getRandomNum(20),
          color
        );
      }
    }
    if (end) {
      // ONE bloom, drawn by the flower pen itself at feature size, sitting in
      // the lower-right corner so the page edge crops it. Nothing else — the
      // rest is clean paper for the title and the cast. (The previous garland
      // was a ring of small blooms composed here rather than by the pen, and
      // it read as scattered blobs.)
      ctx.globalAlpha = 0.8;
      watercolorFlower(W * 0.9, H * 0.94, W * 0.38, "#fd97ad");
      ctx.globalAlpha = 1;
    } else {
      for (const f of flowers) randomFlowers(f.variable, f.amount, f.color, f.radius);
    }
    ctx.filter = "none";
    return cv.toDataURL("image/jpeg", 0.85);
  }

  const PAINTED_THEMES = { watercolor: paintWatercolor, roses: paintRoses };
  // Bump when the painters change so cached paintings are redone; without it
  // albums painted by an older version keep their heavier pigment forever.
  const ART_VERSION = 3;

  /** Paint once per album (or reuse the cache), and dress the page elements.
   *  For every unpainted binding this clears any inline art so the theme's
   *  own CSS shows through. */
  async function ensurePageArt(a) {
    const painter = PAINTED_THEMES[a?.theme];
    if (!painter) {
      document.body.style.removeProperty("--djpb-page-art");
      document.body.style.removeProperty("--djpb-end-art");
      return;
    }
    let art = a.pageArt;
    if (!art?.dataUrl || !art.endUrl || art.theme !== a.theme || art.v !== ART_VERSION) {
      // 900×1260 outpaints the page at any album size; `cover` does the
      // rest. The endpaper gets its own composition from the same pen.
      art = {
        theme: a.theme,
        v: ART_VERSION,
        dataUrl: painter(900, 1260),
        endUrl: painter(900, 1260, true),
      };
      a.pageArt = art;
      try {
        const prev = await req(tx("sessions").get(a.sessionId));
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, pageArt: art }));
      } catch { /* uncached: repainted (differently) next open */ }
    }
    if (album !== a) return;   // switched away while painting
    document.body.style.setProperty("--djpb-page-art", `url("${art.dataUrl}")`);
    document.body.style.setProperty("--djpb-end-art", `url("${art.endUrl}")`);
  }

  /** The cast plate: a FIXED treatment, deliberately independent of the
   *  frame dial — the dramatis personae page stays composed whatever the
   *  loose photos are wearing. Each binding dresses `.castframe` its own way
   *  (pockets, keylines, ticks, neon) purely in CSS.
   *
   *  The frame is a square that CROPS the portrait rather than letterboxing
   *  it. That is the fix for the old drift: with object-fit:contain the img
   *  element stayed wide while the visible picture shrank inside it, so
   *  corners anchored to empty box instead of to the photograph. Cover means
   *  element box and visible picture are the same rectangle, so corners
   *  always grip the picture — and both cast members match in size. */
  function castPortrait(src, alt, tilt) {
    const mount = document.createElement("div");
    mount.className = "castmount";
    mount.style.setProperty("--tilt", `${tilt.toFixed(1)}deg`);

    const frame = document.createElement("div");
    frame.className = "castframe";

    const img = document.createElement("img");
    img.className = "castphoto";
    img.src = src;
    img.alt = alt;
    img.loading = "lazy";
    // The plate crops to a square, so clicking opens the full portrait —
    // the zoom-in cursor was previously decorative here.
    img.addEventListener("click", () => {
      $("lightbox-img").src = src;
      $("lightbox").hidden = false;
    });
    frame.appendChild(img);

    // Four corner elements every binding restyles; keyline-only themes
    // simply hide them and draw on .castframe instead.
    for (const pos of ["tl", "tr", "bl", "br"]) {
      const c = document.createElement("span");
      c.className = `castcorner ${pos}`;
      frame.appendChild(c);
    }
    mount.appendChild(frame);
    return mount;
  }

  function mountPhoto(src, alt, tilt, frame, chinText) {
    const mount = document.createElement("div");
    mount.className = "mount";
    mount.dataset.frame = frame || "corners";
    mount.style.setProperty("--tilt", `${tilt.toFixed(1)}deg`);

    // The print shrink-wraps the photograph; frames, corners and chin all
    // anchor HERE, so they sit on the photo whatever its shape.
    const print = document.createElement("div");
    print.className = "print";

    const img = document.createElement("img");
    img.className = "photo";
    img.src = src;
    img.alt = alt;
    print.appendChild(img);

    // Kraft corners are elements the other frames simply hide.
    for (const pos of ["tl", "tr", "bl", "br"]) {
      const c = document.createElement("span");
      c.className = `corner ${pos}`;
      print.appendChild(c);
    }
    // The chin: instant film's writing strip, the filmstrip's frame number.
    const chin = document.createElement("span");
    chin.className = "chin";
    chin.textContent = chinText || "";
    print.appendChild(chin);

    mount.appendChild(print);
    return mount;
  }

  // ---------- turning ----------

  function turn(delta) {
    if (!album || turning) return;
    const next = pageIndex + delta;
    if (next < 0 || next >= pageCount()) return;
    turning = true;

    const live = $("page-live");
    const under = $("page-under");

    if (delta > 0) {
      renderPage(under, next);                 // next page waits beneath
      live.classList.add("turn-fwd");          // current bends away
      live.addEventListener("animationend", () => {
        live.classList.remove("turn-fwd");
        pageIndex = next;
        renderPage(live, pageIndex);           // live becomes the new page
        under.innerHTML = "";
        turning = false;
        updateChrome();
      }, { once: true });
    } else {
      renderPage(under, pageIndex);            // current page waits beneath
      pageIndex = next;
      renderPage(live, pageIndex);             // previous page…
      live.classList.add("turn-back");         // …turns back into place
      live.addEventListener("animationend", () => {
        live.classList.remove("turn-back");
        under.innerHTML = "";
        turning = false;
        updateChrome();
      }, { once: true });
    }
  }

  // ---------- wiring ----------

  // Page turns use the blank outer margins of the live page instead of
  // transparent overlay buttons. That keeps controls inside the page (heart,
  // photo, caption, tools) clickable even when they sit near an edge.
  $("page-live").addEventListener("click", (e) => {
    if (turning || !album) return;
    if (e.target.closest("button, a, input, textarea, select, img, [contenteditable='true']")) return;
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width) return;
    const x = e.clientX - rect.left;
    if (x <= rect.width * 0.15) turn(-1);
    else if (x >= rect.width * 0.85) turn(1);
  });
  $("ribbon").addEventListener("click", () => {
    favoritesOnly = !favoritesOnly;
    pageIndex = 0;
    renderPage($("page-live"), pageIndex);
    updateChrome();
  });
  $("back-to-shelf").addEventListener("click", renderShelf);
  $("design-btn").addEventListener("click", () => {
    const pop = $("theme-pop");
    if (!pop.childElementCount) {
      const row = (label) => {
        const l = document.createElement("div");
        l.className = "pop-label";
        l.textContent = label;
        const r = document.createElement("div");
        r.className = "pop-row";
        pop.append(l, r);
        return r;
      };

      // On a phone the popover is a bottom sheet that covers the tools row —
      // including the button that opened it — so it needs its own way out.
      const head = document.createElement("div");
      head.className = "pop-head";
      const done = document.createElement("button");
      done.type = "button";
      done.className = "pop-done";
      done.textContent = "Done ✕";
      done.addEventListener("click", () => { pop.hidden = true; });
      head.appendChild(done);
      pop.appendChild(head);

      const bindings = row("Binding");
      for (const [id, label] of THEMES) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "swatch";
        b.dataset.theme = id; // the mini binds in its colors
        const mini = document.createElement("i");
        mini.className = "mini";
        const name = document.createElement("span");
        name.textContent = label;
        b.append(mini, name);
        b.addEventListener("click", async () => {
          album.theme = id;
          applyTheme(id);
          ensurePageArt(album).catch(() => {});
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, theme: id }));
          for (const s of bindings.querySelectorAll(".swatch")) {
            s.classList.toggle("active", s === b);
          }
        });
        bindings.appendChild(b);
      }

      const framesRow = row("Frames");
      for (const [id, label] of FRAMES) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "swatch fswatch";
        const mini = document.createElement("i");
        mini.className = "mini";
        mini.dataset.frame = id;   // the mini wears the material itself
        const name = document.createElement("span");
        name.textContent = label;
        b.append(mini, name);
        b.addEventListener("click", async () => {
          album.frame = id;
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, frame: id }));
          for (const s of framesRow.querySelectorAll(".swatch")) {
            s.classList.toggle("active", s === b);
          }
          renderPage($("page-live"), pageIndex);   // the open page redresses
        });
        framesRow.appendChild(b);
      }

      const fonts = row("Handwriting");
      for (const [id, label] of FONTS) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "fontchip";
        if (id !== "default") b.dataset.font = id; // the sample writes itself
        const aa = document.createElement("i");
        aa.className = "aa";
        aa.textContent = "Aa";
        const name = document.createElement("span");
        name.textContent = label;
        b.append(aa, name);
        b.addEventListener("click", async () => {
          album.font = id;
          applyFont(id);
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, font: id }));
          for (const s of fonts.querySelectorAll(".fontchip")) {
            s.classList.toggle("active", s === b);
          }
        });
        fonts.appendChild(b);
      }
    }
    for (const s of pop.querySelectorAll(".swatch:not(.fswatch)")) {
      s.classList.toggle("active",
        s.dataset.theme === normTheme(album?.theme));
    }
    for (const s of pop.querySelectorAll(".fswatch")) {
      s.classList.toggle("active",
        s.querySelector(".mini")?.dataset.frame === (album?.frame || "corners"));
    }
    for (const s of pop.querySelectorAll(".fontchip")) {
      s.classList.toggle("active",
        (s.dataset.font || "default") === (album?.font || "default"));
    }
    pop.hidden = !pop.hidden;
  });

  // ---------- backup & restore ----------
  // Extension storage is tied to the extension's identity. Updating in place
  // keeps it; loading from a NEW folder, or removing and re-adding, gives
  // Chrome a different id and the albums are simply not there any more. A
  // portable file is the only thing that survives that, so here is one.

  const blobToDataUrl = (blob) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error("read failed"));
    r.readAsDataURL(blob);
  });
  const dataUrlToBlob = async (u) => (await fetch(u)).blob();

  /** Where a finished file should go.
   *
   *  The share sheet exists because downloading on a phone is a dead end.
   *  On a desktop it's the opposite: Windows' sheet has no "save to disk"
   *  target, so handing it the file strands you with no way to reach
   *  Downloads. Save on desktop, offer the sheet on touch, and fall back to
   *  a download either way. Once it's on disk you can still share it from
   *  the file manager. */
  const prefersShareSheet = () =>
    window.matchMedia("(hover: none) and (pointer: coarse)").matches;

  async function deliverFile(blob, name, mime, title) {
    if (prefersShareSheet() && navigator.canShare) {
      try {
        const file = new File([blob], name, { type: mime });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title });
          return "shared";
        }
      } catch (err) {
        if (err?.name === "AbortError") return "cancelled";
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
    return "saved";
  }

  /** @param onlySession export just this album (undefined = everything)
   *  @param share    hand the file to the OS share sheet when available */
  async function backupAll(btn, onlySession, share, titleHint) {
    const original = btn.textContent;
    btn.textContent = "Gathering…";
    try {
      let [images, sessions] = await Promise.all([
        req(tx("images").getAll()),
        req(tx("sessions").getAll()),
      ]);
      if (onlySession) {
        images = images.filter((r) => r.sessionId === onlySession);
        sessions = sessions.filter((s) => s.sessionId === onlySession);
      }

      // The file is assembled as a list of string fragments handed straight
      // to Blob(), never as one JSON string. JSON.stringify() has to build
      // its whole result in memory, and V8 caps a single string at ~512MB —
      // so a large library used to die on "Backup failed" with no
      // explanation. Per-record stringify keeps every fragment ~1MB, and
      // each data URL is dropped as soon as it is written, which also halves
      // peak memory. Same bytes out, no ceiling.
      const parts = ['{"format":"dreamjourney-photobook-backup","version":2,"savedAt":'];
      parts.push(JSON.stringify(new Date().toISOString()));

      let imageCount = 0;
      parts.push(',"images":[');
      for (const r of images) {
        if (imageCount) parts.push(",");
        parts.push(JSON.stringify({
          sessionId: r.sessionId, caption: r.caption || "", prompt: r.prompt || "",
          source: r.source || "", favorite: r.favorite === true,
          // Only present when this photo overrides the album's frame; absent
          // means "wear whatever the album wears", which is the default.
          ...(r.frame ? { frame: r.frame } : {}),
          createdAt: r.createdAt || Date.now(), dataUrl: await blobToDataUrl(r.blob),
        }));
        imageCount += 1;
      }
      parts.push(']');

      parts.push(',"sessions":[');
      let n = 0;
      for (const s of sessions) {
        if (n++) parts.push(",");
        parts.push(JSON.stringify({
          ...s,
          titleBlob: s.titleBlob ? await blobToDataUrl(s.titleBlob) : null,
          referenceBlob: s.referenceBlob ? await blobToDataUrl(s.referenceBlob) : null,
        }));
      }
      parts.push(']}');

      const stamp = new Date().toISOString().slice(0, 10);
      const safe = (onlySession ? (titleHint || album?.title || "album") : "photobook")
        .replace(/[^\w -]+/g, "").trim() || "photobook";
      const name = onlySession ? `${safe}-album-${stamp}.json` : `photobook-backup-${stamp}.json`;
      const blob = new Blob(parts, { type: "application/json" });

      // On a phone, "download a file" is a dead end — the share sheet is how
      // it actually gets to another device or another person.
      const how = await deliverFile(blob, name, "application/json", safe);
      if (how === "cancelled") { btn.textContent = original; return; }
      btn.textContent = `${imageCount} photo${imageCount === 1 ? "" : "s"} ✓`;
    } catch (err) {
      console.warn("[Photobook] backup failed:", err);
      btn.textContent = "Backup failed";
    }
    setTimeout(() => (btn.textContent = original), 3000);
  }

  async function restoreFrom(file, btn) {
    const original = btn.textContent;
    btn.textContent = "Restoring…";
    try {
      const data = JSON.parse(await file.text());
      if (data?.format !== "dreamjourney-photobook-backup") {
        throw new Error("that isn't a photobook backup file");
      }

      // Restores ADD to what's here — an existing album is never wiped by one.
      const existing = await req(tx("images").getAll());
      const seen = new Set(existing.map((r) => `${r.sessionId}|${r.createdAt}`));

      // Every blob is decoded BEFORE its transaction opens. Awaiting inside
      // the add() argument let the event loop turn, and IndexedDB commits a
      // transaction the moment it goes idle — so the store had already closed
      // by the time add() ran and no photo was ever restored.
      let added = 0;
      for (const r of data.images || []) {
        if (seen.has(`${r.sessionId}|${r.createdAt}`)) continue; // already here
        const blob = await dataUrlToBlob(r.dataUrl);
        await req(tx("images", "readwrite").add({
          sessionId: r.sessionId, blob,
          caption: r.caption || "", prompt: r.prompt || "",
          source: r.source || "restored", favorite: r.favorite === true,
          ...(r.frame ? { frame: r.frame } : {}),
          createdAt: r.createdAt || Date.now(),
        }));
        added += 1;
      }
      // Backups written before the scrapbook was removed may still carry a
      // "scrapbook" array. It is ignored rather than rejected, so those older
      // files still restore their albums cleanly.
      for (const s of data.sessions || []) {
        const prev = await req(tx("sessions").get(s.sessionId)).catch(() => null);
        const titleBlob = s.titleBlob
          ? await dataUrlToBlob(s.titleBlob) : (prev?.titleBlob || null);
        const referenceBlob = s.referenceBlob
          ? await dataUrlToBlob(s.referenceBlob) : (prev?.referenceBlob || null);
        await req(tx("sessions", "readwrite").put({ ...s, titleBlob, referenceBlob }));
      }
      btn.textContent = `Restored ${added} photo${added === 1 ? "" : "s"} ✓`;
      renderShelf();
    } catch (err) {
      console.warn("[Photobook] restore failed:", err);
      btn.textContent = `Failed: ${err.message}`.slice(0, 40);
    }
    setTimeout(() => (btn.textContent = original), 4000);
  }

  $("backup-btn").addEventListener("click", (e) => backupAll(e.currentTarget));

  // ---------- the album picker ----------
  //
  // Share, move and save-as-page are all one-album actions that used to live
  // inside the album, which meant you had to open a book to send it. They sit
  // on the shelf now, so each one asks which album first.

  let pickerChoice = null;

  async function shelfAlbums() {
    const [images, sessions] = await Promise.all([
      req(tx("images").getAll()),
      req(tx("sessions").getAll()),
    ]);
    const byId = new Map();
    for (const r of images) {
      if (r.sessionId === "unfiled") continue;
      const a = byId.get(r.sessionId)
        || { sessionId: r.sessionId, count: 0, latest: 0, coverRec: null };
      a.count += 1;
      if ((r.createdAt || 0) >= a.latest) { a.latest = r.createdAt || 0; a.coverRec = r; }
      byId.set(r.sessionId, a);
    }
    for (const s of sessions) {
      const a = byId.get(s.sessionId);
      if (!a) continue;
      a.title = s.customTitle || s.album?.title || s.sheet?.album?.title || null;
      a.blurb = s.blurb || "";
      a.coverBlob = s.coverBlob || null;   // an image the user supplied
    }
    return [...byId.values()].sort((x, y) => y.latest - x.latest);
  }

  function closePicker() {
    $("picker").hidden = true;
    $("picker-list").innerHTML = "";
    pickerChoice = null;
  }

  /** @param onPick  runs with the chosen album once Continue is pressed */
  async function openPicker({ title, sub, action, onPick }) {
    const albums = await shelfAlbums();
    if (!albums.length) return;

    $("picker-title").textContent = title;
    $("picker-sub").textContent = sub;
    $("picker-go").textContent = action;
    $("picker-go").disabled = true;
    pickerChoice = null;

    const list = $("picker-list");
    list.innerHTML = "";
    for (const a of albums) {
      const name = a.title || `Session ${a.sessionId.slice(0, 8)}`;
      const row = document.createElement("button");
      row.className = "picker-row";
      row.type = "button";
      row.setAttribute("aria-pressed", "false");

      const tick = document.createElement("span");
      tick.className = "picker-tick";
      tick.setAttribute("aria-hidden", "true");

      const thumb = document.createElement("img");
      thumb.className = "picker-thumb";
      thumb.alt = "";
      if (a.coverRec) thumb.src = photoUrl(a.coverRec);

      const text = document.createElement("span");
      text.className = "picker-text";
      const h = document.createElement("strong");
      h.textContent = name;
      const meta = document.createElement("small");
      meta.textContent = a.blurb
        ? `${a.count} photo${a.count === 1 ? "" : "s"} · ${a.blurb}`
        : `${a.count} photo${a.count === 1 ? "" : "s"}`;
      text.append(h, meta);

      row.append(tick, thumb, text);
      // One at a time: picking a book releases the one before it.
      row.addEventListener("click", () => {
        for (const other of list.querySelectorAll(".picker-row")) {
          other.classList.remove("chosen");
          other.setAttribute("aria-pressed", "false");
        }
        row.classList.add("chosen");
        row.setAttribute("aria-pressed", "true");
        pickerChoice = { ...a, name };
        $("picker-go").disabled = false;
      });
      list.appendChild(row);
    }

    $("picker").hidden = false;
    $("picker-go").onclick = () => {
      if (!pickerChoice) return;
      const chosen = pickerChoice;
      closePicker();
      onPick(chosen);
    };
  }

  $("picker-cancel").addEventListener("click", closePicker);
  $("picker").addEventListener("click", (e) => {
    if (e.target === $("picker")) closePicker();
  });
  // Escape closes it, like every other dialog here. Without this the picker
  // sat over the shelf swallowing clicks until you found Cancel.
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !$("picker").hidden) {
      e.stopPropagation();
      closePicker();
    }
  }, true);

  // Sending an album to a person and moving it to your own second device
  // produce byte-identical files, so they are one action. If the shared copy
  // ever diverges from the archived one — smaller, and with the sender's
  // sheet stripped — that is the point to split this back into two.
  $("share-btn").addEventListener("click", () => openPicker({
    title: "Save an album to a file",
    sub: "One file holding this album. Send it to someone or move it to your other device — either way, they open Photobook and press Restore to load it.",
    action: "Make the file",
    onPick: (a) => backupAll($("share-btn"), a.sessionId, true, a.name),
  }));

  $("restore-btn").addEventListener("click", () => $("restore-input").click());
  $("restore-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (file) restoreFrom(file, $("restore-btn"));
  });

  /** Ask the host chat page (when embedded) for the newest reply as rendered.
   *  Resolves "" outside the overlay or if the page doesn't answer in time. */
  function requestHostLatest() {
    if (!EMBED) return Promise.resolve("");
    return new Promise((resolve) => {
      const done = (v) => { clearTimeout(timer); removeEventListener("message", on); resolve(v); };
      const on = (e) => {
        // Only the page that embedded this album may answer. browse.html runs
        // in the extension's own origin with access to chrome.* and the whole
        // photobook, and any script on the host page can postMessage into the
        // frame — so the sender is checked, not just the message shape.
        if (e.source !== parent) return;
        if (e.data?.source === "djpb-host" && e.data.cmd === "latest-reply") {
          done(String(e.data.text || ""));
        }
      };
      const timer = setTimeout(() => done(""), 1500);
      addEventListener("message", on);
      parent.postMessage({ source: "djpb-album", cmd: "latest-reply" }, "*");
    });
  }

  // A copy that needs neither the extension nor the site: one HTML file with
  // the photos embedded, openable in any browser, forever.
  $("export-btn").addEventListener("click", () => openPicker({
    title: "Save an album as a web page",
    sub: "One HTML file with the photos inside. Anyone can open it in a browser — no extension needed.",
    action: "Save the page",
    onPick: (a) => exportAsPage(a.sessionId, a.name),
  }));

  async function exportAsPage(sessionId, albumName) {
    const btn = $("export-btn");
    const original = btn.textContent;
    btn.textContent = "Saving…";
    try {
      // The shelf has no open album, so this reads its own copy.
      const [photos, sessionRec] = await Promise.all([
        req(tx("images").index("bySession").getAll(IDBKeyRange.only(sessionId))),
        req(tx("sessions").get(sessionId)),
      ]);
      photos.sort((x, y) => (x.createdAt || 0) - (y.createdAt || 0));
      const album = {
        photos,
        title: albumName,
        endNote: sessionRec?.endNote || sessionRec?.blurb || "",
        titleBlob: sessionRec?.titleBlob || null,
      };
      const readAsDataUrl = (blob) => new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => rej(new Error("read failed"));
        r.readAsDataURL(blob);
      });

      /** The album stores lossless PNGs, which is right for the archive and
       *  wrong for a page you send someone: base64'd, a 20-photo album came
       *  out over 20MB, past what most chat apps will carry. This copy is for
       *  looking at, so it re-encodes to JPEG and loses about 90% of the
       *  weight. The stored originals are untouched. */
      const toDataUrl = async (blob) => {
        try {
          const bmp = await createImageBitmap(blob);
          const cap = 1600;   // no phone album needs more than this on screen
          const scale = Math.min(1, cap / Math.max(bmp.width, bmp.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.round(bmp.width * scale);
          canvas.height = Math.round(bmp.height * scale);
          const ctx = canvas.getContext("2d");
          ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
          bmp.close?.();
          const out = canvas.toDataURL("image/jpeg", 0.85);
          // A tiny or already-small source can come back bigger; keep the win.
          const orig = await readAsDataUrl(blob);
          return out.length < orig.length ? out : orig;
        } catch {
          return readAsDataUrl(blob);   // transparent PNGs, odd codecs, etc.
        }
      };

      const esc = (s) => String(s || "").replace(/[&<>"]/g,
        (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));

      const pages = [];
      for (const rec of album.photos) {
        pages.push(`<figure><img src="${await toDataUrl(rec.blob)}" alt="">` +
          `<figcaption>${esc(rec.caption)}</figcaption></figure>`);
      }
      const titleImg = album.titleBlob ? await toDataUrl(album.titleBlob) : null;

      const doc = `<!doctype html><meta charset="utf-8">
<title>${esc(album.title)}</title>
<style>
 body{margin:0;padding:48px 16px;background:#17101a;color:#4b3a2e;
      font:16px/1.6 Georgia,serif;display:flex;flex-direction:column;
      align-items:center;gap:34px}
 h1{color:#e8dbc0;font-weight:normal;letter-spacing:.1em;text-align:center;margin:0}
 .sub{color:#9b8fa8;font-style:italic;margin:-22px 0 0;text-align:center}
 figure{margin:0;background:#f7f1e3;padding:22px 22px 18px;border-radius:3px;
        box-shadow:0 18px 40px -14px rgba(0,0,0,.8);max-width:660px;width:100%}
 img{width:100%;display:block;border:7px solid #fff;border-bottom-width:9px;
     box-sizing:border-box}
 figcaption{margin-top:14px;white-space:pre-wrap;color:#4b3a2e}
 .plate img{border-width:10px}
</style>
<h1>${esc(album.title)}</h1>
${album.endNote ? `<p class="sub">${esc(album.endNote)}</p>` : ""}
${titleImg ? `<figure class="plate"><img src="${titleImg}" alt=""></figure>` : ""}
${pages.join("\n")}
<p class="sub">${album.photos.length} photograph${album.photos.length === 1 ? "" : "s"}</p>`;

      const name = `${album.title.replace(/[^\w -]+/g, "").trim() || "album"}.html`;
      const blob = new Blob([doc], { type: "text/html" });

      // Sending it to a person is the whole point, so offer the share sheet
      // first on devices that have one.
      const how = await deliverFile(blob, name, "text/html", album.title);
      if (how === "cancelled") { btn.textContent = original; return; }
      btn.textContent = how === "shared" ? "Sent \u2713" : "Saved \u2713";
    } catch (err) {
      console.warn("[Photobook] export failed:", err);
      btn.textContent = "Couldn't save";
    }
    setTimeout(() => (btn.textContent = original), 2500);
  }

  // Outside tap and Escape both dismiss the design sheet.
  document.addEventListener("pointerdown", (e) => {
    const pop = $("theme-pop");
    if (!pop || pop.hidden) return;
    if (pop.contains(e.target) || $("design-btn").contains(e.target)) return;
    pop.hidden = true;
  }, true);
  document.addEventListener("keydown", (e) => {
    const pop = $("theme-pop");
    if (e.key === "Escape" && pop && !pop.hidden) {
      e.stopPropagation();
      pop.hidden = true;
    }
  }, true);

  // The album needs a way to say "no backdrop", not just "which photo".
  let updateBackdropMode = null;
  (() => {
    const btn = document.createElement("button");
    btn.id = "backdrop-mode";
    btn.type = "button";
    const label = () => {
      if (album?.backdropId === "none") return "🌄 Backdrop: off";
      if (album?.backdropId) return "🌄 Backdrop: pinned";
      return "🌄 Backdrop: newest snap";
    };
    updateBackdropMode = () => { btn.textContent = label(); };
    btn.title = "Off, or follow whatever you snap most recently";
    btn.addEventListener("click", async () => {
      // Off ⇄ follow-the-newest. Pinning a specific photo is done on the photo.
      album.backdropId = album.backdropId === "none" ? null : "none";
      await chrome.runtime.sendMessage({
        type: "db", op: "setBackdrop",
        args: { sessionId: album.sessionId, id: album.backdropId },
      });
      updateBackdropMode();
    });
    $("reader-tools")?.prepend(btn);
    updateBackdropMode();
  })();

  $("add-photos").addEventListener("click", () => $("add-input").click());
  $("add-input").addEventListener("change", async (e) => {
    if (!album) return;
    for (const file of e.target.files) {
      await req(tx("images", "readwrite").add({
        sessionId: album.sessionId,
        blob: file,
        caption: file.name.replace(/\.[^.]+$/, ""),
        source: "upload",
        createdAt: Date.now(),
      }));
    }
    e.target.value = "";
    // Land on the newest page.
    await chrome.storage.local.set({ [`djpbBookmark:${album.sessionId}`]: 9999 });
    openAlbum(album.sessionId);
  });
  $("lightbox-close").addEventListener("click", () => ($("lightbox").hidden = true));
  $("lightbox").addEventListener("click", (e) => {
    if (e.target.id === "lightbox") $("lightbox").hidden = true;
  });

  document.addEventListener("keydown", (e) => {
    if (e.target.matches?.("textarea, input, [contenteditable='true']")) return;
    if (!$("lightbox").hidden && e.key === "Escape") {
      $("lightbox").hidden = true;
      return;
    }
    if ($("reader").hidden) return;
    if (e.key === "ArrowRight") turn(1);
    if (e.key === "ArrowLeft") turn(-1);
    if (e.key === "Escape") {
      if (EMBED) parent.postMessage({ source: "djpb-album", cmd: "close" }, "*");
      else renderShelf();
    }
  });

  // Swipe on touch: a thumb drags the page. Three guards, all of which
  // matter on a phone and none of which matter with a mouse:
  //   - a gesture that starts in a scrollable control belongs to that control
  //   - the movement must be clearly horizontal, or scrolling a long note
  //     would flip the page out from under the reader
  //   - it must be a swipe, not a slow drag
  let touch = null;
  document.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1) { touch = null; return; }
    const t = e.touches[0];
    if (t.target?.closest?.("textarea, input, #theme-pop, #lightbox, .note-tools")) {
      touch = null;
      return;
    }
    touch = { x: t.clientX, y: t.clientY, at: Date.now() };
  }, { passive: true });
  document.addEventListener("touchend", (e) => {
    const start = touch;
    touch = null;
    if (!start || $("reader").hidden || !$("lightbox").hidden) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - start.x;
    const dy = t.clientY - start.y;
    if (Math.abs(dx) < 55) return;                    // too small to mean it
    if (Math.abs(dx) < Math.abs(dy) * 1.6) return;    // that was a scroll
    if (Date.now() - start.at > 800) return;          // a drag, not a swipe
    turn(dx < 0 ? 1 : -1);
  }, { passive: true });

  // ---------- boot ----------

  const params = new URLSearchParams(location.search);
  const EMBED = params.get("embed") === "1";

  // Standalone tab on a phone in desktop mode: scale itself the same way the
  // chat page does. Safe here precisely BECAUSE it is top-level — there is no
  // parent zoom to double up with, which is what went wrong in the overlay.
  if (!EMBED) {
    let ownZoom = 1;
    const fitViewport = () => {
      const base = innerWidth * ownZoom;
      const want = window.isPhone(base) && base > 900
        ? Math.min(2.6, Math.max(1, base / 470))
        : 1;
      if (Math.abs(want - ownZoom) < 0.03) return;
      ownZoom = want;
      if (want === 1) document.documentElement.style.removeProperty("zoom");
      else document.documentElement.style.setProperty("zoom", want.toFixed(2));
      setTimeout(fitBook, 120);
    };
    fitViewport();
    addEventListener("orientationchange", () => setTimeout(fitViewport, 250));
    // Same fitted layout as the overlay uses, driven by the real screen size.
    const markCompact = () => document.body.classList.toggle("compact", innerWidth < 900);
    markCompact();
    addEventListener("resize", () => setTimeout(markCompact, 150));
  }

  // NOTE: the album deliberately does NOT zoom itself when embedded. It lives in an iframe
  // inside a page that may already be zoomed, and applying a second zoom here
  // magnified everything a second time — which is what cut the page off at the
  // top and bottom. Instead the book is measured to fit the space available.

  /** Size the book so the WHOLE page is visible, even if that makes it small.
   *  Done in JS with measured pixels because viewport units are unreliable
   *  here: an iframe's units don't reflect a parent's zoom, and dvh is missing
   *  in some mobile Chromium builds (which silently voids any calc using it). */
  function fitBook() {
    const book = $("book");
    if (!book || $("reader").hidden) return;

    const tools = $("reader-tools");
    const chromeH =
      (tools ? tools.getBoundingClientRect().height : 40) +  // tools row
      46 +                                                   // back / close row
      16;                                                    // breathing room

    // Measure the reader itself where possible: it knows the frame's real
    // height, whereas innerHeight can be wrong inside a zoomed iframe.
    const readerH = $("reader").clientHeight || innerHeight;
    const box = Math.min(readerH || innerHeight, innerHeight || readerH);

    const availH = Math.max(180, box - chromeH);
    const availW = Math.max(180, (($("reader").clientWidth || innerWidth) * 0.94));

    // 3:4 keeps the book's proportions, but on a tall phone that leaves a band
    // of dead space below — and squeezes the note into a few clipped lines.
    // Width still comes from 3:4; the height then grows to take what's left.
    const width = Math.min(availW, availH * 0.75);
    let height = width * 4 / 3;

    const compact = document.body.classList.contains("compact") || innerWidth < 900;
    if (compact && availH > height + 24) {
      height = Math.min(availH, Math.round(height * 1.35));   // fill the gap
    }

    book.style.width = `${Math.round(width)}px`;
    book.style.height = `${Math.round(height)}px`;
    book.style.maxHeight = "none";
  }

  addEventListener("resize", () => {
    setTimeout(fitBook, 120);
  });
  addEventListener("orientationchange", () => {
    setTimeout(fitBook, 220);
  });

  if (EMBED) {
    document.body.classList.add("embed");
    const x = $("embed-close");
    x.hidden = false;
    x.addEventListener("click", () =>
      parent.postMessage({ source: "djpb-album", cmd: "close" }, "*"));
  }

  document.addEventListener("keydown", (e) => {
    // In the overlay, Esc from the shelf hands control back to the site page.
    if (EMBED && e.key === "Escape" && $("reader").hidden && $("lightbox").hidden) {
      parent.postMessage({ source: "djpb-album", cmd: "close" }, "*");
    }
  });

  (async () => {
    db = await openDb();
    const wanted = params.get("session");
    if (wanted) {
      await openAlbum(wanted).catch(renderShelf);
    } else {
      renderShelf();
    }
  })();
})();
