// keyboard.js — v11. The whole page moves up with the keyboard, and back down.
//
// Nothing clever, because clever kept failing. In desktop mode this browser
// reports NOTHING when the keyboard opens: no resize, no viewport event, no
// height. Two before/after screenshots showed the page pixel-identical. So the
// page cannot detect the keyboard, and any attempt to infer it is a guess.
//
// Therefore: move by a FIXED amount the user sets once, with arrows on screen
// to set it while the keyboard is actually open. One transform, one transition,
// no scrolling, no padding, no resizing, no DOM detection to get wrong.

(() => {
  // A desktop has no on-screen keyboard, so there is nothing to make room for.
  // This never checked, so focusing the composer on a PC lifted the page as if
  // a keyboard had opened. Bail out entirely on anything that isn't touch —
  // no listeners, no injected styles, nothing.
  // Same strict test used elsewhere: a PHONE, not merely something with a
  // touchscreen. A touchscreen laptop has a hardware keyboard and must never
  // have its page lifted.
if (!window.isPhone()) return;

  const KEY = "kbLift";          // pixels, saved per device
  let lift = null;               // null until loaded
  let enabled = true;            // the user can switch this off
  let focused = null;

  try {
    chrome.storage.sync.get({ [KEY]: null, kbLiftOn: true }, (v) => {
      enabled = v?.kbLiftOn !== false;
      const saved = Number(v?.[KEY]);
      // Anything above 35% of the screen came from the old oversized default;
      // ignore it so this update actually takes effect.
      lift = saved && saved < innerHeight * 0.35 ? saved : null;
    });
    chrome.storage.onChanged.addListener((c, a) => {
      if (a !== "sync") return;
      if (c[KEY]) lift = Number(c[KEY].newValue) || null;
      if (c.kbLiftOn) {
        enabled = c.kbLiftOn.newValue !== false;
        if (!enabled) down();        // switching it off takes effect at once
      }
    });
  } catch { /* defaults below */ }

  const isTextField = (el) =>
    el && el.matches?.("textarea, input[type='text'], input:not([type]), [contenteditable='true']");

  // Halved from 0.46: at that value the bar sat near the top of the screen with
  // a big gap above the keyboard. The browser contributes some movement of its
  // own, so the amount WE add has to be smaller than the keyboard's height.
  const defaultLift = () => Math.round(innerHeight * 0.22);

  try {
    const style = document.createElement("style");
    style.dataset.djpbUi = "1";
    style.textContent = `
      textarea, input[type="text"], input:not([type]) { font-size: max(16px, 1em) !important; }
      body.djpb-kb-up { transition: transform 0.18s ease-out !important; }
    `;
    (document.head || document.documentElement).appendChild(style);
  } catch { /* page behaves as before */ }

  function up() {
    const b = document.body;
    if (!b || !enabled) return;
    if (lift == null) lift = defaultLift();
    b.classList.add("djpb-kb-up");
    b.style.setProperty("transform", `translateY(${-Math.round(lift)}px)`, "important");
  }

  function down() {
    const b = document.body;
    if (!b) return;
    b.style.removeProperty("transform");
    setTimeout(() => b.classList.remove("djpb-kb-up"), 220);
  }


  document.addEventListener("focusin", (e) => {
    if (!isTextField(e.target)) return;
    focused = e.target;
    setTimeout(() => { if (focused) up(); }, 60);
  });

  document.addEventListener("focusout", () => {
    focused = null;
    setTimeout(() => { if (!focused) down(); }, 120);
  });
})();
