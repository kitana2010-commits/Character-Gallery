// content.js — the chat page's link to the extension.
//
// Two jobs. It relays what intercept.js sees on the wire (the /api/chat
// payload, the last reply, the player's last message) to the service
// worker, which builds the appearance sheet from it; and it shows a small
// glow in the composer while the site is generating a reply.
//
// It used to also build an in-page album panel. That panel has been hidden
// by stylesheet since v0.8.0 — the album lives in the overlay and the
// toolbar icon now — so it was five hundred lines of DOM that nobody could
// see, plus two database operations that only it called. Gone.

(() => {
  /** One small element of our own, dropped inside the composer and taken
   *  out again when the reply lands. Nothing of the site's is restyled to
   *  make this work. */
  function mountGenGlow() {
    const form = document.querySelector("form.chatform");
    if (!form || document.getElementById("djpb-genglow")) return;
    const wrap = document.createElement("div");
    wrap.id = "djpb-genglow";
    wrap.setAttribute("aria-hidden", "true");
    wrap.appendChild(document.createElement("span"));
    form.insertBefore(wrap, form.firstChild);
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== "djpb:payload") return;

    if (typeof data.generating === "boolean") {
      const root = document.documentElement;
      root.classList.toggle("djpb-generating", data.generating);
      if (data.generating) mountGenGlow();
      else document.getElementById("djpb-genglow")?.remove();
      return;
    }

    chrome.runtime.sendMessage({
      type: "payload:store",
      payload: data.payload,
      lastReply: data.lastReply || "",
      lastUserMsg: data.lastUserMsg || "",
    }).catch(() => {});
  });

  const SESSION_RE = /\/app\/session\/([0-9a-f-]{36})/i;

  const alive = () => {
    try { return Boolean(chrome.runtime?.id); } catch { return false; }
  };

  // After the extension is reloaded, this script is orphaned: its chrome.*
  // calls fail until the page is refreshed. Say so once, in the console,
  // and stop polling rather than throwing every half second.
  let toldUser = false;
  let watchTimer = null;

  function goneStale() {
    if (toldUser) return;
    toldUser = true;
    console.info("[SnapScapes] The extension was reloaded — refresh this page to reconnect.");
    if (watchTimer) clearInterval(watchTimer);
  }

  // The site is a single-page app: remember which session the reader is in
  // as they move between chats, so the worker can file things correctly
  // when a message arrives without one.
  let currentSession = null;
  const sessionFromUrl = () => (location.pathname.match(SESSION_RE) || [])[1] || null;

  function onNavigate() {
    const session = sessionFromUrl();
    if (session === currentSession) return;
    currentSession = session;
    if (session && alive()) chrome.storage.local.set({ lastSession: session }).catch(() => {});
  }

  function watchUrl() {
    let lastHref = location.href;
    const check = () => {
      if (location.href !== lastHref) {
        lastHref = location.href;
        onNavigate();
      }
    };
    watchTimer = setInterval(() => {
      if (!alive()) return goneStale();
      check();
    }, 500);
    addEventListener("popstate", check);
  }

  watchUrl();
  onNavigate();
})();
