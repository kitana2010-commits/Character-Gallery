// sheet.js — turns an intercepted /api/chat payload into an appearance sheet:
// who the characters are, what they look like, what the lorebooks add.
//
// Every field name here comes from a real captured payload, not a guess.
// Reading the scene lives in scene.js; building a prompt lives in draft.js.

const Sheet = (() => {

  // ---------- character cards ----------

  /** Cards on this site are markdown-sectioned and the convention is a
   *  "## Appearance" heading. Split on headings and take that section;
   *  fall back to the opening paragraph for cards that aren't sectioned. */
  function appearanceFrom(description) {
    const text = String(description || "").trim();
    if (!text) return "";

    const sections = text.split(/^##+\s+/m).filter(Boolean);
    const match = sections.find((s) => /^appearance\b/i.test(s));
    if (match) {
      return collapse(match.replace(/^appearance\s*/i, ""));
    }

    // Unsectioned card: first paragraph is nearly always the physical
    // description, since that's how people write these.
    return collapse(text.split(/\n\s*\n/)[0] || text).slice(0, 400);
  }

  function collapse(s) {
    return String(s).replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
  }

  /** Image prompts need what can be DRAWN, not the character card's entire
   *  psychological dossier. Some unsectioned / loosely sectioned cards put
   *  Appearance, attachment style, money, fame, relationships, etc. in one
   *  blob. Stop at common non-visual labels, then keep a tight visual budget. */
  function promptAppearance(text) {
    let t = collapse(text || "");
    if (!t) return "";

    // A leading colon is common on cards written as "Appearance: ..." after
    // the heading parser has stripped the word Appearance itself.
    t = t.replace(/^[:\-–—\s]+/, "");

    const meta = /\b(?:attachment\s+style|bank\s+account|fame|relationship\s+with|relationships?|opinion\s+on|love\s+language|personality|backstory|history|occupation|job|family|sexuality|likes?|dislikes?|habits?|goals?|motivation|skills?|abilities|powers?|voice|speech|behavior|behaviour|connections?)\s*:/i;
    const cut = t.search(meta);
    if (cut > 0) t = t.slice(0, cut).trim();

    // Prefer sentences that contain drawable traits. This drops nearby card
    // prose like "women love him" while preserving hair, eyes, clothes, scars,
    // tattoos, piercings, build, etc. Fall back to the opening sentence(s) for
    // unusually written cards that don't use our visual vocabulary.
    const sentences = t.split(/(?<=[.!?])\s+/).filter(Boolean);
    const visual = sentences.filter((sentence) => visualScore(sentence, "character") >= 1).slice(0, 2);
    if (visual.length) t = visual.join(" ");
    else t = sentences.slice(0, 2).join(" ") || t;

    // Hard ceiling even for cards with no labels. Past this point, image
    // models get less precise and we start feeding them prose they cannot draw.
    return clampWords(t, 48);
  }

  /** {{char}} and {{user}} are template placeholders. Left in, they reach the
   *  image model as literal braces. */
  function fill(text, names) {
    return String(text || "")
      .replace(/\{\{\s*char\s*\}\}/gi, names.char || "the character")
      .replace(/\{\{\s*user\s*\}\}/gi, names.user || "you");
  }

  // ---------- build the sheet ----------

  /** @param payload the intercepted POST body for /api/chat */
  function fromPayload(payload) {
    const bot = payload.bot || {};
    const persona = payload.persona || {};
    const plot = payload.plot || {};
    const names = { char: bot.name || bot.chatname || "the character",
                    user: persona.name || "you" };

    return {
      sessionId: payload.sessionId,
      updatedAt: Date.now(),

      characters: {
        [names.char]: {
          name: names.char,
          appearance: fill(appearanceFrom(bot.description), names),
          portrait: bot.img_link || bot.imgsrc || null,
          role: "bot",
        },
        [names.user]: {
          name: names.user,
          appearance: fill(appearanceFrom(persona.description), names),
          portrait: persona.imglink || null,
          role: "user",
        },
      },

      // Keyed by lowercased trigger word. Filled from payload.lorebooks once
      // the entry shape is confirmed.
      lore: indexLorebooks(payload.lorebooks, names),

      album: {
        title: plot.title || bot.name || "Album",
        cover: plot.bglink || bot.bglink || null,
      },

    };
  }

  /** Real shape (verified against a live payload):
   *    lorebooks[].entries[] = { name, description, type, img_link,
   *                              keys: [{ keyText }] }
   *  keys are OBJECTS, not strings — treating them as strings yielded
   *  "[object Object]" and matched nothing, which is why lore never appeared. */
  function indexLorebooks(books, names) {
    const index = {};
    for (const book of books || []) {
      for (const entry of book.entries || []) {
        if (entry.hidden) continue;
        const text = loreText(entry.description, names, entry.type);
        if (!text) continue;
        const record = {
          entryName: entry.name || "",
          type: entry.type || "",          // "character" | "location"
          text,
          portrait: entry.img_link || null,
          weight: entry.weight || 0,
        };
        const keys = (entry.keys || []).map((k) =>
          typeof k === "string" ? k : k?.keyText).filter(Boolean);
        // The entry's own name is a trigger too ("Spite (Kellas's Horse)").
        for (const k of [...keys, firstWord(entry.name)]) {
          if (k) index[String(k).toLowerCase().trim()] = record;
        }
      }
    }
    return index;
  }

  /** The entry name's first real word. "The Gilded Cup" used to index under
   *  "the", which matched every sentence in the chat and glued that tavern's
   *  description onto whatever location the prompt had. */
  function firstWord(name) {
    const words = String(name || "").match(/[\w'\u2019]+/g) || [];
    const first = words.find((w) => !/^(the|a|an|of|at|in)$/i.test(w)) || "";
    return first.length >= 3 ? first : "";
  }

  // Words that describe how something LOOKS. Used to pick the drawable part of
  // a lore entry rather than trusting its first sentence — Brin's opens with
  // "longtime friend and occasional lover", which is history, not appearance.
  const VISUAL_WORDS = new Set([
    "tall", "short", "huge", "enormous", "massive", "small", "slender", "broad",
    "heavy", "heavily", "lean", "thin", "built", "muscled", "scarred", "scar",
    "hair", "eyes", "eye", "skin", "beard", "braid", "horns", "wings", "tail",
    "ears", "face", "jaw", "black", "white", "red", "blonde", "blond", "brown",
    "grey", "gray", "silver", "gold", "golden", "pale", "dark", "auburn",
    "copper", "green", "blue", "armor", "armour", "leathers", "cloak", "coat",
    "robes", "dress", "uniform", "boots", "sword", "blade", "axe", "bow",
    "tattoo", "tattoos", "piercing", "piercings", "eyeliner", "makeup", "smirk",
    "arms", "shoulders", "chest", "ribs", "lips", "mouth", "nose", "freckles",
    "warhorse", "horse", "hound", "dog", "wolf", "cat",
    "man", "woman", "warrior", "soldier", "knight", "beauty", "old", "young",
    "stallion", "mare", "beast", "creature", "winged", "clad", "wears",
  ]);

  // Places are drawable through different words than people are. "Lawless
  // territory dividing the Courts" is politics; "scarred tables, dirty floors"
  // is a picture. Scoring locations with the character list omitted them all.
  const PLACE_WORDS = new Set([
    "stone", "wood", "wooden", "timber", "walls", "wall", "floor", "floors",
    "roof", "ceiling", "beams", "rafters", "hearth", "fire", "fireplace",
    "torch", "torches", "lantern", "candle", "window", "windows", "door",
    "doors", "gate", "stairs", "narrow", "wide", "cramped", "vast", "crowded",
    "dirty", "filthy", "scarred", "worn", "old", "ruined", "abandoned",
    "dark", "dim", "smoky", "cold", "damp", "tables", "table", "benches",
    "bed", "furniture", "leather", "iron", "forest", "trees", "river", "road",
    "hills", "cliffs", "snow", "mud", "fields", "tents", "banners", "arches",
    "pillars", "courtyard", "yard", "stable", "stables", "pool", "bath",
    "cave", "tunnel", "cellar", "loft", "hall", "tavern", "barracks", "fort",
  ]);

  function visualScore(text, type) {
    const w = String(text).toLowerCase().match(/[a-z']+/g) || [];
    const list = type === "location" ? PLACE_WORDS : VISUAL_WORDS;
    let n = 0;
    for (const x of w) if (list.has(x)) n += 1;
    return n;
  }

  /** Lore prose carries markup meant for the writer, not an image model:
   *  underscore link markers (_Kellas), bold headers, and template tokens. */
  function loreText(description, names, type) {
    let t = fill(String(description || ""), names);
    t = t.replace(/\*\*([^*]+)\*\*/g, "$1")     // **Spite:** -> Spite:
         .replace(/(^|[\s(])_(?=[A-Za-z])/g, "$1") // _Kellas -> Kellas
         .replace(/^\s*[A-Z][\w'\u2019 ]{0,28}:\s*/, "") // drop leading "Spite:"
         .trim();
    // Search the WHOLE entry for the drawable sentence instead of trusting
    // position: appearance is often buried, and the opening is often history.
    const sentences = t.split(/(?<=[.!?])\s+/).filter((x) => x.trim().length > 8);
    let best = null;
    for (const sentence of sentences) {
      const score = visualScore(sentence, type);
      if (score >= 2 && (!best || score > best.score)) best = { sentence, score };
    }
    // Nothing drawable in the entry (pure personality, like Finn or Ronan) —
    // say nothing rather than describing a face from someone's temperament.
    if (!best) return "";

    return collapse(best.sentence)
      .replace(/,\s+(aptly|usually|which|who|after|though|because|since)\b.*$/i, "")
      .replace(/\s+(and|but)\s+[^,.]*$/i, "")
      .slice(0, 140);
  }

  /** Word-boundary lookup so "home"/"bath"/"horse" don't fire on substrings. */
  function loreFor(sheet, text, type) {
    const hay = " " + String(text || "").toLowerCase() + " ";
    let best = null;
    for (const [key, entry] of Object.entries(sheet.lore || {})) {
      if (key.length < 3) continue;
      if (type && entry.type !== type) continue;
      const re = new RegExp(`[^a-z0-9]${escapeRe(key)}[^a-z0-9]`, "i");
      if (!re.test(hay)) continue;
      if (!best || key.length > best.key.length) best = { key, entry };
    }
    return best ? best.entry : null;
  }

  function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  /** Trim to N words on a word boundary, no trailing function word. */
  function clampWords(text, n) {
    const w = String(text).trim().split(/\s+/);
    if (w.length <= n) return String(text).trim();
    const out = w.slice(0, n);
    while (out.length && /^(for|and|but|the|a|an|with|of|to|in|on|at|as|before|while|that|his|her|their)$/i
             .test(out[out.length - 1])) out.pop();
    return out.join(" ").replace(/[,;:]$/, "");
  }

  // ---------- lookups ----------

  /** Cards use full names, chat uses short ones ("Kellas Jarveth" / "Kellas"). */
  function lookupCharacter(sheet, name) {
    const chars = sheet.characters || {};
    if (chars[name]) return chars[name];
    const needle = String(name).toLowerCase();
    return Object.values(chars).find((c) => {
      const n = String(c.name).toLowerCase();
      return n.startsWith(needle) || needle.startsWith(n.split(" ")[0]);
    }) || null;
  }

  /** Lorebooks are keyword-triggered, so this is a lookup, not fuzzy matching. */
  function matchLore(sheet, text) {
    const hit = loreFor(sheet, text, "location") || loreFor(sheet, text, null);
    return hit ? hit.text : "";
  }

  return { fromPayload, appearanceFrom, promptAppearance, fill, matchLore, loreFor, lookupCharacter };
})();

if (typeof module !== "undefined" && module.exports) module.exports = Sheet;
