// background.js — the service worker.
//
// Owns the photo store, the session records (sheet + scene memory), the
// generation backends and the ChatGPT/Grok/Gemini bridge. Drafting a prompt
// is delegated to draft.js. Message types:
//   {type:"db", op, args}                          → storage operations
//   {type:"payload:store", payload, lastReply, lastUserMsg}
//   {type:"prompt:draft", sessionId, replyText, thinkText, …}
//   {type:"generate", prompt, negative, reference, strength}
//   {type:"fetchImage", url}                       → fetch any image as data URL
//   {type:"snap:arm", sessionId, prompt, returnUrl}→ prime the bridge
//   {type:"snap:peek"}                             → capture.js asks what's pending
//   {type:"snap:save", dataUrl, sessionId, caption}

let BOOT_ERROR = null;
try {
  // Order matters: each one reads the globals the previous ones define.
  importScripts("condense.js", "scene.js", "sheet.js", "draft.js");
} catch (err) {
  BOOT_ERROR = String(err?.message || err);
  console.error("[SnapScapes] startup failed — a helper script did not load:", err);
}

// ======================= storage =======================

const DB_NAME = "dj-photobook";
const DB_VERSION = 3;
const IMAGES = "images";
const SESSIONS = "sessions";

let dbPromise = null;

function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const r = indexedDB.open(DB_NAME, DB_VERSION);
    r.onupgradeneeded = () => {
      const db = r.result;
      if (!db.objectStoreNames.contains(IMAGES)) {
        const s = db.createObjectStore(IMAGES, { keyPath: "id", autoIncrement: true });
        s.createIndex("bySession", "sessionId", { unique: false });
      }
      if (!db.objectStoreNames.contains(SESSIONS)) {
        db.createObjectStore(SESSIONS, { keyPath: "sessionId" });
      }
    };
    r.onblocked = () =>
      reject(new Error("photobook database is blocked by another tab — close the album tab"));
    r.onsuccess = () => {
      const db = r.result;
      db.onversionchange = () => { db.close(); dbPromise = null; };
      resolve(db);
    };
    r.onerror = () => reject(r.error);
  });
  dbPromise = dbPromise.catch((err) => { dbPromise = null; throw err; });
  return dbPromise;
}

function req(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function store(name, mode) {
  const db = await openDb();
  return db.transaction(name, mode).objectStore(name);
}

async function dataUrlToBlob(dataUrl) {
  return (await fetch(dataUrl)).blob();
}

async function blobToDataUrl(blob) {
  const buf = await blob.arrayBuffer();
  return `data:${blob.type || "image/png"};base64,${arrayBufferToBase64(buf)}`;
}

const MAX_REFS = 4;

// A small JPEG of a reference, sized for the Snap card's chips (192px covers
// the hover preview at 1x and the 26px chip at any density). Generated once
// per reference and cached on the record, so chips open instantly after the
// first time. Falls back to the full image if OffscreenCanvas is unavailable.
const THUMB_PX = 192;

async function makeThumb(blob) {
  try {
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, THUMB_PX / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    canvas.getContext("2d").drawImage(bmp, 0, 0, w, h);
    bmp.close?.();
    const out = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.75 });
    return blobToDataUrl(out);
  } catch {
    return blobToDataUrl(blob);   // tiny worst case: chip shows the full image
  }
}

/** Session record's references, with a `thumb` dataUrl on every entry.
 *  Backfills (and persists) thumbs for references saved before thumbs
 *  existed, so old chats get pictures on their chips too. */
async function refsWithThumbs(sessionId) {
  const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const refs = await refsOf(rec);
  let dirty = false;
  for (const r of refs) {
    if (!r.thumb && r.blob) {
      r.thumb = await makeThumb(r.blob);
      dirty = true;
    }
  }
  if (dirty && rec) {
    try {
      const rec2 = { ...rec, sessionId, references: refs };
      delete rec2.referenceBlob;
      await req((await store(SESSIONS, "readwrite")).put(rec2));
    } catch { /* cache miss next time; nothing lost */ }
  }
  return refs;
}

async function refsOf(rec) {
  if (!rec) return [];
  if (Array.isArray(rec.references)) return [...rec.references];
  if (rec.referenceBlob) return [{ blob: rec.referenceBlob, label: "Book ref" }];
  return [];
}

async function recordOut(rec) {
  return {
    id: rec.id,
    sessionId: rec.sessionId,
    caption: rec.caption || "",
    createdAt: rec.createdAt,
    source: rec.source || "",
    dataUrl: await blobToDataUrl(rec.blob),
  };
}

const dbOps = {
  async add({ sessionId, dataUrl, meta = {} }) {
    const blob = await dataUrlToBlob(dataUrl);
    const s = await store(IMAGES, "readwrite");
    return req(s.add({
      sessionId: sessionId || "unfiled",
      blob,
      caption: meta.caption || "",
      source: meta.source || "",
      prompt: meta.prompt || "",
      conditions: meta.conditions && typeof meta.conditions === "object"
        ? { ...meta.conditions }
        : undefined,
      createdAt: meta.createdAt || Date.now(),
    }));
  },

  async backdrop({ sessionId, knownId }) {
    if (!sessionId) return null;

    let target = null;
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const pinned = Boolean(rec?.backdropId) && rec.backdropId !== "none";
    if (rec?.backdropId === "none") return null;
    if (rec?.backdropId) {
      target = await req((await store(IMAGES, "readonly")).get(rec.backdropId)).catch(() => null);
    }
    if (!target) {
      const all = await req(
        (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId)));
      all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      target = all[all.length - 1] || null;
    }
    if (!target) return null;
    const conditions = target.conditions && typeof target.conditions === "object"
      ? { ...target.conditions }
      : {};
    const manualEffects = Array.isArray(target.manualEffects)
      ? [...target.manualEffects]
      : (target.manualEffects && typeof target.manualEffects === "object"
        ? {
            effects: Array.isArray(target.manualEffects.effects) ? [...target.manualEffects.effects] : [],
            intensity: target.manualEffects.intensity && typeof target.manualEffects.intensity === "object"
              ? { ...target.manualEffects.intensity }
              : {},
          }
        : null);
    if (knownId && String(target.id) === String(knownId)) {
      return { id: target.id, unchanged: true, conditions, manualEffects, pinned };
    }
    return {
      id: target.id,
      pinned,
      dataUrl: await blobToDataUrl(target.blob),
      conditions,
      manualEffects,
    };
  },

  async setEffects({ id, effects }) {
    const rec = await req((await store(IMAGES, "readonly")).get(id));
    if (!rec) throw new Error("Image not found");

    const allowed = new Set([
      "rain", "lightning", "snow", "fog",
      "embers", "fireflies", "petals", "lilacs",
      "vignette", "sunlight",
    ]);
    const clampIntensity = (value) => {
      const n = Number(value);
      if (!Number.isFinite(n)) return 3;
      return Math.max(1, Math.min(4, Math.round(n)));
    };

    if (effects === null || effects === undefined) {
      delete rec.manualEffects;
    } else if (Array.isArray(effects)) {
      rec.manualEffects = [...new Set(effects.filter((name) => allowed.has(name)))];
    } else if (effects && typeof effects === "object") {
      const names = [...new Set(
        (Array.isArray(effects.effects) ? effects.effects : []).filter((name) => allowed.has(name))
      )];
      const intensity = {};
      const source = effects.intensity && typeof effects.intensity === "object"
        ? effects.intensity
        : {};
      for (const name of names) intensity[name] = clampIntensity(source[name]);
      rec.manualEffects = { effects: names, intensity };
    } else {
      rec.manualEffects = [];
    }

    await req((await store(IMAGES, "readwrite")).put(rec));
    return {
      id: rec.id,
      conditions: rec.conditions && typeof rec.conditions === "object"
        ? { ...rec.conditions }
        : {},
      manualEffects: Array.isArray(rec.manualEffects)
        ? [...rec.manualEffects]
        : (rec.manualEffects && typeof rec.manualEffects === "object"
          ? {
              effects: Array.isArray(rec.manualEffects.effects) ? [...rec.manualEffects.effects] : [],
              intensity: rec.manualEffects.intensity && typeof rec.manualEffects.intensity === "object"
                ? { ...rec.manualEffects.intensity }
                : {},
            }
          : null),
    };
  },

  /** The Snapscape mode for a chat, without touching any image blobs:
   *  {mode:"follow"|"pinned"|"none", id, newestId}. "follow" is backdropId
   *  null/absent (the backdrop tracks the newest photo); "pinned" holds one;
   *  "none" is the explicit off state. newestId lets a UI pin "what is
   *  showing right now" when the user turns follow off. */
  async scapeInfo({ sessionId }) {
    if (!sessionId) return { mode: "follow", id: null, newestId: null };
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
    const all = await req(
      (await store(IMAGES, "readonly")).index("bySession").getAll(IDBKeyRange.only(sessionId))
    ).catch(() => []);
    all.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    const newestId = all.length ? all[all.length - 1].id : null;
    if (rec?.backdropId === "none") return { mode: "none", id: null, newestId };
    if (rec?.backdropId) return { mode: "pinned", id: rec.backdropId, newestId };
    return { mode: "follow", id: null, newestId };
  },

  async setBackdrop({ sessionId, id }) {
    await dbOps.mergeSession({ sessionId, patch: { backdropId: id || null } });
    return { ok: true };
  },

  async list({ sessionId }) {
    const s = await store(IMAGES, "readonly");
    const recs = await req(s.index("bySession").getAll(IDBKeyRange.only(sessionId)));
    recs.sort((a, b) => a.createdAt - b.createdAt);
    return Promise.all(recs.map(recordOut));
  },



  async getReference({ sessionId }) {
    const refs = await refsOf(
      await req((await store(SESSIONS, "readonly")).get(sessionId))
    );
    return refs.length ? blobToDataUrl(refs[0].blob) : null;
  },

  async addReference({ sessionId, dataUrl, label }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const refs = await refsOf(prev);
    if (refs.length >= MAX_REFS) {
      throw new Error(`Reference limit is ${MAX_REFS} — remove one first.`);
    }
    const blob = await dataUrlToBlob(dataUrl);
    refs.push({
      blob,
      thumb: await makeThumb(blob),
      label: String(label || "reference").slice(0, 48),
    });
    const rec = { ...(prev || {}), sessionId, references: refs };
    delete rec.referenceBlob;
    const s = await store(SESSIONS, "readwrite");
    return req(s.put(rec));
  },

  async listReferences({ sessionId }) {
    const refs = await refsWithThumbs(sessionId);
    return Promise.all(
      refs.map(async (r, index) => ({
        index,
        // Auto-numbered labels are re-derived from position so they can't
        // drift after removals; hand-set labels pass through untouched.
        label: /^Book ref( \d+)?$/.test(r.label || "")
          ? `Book ref ${index + 1}`
          : (r.label || "reference"),
        dataUrl: await blobToDataUrl(r.blob),
        thumb: r.thumb || null,
      }))
    );
  },

  async removeReference({ sessionId, index }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    if (!prev) return null;
    const refs = await refsOf(prev);
    const at = Number(index);
    refs.splice(at, 1);
    const rec = { ...prev, sessionId, references: refs };
    delete rec.referenceBlob;
    const s = await store(SESSIONS, "readwrite");
    const put = await req(s.put(rec));

    // The saved picks are keyed book:0, book:1, … — shift everything above
    // the removed slot down one, or each remaining photo inherits the on/off
    // state of the photo that USED to sit at its index.
    try {
      const key = refPickKey(sessionId);
      const saved = (await chrome.storage.local.get({ [key]: null }))[key];
      if (saved && typeof saved === "object") {
        const next = {};
        for (const [k, v] of Object.entries(saved)) {
          const m = /^book:(\d+)$/.exec(k);
          if (!m) { next[k] = v; continue; }         // portrait keys stay put
          const i = Number(m[1]);
          if (i < at) next[k] = v;
          else if (i > at) next[`book:${i - 1}`] = v;
          // i === at: dropped with its photo
        }
        await chrome.storage.local.set({ [key]: next });
      }
    } catch { /* worst case: a chip defaults back to off */ }
    return put;
  },


  async mergeSession({ sessionId, patch }) {
    const prev = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const s = await store(SESSIONS, "readwrite");
    return req(s.put({ ...(prev || {}), sessionId, ...patch }));
  },

  /** The album's cast, for the Snap card's character picker. Portraits are
   *  already small (scaled on upload), so they travel as-is. */
  async getCast({ sessionId }) {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    return (Array.isArray(rec?.cast) ? rec.cast : [])
      .filter((c) => c.img)
      .map((c) => ({ id: c.id, name: c.name || "", img: c.img }));
  },
};

// ======================= config =======================

const DEFAULTS = {
  preset: "pollinations",
  endpoint: "",
  model: "",
  modelOpenRouter: "google/gemini-2.5-flash-image",
  width: 768,
  height: 768,
  steps: 25,
  condenser: "heuristic",
  condenserModelClaude: "claude-haiku-4-5-20251001",
  condenserModel: "gpt-5.4-nano",
  quality: "low",
  style: "stylized digital illustration, semi realistic anime inspired",
  bridge: "chatgpt",
};

(async () => {
  try {
    const { style } = await chrome.storage.sync.get({ style: null });
    if (style === "painterly digital art, cinematic composition") {
      await chrome.storage.sync.set({ style: DEFAULTS.style });
    }
  } catch { /* first run */ }
})();

const BRIDGE_URLS = {
  chatgpt: "https://chatgpt.com/",
  grok: "https://grok.com/",
  gemini: "https://gemini.google.com/",
};

/** Where a bridge lives, for finding a tab that is already open on it. */
const BRIDGE_MATCHES = {
  chatgpt: ["*://chatgpt.com/*", "*://chat.openai.com/*"],
  grok: ["*://grok.com/*"],
  gemini: ["*://gemini.google.com/*"],
};

async function getConfig() {
  const [synced, local] = await Promise.all([
    chrome.storage.sync.get(DEFAULTS),
    chrome.storage.local.get({ apiKey: "", apiKeyOpenRouter: "" }),
  ]);
  return {
    ...DEFAULTS,
    ...synced,
    apiKey: local.apiKey || "",
    apiKeyOpenRouter: local.apiKeyOpenRouter || "",
  };
}

// ======================= message router =======================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const reply = (p) => p
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  switch (msg?.type) {
    case "db": {
      const op = dbOps[msg.op];
      if (!op) {
        sendResponse({ ok: false, error: `Unknown db op "${msg.op}"` });
        return;
      }
      reply(op(msg.args || {}).then((result) => ({ result: result ?? null })));
      return true;
    }
    // Manual diagnostic, no in-app caller by design. From any extension
    // page's console: chrome.runtime.sendMessage({ type: "health" })
    case "health":
      sendResponse({
        ok: true,
        boot: BOOT_ERROR,
        condenser: typeof PromptCondenser !== "undefined",
        sheet: typeof SheetBuilder !== "undefined",
        version: chrome.runtime.getManifest().version,
      });
      return true;
    case "config:summary":
      reply(configSummary());
      return true;
    case "options:open":
      reply((async () => { await chrome.runtime.openOptionsPage(); return {}; })());
      return true;
    case "albums:open":
      reply((async () => {
        await openAlbumTab(msg.sessionId || null);
        return {};
      })());
      return true;
    case "payload:store":
      reply(storePayload(msg));
      return true;
    case "prompt:draft":
      reply(draftPrompt(msg));
      return true;
    case "generate":
      reply(generate(msg));
      return true;
    case "fetchImage":
      reply(fetchAsDataUrl(msg.url).then((dataUrl) => ({ dataUrl })));
      return true;
    case "snap:arm":
      reply(armSnap(msg, sender));
      return true;
    case "snap:peek":
      reply(peekSnap(sender.tab?.id));
      return true;
    case "snap:save":
      reply(saveSnap({ ...msg, tabId: sender.tab?.id }));
      return true;
    case "snap:refimage":
      reply(snapRefImage(msg.role));
      return true;
    case "snap:refpicks":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        return { sources: sid ? await snapRefPicks(sid) : [] };
      })());
      return true;
    case "snap:setrefpick":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        if (!sid) throw new Error("No chat to attach to");
        const key = refPickKey(sid);
        const saved = (await chrome.storage.local.get({ [key]: null }))[key] || {};
        const now = await snapRefPicks(sid);
        const next = {};
        for (const src of now) next[src.id] = src.on;
        next[msg.id] = msg.on === true;
        await chrome.storage.local.set({ [key]: { ...saved, ...next } });
        return { sources: await snapRefPicks(sid) };
      })());
      return true;
    case "snap:refimages":
      reply((async () => {
        const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
        const sid = msg.sessionId || pendingSnap?.sessionId || (await lastSession());
        if (!sid) return { images: [] };
        const picks = (await snapRefPicks(sid)).filter((p) => p.on);
        const images = [];
        for (const src of picks) {
          try {
            const got = await snapRefDataUrl(sid, src);
            if (got?.dataUrl) images.push(got);
          } catch { /* unavailable */ }
        }
        return { images };
      })());
      return true;
    case "bridge:hello":
      noteBridgeTab(sender.tab?.id, msg.url, msg.bridge);
      reply(Promise.resolve({ noted: true }));
      return true;
    default:
      return;
  }
});

// ======================= sheet + drafting =======================

async function sessionRecord(sessionId) {
  return req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
}

/** Every send from the chat page lands here: the intercepted context becomes
 *  the sheet, and the two newest turns update the scene memory — so the next
 *  snap knows where the story was one turn ago, without waiting on the Nexus. */
async function storePayload({ payload, lastReply, lastUserMsg }) {
  const built = Sheet.fromPayload(payload || {});
  if (!built.sessionId) throw new Error("Payload had no sessionId");

  const existing = await sessionRecord(built.sessionId);
  const hasNewChars = Object.keys(built.characters || {}).length > 0;
  if (existing?.sheet?.characters && !hasNewChars) {
    return { sessionId: built.sessionId };
  }
  const sheet = existing?.sheet?.characters
    ? {
        ...built,
        characters: mergeCharacters(existing.sheet.characters, built.characters),
        lore: Object.keys(built.lore || {}).length ? built.lore : (existing.sheet.lore || {}),
      }
    : built;

  const patch = { sheet };
  if (built.album?.title) patch.album = built.album;
  if (String(lastReply || "").trim()) patch.lastReply = String(lastReply);
  if (String(lastUserMsg || "").trim()) patch.lastUserMsg = String(lastUserMsg);

  if (patch.lastReply || patch.lastUserMsg) {
    try {
      const learned = SceneLocator.memoryFromSend({
        lastUserMsg: patch.lastUserMsg || "",
        lastReply: patch.lastReply || "",
        previous: existing?.sceneMemory || null,
        cast: Object.values(sheet.characters || {}).map((c) => c.name),
        lore: sheet.lore || {},
      });
      if (learned) patch.sceneMemory = { ...(existing?.sceneMemory || {}), ...learned };
    } catch (err) {
      console.warn("[SnapScapes] scene memory skipped:", err?.message || err);
    }
  }

  await dbOps.mergeSession({ sessionId: built.sessionId, patch });
  await chrome.storage.local.set({ lastSession: built.sessionId });
  return { sessionId: built.sessionId };
}

function mergeCharacters(existing, incoming) {
  const out = { ...(existing || {}) };
  for (const [name, c] of Object.entries(incoming || {})) {
    const prev = out[name];
    if (prev?.edited) continue;
    if (!prev) { out[name] = c; continue; }
    const better = (c.appearance || "").length >= (prev.appearance || "").length ? c : prev;
    out[name] = { ...prev, ...better, portrait: c.portrait || prev.portrait || null };
  }
  return out;
}

/**
 * The snap. Gathers what the drafter needs from storage and config, hands it
 * the page's view of the conversation, and records what it learned about the
 * scene for next time.
 */
async function draftPrompt(msg) {
  const replyText = String(msg?.replyText || "");
  try {
    const cfg = await getConfig();
    const rec = await sessionRecord(msg.sessionId);
    const sheet = rec?.sheet || { characters: {}, lore: {} };

    // The stored player message only belongs to the NEWEST reply. Snapping an
    // older one with it attached described a turn that hadn't happened yet.
    const playerMsg = msg.isLatest === false ? "" : String(rec?.lastUserMsg || "");

    const result = await Drafter.draft({
      replyText,
      thinkText: msg.thinkText || "",
      playerMsg,
      history: Array.isArray(msg.history) ? msg.history.map(String) : [],
      nexus: msg.nexus || null,
      sheet,
      memory: rec?.sceneMemory || null,
      cfg,
      llm: draftWithModel,
    });

    // Older messages must not overwrite what we know about the present.
    if (result.memory && msg.isLatest !== false) {
      dbOps.mergeSession({ sessionId: msg.sessionId, patch: { sceneMemory: result.memory } })
        .catch(() => { /* memory is a nicety */ });
    }
    delete result.memory;   // stored above; the page has no use for it
    return result;
  } catch (err) {
    console.error("[SnapScapes] draft failed, using plain fallback:", err);
    const out = Drafter.fallbackDraft(replyText, err);
    delete out.memory;
    return out;
  }
}

// ======================= LLM upgrade =======================

async function draftWithModel(text, castSheet, cfg) {
  const keys = await chrome.storage.local.get({ apiKey: "", apiKeyAnthropic: "" });
  if (cfg.condenser === "claude") {
    if (!keys.apiKeyAnthropic) return [];
    return claudeCondense(text, castSheet, cfg, keys.apiKeyAnthropic);
  }
  if (!keys.apiKey) return [];
  return llmCondense(text, castSheet, { ...cfg, apiKey: keys.apiKey });
}

async function claudeCondense(text, sheet, cfg, key) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: cfg.condenserModelClaude || "claude-haiku-4-5-20251001",
      max_tokens: 700,
      temperature: 0.4,
      system: PromptCondenser.llmInstruction(sheet),
      messages: [{ role: "user", content: String(text).slice(0, 8000) }],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    if (res.status === 401) throw new Error("Anthropic rejected the API key (401)");
    throw new Error(`Claude HTTP ${res.status}${body ? `: ${body.slice(0, 120)}` : ""}`);
  }
  const data = await res.json();
  const out = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  return PromptCondenser.parseLlmJson(out);
}

async function llmCondense(text, sheet, cfg) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.apiKey}`,
    },
    body: JSON.stringify({
      model: cfg.condenserModel,
      messages: [
        { role: "system", content: PromptCondenser.llmInstruction(sheet) },
        { role: "user", content: String(text).slice(0, 8000) },
      ],
      max_tokens: 500,
      temperature: 0.4,
    }),
  });
  if (!res.ok) throw new Error(`condenser HTTP ${res.status}`);
  const data = await res.json();
  return PromptCondenser.parseLlmJson(data.choices?.[0]?.message?.content || "");
}

// ======================= generation =======================

async function generate({ prompt, negative, reference, references, strength }) {
  const cfg = await getConfig();
  if (!prompt) throw new Error("No prompt");

  const refs = (Array.isArray(references) && references.length
    ? references
    : reference ? [reference] : []
  ).slice(0, MAX_REFS);

  switch (cfg.preset) {
    case "pollinations":
      return { dataUrl: await genPollinations(prompt, cfg), usedReference: false };
    case "a1111":
      return { dataUrl: await genA1111(prompt, negative, refs[0] || null, strength, cfg),
               usedReference: Boolean(refs[0]) };
    case "openrouter":
      return { dataUrl: await genOpenRouter(prompt, refs, cfg),
               usedReference: refs.length > 0 };
    case "openai":
      return { dataUrl: await genOpenAI(prompt, refs, cfg),
               usedReference: refs.length > 0 };
    default:
      throw new Error(`Unknown preset "${cfg.preset}"`);
  }
}

async function genPollinations(prompt, cfg) {
  const url =
    "https://image.pollinations.ai/prompt/" + encodeURIComponent(prompt) +
    `?width=${Number(cfg.width)}&height=${Number(cfg.height)}` +
    `&nologo=true&seed=${Math.floor(Math.random() * 1e9)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Pollinations returned ${res.status}`);
  const blob = await res.blob();
  if (!blob.type.startsWith("image/")) throw new Error("Pollinations returned no image");
  return blobToDataUrl(blob);
}

async function genA1111(prompt, negative, reference, strength, cfg) {
  const base = normalizeBase(cfg.endpoint || "http://127.0.0.1:7860");
  const common = {
    prompt,
    negative_prompt: negative || PromptCondenser.SD_NEGATIVE,
    width: Number(cfg.width),
    height: Number(cfg.height),
    steps: Number(cfg.steps),
  };
  const body = reference
    ? { ...common, init_images: [stripDataUrl(reference)],
        denoising_strength: clamp(Number(strength) || 0.6, 0.2, 0.85) }
    : common;
  const path = reference ? "/sdapi/v1/img2img" : "/sdapi/v1/txt2img";

  const res = await fetch(base + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Backend returned ${res.status}`);
  const data = await res.json();
  const b64 = data.images?.[0];
  if (!b64) throw new Error("Backend returned no image");
  return `data:image/png;base64,${b64}`;
}

async function genOpenAI(prompt, refs, cfg) {
  const base = normalizeBase(cfg.endpoint || "https://api.openai.com");
  const model = cfg.model || "gpt-image-1-mini";
  const size = `${Number(cfg.width)}x${Number(cfg.height)}`;
  if (!cfg.apiKey) throw new Error("No API key set — open the extension's Options page.");

  let res;
  if (refs.length) {
    const form = new FormData();
    form.append("model", model);
    form.append("prompt", prompt);
    form.append("quality", cfg.quality);
    if (refs.length === 1) {
      form.append("image", await dataUrlToBlob(refs[0]), "reference.png");
    } else {
      for (let i = 0; i < refs.length; i++) {
        form.append("image[]", await dataUrlToBlob(refs[i]), `reference-${i + 1}.png`);
      }
    }
    res = await fetch(`${base}/v1/images/edits`, {
      method: "POST",
      headers: { Authorization: `Bearer ${cfg.apiKey}` },
      body: form,
    });
  } else {
    res = await fetch(`${base}/v1/images/generations`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({ model, prompt, size, quality: cfg.quality, n: 1 }),
    });
  }

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 400 && /safety|policy|moderation/i.test(text)) {
      throw new Error("That prompt was refused by the content filter. Try rewording, or switch backend in Options.");
    }
    throw new Error(`OpenAI returned ${res.status}${text ? `: ${text.slice(0, 140)}` : ""}`);
  }
  const data = await res.json();
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) throw new Error("OpenAI returned no image");
  return `data:image/png;base64,${b64}`;
}

async function genOpenRouter(prompt, refs, cfg) {
  const model = cfg.modelOpenRouter || "google/gemini-2.5-flash-image";
  if (!cfg.apiKeyOpenRouter) {
    throw new Error("No OpenRouter API key set — open the extension's Options page.");
  }

  const body = {
    model,
    prompt,
    size: `${Number(cfg.width)}x${Number(cfg.height)}`,
    n: 1,
  };
  if (refs.length) {
    body.input_references = refs.map((url) => ({
      type: "image_url",
      image_url: { url },
    }));
  }

  const res = await fetch("https://openrouter.ai/api/v1/images", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${cfg.apiKeyOpenRouter}`,
      "HTTP-Referer": "https://dreamjourneyai.com",
      "X-Title": "SnapScapes",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 401) {
      throw new Error("OpenRouter rejected the API key (401). Check it in Options.");
    }
    if (res.status === 400 && /model/i.test(text)) {
      throw new Error(`OpenRouter didn't recognize the model "${model}". Check the slug on openrouter.ai/models.`);
    }
    throw new Error(`OpenRouter returned ${res.status}${text ? `: ${text.slice(0, 140)}` : ""}`);
  }

  const data = await res.json();
  const img = data.data?.[0];
  if (!img?.b64_json) throw new Error("OpenRouter returned no image");
  return `data:${img.media_type || "image/png"};base64,${img.b64_json}`;
}

// ======================= snap bridge =======================

async function configSummary() {
  const cfg = await getConfig();
  const keys = await chrome.storage.local.get({ apiKey: "", apiKeyOpenRouter: "" });
  const info = {
    pollinations: { label: "Pollinations", note: "free, basic quality", needsKey: false },
    a1111:        { label: "local SD",     note: "your own GPU",        needsKey: false },
    openai:       { label: "OpenAI",       note: "your API credit",     needsKey: true,
                    key: keys.apiKey },
    openrouter:   { label: "OpenRouter",   note: "your API credit",     needsKey: true,
                    key: keys.apiKeyOpenRouter },
  }[cfg.preset] || { label: cfg.preset, note: "", needsKey: false };

  return {
    preset: cfg.preset,
    bridge: cfg.bridge || "chatgpt",
    label: info.label,
    note: info.note,
    ready: !info.needsKey || Boolean(info.key),
    needsKey: Boolean(info.needsKey),
  };
}

async function noteBridgeTab(tabId, url, bridge) {
  if (!tabId) return;
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  bridgeTabs[tabId] = { url: url || "", bridge, seen: Date.now() };
  await chrome.storage.session.set({ bridgeTabs });
}

async function forgetBridgeTab(tabId) {
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  if (bridgeTabs[tabId]) {
    delete bridgeTabs[tabId];
    await chrome.storage.session.set({ bridgeTabs });
  }
}

async function tabForSession(sessionId, bridge) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  const claim = bridgeBySession[sessionId];
  if (!claim || claim.bridge !== bridge) return null;
  try { return await chrome.tabs.get(claim.id); } catch { return null; }
}

async function claimTabForSession(sessionId, tabId, bridge) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  for (const [sid, v] of Object.entries(bridgeBySession)) {
    if (v.id === tabId && sid !== sessionId) delete bridgeBySession[sid];
  }
  bridgeBySession[sessionId] = { id: tabId, bridge };
  await chrome.storage.session.set({ bridgeBySession });
}

async function claimedTabIds(exceptSessionId) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  return new Set(Object.entries(bridgeBySession)
    .filter(([sid]) => sid !== exceptSessionId)
    .map(([, v]) => v.id));
}

/** Tabs already open on this bridge, whether or not they ever said hello.
 *
 *  The extension used to know only about tabs where capture.js had run AND
 *  announced itself. A tab opened BEFORE the extension was last reloaded
 *  never ran the content script, and the announcements live in
 *  storage.session, which the browser clears on restart — so a perfectly
 *  good ChatGPT tab sitting right there was invisible and we opened another
 *  one. With host permission for the bridge domains we can simply look. */
async function queryBridgeTabs(bridge) {
  const url = BRIDGE_MATCHES[bridge] || BRIDGE_MATCHES.chatgpt;
  try {
    const tabs = await chrome.tabs.query({ url });
    return tabs.filter((t) => typeof t.id === "number");
  } catch {
    return [];   // permission not granted (or an older profile) — announcements only
  }
}

async function findLiveBridgeTab(bridge, exceptSessionId) {
  const taken = await claimedTabIds(exceptSessionId);
  const { bridgeTabs } = await chrome.storage.session.get({ bridgeTabs: {} });
  const seenAt = new Map(Object.entries(bridgeTabs)
    .filter(([, v]) => v.bridge === bridge)
    .map(([id, v]) => [Number(id), v.seen || 0]));

  // Everything the browser has open on this bridge, plus anything that said
  // hello, deduplicated. A tab we have heard from recently is the better
  // guess, so those sort first; unclaimed tabs beat someone else's.
  const ids = new Set([...(await queryBridgeTabs(bridge)).map((t) => t.id), ...seenAt.keys()]);
  const all = [...ids].map((id) => ({ id, bridge, seen: seenAt.get(id) || 0 }))
    .sort((a, b) => b.seen - a.seen);

  const order = [...all.filter((t) => !taken.has(t.id)), ...all.filter((t) => taken.has(t.id))];

  for (const t of order) {
    try {
      await chrome.tabs.get(t.id);
      return t;
    } catch {
      await forgetBridgeTab(t.id);
    }
  }
  return null;
}

chrome.tabs.onRemoved.addListener((id) => {
  forgetBridgeTab(id);
  clearSnapForTab(id).catch(() => {});
  releaseTabClaim(id).catch(() => {});
});

async function releaseTabClaim(tabId) {
  const { bridgeBySession } = await chrome.storage.session.get({ bridgeBySession: {} });
  let touched = false;
  for (const [sid, v] of Object.entries(bridgeBySession)) {
    if (v.id === tabId) { delete bridgeBySession[sid]; touched = true; }
  }
  if (touched) await chrome.storage.session.set({ bridgeBySession });
}

async function armSnap({ sessionId, prompt, returnUrl, replyText, conditions }) {
  const cfg = await getConfig();
  const snap = { sessionId, prompt, returnUrl, replyText: replyText || "",
                 conditions: conditions && typeof conditions === "object" ? { ...conditions } : {},
                 createdAt: Date.now() };
  await chrome.storage.session.set({ pendingSnap: snap });

  let tab = await tabForSession(sessionId, cfg.bridge);
  if (!tab) {
    const live = await findLiveBridgeTab(cfg.bridge, sessionId);
    if (live) {
      try {
        tab = await chrome.tabs.get(live.id);
        await claimTabForSession(sessionId, tab.id, cfg.bridge);
      } catch { tab = null; }
    }
  }
  const url = BRIDGE_URLS[cfg.bridge] || BRIDGE_URLS.chatgpt;
  if (tab) {
    await chrome.tabs.update(tab.id, { active: true });
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch { /* focus window */ }
    // A tab found by looking rather than by announcement may predate the
    // extension's last reload, so capture.js was never injected into it and
    // nothing is listening. If it doesn't answer, reload it once: the
    // content script mounts and collects the pending snap on its own.
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "snap:armed" });
    } catch {
      try { await chrome.tabs.reload(tab.id); } catch { /* leave it be */ }
    }
  } else {
    tab = await chrome.tabs.create({ url });
    await claimTabForSession(sessionId, tab.id, cfg.bridge);
  }
  if (tab?.id) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    pendingByTab[tab.id] = snap;
    await chrome.storage.session.set({ pendingByTab });
  }

  return { snap, reused: Boolean(tab), opened: true };
}

async function peekSnap(tabId) {
  const pendingSnap = await snapForTab(tabId);
  if (!pendingSnap || Date.now() - pendingSnap.createdAt > 30 * 60 * 1000) {
    return { snap: null };
  }
  const rec = await req((await store(SESSIONS, "readonly"))
    .get(pendingSnap.sessionId)).catch(() => null);
  const chars = Object.values(rec?.sheet?.characters || {});
  return {
    snap: pendingSnap,
    charName: chars.find((c) => c.role === "bot")?.name || null,
    userName: chars.find((c) => c.role === "user")?.name || null,
  };
}

async function snapForTab(tabId) {
  if (tabId != null) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    const mine = pendingByTab[tabId];
    if (mine && Date.now() - mine.createdAt <= 30 * 60 * 1000) return mine;
  }
  const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
  return pendingSnap;
}

async function clearSnapForTab(tabId) {
  if (tabId != null) {
    const { pendingByTab } = await chrome.storage.session.get({ pendingByTab: {} });
    if (pendingByTab[tabId]) {
      delete pendingByTab[tabId];
      await chrome.storage.session.set({ pendingByTab });
    }
  }
  await chrome.storage.session.remove("pendingSnap");
}

async function saveSnap({ dataUrl, sessionId, caption, tabId }) {
  const pendingSnap = await snapForTab(tabId);
  const target = sessionId || pendingSnap?.sessionId || "unfiled";

  let note = caption || pendingSnap?.replyText || "";
  if (!note) {
    const rec = await sessionRecord(target);
    note = SceneLocator.stripThinking(rec?.lastReply || "").trim();
    if (note) note = Drafter.tidyProse(PromptCondenser.stripInstructions(note, 4000));
  }

  const id = await dbOps.add({
    sessionId: target,
    dataUrl,
    meta: {
      source: "captured",
      caption: note || pendingSnap?.prompt || "",
      prompt: pendingSnap?.prompt || "",
      conditions: pendingSnap?.conditions || {},
    },
  });
  await clearSnapForTab(tabId);

  // Tell the capture toast whether the Snapscape will pick this photo up on
  // its own (follow mode) or whether an explicit "Set as Snapscape" is the
  // only way it changes (pinned/none).
  let follow = true;
  if (target !== "unfiled") {
    const scape = await dbOps.scapeInfo({ sessionId: target }).catch(() => null);
    follow = !scape || scape.mode === "follow";
  }

  return { id, sessionId: target, follow, returnUrl: pendingSnap?.returnUrl || null };
}

async function lastSession() {
  const { lastSession } = await chrome.storage.local.get({ lastSession: null });
  return lastSession || "unfiled";
}

async function snapRefSources(sessionId) {
  const rec = await req((await store(SESSIONS, "readonly")).get(sessionId)).catch(() => null);
  const out = [];
  for (const role of ["bot", "user"]) {
    const c = Object.values(rec?.sheet?.characters || {}).find((x) => x.role === role && x.portrait);
    if (c) out.push({
      id: `portrait:${role}`, kind: "portrait", role, name: c.name,
      thumbUrl: c.portrait,   // site-hosted; the chat page can render it directly
    });
  }
  // Every book reference gets its own chip, each carrying a thumbnail of its
  // actual photo. A photo picked from the album has no name worth printing —
  // captions are reply text and were cutting off mid-word — so those stay
  // numbered. A face picked from the CAST has a name, and that name was
  // being thrown away here and replaced with "Book ref", which is the one
  // case where the chip could say who it actually is.
  const AUTO_LABEL = /^(?:book ref(?: \d+)?|reference|character)$/i;
  const refs = await refsWithThumbs(sessionId);
  refs.forEach((r, i) => {
    const named = String(r.label || "").trim();
    out.push({
      id: `book:${i}`, kind: "book", index: i,
      name: named && !AUTO_LABEL.test(named)
        ? named.slice(0, 24)
        : (refs.length > 1 ? `Book ref ${i + 1}` : "Book ref"),
      thumb: r.thumb || null,
    });
  });
  return out;
}

const refPickKey = (sessionId) => `djpbSnapRefPick:${sessionId}`;

async function snapRefPicks(sessionId) {
  const sources = await snapRefSources(sessionId);
  const key = refPickKey(sessionId);
  const saved = (await chrome.storage.local.get({ [key]: null }))[key];
  return sources.map((src) => ({
    ...src,
    on: saved && typeof saved === "object" && src.id in saved
      ? saved[src.id] === true
      : src.kind === "portrait",
  }));
}

async function snapRefDataUrl(sessionId, src) {
  if (src.kind === "portrait") {
    const rec = await req((await store(SESSIONS, "readonly")).get(sessionId));
    const c = Object.values(rec?.sheet?.characters || {})
      .find((x) => x.role === src.role && x.portrait);
    if (!c) return null;
    return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
  }
  const refs = await refsOf(await req((await store(SESSIONS, "readonly")).get(sessionId)));
  const hit = refs[src.index];
  if (!hit?.blob) return null;
  return { dataUrl: await blobToDataUrl(hit.blob), name: hit.label || "Book photo" };
}

async function snapRefImage(role) {
  const { pendingSnap } = await chrome.storage.session.get({ pendingSnap: null });
  const sid = pendingSnap?.sessionId || (await lastSession());
  if (role === "bot" || role === "user") {
    const rec0 = await req((await store(SESSIONS, "readonly")).get(sid));
    const c = Object.values(rec0?.sheet?.characters || {})
      .find((x) => x.role === role && x.portrait);
    if (!c) throw new Error(role === "bot"
      ? "No character portrait on file for this chat yet"
      : "No persona portrait on file for this chat yet");
    return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
  }
  const key = `djpbSnapRef:${sid}`;
  let choice = (await chrome.storage.local.get({ [key]: null }))[key];
  if (!choice || choice.kind === "none") {
    const rec0 = await req((await store(SESSIONS, "readonly")).get(sid));
    const chars = Object.values(rec0?.sheet?.characters || {});
    const auto = chars.find((c) => c.role === "bot" && c.portrait)
      || chars.find((c) => c.portrait);
    if (auto) choice = { kind: "portrait", name: auto.name };
    else if (await dbOps.getReference({ sessionId: sid })) choice = { kind: "session" };
    else throw new Error("No portrait or reference on file for this chat yet");
  }
  if (choice.kind === "session") {
    const dataUrl = await dbOps.getReference({ sessionId: sid });
    if (!dataUrl) throw new Error("The book reference is gone");
    return { dataUrl, name: "Book ref" };
  }
  const rec = await req((await store(SESSIONS, "readonly")).get(sid));
  const c = Object.values(rec?.sheet?.characters || {})
    .find((ch) => ch.name === choice.name);
  if (!c?.portrait) throw new Error(`No portrait on file for ${choice.name}`);
  return { dataUrl: await fetchAsDataUrl(c.portrait), name: c.name };
}

// ======================= right-click capture =======================

(async () => {
  try {
    if (navigator.storage?.persist && !(await navigator.storage.persisted())) {
      const ok = await navigator.storage.persist();
      console.info("[SnapScapes] persistent storage:", ok ? "granted" : "not granted");
    }
  } catch { /* storage fallback */ }
})();

// ======================= the toolbar icon =======================

/** Clicking the extension's icon opens the album — the one thing people
 *  want to reach without snapping something first. On a Dreamjourney chat
 *  it opens in-page, over the conversation, so the reader keeps their
 *  place; anywhere else (or if the page has no listener yet) it opens the
 *  shelf in a tab, reusing the one already open rather than stacking up. */
const DJ_APP = /^https?:\/\/(www\.)?dreamjourneyai\.com\/app\//i;
const ALBUM_TAB_KEY = "albumTabId";

chrome.action.onClicked.addListener(async (tab) => {
  const sessionId = (tab?.url || "").match(/\/app\/session\/([0-9a-f-]{36})/i)?.[1] || null;

  if (tab?.id && DJ_APP.test(tab.url || "")) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "album:open", sessionId });
      return;
    } catch { /* no content script here yet — fall through to a tab */ }
  }
  await openAlbumTab(sessionId);
});

async function openAlbumTab(sessionId) {
  const url = chrome.runtime.getURL("browse.html") +
    (sessionId ? `?session=${encodeURIComponent(sessionId)}` : "");
  const { [ALBUM_TAB_KEY]: known } = await chrome.storage.session.get({ [ALBUM_TAB_KEY]: null });
  if (known) {
    try {
      await chrome.tabs.update(known, { active: true, url });
      const t = await chrome.tabs.get(known);
      try { await chrome.windows.update(t.windowId, { focused: true }); } catch { /* focus */ }
      return;
    } catch { /* it was closed */ }
  }
  const created = await chrome.tabs.create({ url });
  await chrome.storage.session.set({ [ALBUM_TAB_KEY]: created.id });
}

chrome.runtime.onInstalled.addListener(() => {
chrome.contextMenus.create({
    id: "djpb-save-image",
    title: "Save image to photobook",
    contexts: ["image"],
  });
});

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== "djpb-save-image" || !info.srcUrl) return;
  try {
    const dataUrl = info.srcUrl.startsWith("data:")
      ? info.srcUrl
      : await fetchAsDataUrl(info.srcUrl);
    await saveSnap({ dataUrl, sessionId: null, caption: "" });
  } catch (err) {
    console.warn("[SnapScapes] Right-click save failed:", err.message);
  }
});

// ======================= helpers =======================

async function fetchAsDataUrl(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return blobToDataUrl(await res.blob());
}

function normalizeBase(endpoint) {
  return String(endpoint)
    .replace(/\/+$/, "")
    .replace(/\/v1\/images\/(generations|edits)$/i, "")
    .replace(/\/sdapi\/v1\/(txt2img|img2img)$/i, "")
    .replace(/\/v1$/i, "")
    .replace(/\/+$/, "");
}

function stripDataUrl(dataUrl) {
  const i = dataUrl.indexOf(",");
  return i >= 0 ? dataUrl.slice(i + 1) : dataUrl;
}

function clamp(n, lo, hi) {
  return Math.min(hi, Math.max(lo, n));
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(binary);
}