# SnapScapes v2.0.0

## SnapScapes2.1 color theme merge

This build starts from SnapScapes2.1 (extension v0.37.1) and incorporates the
backdrop color theme from the older DJBook build. The current album designs,
reference controls, Snap buttons, image capture, and other current features
remain in place.

With a backdrop active, its colors tint the chat bubbles, input bar, Snap
button, and extension menus. Click **Scape** to open the appearance controls:

- **Color theme:** switch backdrop-based colors on or off (default on). Off
  restores the default colors while keeping the backdrop, effects, and chat
  opacity. It also removes the colored fill and sweeping generation shine
  across the message input panel. The setting is remembered after refreshing
  or changing chats.
- **Horizontal Position:** move the backdrop crop left or right (default 50%).
- **Chat Box Opacity:** adjust the chat gradient from 0% to 90% (default 35%).
- **Color Vibrancy Boost:** adjust the sampled colors from 10% to 400%
  (default 180%). Disabled while Color theme is off; its saved value is kept.

Each slider also accepts a typed percentage. Preferences are remembered for
the DreamJourney site in the same browser profile. **Turn backdrops off** is
in this menu; turning Scape off or leaving a chat removes the theme. Pinned
backdrops still have an **Unpin image** action. The donor's separate avatar
and logo relocation changes are not part of this merge.

To update, extract this ZIP and copy the contents of its **DJBook** folder over
the files in your existing extension folder. In `chrome://extensions`, click
**Reload** on the existing extension, then refresh DreamJourney. Keep the
existing installation so its stored albums and settings remain available.

## Version 2.0

The version number restarts here. Everything below was released as 0.4x
and 0.5x; the extension is the same one, and nothing in it depends on the
number — no migrations, no gates, no stored version checks. The backup
file's own `"version": 2` field is unrelated and unchanged.

Chrome only requires a version to *increase*, and 2.0.0 is higher than
0.54.0, so updates behave normally. Going the other way later would not
work, so this is a one-time move.

## Roses, on black (v2.0)

Roses now comes in a dark ground: the same cover, ribbon, corners and
painted blooms, over black instead of blush. It is not a new binding —
choose it from the **Ground** row in the Design sheet, which appears only
when Roses is the binding, and it is remembered per album. The blooms are
repainted for the dark page (the ground is painted in, not layered), and
an exported book opens in whichever ground the album was in.

## Housekeeping

The in-page album panel that `content.js` built — a toggle at the corner of
the chat, a gallery, a lightbox, a reference bar, a generate form — has
been hidden by stylesheet since v0.8.0, when the album moved into the
overlay. It was still being built on every page, invisibly: five hundred
lines of DOM that nobody could see, three hundred lines of styles for it,
and two database operations only it called (`getPortraits`, `setCaption`),
plus two more nothing at all called (`remove`, `getReference` in the
proxy). All gone. `content.js` is down to the two things it actually does:
relaying the intercepted payload to the worker, and the generating glow.
The rules for the long-retired Nexus tab went with them.

Nothing user-visible changes. The album, the overlay, the toolbar icon and
the Snap card are untouched, and the database is not.

## Small fixes

**New chapters landed at the back of the book.** A chapter was stamped
with the moment you made it, and pages are ordered by timestamp — so on an
album you had been keeping for months, every chapter sorted after every
photograph already in it. The button says "Start a new chapter here", and
now it means it: the chapter takes a moment just before the page you are
looking at and lands in front of it. Pressing it on the title or cast page
puts the chapter at the head of the story.

Chapters already stranded at the back can be removed (the control is at the
top-left of a chapter page) and made again on the page where they belong.

**Large photographs came out blocky.** The mount around every photograph
carried `filter: drop-shadow(...)`, and a CSS filter rasterises its whole
subtree at a fixed resolution — so a big picture was downsampled into that
raster and displayed blocky, while a smaller one fit and looked fine. That
is why re-saving the same image at a smaller size "fixed" it, which is what
gave the cause away. Every shadow on a photograph is a `box-shadow` now:
no raster, and on a rectangular photo the same picture. Six rules in total,
across the themes and the frame styles.

**Photographs also looked blocky, then sharp when you clicked about, then
blocky again.** The page carried `backface-visibility: hidden` as a standing rule,
which promotes it to its own composited layer for as long as it is on
screen. A promoted layer is rasterised once — and after a page turn, which
scales and rotates it, Chrome kept the raster it had made for the
animation, so a photograph sat there at animation resolution until
something forced a repaint. Interacting with the page repainted it and it
went sharp; settling down brought the stale raster back. The flip still
gets the hint while it is turning; a page at rest no longer does.

**Chapter pictures are sized to the room they have.** After the frame was
made to follow the picture's own shape, a small source — a crop you had
re-saved, say — sat at its natural size with the rest of the page empty
beneath it, because nothing scaled it up any more. The picture is now sized
per image: as wide as 80% of the page or as tall as its slot, whichever it
reaches first, at its own proportions, and re-fitted when the window
changes.

**Chapter pictures kept the same 2:1 frame whatever their shape.** The
slot was a fixed box — 80% wide, 42% tall — with `object-fit: cover`, so a
tall picture was cropped to a wide one and everything came out looking
alike. The mount and its border belong to the image now, which keeps its
own proportions; and because a tall picture takes more of the page than a
wide one ever did, the slot gives space back when the page is tight rather
than pushing the chapter's note off the foot of it.

**A chapter picture came out tiny.** Whether the slot showed its dashed
"choose a picture" placeholder was decided by `ch.photoId`, which only
covers the older way of pointing at one of the album's own photographs — a
picture you choose from your own computer is stored elsewhere. So the slot
stayed styled as empty after you filled it, and the image was crushed into
the middle of the placeholder's padding. The slot also now has a real box
to fill, rather than only a maximum height, so the picture covers it
properly.

**"Remove chapter" was hiding under the Favorites ribbon.** The control sat
at the top-right of a chapter page, the ribbon hangs at the same corner
with a higher stacking order, and on a narrow book the silk lay straight
across it — half the words hidden, the near half unclickable. It sits at
the top-left now, where nothing else on a chapter page does. (The
favourite heart already dodges the ribbon by sitting at the foot of the
page; this was the one control that had never been moved out of its way.)

It still only appears when your pointer is over the page, which is
deliberate — losing a chapter you wrote to a stray click would be worse
than the extra moment it takes to find it.

## Save an album as a book (v2.0)

**👁 Save as web page** on the shelf now writes the actual book: the
binding, the cast pages, the chapters, the folio numbers, the fonts, and
pages you turn with the arrows, the keyboard or a swipe. One HTML file,
nothing installed, works offline forever. The old export was a scroll of
framed photos with captions and threw the book away.

The pages are rendered by the reader's own `renderPage`, then serialised —
so the book in the file is the book on screen by construction, rather than
a second renderer that drifts. Editable fields become the text you typed,
controls are stripped, and every image is inlined.

**You choose the size, and are told what it costs first.** Base64 adds
about a third on top of the photos, so a long album can make a very large
file. Web quality (1400px, ~190KB a photo) looks the same on a screen and
is small enough to send; full quality (2600px) is there for printing or
zooming right in. Past 20 photographs the dialog says larger files are slow
to write and open; past 60 it names the likely size — a 120-photo album is
about 31MB at web quality and 144MB at full — and says plainly which one to
pick. The estimate is shown beside each option before you commit, not after
a four-minute wait.

Two things caught on the first real export: the book takes its size from
script in the reader (`fitBook`), which a static file doesn't have, so it
collapsed to a single visible page with nothing to turn — the exported
file now sizes itself and carries its own ‹ 3 of 24 › controls. And the
cast page came out empty, because in the reader a portrait, a name and a
note are each a `<button>`, and stripping the controls stripped the
content with them. Buttons that hold content are turned into plain
elements now; only the controls go. Long captions scroll instead of being
cut off at the foot of the page.

It is a keepsake, not a working copy: no editing, no favouriting, no
Snapscapes, no shelf. Backup remains the way to move albums between
machines. A print stylesheet is included, so the browser's Save as PDF
gives one page per sheet.

## Colour theme, reworked (v0.53) — by Taiga

The palette pulled from a Snapscape is much better at finding the colour a
picture is actually *about*. Saturated pixels are weighted far above flat
ones, greys are pushed down, and warm and red tones — which the old
sampling kept losing — are given room. Muddy oranges are lifted out of
brown into a clean orange rather than being sampled as sludge.

Two new sliders in the Scape menu:

- **Vibrancy** — how hard the extracted colours are pushed. Low keeps the
  picture's own muted tones; high gives a bolder theme.
- **Gradient balance** — slides the theme between its two colours, so you
  can favour one end of the gradient over the other.

Chat Box Opacity now goes all the way to fully opaque. (The stored value
already allowed it, but a live slider drag was still clamped just short —
so the top of the slider disagreed with itself until you reloaded. Fixed.)

Message toolbar buttons pick up the theme's accent, with a matching glow on
hover — but only while the colour theme is **on**. Those rules are drawn
from the extracted palette, and with the theme off the palette variables
fall back to our own violet and pink, which turned the site's refresh and
delete buttons pink for anyone simply running a Snapscape. Theme off now
means the site keeps its own buttons, and the toggle takes effect at once.

Like the rest of the colour theme, all of this is skipped when Nebula is
styling the chat, unless you turn the theme on yourself.

## Adding a photo lands on the photo (v0.52.2)

**＋ Add photos** used to set the bookmark to page 9999 and reopen the
book. That clamps to the last page — the back pocket — so you were dropped
*past* your new photograph and had to turn back to write under it. It now
turns to the photograph itself, and puts the cursor in the caption line,
which is the reason you are on that page. Adding several at once starts you
on the first; the rest follow as you turn.

The filename is no longer used as the caption. "IMG_2049" was something to
delete before you could write, and a picture that came out of ChatGPT
carries a worse name than that.

## Renamed to SnapScapes (v0.52)

The extension, its options page, the album's masthead and the console
prefix all say SnapScapes now.

**Keep the folder name.** The folder in this zip is still `DJBook` on
purpose. Chrome derives an unpacked extension's ID from the absolute path
of its folder, and the ID is the origin that owns the IndexedDB database
and extension storage. Load from a *new* path and Chrome treats it as a
different extension: empty shelf, no albums, no saved casts, no settings.
Nothing is destroyed — the old data is still there under the old ID — but
the only way back is to load the old folder again. So: replace the files
inside the folder you already use, and press Reload. Do not extract to a
new folder, and do not rename it.

Nothing underneath moved, deliberately: the database is still
`dj-photobook`, backup files still carry the
`dreamjourney-photobook-backup` format tag, and the `djpb-` element
prefixes, storage keys and message types are unchanged. Renaming any of
those would orphan every album already saved and make existing backup
files unreadable. They are data, not branding.

## The toolbar icon opens your album (v0.51)

There was no way to reach the shelf without snapping something first — the
📖 button lives in the Snap card, which you only see after a snap. The
extension had no toolbar icon at all (no `action` in the manifest), so
that was the obvious empty spot.

Clicking it now opens the album. On a Dreamjourney chat it opens **in
page**, over the conversation, so you keep your place — and pressing it
again puts it away. Anywhere else it opens the shelf in a tab, reusing the
tab it opened last time instead of stacking up new ones. If the page hasn't
finished loading the extension yet, it falls back to the tab rather than
doing nothing.

The extension also has proper icons now, where before Chrome drew a grey
placeholder: a closed book on the Snap pill's own violet-to-pink gradient,
with a small scape — hills under a low sun — on its cover. A closed book
reads better than an open one at toolbar size, because the dark spine
beside the pale cover is a shape that survives being sixteen pixels wide.
The 16px version drops the cover art and keeps only that spine and two
page rules; the larger sizes carry the full picture.

## Clicking a text box no longer turns the page (v0.50.1)

Turning was triggered by any click near the page's left or right edge that
*missed a control*. The ruled area around a caption box and the space
beside the inscription both counted, so aiming at a text box flipped the
page unless you hit its middle. Only the page's own blank margin turns now,
and nothing turns while you have something on the page focused for editing.

Because that leaves less margin to aim at, the ‹ › arrows are click targets
again — the glyphs themselves, not the full-height edge, which is what used
to swallow clicks meant for the favourite heart and the photo controls.

## Saved casts (v0.50)

A cast belongs to an album, but the people don't — someone running a dozen
scenarios in the same world was re-adding the same faces to every new book.
**⌸ Saved casts…** on the first cast page keeps this album's cast under a
name of your choosing (portraits, notes and all), and drops any saved cast
into any other album.

Loading **adds, never replaces**: anyone already on this album's cast by
name is left exactly as they are, so a portrait or note you set here can't
be clobbered by an older copy of that character. Blank rows you had already
started get filled before new ones are added. Each saved cast can be
updated from the current album, renamed by saving again, or forgotten —
forgetting it leaves the characters in every album they were added to.

Saved casts live in extension storage rather than in any one album, so they
outlive the books they came from. They are not yet included in the shelf's
Backup file, which covers albums only; that is worth doing next.

## Loose icons on a laptop (v0.49.1)

A screenshot from a Chromebook showed the Snap camera floating above the
composer and the Scape icon below the message box, both as bare circles.
Two faults:

- **"Narrow" was measuring height.** The test was
  `Math.min(innerWidth, innerHeight) < 820`, so a short viewport counted —
  and a Chromebook's display scaling puts plenty of laptops at about
  1536x730. A full-width screen was getting the phone layout. It now asks
  whether this is a phone, or whether the window is genuinely narrow;
  height says nothing about how much room a row has.
- **The phone layout docked beside the wrong button.** It took the first
  button in the composer, which is Options in the top-left corner, and put
  the camera before it. It now finds the send control properly — and checks
  the `type` *attribute*, since `button.type` reports "submit" for every
  button in a form by default, which would have picked Options again. On a
  phone, Scape lands beside the pill instead of being appended under the
  message box.

## It stops opening a second ChatGPT tab (v0.49)

"Send to ChatGPT" kept opening a new tab even with ChatGPT already sitting
open. The extension could only reuse tabs it had *heard from*: `capture.js`
announces itself when it loads, and those announcements live in
`storage.session`. So a tab opened before the extension was last reloaded
never ran the content script and was invisible, and a browser restart wiped
the list even though the tab was still there.

It now also *looks*, via `chrome.tabs.query` — which needs host permission
for the bridge domains, so `chatgpt.com`, `chat.openai.com`, `grok.com` and
`gemini.google.com` are declared in `host_permissions`. That is not new
access: `capture.js` already runs on all four. A reused tab that never ran
the content script is reloaded once so it mounts and collects the pending
snap; a tab that answers is left alone. Announcements are still used to
prefer the most recently seen tab, and if the permission is somehow absent
the old announcement-only behaviour still works.

**A note on the bridge, while we are here.** OpenAI's terms say you may not
"automatically or programmatically extract data or Output". Saving a
generated image off the page is exactly that, however small the scale. The
extension never sends a prompt for you and never saves without a click, and
every other route to the album — Pollinations, the OpenAI API, OpenRouter,
A1111, ＋ Add photos, the back pocket — is unaffected. Use those if the
distinction matters to you.

## Snap and Scape sit beside the site's own buttons (v0.48.6 – .7)

The site mounts its **Nexus button a beat after the composer renders**. It
joins the right-hand group, and because that group is right-aligned,
everything already in it slides left to make room — which is why Scape
jumped while Snap, over in the left group, did not.

Both now dock **in the row, immediately after the site's left-hand group**,
with Scape following Snap so their order never swaps. That is where they
started out. (0.48.6 put them *inside* that group, which wrapped the
composer onto a second line on layouts where the group is narrow — hence
.7.) Appending to the end of the row is what exposed them to the late Nexus
shift, and it isn't done anywhere now.

## The composer stops jittering (v0.48.5)

Reported with both other extensions off, so this one was ours. Three
faults, each feeding the next:

- **The row finder took the wrong element.** v0.46 looked for an ancestor
  containing *every* labelled button, but the site groups them (options and
  nexus together, the rest elsewhere), so the only element holding all of
  them is the whole composer — and appending there dropped our buttons
  below the row and wrapped it. It now anchors on one button and takes the
  outermost ancestor that isn't the form, which is the row itself.
- **Shape tests made the answer unstable.** Whether a candidate "looked
  like a row" depended on its measured width and height, so a row that
  wrapped, re-rendered or animated changed the answer between ticks and the
  buttons moved. There is no shape test now.
- **A momentary zero height read as "collapsed".** The site rebuilds the
  composer often; during a rebuild the row measures nothing. We un-docked,
  which mutated the DOM, which caused another render. A zero now has to
  persist before it is believed.

On top of that, a button already sitting in a usable row is left alone
rather than re-parented to an equally valid one, and the Scape button
follows the Snap pill's decision instead of making its own — so the two
can't take turns moving each other.

## Cast references wear their own name (v0.48.4)

Picking a face through **＋ Character** already stored that character's
name with the reference — the Snap card just threw it away and printed
"Book ref" on every chip. It now keeps the name, so a cast reference reads
"Rhysand" instead of "Book ref 2". Photos picked from the album stay
numbered: their only label would be the reply text they were captioned
with, which cuts off mid-word and makes two chips look identical.

## The prompt box resizes again (v0.48.3)

Some readers could not drag the Snap prompt taller and others could, on the
same browser. The card is a column flex container with a max height, and
flex items shrink by default — so once the card's contents reached that cap,
dragging the handle grew the box and flex squashed it back in the same
frame. Whether you hit it came down to window height (70vh on a laptop is
about 560px) and how much was in the card that day: add reference chips or
the details bar and a machine that worked stops working. Nothing in the card
shrinks now — it scrolls, which is what the card is for — the box starts
taller, the cap is more generous on short windows, and the height you drag
it to is remembered for next time (clamped, so a size chosen on a big
monitor can't swallow a laptop's card).

## Index, a bigger cast, one Snapscape control (v0.48)

**☷ Index.** A new button in the reader's toolbar opens a sheet over the
book: every page as a tile with its picture and page number, chapters as
headings that split the grid into sections, the title and cast pages up
front, The End and the back pocket at the tail, and the page you're on
outlined. Click a tile to turn straight to it; Esc or click outside to
close. It's a sheet rather than pages in the book because a long album's
index would itself be a dozen pages to flip through. Thumbnails reuse the
album's own object URLs, lazy-loaded, so a 400-photo album opens it fast.
Favourites view indexes favourites only. The page-number jump box and the
contents list on The End page are unchanged.

**The cast grows past six.** The "Add a character…" row only appeared while
the last cast page had room, so a full page of six left no way to start
page seven even though the paging (i, ii, iii…) was all there. A full page
now shows a compact "＋ Add another…" beside the folio; adding from it
starts the next page and turns to it.

**Empty cast pages clean themselves up (v0.48.1).** "Add another" has to
create a blank entry for you to fill in, and a blank entry was enough to
keep a whole cast page alive forever. Entries with no name, no note and no
portrait are now dropped when you leave the cast section — turning past it,
jumping elsewhere, opening the index, or going back to the shelf — and the
destination page shifts by however many pages that removed, so "turn to the
first photograph" still lands on the first photograph. Moving *between*
cast pages prunes nothing: the blank row you just made is the one you're
about to fill in. Individual characters still have their own ✕.

**Remove a cast page (v0.48.2).** Each cast page's folio line carries a
faint "✕ Remove page" that takes the whole leaf out — it names who is on it
and confirms first, and photographs are untouched. Clearing six characters
one ✕ at a time was a chore, and once a page's people were gone there was
no other way to be rid of it. The pages after it shuffle up.

**One way to control Snapscapes.** The album's toolbar "🌄 Backdrop:
newest snap / pinned / off" button duplicated the chat's 🌄 Scape button
and the Snap card's "Always update Snapscape" switch, so it's gone. The
per-photo pin stays — it's the only way to choose an *older* photo — and
now says "Set as Snapscape" to match the rest of the extension.

## Leaner fallback prompt (v0.47.1)

The built-in prompt (chats without a SNAP thinking template) now leads with
"Create an image of this moment." and goes straight to Context, Location
and the scene lines. Gone: the per-character "Right now:" poses (clauses
glued together by pronoun guesswork; the movement already lives in Context,
which is built from whole sentences), "(the player)" after the persona's
name, and the Characters list by default — reference images carry the
faces. The card's **Appearance** toggle, now off by default, brings the
Characters block back with names and card looks for the Generate routes
that send no references. Context also no longer repeats the same beat
twice when the interaction pass and the moment sentence describe it in
different words.

## Aster (v0.47)

Aster is a good neighbour: it styles only its own panels and its MAIN-world
`fetch` wrapper (thinking-template override, message exclusions) wraps ours
rather than replacing it, so we see each request as it actually goes out.
Three small things, all handled on our side:

- Aster's **"Remove thinking"** button sits inside a message's markdown.
  It is excluded from text extraction like Nebula's elements are, so it
  can't leak into a prompt.
- Aster's **tool panel** is fixed top-right at the maximum z-index. When it
  is open and would cover the Snap card, the card steps left of it — the
  same manoeuvre it already does for the site's Nexus drawer.
- Aster's `djt-*` elements are never scanned as toolbars or messages.

Also: **no camera in the reroll pager.** The "‹ 2/2 › ✓" row that appears
while paging regenerations is a row of icon buttons, so the toolbar
heuristic adopted it and put a camera there. It's skipped now; cameras
stay in the message toolbar and the Snap pill is unchanged.

Not possible from our side: reading Aster's downloaded Nexus snapshot
(separate extension storage, no messaging API), or protecting the SNAP
template from an Aster thinking-template override that omits it.

## Nebula, and the site's real selectors (v0.46)

**Placement now uses the site's own hooks first**, with the old shape-based
heuristics kept only as a fallback: `div[id^="message-"]` is a message,
`div[data-sentry-element="ThinkingProcess"]` is the thinking widget,
`form.chatform` is the composer, and the docking row is found by
`aria-label="Open Memory Nexus"` / `"Open chat options"` rather than button
text (which Nebula's icon-only mode hides). Cameras and the pill should land
in the same place every time.

**Coexisting with Nebula.** Nebula owns the surface — fonts, bubbles, the
composer — and we own the floor: the picture behind the page and the
effects. Detection is DOM-only (Nebula's `#djai-custom-styles` is in
`<head>` when it's on); there is no shared storage between extensions.
While Nebula is on:

- The **colour theme defaults off** and is remembered separately for Nebula
  users (`djpb_color_theme_nebula`). Nebula keeps its bubbles and composer.
  Turning the theme on in the Scape menu still overrides Nebula, by choice.
- The chat-opacity and default-composer repaints are skipped, since those
  are Nebula's to paint.
- Nebula's near-opaque body wash — which sat between the page and our
  backdrop and hid every Snapscape — goes transparent **only while a
  Snapscape is showing**. Nebula's wallpaper stays behind ours; the moment
  the Snapscape is off, Nebula's look returns exactly as configured. Our own
  scrim and Chat Box Opacity slider do the dimming.
- Nebula's global font rules (`* { font-family !important }` and 14px/300
  on every div/p/span) no longer restyle the Snap card, Details and Scape
  panels; those are pinned to a plain system face. The pill and cameras are
  deliberately left to dress like the rows they sit in.
- Nebula's own elements (collapse toggle, feedback buttons, volume widget,
  character counter) are never scanned as toolbars or messages. If Nebula's
  collapse toggle folds the composer's options row, the pill steps out and
  floats instead of vanishing with it.

**v0.46.1 — no more jiggling when Nebula's font size changes.** Two loops.
Nebula watches `<html>`'s `style` attribute and rebuilds its whole
stylesheet (remove, re-add 100ms later) on any change; we were rewriting
our CSS variables there even when unchanged, and during Nebula's 100ms gap
our detection read "Nebula off", flipped mode, and wrote the variables
again. Now `<html>` is only written when a value actually changes, and
"Nebula off" has to persist 1.5s before we believe it. Separately, both
dock finders rejected any composer row taller than 140px — a big font
wrapped the row past that, our buttons were pulled out, the row shrank,
they were put back, every 2 seconds. The row is now identified by the
site's labelled buttons with no height test, and snap.js's finder is
shared with backdrop.js so the two buttons can never disagree.

Independently of Nebula: the site paints a bot's own background picture as
`.bg-overlay::before` from `var(--bg-image)`. While a Snapscape is on, that
picture is hidden so the two never fight; off, it returns. We never set
`--bg-image` ourselves — the site owns it.

## Where the scene is (v0.45)

The built-in prompt (the one used when a chat has no SNAP thinking template)
kept naming the wrong room. Three things caused it: the plot's opening scene
was used as a last resort, so "the market square at noon" appeared twenty
chapters later; the first place-phrase in the reply won, so "walked through
the forest… stepped into the cave" gave forest; and furniture counted as a
place ("on the table"). The scene reader is now its own module, `scene.js`,
and reads sources newest-first until one answers:

1. `WHERE:` in the thinking block — unchanged, still wins outright.
2. The reply itself: the LAST arrival ("stepped into", "led her into",
   "pulled up outside") beats the last plain "in the <place>". Dialogue,
   memories ("that night in the tavern"), hypotheticals and negations
   ("not in the library") are ignored, and furniture is not a place.
   Named places ("the Rusty Nail Tavern") and lorebook location entries are
   recognised and keep their proper name.
3. The player's own last message — only when snapping the newest reply.
4. The previous few replies on screen, newest first.
5. Scene memory: every send records where the story was, so the fallback
   is at most one turn stale (the Nexus panel runs 3–7 behind and is never
   read for location).
6. Nothing. No Location line is written rather than a wrong one.

The card says when a location was carried from an earlier reply. A location
pinned in Details now REPLACES a carried guess and refines one read from the
reply. Time of day no longer fires on "dark hair"; the last mention wins.

The drafting pipeline moved out of `background.js` into `draft.js` as six
named steps (read the turn → cast → people → scene → moments → assemble) and
`sheet.js` is card and lorebook parsing only. Removed: the never-sent
`condense` message, `listAll`/`listSessions`/`getSheet` ops, the unused
`tags` field on drafts, `extraRefs`, `hasTemplate`, the old keyword weather
table, and the no-op Nexus tab code. Fixed a use-before-declare error that
silently dropped poses from LLM-drafted candidates, and a lorebook entry
named "The …" being indexed under the word "the".

## Existing features

Everything from the approved feature map that doesn't require the site's
message DOM. Unzip over your extension folder (or load this folder fresh at
`chrome://extensions` → Load unpacked) and reload.

Nothing needs an API key. A fresh install generates via Pollinations
immediately, and "Send to ChatGPT" uses your existing subscription.

## What's in it

**The data layer (A1–A4, A7).** A MAIN-world script watches the site's own
`/api/chat` send and reads the body — character card, persona, lorebooks,
plot — once per message you send. History is stripped inside the page before
anything is stored; only the newest reply is kept, for the album's paste
button. The sheet builds itself: appearance from the card's `## Appearance`
section, `{{char}}`/`{{user}}` filled, portraits from the card art, album
title and cover from the plot. Hand edits to a sheet survive re-intercepts.

**The snap (B2, B3, most of B4).** A 📷 Snap pill sits above the 📖 toggle.
Click it: the newest reply is read, `WHO:`/`WHERE:`/`NOW:` mined from its
thinking block, the top 2–3 visual moments offered as chips, and the full
prompt assembled into one editable box. Three routes: **Generate** (backend
from Options), **Send to ChatGPT** (copies the prompt, arms the capture,
opens the tab — you paste and send, the image saves itself with a "back to
chat" link), and **Copy**. 📎 chips put each character's portrait on the
clipboard as an image for reference-pasting. Pure-dialogue replies fall back
to the `NOW:` line so a snap never comes back empty.

**The album (D1–D6, D7).** Open `browse.html` (link in Options). A shelf of
leather-bound books — covers from each plot's art, titles embossed, a photo
count, dust on albums untouched for a month. Open one: marbled endpaper with
the cast's portraits mounted and named, then one photo per page — a fixed
hand-mounted tilt, date stamp — with your note beneath in script on ruled
lines, autosaved, with **Paste latest reply**.
Pages turn in 3D; the fore-edge stack thins as you read; a ribbon bookmark
returns you to where you left off; arrow keys and swipe both work. Inside
the back cover, a paper sleeve holds unfiled right-click captures — click
one to mount it in this album. All of it reads IndexedDB directly: no photos
travel through messages anymore.

**Saving from ChatGPT.** Nothing is ever saved without a click. When a fresh
image finishes rendering, the bridge toast shows a **thumbnail** of it with a
**♥ Save to photobook** button; the button stays disabled until the image has
stopped changing, so a click can't grab a half-drawn frame. If the thumbnail
shows the wrong picture, ◀ ▶ step through the other fresh candidates — or
just wait, since the generation becomes the newest candidate when it lands.
Images inside a *user* turn (the references we pasted, echoed back by the
site) are never candidates at all: that is DOM position, not pixel
similarity, so a generation derived from its own reference can't be mistaken
for it.

**References from the album.** The Snap card's reference row takes up to four
photos. **＋ Album photo** (which now shows how many slots are used, e.g.
*2/4*) drops a strip of this chat's newest photos into the card — tap one and
it becomes a reference and switches on in the same motion; **tap it again to
remove it**. Photos in use wear a numbered badge that matches their chip, and
a header line counts the slots. Every chip — portraits and book refs alike —
now carries a **thumbnail of its actual photo**, and hovering a chip pops a
larger preview, so "Book ref 1" vs "Book ref 2" is never a guess. Thumbnails
are made once in the worker (192px JPEG) and cached on the reference, so the
card stays fast. Removing a ref now also re-keys the saved on/off states and
renumbers auto labels, so the remaining photos keep *their own* settings
instead of inheriting a neighbour's. The album's own "Use as ref" button was removed in v0.37.1 — references are picked from the Snap card, and the button was clutter inside the book. Each book chip still has a **×**, and
**📖 Photo Album** still opens the full album for browsing.

**Snapscapes (the chat backdrop).** The **"Always update Snapscape with new
gens"** checkbox lives in the Snap card, on by default. *On*, the backdrop
follows your newest photo per chat. *Off*, the current backdrop is pinned and
a **🖼 Set as Snapscape** button appears with each new result — in the Snap
card after Generate, and in the ChatGPT toast after a save. It maps onto the
album page's pin control's three states (follow / pinned / none), so the two
surfaces can never disagree.

**Composer flattening fix (v0.37.5).** Turning the Scape colour theme off
switches on `html.djpb-default-theme`, which flattens the chat composer. That
flattening was also erasing DreamJourney's own "generating" shine — the
animated sweep on the composer that is the only sign a reply is coming — via
`animation: none`, `border-image: none`, blanket `::before/::after {content:
none}`, and a catch-all that cleared empty absolute overlays around the form.
The block now forces only the composer's base colour, using `background-color`
rather than the `background` shorthand (which resets background-image), so any
image, animation, border-image, pseudo-element or overlay the site paints
survives. The bar still reads flat and dark when idle; the shine returns
during generation.

**Dramatis Personae (v0.44).** A cast page as front matter, sitting straight
after the title page — its position isn't a choice, the way a book's cast list
isn't. Six characters to a page at the title page's own plate size, spilling
onto as many pages as the cast needs (numbered i, ii, iii). Each is a portrait
uploaded from the reader's machine (downscaled on the way in), a name, and a
PRIVATE note — a reminder of who somebody is, never sent to an image
generator, because "the antagonist, betrayed Rhys in chapter two" would only
confuse a picture. None of it exists until the first character is added, and
favourites view hides it. In the Snap card, **＋ Character** opens the cast and
picking a face attaches that portrait as an ordinary reference, feeding the
same four slots as everything else rather than adding a parallel system.

**Chapters, endings and a shelf that talks (v0.39).** Books now stand SPINE OUT, the way they do
on a real shelf — the spine is its own object with raised bands and gilt
lettering, and the cover is only seen once the book is pulled. (v0.39.0 added
spine lettering but left the books face-on, so the text just overlapped the
covers.) Spine thickness grows with an album's photo count on a curve
(capped, so a 400-photo book doesn't eat the shelf), and the spine letters
the title in three tiers — a fat book gets two lines, a medium one a single
line truncated at a WORD boundary, and a thin book just a foil initial with
the title on hover. Nothing is lost to truncation since the full title is on
the cover. Clicking a book pulls it off the shelf to face you; a second click
opens it, clicking away or Escape shelves it, and double-click skips the
ceremony. **Chapter pages** are markers carrying their own timestamp, so they
sort into the same run as the photographs — "start a chapter here" just drops
one at now, and numbering derives from position so deleting one renumbers the
rest. Each has a name, one photograph chosen from the album, and a line at the
foot. **The End** adds a last page with the tally (photographs, chapters, when
begun, how long it took) and a clickable contents list; it reads "Or is it?"
at the foot and can be lifted again, because people finish an album and then
keep playing. Favourites view hides both — it's a filter, not the story. The
page counter is also now a jump box: click it, type a page.

**After Hours.** v0.37: the faint window grid is gone from the front page —
it read as graph paper against the neon — replaced by a single large pink
sign-glare behind the title with a cold cyan counter-glow low right, the
rest falling into black. Inside, the white diagonal rain streaks are gone
(they read as scratches, not weather); the neon gutter tube, street dots and
light pollution stay. Notes now sit in a NEON FRAME built with the
gradient-border technique from the user's card CSS: the ::after paints a
gradient across the box and a two-layer mask (padding-box + border-box,
composited with intersect) punches out the middle so only the border keeps
it. Recoloured to the binding's cyan-to-pink, full brightness, glow spilling
onto the page. Static — the source's cursor-following lens is left out.

**Roses.** v0.36 replaced the front page. The old one used a garland composed
here in code — a ring of small blooms at fixed positions — which read as
scattered blobs. It is now a SINGLE bloom drawn by the flower pen itself at
feature size, sitting in the lower-right corner so the page edge crops it,
on clean blush paper with room for the title and cast. The interior art is
untouched: the pen's own scatter, exactly as written. Notes there now sit on
the same frosted vellum slip Watercolor uses, so the art reads through
instead of being boxed out.

**The ribbon.** v0.34 gave every binding its own silk. Two hardcoded colours
used to leak through the theme system: the base ribbon faded into a plum
maroon (#5e1531) at the foot, and pulling it out swapped in a bright pink
(#d4487a) — so Deepwood ended in maroon and Emberfall flashed pink. Both are
gone. Each binding now declares its full background stack (Classic's twin
brass rules on oxblood, Arcana's amethyst fade with moon-silver rules,
Punk's black with a scream-red spine band, Aurora's aurora light running
down the length, Deepwood's grosgrain centre band, Emberfall charred-to-
ember, Red Flags' gold keylines, After Hours' neon tubes, Watercolor's
drifting wash, Roses' pink-to-plum), and `.active` simply brightens whatever
the binding is wearing. The word sits higher and larger (13.5px, up from 11px; After Hours keeps its
16px script). The earlier attempt to raise it barely moved because Chrome
vertically centres a button's content by default — the ribbon is a
<button>, so the word was being auto-centred in the silk regardless of its
margin. Explicit flex alignment (align-items: flex-start) is what actually
puts it near the head, and it reads "Favorites" with
the capital — an `uppercase` transform had been flattening it.

**The cast plate.** The dramatis personae portraits on the front page wear a
FIXED treatment, deliberately independent of the frame dial: loose photos
wear Kraft/Instant/Spray, the cast always wears its binding's own corners.
Each portrait is a square plate that crops (rather than letterboxes) the
image — which is also the bug fix: with `object-fit: contain` the `<img>` box
stayed wide while the visible picture shrank inside it, so corners anchored
to empty space instead of to the photograph. Corners now scale with the
plate instead of sitting at a fixed 26px. Per binding: brass pockets
(Classic), gold keyline with violet corner stars (Arcana), keyline-only in
each binding's own metal (Punk, Aurora, Deepwood), charred corners
(Emberfall), gold L-brackets (Red Flags), pink-and-cyan neon clips (After
Hours), and the Classic pocket recoloured per corner in the pens' own hues
(Watercolor, Roses). Clicking a portrait now opens it full-size.

**Album design.** 🎨 Design sets three things per album. *Binding* re-skins
the whole book through the variable system. v0.30 reshaped the roster:
Grimoire is now **Classic** (the old neutral default retired into it); Noir
and Sunny were retired, their slots taken by two *painted* bindings —
**Watercolor** and **Roses** — whose page backgrounds are generated once per
album by the two canvas pens supplied by the user (WaterColor blob engine;
arc-petal flower scatter), cached on the album, and never repainted: every
book is a one-off still. Their shelf covers wear the album's own painting
behind a linen scrim. v0.35 softened Watercolor: the pigment is diluted at
the source (lower alpha per pass — genuinely more water, not a pale film
over a bold painting), a bloom-out clears the middle of the page so writing
has paper to sit on while full colour stays at the borders where the pen
bleeds from, and notes sit on a frosted vellum slip that the wash still
reads through. Cached paintings carry an ART_VERSION so existing albums
repaint at the new dilution instead of keeping the old heavy pigment. Each
painted album also gets its own painted
FRONT PAGE: a second, distinct composition from the same pen — a title-page
wash for Watercolor, a bloom garland for Roses — bordering the endpaper and
leaving the centre clear for the cast. **Vendetta became Punk**: same id (saved albums keep
their clothes), same red-and-black cover and endpapers, but the interior
pages are now midnight-rock newsprint — hairline magazine rules, one
scream-red gutter rule, a barcode at the page foot, a lowercase typewriter
date. A new universal frame joins the dial: **Spray paint**, the
turbulence-displaced graffiti frame, available to every binding. Stored
themes migrate automatically (default→Classic, Sunny→Watercolor,
Noir→Roses). Gothic Romance became **Aurora** in v0.32
(same id, saved albums migrate seamlessly): the rose window and moths are
gone, replaced by a fantasy night galaxy built from the user's starfield
code — mardi-gras purple, white-smoke stars in layered cream halos (baked
static, never shimmering), a glowing crescent moon in every page's margin
and hung large over the endpaper sky, with the room lit by the code's own
elliptical gradient. The remaining roster — Arcana, Deepwood,
Emberfall — and two
bindings drawn from Eurielle's Gallery pages: **Red Flags** (oxblood pages
with a static blood vignette, gold corner ticks, a fading gold gutter rule
with the thorned heart at its centre, thorn stars near the fore-edge, black
oxblood calf cover with gold-tooled ticks) and **After Hours** (night-glass
pages with corner light pollution, static rain, a pink neon tube wired down
the gutter, street dots at the fore-edge, a wet-glass cover with a neon
title — and the favourites ribbon re-skinned as a vertical neon sign, same
element and behaviour, new material). *Handwriting*
picks the note face. *Frames* chooses how a photograph is mounted: kraft
corners, instant film, gilded, filmstrip, washi tape or postage — each a
different physical object rather than a recoloured border. Instant film
writes the date on its own chin (and the page's rubber stamp steps aside);
the filmstrip prints a frame number. The ❏ button under any photo overrides
the album's choice for that page alone, cycling through the six and back to
"Album frame". Both the album default and the per-photo overrides travel in
backups.

**Fixes (E1, E2).** Options requests permissions *before* any await, so the
gesture bug is gone; migration claims a flag before copying, so two open tabs
can't duplicate your photos; the API key lives in `storage.local`; the dead
branch in `onNavigate` is removed.

## Still needs the site's DOM (deferred, by design)

- **Per-message 📷 buttons and true inline results (B1/B4).** The pill snaps
  the *latest* reply using a heuristic (innermost big text blocks, then climb
  to swallow the thinking fence). If it grabs the wrong element, set an exact
  selector once and it's used forever:
  `chrome.storage.local.set({ djpbMessageSelector: ".their-message-class" })`
- **Lorebook entries (A5).** `indexLorebooks` handles the three likely shapes
  but it's unverified until `lorebooks[0]` is expanded. Side characters show
  "(no description on file)" until then — the line is editable in the box.
- **Generation queue (B5)** and sheet accretion (A6) — next round.

## First-run checklist

1. Load the extension, open a chat, **send one message** — that first send is
   what populates the sheet.
2. Hit 📷 Snap. Check the assembled prompt names your characters correctly.
3. Try Generate (Pollinations) once, then the ChatGPT route once.
4. Open the album from Options and turn some pages.
5. Hit 🎨 Design and try a binding and a frame; then ❏ under a photo to give
   that one page its own mounting.

## File inventory

`manifest.json` · `intercept.js` (MAIN world) · `background.js` ·
`condense.js` · `scene.js` · `sheet.js` · `draft.js` · `snap.js` + `snap.css` · `capture.js` ·
`content.js` + `content.css` + `db.js` (v0.4, patched) · `backdrop.js` ·
`zoom.js` · `keyboard.js` · `mobile.js` ·
`browse.html/css/js` (rebuilt) · `fonts/` (bundled Alex Brush for the Handwritten pack) · `options.html/js` (rebuilt)
