// browse.js — the album.
//
// This page shares the extension origin with the service worker, so it opens
// the same IndexedDB directly: no photos travel through messages (the v0.4
// browse page shipped every image as base64 — this reads blobs and hands the
// <img> an object URL, which is the difference between instant and seconds).
//
// Page model per album:
//   0            endpaper (cast portraits)
//   1..N         one photo per page
//   N+1          back pocket (unfiled loose photos)

(() => {
  const DB_NAME = "dj-photobook";
  const DB_VERSION = 3;

  const $ = (id) => document.getElementById(id);
  const urlCache = new Map(); // image id -> object URL, revoked on album close
  const extraUrls = [];       // one-off object URLs (title image), same lifecycle

  // Each album picks its world. The variables cascade from body[data-theme]
  // in the reader and from .book-cover[data-theme] on the shelf.
  const THEMES = [
    ["grimoire", "Classic"],
    ["arcana", "Arcana"],
    ["vendetta", "Punk"],
    ["gothic", "Aurora"],
    ["forest", "Deepwood"],
    ["ember", "Emberfall"],
    ["redflags", "Red Flags"],
    ["afterhours", "After Hours"],
    ["watercolor", "Watercolor"],
    ["roses", "Roses"],
  ];
  // Retired bindings map onto their replacements so no stored album ever
  // loses its clothes: the old neutral default and Grimoire are now one
  // binding called Classic; Sunny's slot went to Watercolor and Noir's to
  // Roses; Vendetta kept its id (saved albums!) and became Punk.
  const LEGACY_THEMES = { default: "grimoire", scrapbook: "watercolor", noir: "roses" };
  const normTheme = (t) => LEGACY_THEMES[t] || t || "grimoire";
  // Each album picks its world. The variables cascade from body[data-theme]
  // in the reader and from .book-cover[data-theme] on the shelf.
  // Six ways to mount a photograph — each a different physical object, not a
  // border colour. Per-album default, per-photo override (rec.frame).
  const FRAMES = [
    ["corners",  "Kraft corners"],
    ["instant",  "Instant film"],
    ["gilded",   "Gilded"],
    ["film",     "Filmstrip"],
    ["spray",    "Spray paint"],
    ["plate",    "Illuminated plate"],
    ["borealis", "Borealis"],
    ["pact",     "Pact plate"],
    ["sign",     "Lit sign"],
    ["bloom",    "Pressed bloom"],
  ];
  // Washi tape and Postage were retired. Their stored ids still arrive from
  // albums saved before this version, so they map forward instead of falling
  // through to the default — nobody's photo silently changes dress.
  const LEGACY_FRAMES = { tape: "plate", stamp: "bloom" };
  const normFrame = (f) => LEGACY_FRAMES[f] || f || "corners";
  // Each binding has a signature mount. A brand-new album wears its
  // binding's frame; once you pick one yourself, your choice sticks.
  const THEME_FRAME = {
    grimoire: "plate", gothic: "borealis", redflags: "pact",
    afterhours: "sign", roses: "bloom",
  };
  const frameLabel = (id) => (FRAMES.find(([f]) => f === normFrame(id)) || FRAMES[0])[1];

  const applyTheme = (t) => {
    if (!t || t === "default") delete document.body.dataset.theme;
    else document.body.dataset.theme = t;
    applyShade(album?.shade);
  };
  /** Light or dark ground for a binding that offers both. Roses is the only
   *  one so far: the same blooms over black instead of blush. */
  const applyShade = (sh) => {
    if (sh === "dark") document.body.dataset.shade = "dark";
    else delete document.body.dataset.shade;
  };
  const FONTS = [
    ["default", "Theme's pick"],
    ["hand", "Handwritten"],
    ["print", "Print"],
    ["typewriter", "Typewriter"],
    ["elegant", "Elegant"],
    ["marker", "Marker"],
  ];
  const applyFont = (f) => {
    if (!f || f === "default") delete document.body.dataset.font;
    else document.body.dataset.font = f;
  };

  let db = null;
  let album = null;   // {sessionId, title, photos[], sheet, lastReply, unfiled[]}
  let pageIndex = 0;
  let turning = false;
  let favoritesOnly = false;

  // ---------- storage ----------

  function openDb() {
    return new Promise((resolve, reject) => {
      const r = indexedDB.open(DB_NAME, DB_VERSION);
      r.onupgradeneeded = () => {
        // Mirror the worker's schema exactly, in case this page runs first.
        const d = r.result;
        if (!d.objectStoreNames.contains("images")) {
          const s = d.createObjectStore("images", { keyPath: "id", autoIncrement: true });
          s.createIndex("bySession", "sessionId", { unique: false });
        }
        if (!d.objectStoreNames.contains("sessions")) {
          d.createObjectStore("sessions", { keyPath: "sessionId" });
        }
      };
      r.onblocked = () =>
        reject(new Error("the SnapScapes database is busy in another tab"));
      r.onsuccess = () => {
        r.result.onversionchange = () => r.result.close();
        resolve(r.result);
      };
      r.onerror = () => reject(r.error);
    });
  }

  const req = (r) => new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

  const tx = (name, mode = "readonly") => db.transaction(name, mode).objectStore(name);

  function photoUrl(rec) {
    if (!urlCache.has(rec.id)) urlCache.set(rec.id, URL.createObjectURL(rec.blob));
    return urlCache.get(rec.id);
  }

  function releaseUrls() {
    for (const url of urlCache.values()) URL.revokeObjectURL(url);
    urlCache.clear();
    for (const url of extraUrls) URL.revokeObjectURL(url);
    extraUrls.length = 0;
  }

  // ---------- shelf ----------

  async function renderShelf() {
    releaseUrls();
    album = null;
    favoritesOnly = false;
    applyTheme("default"); // the room is neutral; each cover wears its own
    applyFont("default");
    $("reader").hidden = true;
    $("shelf").hidden = false;

    const [images, sessions] = await Promise.all([
      req(tx("images").getAll()),
      req(tx("sessions").getAll()),
    ]);

    const byId = new Map();
    for (const r of images) {
      const a = byId.get(r.sessionId) || { sessionId: r.sessionId, count: 0, latest: 0, coverRec: null };
      a.count += 1;
      if ((r.createdAt || 0) >= a.latest) { a.latest = r.createdAt || 0; a.coverRec = r; }
      a.byId = a.byId || new Map();
      a.byId.set(r.id, r);
      byId.set(r.sessionId, a);
    }
    for (const s of sessions) {
      const a = byId.get(s.sessionId);
      if (!a) continue; // a sheet with no photos yet isn't a book on the shelf
      a.title = s.customTitle || s.album?.title || s.sheet?.album?.title || null;
      a.cover = s.album?.cover || null;
      a.coverId = s.coverId || null;      // a photo the user picked
      a.theme = normTheme(s.theme);
      a.pageArt = s.pageArt || null;
      a.blurb = s.blurb || "";
      a.coverBlob = s.coverBlob || null;   // an image the user supplied
    }

    const row = $("shelf-row");
    row.innerHTML = "";
    const albums = [...byId.values()]
      .filter((a) => a.sessionId !== "unfiled")
      .sort((x, y) => y.latest - x.latest);

    $("shelf-empty").hidden = albums.length > 0;

    /** Slide a book off the shelf and turn it to face the reader. Clicking
   *  anywhere else — or Escape — puts it back in its own slot. */
  function pullOut(slot) {
    for (const c of document.querySelectorAll(".book-slot.pulled")) {
      if (c !== slot) c.classList.remove("pulled");
    }
    slot.classList.add("pulled");
    document.getElementById("shelf-row")?.classList.add("has-pulled");
  }
  function shelveAll() {
    for (const c of document.querySelectorAll(".book-slot.pulled")) c.classList.remove("pulled");
    document.getElementById("shelf-row")?.classList.remove("has-pulled");
  }
  document.addEventListener("click", (e) => {
    if (!document.querySelector(".book-slot.pulled")) return;
    if (!e.target.closest(".book-slot.pulled")) shelveAll();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && document.querySelector(".book-slot.pulled")) {
      e.stopPropagation();
      shelveAll();
    }
  });

  const MONTH = 30 * 24 * 3600 * 1000;
    for (const a of albums) {
      const cover = document.createElement("div");
      cover.className = "book-cover" + (Date.now() - a.latest > MONTH ? " dusty" : "");
      cover.dataset.theme = a.theme;
      // Watercolor and Roses covers show the album's own cached painting
      // behind a linen scrim, so every book on the shelf is one of a kind.
      if (a.pageArt?.dataUrl && a.pageArt.theme === a.theme) {
        const scrim = a.theme === "roses"
          ? "linear-gradient(rgba(253, 246, 242, 0.58), rgba(253, 246, 242, 0.78))"
          : "linear-gradient(rgba(252, 250, 244, 0.6), rgba(252, 250, 244, 0.8))";
        if (a.theme === "watercolor" || a.theme === "roses") {
          cover.style.background = `${scrim}, url("${a.pageArt.dataUrl}") center / cover`;
        }
      }

      // The whole board opens the album, except the intro strip, which edits.
      // A <button> can't legally contain another, so the hit target is its own
      // layer underneath rather than a wrapper around everything.
      const hit = document.createElement("button");
      hit.className = "cover-hit";
      hit.type = "button";
      hit.setAttribute("aria-label", `Open ${a.title || "this album"}`);

      // A book is boards + spine + a page block, not a rectangle with a
      // picture on it. These three carry the object; the rest is printing.
      const spine = document.createElement("span");
      spine.className = "cover-spine";
      spine.setAttribute("aria-hidden", "true");

      const pages = document.createElement("span");
      pages.className = "cover-pages";
      pages.setAttribute("aria-hidden", "true");

      const plate = document.createElement("span");
      plate.className = "cover-plate";   // the recess the photograph sits in

      const art = document.createElement("img");
      art.className = "cover-art";
      art.alt = "";
      // Prefer the plot's background art; fall back to the newest photo.
      // Priority: the photo the user chose, then the site's own cover art,
      // then whatever arrived most recently.
      // Priority: an image the user supplied, then a photo they picked from
      // the album, then the site's own art, then the newest photo.
      const chosen = a.coverId && a.byId ? a.byId.get(a.coverId) : null;
      if (a.coverBlob) {
        const u = URL.createObjectURL(a.coverBlob);
        extraUrls.push(u);
        art.src = u;
      } else {
        art.src = chosen ? photoUrl(chosen)
                         : (a.cover || (a.coverRec ? photoUrl(a.coverRec) : ""));
      }

      const title = document.createElement("span");
      title.className = "cover-title";
      title.textContent = a.title || `Session ${a.sessionId.slice(0, 8)}`;

      const count = document.createElement("span");
      count.className = "cover-count";
      count.textContent = `${a.count} ✦`;

      // A line in the owner's own words. Two albums from the same character
      // look identical on the shelf; this is what tells them apart.
      const blurb = document.createElement("button");
      blurb.className = "cover-blurb" + (a.blurb ? "" : " empty");
      blurb.type = "button";
      blurb.textContent = a.blurb || "Add a note…";
      blurb.title = "Click to describe this album";
      blurb.addEventListener("click", (e) => {
        e.stopPropagation();
        editBlurb(a, blurb);
      });

      plate.appendChild(art);
      cover.append(hit, spine, pages, title, plate, blurb, count);

      /* --- the book as an object on a shelf ---------------------------
         Thickness grows with the photo count on a curve, so a well-fed
         album is visibly fat while a 400-photo one doesn't eat the shelf.
         The spine carries the title, but only if it can hold it: a thin
         book gets an initial, a fat one gets two lines. Nothing is lost
         to truncation — the full title is on the cover you pull out. */
      const thickness = Math.round(14 + 40 * (1 - Math.exp(-a.count / 26)));
      cover.style.setProperty("--thick", `${thickness}px`);
      // Books stand spine-out like a real shelf. The spine is its own object,
      // not a strip painted on the front of the cover — the cover is only
      // seen once the book is pulled.
      const shelfSpine = document.createElement("button");
      shelfSpine.type = "button";
      shelfSpine.className = "shelf-spine";
      shelfSpine.style.setProperty("--thick", `${thickness}px`);
      // a little height variation so the row isn't a picket fence
      const hVar = 88 + ((a.sessionId.charCodeAt(0) + a.count * 7) % 11);
      shelfSpine.style.setProperty("--spine-h", `${hVar}%`);
      shelfSpine.setAttribute("aria-label", `${a.title || "Album"} — ${a.count} photographs`);
      const spineText = document.createElement("span");
      spineText.className = "spine-text";
      const full = a.title || `Session ${a.sessionId.slice(0, 8)}`;
      // Roughly how many characters this spine's height can carry.
      const fits = thickness >= 30 ? 34 : thickness >= 18 ? 22 : 0;
      if (!fits) {
        spineText.classList.add("initial");
        spineText.textContent = full.trim().charAt(0).toUpperCase();
      } else if (full.length <= fits) {
        spineText.textContent = full;
      } else {
        // cut at a word boundary, never mid-word
        const cut = full.slice(0, fits);
        const space = cut.lastIndexOf(" ");
        spineText.textContent = (space > fits * 0.5 ? cut.slice(0, space) : cut).trim() + "…";
      }
      if (thickness >= 34) spineText.classList.add("wide");
      spineText.title = full;

      const bands = document.createElement("span");
      bands.className = "spine-bands";
      bands.setAttribute("aria-hidden", "true");
      const foot = document.createElement("span");
      foot.className = "spine-foot";
      foot.textContent = String(a.count);
      shelfSpine.append(bands, spineText, foot);

      // One click pulls the book out and turns it to face you; a second
      // opens it; clicking away puts it back. Double-click skips the
      // ceremony for people who just want the album.
      // Spine: pull the book out. Cover (once out): open it.
      shelfSpine.addEventListener("click", (e) => {
        e.stopPropagation();
        pullOut(slot);
      });
      shelfSpine.addEventListener("dblclick", (e) => {
        e.stopPropagation();
        openAlbum(a.sessionId);
      });
      hit.addEventListener("click", (e) => {
        e.stopPropagation();
        if (slot.classList.contains("pulled")) openAlbum(a.sessionId);
      });

      // Wrapper, because a delete control can't legally nest inside a button.
      const slot = document.createElement("div");
      slot.className = "book-slot";
      const del = document.createElement("button");
      del.className = "book-del";
      del.type = "button";
      del.textContent = "✕";
      del.title = "Delete this album";
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        const name = a.title || `Session ${a.sessionId.slice(0, 8)}`;
        const ok = await askConfirm({
          title: `Delete “${name}”?`,
          body: a.count === 1
            ? "This removes the album and its one photo."
            : `This removes the album and all ${a.count} photos in it.`,
          warn: "This can't be undone. Save the album to a file first if you want to keep it.",
          yes: "Delete album",
        });
        if (!ok) return;
        const store = tx("images", "readwrite");
        for (const rec of images.filter((r) => r.sessionId === a.sessionId)) {
          await req(store.delete(rec.id));
        }
        // The session record holds the title, theme and cast — clear it too.
        await req(tx("sessions", "readwrite").delete(a.sessionId)).catch(() => {});
        renderShelf();
      });
      const pick = document.createElement("button");
      pick.className = "book-cover-btn";
      pick.type = "button";
      pick.textContent = "🖼";
      pick.title = "Choose this album's cover image";
      pick.setAttribute("aria-label", `Choose a cover image for ${a.title || "this album"}`);
      pick.addEventListener("click", (e) => {
        e.stopPropagation();
        chooseCover(a);
      });

      slot.style.setProperty("--thick", `${thickness}px`);
      // the spine is a sibling of the cover, so the binding's leather vars
      // have to live on the slot for it to inherit them
      slot.dataset.theme = a.theme;
      slot.append(shelfSpine, cover, pick, del);
      row.appendChild(slot);
    }
  }

  /** An in-page replacement for confirm().
   *
   *  Two reasons it isn't the native one: Chrome blocks alert/confirm/prompt
   *  inside cross-origin frames, and the album opens as an extension frame
   *  over the chat — so in the overlay the native call returns false without
   *  ever asking, and the delete silently did nothing. This also lets a
   *  destructive answer look destructive.
   *
   *  Cancel takes focus, so a stray Enter keeps the photos. */
  function askConfirm({ title, body, warn, yes = "Delete", no = "Keep it", alt = null, danger = true }) {
    return new Promise((resolve) => {
      const wrap = $("confirm");
      const yesBtn = $("confirm-yes");
      const noBtn = $("confirm-no");
      const altBtn = $("confirm-alt");
      altBtn.hidden = !alt;
      if (alt) altBtn.textContent = alt;
      $("confirm-title").textContent = title;
      $("confirm-body").textContent = body || "";
      $("confirm-body").hidden = !body;
      $("confirm-warn").textContent = warn || "";
      $("confirm-warn").hidden = !warn;
      yesBtn.textContent = yes;
      noBtn.textContent = no;
      yesBtn.classList.toggle("danger", danger);

      const finish = (answer) => {
        wrap.hidden = true;
        yesBtn.onclick = noBtn.onclick = altBtn.onclick = wrap.onclick = null;
        document.removeEventListener("keydown", onKey, true);
        resolve(answer);
      };
      const onKey = (e) => {
        if (e.key === "Escape") { e.stopPropagation(); finish(false); }
      };

      yesBtn.onclick = () => finish(true);
      altBtn.onclick = () => finish("alt");
      noBtn.onclick = () => finish(false);
      wrap.onclick = (e) => { if (e.target === wrap) finish(false); };
      document.addEventListener("keydown", onKey, true);

      wrap.hidden = false;
      noBtn.focus();
    });
  }

  /** Any image the user likes, not only a photo already in the album. Stored
   *  as a blob on the session record so it survives backup and restore like
   *  everything else. Downscaled on the way in: a cover is shown at 200px, so
   *  a 12MP phone photo would be dead weight in every backup from then on. */
  async function chooseCover(a) {
    const has = Boolean(a.coverBlob);
    const answer = await askConfirm({
      title: `Cover for “${a.title || "this album"}”`,
      body: has
        ? "Pick a different image, or go back to using a photo from the album."
        : "Pick any image from your computer. It replaces the photo currently shown on this book.",
      yes: "Choose an image…",
      no: "Cancel",
      alt: has ? "Use an album photo" : null,
      danger: false,
    });
    if (answer === "alt") {
      const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
      await req(tx("sessions", "readwrite")
        .put({ ...(prev || {}), sessionId: a.sessionId, coverBlob: null }));
      renderShelf();
      return;
    }
    if (answer !== true) return;

    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const blob = await shrinkForCover(file);
        const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, coverBlob: blob }));
        renderShelf();
      } catch (err) {
        console.warn("[SnapScapes] cover failed:", err);
      }
    };
    input.click();
  }

  /** Covers are displayed at 200px wide in a 4:3 window. 900px on the long
   *  edge is generous for a retina screen and keeps the file small. */
  async function shrinkForCover(file) {
    const bmp = await createImageBitmap(file);
    const cap = 900;
    const scale = Math.min(1, cap / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
    bmp.close?.();
    const out = await new Promise((r) => canvas.toBlob(r, "image/jpeg", 0.88));
    return out && out.size < file.size ? out : file;
  }

  /** Kept short on purpose: it has to read at cover size, and a paragraph
   *  would swallow the art it sits under. */
  const BLURB_MAX = 200;

  function editBlurb(a, btn) {
    const box = document.createElement("textarea");
    box.className = "cover-blurb-edit";
    box.value = a.blurb || "";
    box.maxLength = BLURB_MAX;
    box.rows = 3;
    box.placeholder = "A line to tell this album apart…";

    let done = false;
    const save = async () => {
      if (done) return;
      done = true;
      const text = box.value.trim().slice(0, BLURB_MAX);
      if (text !== (a.blurb || "")) {
        const prev = await req(tx("sessions").get(a.sessionId)).catch(() => null);
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, blurb: text }));
        a.blurb = text;
      }
      box.replaceWith(btn);
      btn.textContent = a.blurb || "Add a note…";
      btn.classList.toggle("empty", !a.blurb);
    };

    box.addEventListener("keydown", (e) => {
      e.stopPropagation();               // arrow keys page the book otherwise
      if (e.key === "Escape") { done = true; box.replaceWith(btn); }
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); save(); }
    });
    box.addEventListener("click", (e) => e.stopPropagation());
    box.addEventListener("blur", save);

    btn.replaceWith(box);
    box.focus();
    box.select();
  }

  // ---------- album ----------

  async function openAlbum(sessionId) {
    const switchingAlbum = !album || album.sessionId !== sessionId;
    if (switchingAlbum) favoritesOnly = false;
    const [photos, sessionRec, unfiled] = await Promise.all([
      req(tx("images").index("bySession").getAll(IDBKeyRange.only(sessionId))),
      req(tx("sessions").get(sessionId)),
      req(tx("images").index("bySession").getAll(IDBKeyRange.only("unfiled"))),
    ]);
    photos.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

    album = {
      sessionId,
      photos,
      unfiled,
      sheet: sessionRec?.sheet || null,
      lastReply: sessionRec?.lastReply || "",
      titleBlob: sessionRec?.titleBlob || null,
      endNote: sessionRec?.endNote || "",
      theme: normTheme(sessionRec?.theme),
      pageArt: sessionRec?.pageArt || null,
      chapters: Array.isArray(sessionRec?.chapters) ? sessionRec.chapters : [],
      cast: Array.isArray(sessionRec?.cast) ? sessionRec.cast : [],
      endedAt: sessionRec?.endedAt || null,
      coverId: sessionRec?.coverId || null,
      backdropId: sessionRec?.backdropId || null,
      font: sessionRec?.font || "default",
      shade: sessionRec?.shade === "dark" ? "dark" : "light",
      frame: sessionRec?.frame
        ? normFrame(sessionRec.frame)
        : (THEME_FRAME[normTheme(sessionRec?.theme)] || "corners"),
      title: sessionRec?.customTitle || sessionRec?.album?.title
        || sessionRec?.sheet?.album?.title || `Session ${sessionId.slice(0, 8)}`,
    };

    applyTheme(album.theme);
    ensurePageArt(album).catch(() => {});
    applyFont(album.font);
    $("shelf").hidden = true;
    $("reader").hidden = false;
    requestAnimationFrame(fitBook);   // measure once the reader is laid out

    const { [`djpbBookmark:${sessionId}`]: saved } =
      await chrome.storage.local.get({ [`djpbBookmark:${sessionId}`]: 0 });
    pageIndex = Math.min(saved || 0, pageCount() - 1);

    renderPage($("page-live"), pageIndex);
    updateChrome();
  }

  const visiblePhotos = () => favoritesOnly
    ? album.photos.filter((rec) => rec.favorite === true)
    : album.photos;

  /** The book's page sequence. Chapter markers carry their own timestamp and
   *  sort into the same run as the photographs, so "start a chapter here"
   *  just drops a marker at now — no reordering machinery, and deleting one
   *  renumbers the rest for free because the number comes from position.
   *  Favourites view hides chapters: it isn't the story, it's a filter. */
  function pageItems() {
    const photos = visiblePhotos().map((rec) => ({ kind: "photo", at: rec.createdAt || 0, rec }));
    if (favoritesOnly) return photos;
    const chapters = (album.chapters || []).map((ch) => ({ kind: "chapter", at: ch.at || 0, ch }));
    const all = [...photos, ...chapters].sort((a, b) => a.at - b.at);
    let n = 0;
    for (const it of all) if (it.kind === "chapter") it.number = ++n;
    return all;
  }
  const storyEnded = () => !favoritesOnly && Boolean(album.endedAt);

  /* --- front matter -------------------------------------------------
     The cast sits straight after the title page, the way a book's
     dramatis personae does — its position isn't a choice, unlike a
     chapter's. Six to a page, spilling onto as many pages as it needs.
     None of it exists until a character is added, so a small album
     isn't carrying blank pages. Hidden in favourites view, which is a
     filter rather than the book. */
  const CAST_PER_PAGE = 6;
  const castList = () => (favoritesOnly ? [] : (album.cast || []));
  const castPages = () => Math.ceil(castList().length / CAST_PER_PAGE);
  /** Page index of the first photograph/chapter — everything after the
   *  title page and the cast. Every jump target is measured from here. */
  const itemOffset = () => 1 + castPages();
  // title page + cast pages + items + (the end) + back pocket
  const pageCount = () => itemOffset() + pageItems().length + (storyEnded() ? 2 : 1);

  function updateChrome() {
    const photos = visiblePhotos();
    const n = pageCount();
    $("page-count").textContent =
      pageIndex === 0 ? (favoritesOnly ? `♥ FAVORITES · ${photos.length}` : album.title.toUpperCase())
      : pageIndex === n - 1 ? (favoritesOnly ? "END OF FAVORITES" : "BACK POCKET")
      : (pageIndex < itemOffset()) ? "DRAMATIS PERSONAE"
      : (storyEnded() && pageIndex === itemOffset() + pageItems().length) ? "THE END"
      : (pageItems()[pageIndex - itemOffset()]?.kind === "chapter")
        ? `CHAPTER ${roman(pageItems()[pageIndex - itemOffset()].number)}`
        : `${pageIndex - itemOffset() + 1} / ${pageItems().length}${favoritesOnly ? " ♥" : ""}`;
    // The ribbon IS the favourites tab now — a bookmark you can actually
    // pull on, rather than a button competing with it for the same idea.
    const favCount = album.photos.filter((r) => r.favorite).length;
    const ribbon = $("ribbon");
    ribbon.classList.toggle("active", favoritesOnly);
    ribbon.dataset.count = favCount || "";
    ribbon.title = favoritesOnly
      ? "Back to the whole album"
      : favCount ? `${favCount} favourite${favCount === 1 ? "" : "s"}` : "Heart a photo to start a favourites page";

    // Fore-edge thins as you read through the book.
    const remaining = Math.max(0, n - 1 - pageIndex);
    $("fore-edge").style.width = `${Math.min(12, 3 + remaining * 1.6)}px`;

    $("ribbon").hidden = false;   // always reachable: it is the tab, not a marker
    $("edge-prev").disabled = pageIndex === 0;
    $("edge-next").disabled = pageIndex === n - 1;
    chrome.storage.local.set({ [`djpbBookmark:${album.sessionId}`]: pageIndex });
  }

  // ---------- pages ----------

  function renderPage(host, index) {
    host.innerHTML = "";
    const inner = document.createElement("div");
    inner.className = "page-inner";

    const items = pageItems();
    const off = itemOffset();
    const endAt = storyEnded() ? off + items.length : -1;
    if (index === 0) renderEndpaper(inner);
    else if (index === pageCount() - 1) renderPocket(inner);
    else if (index < off) renderCastPage(inner, index - 1);
    else if (index === endAt) renderEndMatter(inner, items);
    else {
      const it = items[index - off];
      if (it?.kind === "chapter") renderChapterPage(inner, it);
      else renderPhotoPage(inner, it?.rec);
    }

    host.appendChild(inner);
  }

  const ROMAN = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X",
    "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX"];
  const roman = (n) => ROMAN[n] || String(n);

  /** A chapter divider. Auto-numbered from its position, named by the owner,
   *  with one photograph from the album and a line at the foot. */
  const WORDS = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven",
    "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen",
    "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty"];
  const words = (n) => WORDS[n] || String(n);

  function renderChapterPage(inner, item) {
    inner.classList.add("chapterpage");
    const ch = item.ch;

    const lab = document.createElement("div");
    lab.className = "ch-lab";
    lab.textContent = "Chapter";

    const big = document.createElement("div");
    big.className = "ch-big";
    big.textContent = words(item.number);

    const rule = document.createElement("div");
    rule.className = "ch-rule";
    rule.innerHTML = '<i></i><b>\u2726</b><i></i>';

    const title = document.createElement("button");
    title.className = "ch-title" + (ch.title ? "" : " empty");
    title.type = "button";
    title.textContent = ch.title || "Name this chapter…";
    title.title = "Click to rename";
    title.addEventListener("click", () => editChapterField(ch, title, "title", "Name this chapter…"));
    inner.append(lab, big, rule, title);

    // A picture chosen from the reader's machine lives in ch.img; ch.photoId
    // is the older form, pointing at one of the album's own photographs. The
    // placeholder used to be decided by photoId alone, so a picture you chose
    // yourself left the slot styled as empty — dashed border, placeholder
    // padding — and the image was crushed into the middle of it.
    const legacy = ch.photoId ? album.photos.find((p) => p.id === ch.photoId) : null;
    const src = ch.img || (legacy ? photoUrl(legacy) : null);

    const pic = document.createElement("button");
    pic.className = "ch-pic" + (src ? "" : " empty");
    pic.type = "button";
    if (src) {
      const img = document.createElement("img");
      img.src = src;
      img.alt = "";
      pic.appendChild(img);
      // Size the picture to the room it has, at its own proportions: as wide
      // as 80% of the page or as tall as the slot, whichever it reaches
      // first. CSS alone can't do "fill the slot without letterboxing" for
      // an image whose ratio isn't known until it loads — max-width and
      // max-height stop a big picture overflowing but leave a small one at
      // its natural size, which after re-saving a crop was postage-stamp
      // sized with the rest of the page empty beneath it.
      const fit = () => {
        const W = pic.clientWidth, H = pic.clientHeight;
        if (!W || !H || !img.naturalWidth || !img.naturalHeight) return;
        const r = img.naturalWidth / img.naturalHeight;
        img.style.width = `${Math.round(Math.min(W * 0.8, H * r))}px`;
        img.style.height = "auto";
      };
      if (img.complete && img.naturalWidth) fit(); else img.addEventListener("load", fit, { once: true });
      if (typeof ResizeObserver === "function") {
        const ro = new ResizeObserver(fit);
        ro.observe(pic);
      }
    } else {
      pic.textContent = "＋ choose a picture";
    }
    pic.title = "Choose a picture from your computer";
    pic.addEventListener("click", () => pickChapterPhoto(ch));
    inner.appendChild(pic);

    // The body fills the foot of the page — a paragraph, not a caption.
    const body = document.createElement("button");
    body.className = "ch-body" + (ch.note ? "" : " empty");
    body.type = "button";
    body.textContent = ch.note || "Write something about this chapter…";
    body.addEventListener("click", () => editChapterField(ch, body, "note", "Write something about this chapter…"));

    const foot = document.createElement("div");
    foot.className = "ch-foot";
    foot.textContent = `\u2014 ${roman(item.number)} \u2014`;

    // Removing a chapter is deliberate: the control only appears on hover,
    // and it asks first. Losing a chapter you wrote to a stray click would
    // be worse than the extra step.
    const del = document.createElement("button");
    del.className = "ch-del";
    del.type = "button";
    del.textContent = "Remove chapter";
    del.title = "Remove this chapter page";
    del.addEventListener("click", async (e) => {
      e.stopPropagation();
      const ok = await askConfirm({
        title: `Remove Chapter ${roman(item.number)}?`,
        body: ch.title ? `“${ch.title}” will be taken out of the book.`
                       : "This chapter page will be taken out of the book.",
        warn: "The photographs stay in the album — only the chapter page goes. "
            + "Later chapters renumber themselves.",
        yes: "Remove chapter",
      });
      if (!ok) return;
      album.chapters = (album.chapters || []).filter((c) => c.id !== ch.id);
      await saveChapters();
      pageIndex = Math.min(pageIndex, pageCount() - 1);
      renderPage($("page-live"), pageIndex);
      updateChrome();
    });

    inner.append(body, foot, del);
  }

  const LOWER_ROMAN = ["", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"];

  /** One page of the cast. Six characters, portrait beside a name and a
   *  private note — the note is never sent anywhere; it is for the reader
   *  remembering who somebody was. */
  function renderCastPage(inner, pageNo) {
    inner.classList.add("castpage");
    const all = castList();
    const slice = all.slice(pageNo * CAST_PER_PAGE, (pageNo + 1) * CAST_PER_PAGE);

    const hd = document.createElement("div");
    hd.className = "cast-hd";
    const lab = document.createElement("span");
    lab.className = "cast-lab";
    lab.textContent = "Dramatis";
    const big = document.createElement("span");
    big.className = "cast-big";
    big.textContent = "Personae";
    hd.append(lab, big);

    const rule = document.createElement("div");
    rule.className = "cast-rule";
    rule.innerHTML = '<i></i><b>\u2767</b><i></i>';
    inner.append(hd, rule);

    for (const c of slice) {
      const row = document.createElement("div");
      row.className = "cast-row";

      const pf = document.createElement("button");
      pf.type = "button";
      pf.className = "cast-pf" + (c.img ? "" : " empty");
      pf.title = "Choose a picture from your computer";
      if (c.img) {
        const img = document.createElement("img");
        img.src = c.img;
        img.alt = "";
        pf.appendChild(img);
      } else {
        pf.textContent = "＋";
      }
      pf.addEventListener("click", () => pickCastPortrait(c));

      const who = document.createElement("div");
      who.className = "cast-who";

      const nm = document.createElement("button");
      nm.type = "button";
      nm.className = "cast-nm" + (c.name ? "" : " empty");
      nm.textContent = c.name || "Name…";
      nm.addEventListener("click", () => editCastField(c, nm, "name", "Name…"));

      const nt = document.createElement("button");
      nt.type = "button";
      nt.className = "cast-nt" + (c.note ? "" : " empty");
      nt.textContent = c.note || "Who are they? (only you see this)";
      nt.addEventListener("click", () => editCastField(c, nt, "note", "Who are they? (only you see this)"));

      who.append(nm, nt);

      const del = document.createElement("button");
      del.type = "button";
      del.className = "cast-del";
      del.textContent = "✕";
      del.title = "Remove from the cast";
      del.addEventListener("click", async (e) => {
        e.stopPropagation();
        const ok = await askConfirm({
          title: `Remove ${c.name || "this character"}?`,
          body: "They will be taken out of the cast list.",
          warn: "Photographs in the album are untouched.",
          yes: "Remove",
        });
        if (!ok) return;
        album.cast = album.cast.filter((x) => x.id !== c.id);
        await saveCast();
        pageIndex = Math.min(pageIndex, pageCount() - 1);
        renderPage($("page-live"), pageIndex);
        updateChrome();
      });

      row.append(pf, who, del);
      inner.appendChild(row);
    }

    // The add control lives on the last cast page. It used to appear only
    // while that page had room, so a full page of six had no way to start
    // page seven — the paging (i, ii, iii…) was all there and unreachable.
    // A full page gets a compact control beside the folio instead of a row
    // that wouldn't fit; adding from it starts the next page.
    const last = pageNo === castPages() - 1;
    const full = slice.length >= CAST_PER_PAGE;
    if (last && !full) {
      const add = document.createElement("button");
      add.type = "button";
      add.className = "cast-add";
      add.innerHTML = '<span class="sq">＋</span><span>Add a character…</span>';
      add.addEventListener("click", addCastMember);
      inner.appendChild(add);
    }

    // One control, on the first cast page only, so it doesn't repeat.
    if (pageNo === 0) {
      const shelf = document.createElement("button");
      shelf.type = "button";
      shelf.className = "cast-sets";
      shelf.textContent = "⌸ Saved casts…";
      shelf.title = "Keep this cast for another book, or bring one in";
      shelf.addEventListener("click", openCastSets);
      inner.appendChild(shelf);
    }

    const foot = document.createElement("div");
    foot.className = "cast-foot";
    const folio = document.createElement("span");
    folio.textContent = `\u2014 ${LOWER_ROMAN[pageNo + 1] || pageNo + 1} \u2014`;
    foot.appendChild(folio);

    if (last && full) {
      const more = document.createElement("button");
      more.type = "button";
      more.className = "cast-add compact";
      more.textContent = "＋ Add another…";
      more.title = "Starts a new cast page";
      more.addEventListener("click", addCastMember);
      foot.appendChild(more);
    }

    // Tear the whole leaf out. Blank pages clear themselves when you leave
    // the cast, but a page of characters you no longer want needs saying so
    // — one at a time through six ✕s is a chore, and the last page can't be
    // reached any other way once its people are gone.
    const drop = document.createElement("button");
    drop.type = "button";
    drop.className = "cast-drop";
    drop.textContent = "✕ Remove page";
    drop.title = "Take this page of the cast out of the book";
    drop.addEventListener("click", async () => {
      const named = slice.filter((c) => !castIsEmpty(c));
      const ok = await askConfirm({
        title: `Remove cast page ${LOWER_ROMAN[pageNo + 1] || pageNo + 1}?`,
        body: named.length
          ? `${named.length} character${named.length === 1 ? "" : "s"} listed here ` +
            `(${named.map((c) => c.name || "unnamed").join(", ")}) will be taken out of the cast.`
          : "This page has nobody on it.",
        warn: "Photographs in the album are untouched.",
        yes: "Remove page",
      });
      if (!ok) return;
      const ids = new Set(slice.map((c) => c.id));
      album.cast = (album.cast || []).filter((c) => !ids.has(c.id));
      await saveCast();
      // The pages after this one shuffle up; stay where we are if there is
      // still a cast page here, otherwise step back to the one before it.
      pageIndex = Math.min(pageIndex, Math.max(0, itemOffset() - 1));
      renderPage($("page-live"), pageIndex);
      updateChrome();
    });
    foot.appendChild(drop);

    inner.appendChild(foot);
  }

  /** A cast entry with no name, no note and no portrait is a placeholder the
   *  reader started and abandoned — invisible on the page except as an empty
   *  row, and (worse) enough to keep a whole cast page alive. "Add another"
   *  has to create one to have something to fill in, so instead of refusing
   *  to make it, we clear it up on the way out. */
  const castIsEmpty = (c) =>
    !String(c?.name || "").trim() && !String(c?.note || "").trim() && !c?.img;

  /** Drop blank entries. Synchronous on the in-memory album (so page maths
   *  is right immediately); the write follows. Returns how many went. */
  function pruneEmptyCast() {
    const list = album?.cast || [];
    const kept = list.filter((c) => !castIsEmpty(c));
    if (kept.length === list.length) return 0;
    const removed = list.length - kept.length;
    album.cast = kept;
    saveCast().catch(() => { /* the page is already gone from view */ });
    return removed;
  }

  /** Leaving the cast section: tidy it, and shift the destination by however
   *  many pages that removed, so "turn to the first photograph" still lands
   *  on the first photograph. Moving BETWEEN cast pages prunes nothing —
   *  the blank row you just made is the one you are about to fill in. */
  function tidyCastOnLeave(target) {
    const before = itemOffset();
    const onCast = pageIndex >= 1 && pageIndex < before;
    if (!onCast) return target;
    if (target !== 0 && target < before) return target;   // still in the cast
    if (!pruneEmptyCast()) return target;
    const delta = itemOffset() - before;                  // negative
    return target >= before ? target + delta : target;
  }

  async function saveCast() {
    const prev = await req(tx("sessions").get(album.sessionId));
    await req(tx("sessions", "readwrite")
      .put({ ...(prev || {}), sessionId: album.sessionId, cast: album.cast || [] }));
  }

  async function addCastMember() {
    album.cast = album.cast || [];
    album.cast.push({ id: `cast_${Date.now().toString(36)}`, name: "", note: "", img: null });
    await saveCast();
    // follow the new entry if it started a fresh page
    goToPage(Math.min(pageIndex + (castList().length % CAST_PER_PAGE === 1 ? 1 : 0), castPages()));
    renderPage($("page-live"), pageIndex);
    updateChrome();
  }

  /** Portraits come from the reader's own machine and are scaled down on the
   *  way in — six full-size camera files a page would bloat the record. */
  function pickCastPortrait(c) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.hidden = true;
    document.body.appendChild(input);
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      input.remove();
      if (!file) return;
      try {
        c.img = await shrinkImage(file, 600, 0.85);
        await saveCast();
        renderPage($("page-live"), pageIndex);
      } catch { /* unreadable file — leave the entry as it was */ }
    });
    input.click();
  }

  function editCastField(c, el, key, placeholder) {
    const box = document.createElement(key === "name" ? "input" : "textarea");
    box.className = el.className.replace(" empty", "") + " editing";
    box.value = c[key] || "";
    box.placeholder = placeholder;
    el.replaceWith(box);
    box.focus();
    let done = false;
    const finish = async (keep) => {
      if (done) return;
      done = true;
      if (keep) { c[key] = box.value.trim(); await saveCast(); }
      renderPage($("page-live"), pageIndex);
    };
    box.addEventListener("blur", () => finish(true));
    box.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && key === "name") { e.preventDefault(); finish(true); }
      if (e.key === "Escape") { e.stopPropagation(); finish(false); }
    });
  }

  /** The last page: the tally, then a contents list you can jump from. */
  function renderEndMatter(inner, items) {
    inner.classList.add("endmatter");
    const chapters = items.filter((i) => i.kind === "chapter");
    const photos = items.filter((i) => i.kind === "photo");
    const first = photos.length ? photos[0].at : album.endedAt;
    const last = album.endedAt || (photos.length ? photos[photos.length - 1].at : Date.now());
    const days = Math.max(1, Math.round((last - first) / 86400000));
    const span = days < 31 ? `${days} day${days === 1 ? "" : "s"}`
      : days < 365 ? `${Math.round(days / 30)} months`
      : `${(days / 365).toFixed(1)} years`;

    const hd = document.createElement("div");
    hd.className = "em-hd";
    hd.textContent = "The End";

    const sub = document.createElement("div");
    sub.className = "em-sub";
    sub.textContent = album.title || "";
    inner.append(hd, sub);

    // ---- the tally -------------------------------------------------
    const times = photos.map((p) => p.at).filter(Boolean);
    const favs = album.photos.filter((r) => r.favorite === true).length;

    // busiest day: group by local calendar date, not by UTC
    const byDay = new Map();
    for (const t of times) {
      const d = new Date(t);
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      const cur = byDay.get(key) || { n: 0, at: t };
      cur.n += 1;
      byDay.set(key, cur);
    }
    let bestAt = null, bestCount = 0;
    for (const { n, at } of byDay.values()) {
      if (n > bestCount) { bestCount = n; bestAt = at; }
    }
    const bestDayLabel = bestAt
      ? new Date(bestAt).toLocaleDateString(undefined, { day: "numeric", month: "long" })
      : "";

    // pace: how often a photograph arrived across the book's whole life
    const pace = times.length > 1 ? (last - first) / 86400000 / (times.length - 1) : 0;
    const paceLabel = !pace ? "—"
      : pace < 1 ? `${Math.max(1, Math.round(1 / pace))}/day`
      : pace < 2 ? "daily"
      : `${Math.round(pace)} days`;
    const paceCaption = !pace ? "pace"
      : pace < 1 ? "a day's work"
      : pace < 2 ? "roughly" : "between photographs";

    // longest chapter, measured by how many photographs sit under it
    let longestCh = null, longestChN = 0;
    for (let i = 0; i < items.length; i++) {
      if (items[i].kind !== "chapter") continue;
      let n = 0;
      for (let j = i + 1; j < items.length && items[j].kind !== "chapter"; j++) n++;
      if (n > longestChN) { longestChN = n; longestCh = items[i]; }
    }

    // night owl or daylight worker? 10pm–5am counts as after midnight
    const night = times.filter((t) => { const h = new Date(t).getHours(); return h >= 22 || h < 5; }).length;
    const nightShare = times.length ? night / times.length : 0;

    const stats = document.createElement("div");
    stats.className = "em-stats";
    const stat = (big, small) => {
      const d = document.createElement("div");
      const b = document.createElement("b");
      b.textContent = big;
      d.append(b, document.createTextNode(small));
      stats.appendChild(d);
    };
    stat(String(photos.length), "photographs");
    stat(String(chapters.length), chapters.length === 1 ? "chapter" : "chapters");
    stat(String(favs), favs === 1 ? "favourite" : "favourites");
    stat(new Date(first).toLocaleDateString(undefined, { day: "numeric", month: "short" }), "begun");
    stat(span, "in the making");
    stat(paceLabel, paceCaption);
    inner.appendChild(stats);

    // ---- the notable lines ------------------------------------------
    // Each one hides itself when it has nothing to say: a book with three
    // photographs has no "busiest day", and an even one has no night shift.
    const lines = [];
    if (bestCount >= 3) {
      lines.push(`Busiest day: ${bestDayLabel} \u2014 ${bestCount} photographs.`);
    }
    if (longestCh && longestChN >= 3) {
      lines.push(`Chapter ${roman(longestCh.number)}${longestCh.ch.title ? `, \u201c${longestCh.ch.title}\u201d,` : ""} ran longest at ${longestChN} photographs.`);
    }
    if (times.length >= 6) {
      if (nightShare >= 0.55) lines.push("Most of this book was made after midnight.");
      else if (nightShare <= 0.12) lines.push("Most of this book was made in daylight.");
    }
    if (lines.length) {
      const note = document.createElement("div");
      note.className = "em-notes";
      for (const t of lines) {
        const p = document.createElement("p");
        p.textContent = t;
        note.appendChild(p);
      }
      inner.appendChild(note);
    }

    if (chapters.length) {
      const cts = document.createElement("div");
      cts.className = "em-contents";
      for (const c of chapters) {
        const row = document.createElement("button");
        row.className = "em-row";
        row.type = "button";
        const name = document.createElement("span");
        name.textContent = `${roman(c.number)} · ${c.ch.title || "Untitled"}`;
        const dots = document.createElement("em");
        const pg = document.createElement("span");
        const target = items.indexOf(c) + itemOffset();
        pg.textContent = String(target);
        row.append(name, dots, pg);
        row.title = "Turn to this chapter";
        row.addEventListener("click", () => goToPage(target));
        cts.appendChild(row);
      }
      inner.appendChild(cts);
    }

    const orn = document.createElement("div");
    orn.className = "em-orn";
    orn.textContent = "Or is it?";

    const reopen = document.createElement("button");
    reopen.className = "em-reopen";
    reopen.type = "button";
    reopen.textContent = "Reopen this story";
    reopen.addEventListener("click", async () => {
      album.endedAt = null;
      await saveStoryEnd(null);
      pageIndex = Math.min(pageIndex, pageCount() - 1);
      renderPage($("page-live"), pageIndex);
      updateChrome();
    });
    inner.append(orn, reopen);
  }

  /** Turn straight to a page — used by the contents list and the counter. */
  function goToPage(n) {
    const target = Math.max(0, Math.min(tidyCastOnLeave(n), pageCount() - 1));
    if (target === pageIndex) return;
    pageIndex = target;
    renderPage($("page-live"), pageIndex);
    updateChrome();
  }

  async function saveChapters() {
    const prev = await req(tx("sessions").get(album.sessionId));
    await req(tx("sessions", "readwrite")
      .put({ ...(prev || {}), sessionId: album.sessionId, chapters: album.chapters || [] }));
  }
  async function saveStoryEnd(at) {
    const prev = await req(tx("sessions").get(album.sessionId));
    await req(tx("sessions", "readwrite")
      .put({ ...(prev || {}), sessionId: album.sessionId, endedAt: at }));
  }

  /** Inline edit for a chapter's title or footnote. */
  function editChapterField(ch, el, key, placeholder) {
    const box = document.createElement(key === "title" ? "input" : "textarea");
    box.className = el.className.replace(" empty", "") + " editing";
    box.value = ch[key] || "";
    box.placeholder = placeholder;
    el.replaceWith(box);
    box.focus();
    let done = false;
    const finish = async (keep) => {
      if (done) return;
      done = true;
      if (keep) {
        ch[key] = box.value.trim();
        await saveChapters();
      }
      renderPage($("page-live"), pageIndex);
    };
    box.addEventListener("blur", () => finish(true));
    box.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && key === "title") { e.preventDefault(); finish(true); }
      if (e.key === "Escape") { e.stopPropagation(); finish(false); }
    });
  }

  /** The chapter picture comes from the reader's own machine, not the album —
   *  the album's photographs are already in the book, so a chapter opener
   *  wants something new. Scaled down before storing: it lives on the
   *  session record, so a full-size camera file would bloat it badly. */
  function pickChapterPhoto(ch) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.hidden = true;
    document.body.appendChild(input);
    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      input.remove();
      if (!file) return;
      try {
        ch.img = await shrinkImage(file, 1400, 0.86);
        delete ch.photoId;            // an upload supersedes any old pick
        await saveChapters();
        renderPage($("page-live"), pageIndex);
      } catch {
        // unreadable or unsupported file — leave the chapter as it was
      }
    });
    input.click();
  }

  /** Draw the file to a canvas at a sane size and return a JPEG data URL. */
  function shrinkImage(file, maxEdge, quality) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
        const cv = document.createElement("canvas");
        cv.width = Math.max(1, Math.round(img.width * scale));
        cv.height = Math.max(1, Math.round(img.height * scale));
        cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        resolve(cv.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
      img.src = url;
    });
  }

  function renderEndpaper(inner) {
    inner.classList.add("endpaper");
    if (favoritesOnly) inner.classList.add("favorites-endpaper");
    const h = document.createElement("h2");
    h.textContent = favoritesOnly ? "Favorite memories" : album.title;
    h.title = favoritesOnly ? "Heart a photo to keep it here" : "Click to rename this album";
    if (!favoritesOnly) h.addEventListener("click", () => {
      const input = document.createElement("input");
      input.className = "rename";
      input.value = album.title;
      input.maxLength = 60;
      const save = async () => {
        const name = input.value.trim();
        if (name && name !== album.title) {
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, customTitle: name }));
          album.title = name;
        }
        input.replaceWith(h);
        h.textContent = album.title;
        updateChrome();
      };
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") save();
        if (e.key === "Escape") input.replaceWith(h);
        e.stopPropagation();
      });
      input.addEventListener("blur", save);
      h.replaceWith(input);
      input.focus();
      input.select();
    });
    inner.appendChild(h);

    // A tooled rule under the title, the way a title page carries one.
    const rule = document.createElement("div");
    rule.className = "endpaper-rule";
    rule.setAttribute("aria-hidden", "true");
    rule.innerHTML = "<span></span><i>\u2766</i><span></span>";
    inner.appendChild(rule);

    if (favoritesOnly) {
      const favs = visiblePhotos();
      const msg = document.createElement("p");
      msg.className = "favorites-intro";
      msg.textContent = favs.length
        ? `${favs.length} hearted photo${favs.length === 1 ? "" : "s"}. Flip forward to revisit them.`
        : "No favorites yet. Heart any photo in the album and it will appear here.";
      inner.appendChild(msg);
      return;
    }

    const cast = document.createElement("div");
    cast.className = "cast";
    const characters = Object.values(album.sheet?.characters || {});
    for (const c of characters.slice(0, 2)) {
      if (!c.portrait) continue;
      const fig = document.createElement("figure");
      const mount = castPortrait(c.portrait, c.name, -1.2 + Math.random() * 2.4);
      const cap = document.createElement("figcaption");
      cap.textContent = c.name;
      fig.append(mount, cap);
      cast.appendChild(fig);
    }
    if (!cast.children.length) {
      const note = document.createElement("p");
      note.style.cssText = "color:#4b3a5e;font-style:italic;text-align:center";
      note.textContent = "Send a message in this chat and the cast appears here on its own.";
      cast.appendChild(note);
    }
    if (cast.children.length) {
      const label = document.createElement("p");
      label.className = "cast-label";
      label.textContent = characters.length > 1 ? "the cast" : "our cast";
      inner.appendChild(label);
    }
    inner.appendChild(cast);

    // A line of provenance between the cast and the plate: it fills the
    // gap the larger portraits left, and tells you what you are holding.
    if (album.photos.length) {
      const dates = album.photos.map((r) => r.createdAt || 0).filter(Boolean);
      const first = new Date(Math.min(...dates));
      const meta = document.createElement("p");
      meta.className = "endpaper-meta";
      const n = album.photos.length;
      meta.textContent = `${n} photograph${n === 1 ? "" : "s"} · begun ` +
        first.toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
      inner.appendChild(meta);
    }

    // Title image below the cast — yours to choose — plus a small inscription.
    const slot = document.createElement("div");
    slot.className = "title-slot";
    const pick = document.createElement("input");
    pick.type = "file";
    pick.accept = "image/*";
    pick.hidden = true;
    pick.addEventListener("change", async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const prev = await req(tx("sessions").get(album.sessionId));
      await req(tx("sessions", "readwrite")
        .put({ ...(prev || {}), sessionId: album.sessionId, titleBlob: file }));
      album.titleBlob = file;
      renderPage($("page-live"), 0);
    });
    if (album.titleBlob) {
      const url = URL.createObjectURL(album.titleBlob);
      extraUrls.push(url);
      const mount = mountPhoto(url, "Title image", 0.8, album.frame, "");
      mount.classList.add("title-mount");
      mount.title = "Click to change the title image";
      mount.querySelector("img.photo").style.cursor = "pointer";
      mount.querySelector("img.photo").addEventListener("click", () => pick.click());
      slot.appendChild(mount);
    } else {
      const add = document.createElement("button");
      add.type = "button";
      add.className = "title-add";
      add.textContent = "Add a title image";
      add.addEventListener("click", () => pick.click());
      slot.appendChild(add);
    }
    slot.appendChild(pick);

    const inscription = document.createElement("textarea");
    inscription.className = "inscription";
    inscription.rows = 2;
    inscription.placeholder = "Write something on the first page…";
    inscription.value = album.endNote || "";
    let t = null;
    inscription.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(async () => {
        album.endNote = inscription.value.trim();
        const prev = await req(tx("sessions").get(album.sessionId));
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: album.sessionId, endNote: album.endNote }));
      }, 500);
    });
    inscription.addEventListener("keydown", (e) => e.stopPropagation());
    slot.appendChild(inscription);
    inner.appendChild(slot);
  }

  function renderPhotoPage(inner, rec) {
    const url = photoUrl(rec);

    // Deterministic tilt per photo: mounted by hand, but never shifting.
    const tilt = ((rec.id * 137) % 30) / 10 - 1.5;

    const chinFor = (frame) => {
      if (frame === "instant") {
        return new Date(rec.createdAt || Date.now())
          .toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
      }
      if (frame === "film") {
        const n = (visiblePhotos().indexOf(rec) + 1) || 1;
        return `\u2116 ${String(n).padStart(2, "0")}`;
      }
      return "";
    };

    const effFrame = () => normFrame(rec.frame || album.frame);
    const mount = mountPhoto(url, rec.caption || "", tilt, effFrame(), chinFor(effFrame()));
    const heart = document.createElement("button");
    heart.type = "button";
    heart.className = "favorite-heart" + (rec.favorite ? " active" : "");
    heart.textContent = rec.favorite ? "♥" : "♡";
    heart.title = rec.favorite ? "Remove from favorites" : "Add to favorites";
    heart.setAttribute("aria-label", heart.title);
    heart.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      rec.favorite = !rec.favorite;
      await req(tx("images", "readwrite").put(rec));
      heart.classList.toggle("active", rec.favorite);
      heart.textContent = rec.favorite ? "♥" : "♡";
      heart.title = rec.favorite ? "Remove from favorites" : "Add to favorites";
      heart.setAttribute("aria-label", heart.title);
      updateChrome();
      if (favoritesOnly && !rec.favorite) {
        pageIndex = Math.min(pageIndex, pageCount() - 1);
        renderPage($("page-live"), pageIndex);
        updateChrome();
      }
    });
    mount.querySelector(".print").appendChild(heart);
    mount.querySelector("img.photo").addEventListener("click", () => {
      $("lightbox-img").src = url;
      $("lightbox").hidden = false;
    });
    inner.appendChild(mount);

    const stamp = document.createElement("span");
    stamp.className = "datestamp";
    stamp.textContent = new Date(rec.createdAt || Date.now())
      .toLocaleDateString(undefined, { year: "numeric", month: "short", day: "2-digit" })
      .toUpperCase();
    inner.appendChild(stamp);

    // The note beneath: the reply that made this moment, or your own words.
    const note = document.createElement("div");
    note.className = "note";
    const ta = document.createElement("textarea");
    ta.placeholder = "Write something under this photo…";
    ta.value = rec.caption || "";

    const tools = document.createElement("div");
    tools.className = "note-tools";
    const paste = document.createElement("button");
    paste.type = "button";
    paste.textContent = "Paste latest reply";
    paste.title = "Fill the note with the newest reply from this chat";

    const cover = document.createElement("button");
    cover.type = "button";
    // Show at a glance which photo is currently the cover.
    cover.textContent = album.coverId === rec.id ? "✓ cover" : "Make cover";
    cover.title = "Show this photo on the album's cover";
    cover.addEventListener("click", async () => {
      const prev = await req(tx("sessions").get(album.sessionId));
      const already = prev?.coverId === rec.id;
      await req(tx("sessions", "readwrite").put({
        ...(prev || {}),
        sessionId: album.sessionId,
        coverId: already ? null : rec.id,     // tapping again clears it
      }));
      album.coverId = already ? null : rec.id;
      cover.textContent = already ? "Make cover" : "✓ cover";
      setTimeout(() => (cover.textContent = album.coverId === rec.id ? "✓ cover" : "Make cover"), 1800);
    });

    // Pin this photo behind the chat instead of letting the newest snap win.
    const backdrop = document.createElement("button");
    backdrop.type = "button";
    const pinLabel = () =>
      album.backdropId === rec.id ? "✓ Snapscape — tap to unpin" : "Set as Snapscape";
    backdrop.textContent = pinLabel();
    backdrop.title = "Pin this photo as the chat's Snapscape. The chat's 🌄 Scape button turns Snapscapes on and off.";
    backdrop.addEventListener("click", async () => {
      const already = album.backdropId === rec.id;
      album.backdropId = already ? null : rec.id;
      // req() is for IndexedDB requests; a runtime message is already a promise.
      await chrome.runtime.sendMessage({
        type: "db", op: "setBackdrop",
        args: { sessionId: album.sessionId, id: album.backdropId },
      });
      backdrop.textContent = pinLabel();
    });

    // The frame dial. rec.frame null means "wear the album's frame".
    const frameBtn = document.createElement("button");
    frameBtn.type = "button";
    frameBtn.className = "frame-dial";
    const frameText = () => rec.frame
      ? `\u274f ${frameLabel(rec.frame)}`
      : `\u274f Album frame`;
    frameBtn.textContent = frameText();
    frameBtn.title = "Change how this photo is mounted";
    frameBtn.addEventListener("click", async () => {
      const order = [null, ...FRAMES.map(([id]) => id)];
      const cur = rec.frame ? normFrame(rec.frame) : null;
      const next = order[(order.indexOf(cur) + 1) % order.length];
      rec.frame = next;
      if (next === null) delete rec.frame;
      await req(tx("images", "readwrite").put(rec));
      // Redress the mount where it stands.
      const f = effFrame();
      mount.dataset.frame = f;
      mount.querySelector(".chin").textContent = chinFor(f);
      mount.classList.remove("redress");
      void mount.offsetWidth;                 // restart the settle animation
      mount.classList.add("redress");
      frameBtn.textContent = frameText();
    });

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "danger";
    remove.textContent = "Take out";
    remove.title = "Remove this photo from the album (deletes it)";
    remove.addEventListener("click", async () => {
      if (!await askConfirm({ title: "Take this photo out?", body: "It leaves the album and is deleted.", warn: "This can't be undone.", yes: "Delete photo", })) return;
      await req(tx("images", "readwrite").delete(rec.id));
      const url = urlCache.get(rec.id);
      if (url) { URL.revokeObjectURL(url); urlCache.delete(rec.id); }
      // Keep the reader open at the same spot (clamped if this was the last page).
      await chrome.storage.local.set({ [`djpbBookmark:${album.sessionId}`]: Math.max(0, pageIndex - 1) });
      openAlbum(album.sessionId);
    });

    const savedTag = document.createElement("span");
    savedTag.className = "saved";

    paste.addEventListener("click", async () => {
      // Ask the chat page for the reply as it stands RIGHT NOW. The stored
      // copy comes from the outgoing request, which is written before the
      // reply it describes exists — so it's permanently one message behind.
      savedTag.textContent = "fetching\u2026";
      const live = await requestHostLatest();
      savedTag.textContent = "";
      const text = live || album.lastReply || "";
      if (!text) {
        savedTag.textContent = "no reply available yet";
        return;
      }
      // The note is the visible prose, not the machinery around it.
      ta.value = text
        .replace(/```?\s*<thinking>[\s\S]*?<\/thinking>\s*```?/gi, "")
        .replace(/^\s*Thinking Process\s*(Show|Hide)?\s*$/gim, "")
        .trim();
      saveNote();
    });

    let saveTimer = null;
    const saveNote = () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(async () => {
        rec.caption = ta.value.trim();
        await req(tx("images", "readwrite").put(rec));
        savedTag.textContent = "saved ✎";
        setTimeout(() => (savedTag.textContent = ""), 1800);
      }, 500);
    };
    ta.addEventListener("input", saveNote);

    // "Use as ref" lived here; references are set from the Snap card's
    // chip row instead, which is where the picking happens anyway.
    tools.append(backdrop, cover, frameBtn, paste, remove, savedTag);
    note.append(ta, tools);
    inner.appendChild(note);
  }

  function renderPocket(inner) {
    if (favoritesOnly) {
      inner.classList.add("pocket", "favorites-pocket");
      const h = document.createElement("h2");
      h.textContent = "End of favorites";
      const p = document.createElement("p");
      p.className = "favorites-intro";
      p.textContent = "Switch back to All photos to keep flipping through the full album.";
      inner.append(h, p);
      return;
    }
    inner.classList.add("pocket");
    const h = document.createElement("h2");
    h.textContent = "Loose photos";
    inner.appendChild(h);

    const sleeve = document.createElement("div");
    sleeve.className = "sleeve";
    album.unfiled.forEach((rec, i) => {
      const b = document.createElement("div");
      b.className = "loose";
      b.style.setProperty("--tilt", `${(i % 3) - 1}deg`);

      const img = document.createElement("img");
      img.src = photoUrl(rec);
      img.alt = "";
      img.title = "Add to this album";
      img.addEventListener("click", async () => {
        rec.sessionId = album.sessionId;
        await req(tx("images", "readwrite").put(rec));
        openAlbum(album.sessionId); // re-read; the photo now has a page
      });

      const x = document.createElement("button");
      x.type = "button";
      x.className = "loose-x";
      x.textContent = "✕";
      x.title = "Throw this loose photo away";
      x.addEventListener("click", async (e) => {
        e.stopPropagation();
        if (!await askConfirm({ title: "Throw this photo away?", body: "It is deleted from the back pocket.", warn: "This can't be undone.", yes: "Delete photo", })) return;
        await req(tx("images", "readwrite").delete(rec.id));
        const url = urlCache.get(rec.id);
        if (url) { URL.revokeObjectURL(url); urlCache.delete(rec.id); }
        openAlbum(album.sessionId);
      });

      b.append(img, x);
      sleeve.appendChild(b);
    });
    inner.appendChild(sleeve);
  }

  // ======================= painted pages =======================
  // Watercolor and Roses pages are PAINTED, not styled: the two canvas pens
  // the user supplied run once, invisibly, to completion, and the finished
  // still is cached on the album and mounted as the page background. Every
  // album gets its own one-off painting (the pens are random by nature);
  // after that first render the page never changes and nothing ever moves.

  /** The WaterColor engine (verbatim geometry: wiggled sine/cosine walk,
   *  midpoint subdivision to 3000 points, multi-pass hard-light fills at
   *  decaying alpha). The original painted across animation frames; here the
   *  passes run synchronously so only the finished wash is ever seen. */
  function paintWatercolor(W, H, end) {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fdfcf7";
    ctx.fillRect(0, 0, W, H);

    const twoPI = 2 * Math.PI;
    const randomWiggle = (w) => (Math.random() * w) * (Math.random() < 0.5 ? -1 : 1);
    let hue = -25;
    const randomColor = () => {
      hue = Math.floor((hue % 360) + 25 + 15 * Math.random());
      return `hsl(${hue}, 50%, 55%)`;
    };

    function Blob(o) {
      Object.assign(this, { speed: 0.3, maxPoints: 3000, maxRender: 5, scale: false }, o);
      if (!this.fill) this.fill = randomColor();
      for (let c = 1; c <= this.maxRender; c++) this.draw(c);
    }
    Blob.prototype = {
      buildPoints() {
        const wiggle = this.size * 0.15;
        let rotation = 0, x = -this.size, y = 0;
        const horizontal = Math.random() > 0.5, start = [x, y];
        this.points = [start];
        for (; rotation < twoPI; rotation += this.speed) {
          x += this.size * this.speed * Math.sin(rotation) * (horizontal ? 1 : 0.7) + randomWiggle(wiggle);
          y += this.size * this.speed * Math.cos(rotation) * (horizontal ? 0.7 : 1) + randomWiggle(wiggle);
          this.points.push([x, y]);
        }
        this.points.push(start);
        this.originalPoints = this.points;
        return this.points;
      },
      expandPoints() {
        if (!this.points) return this.buildPoints();
        if (this.points.length > this.maxPoints) return false;
        const wiggle = this.size * 0.05;
        const p = [];
        for (let i = 0, len = this.points.length - 1; i < len; i++) {
          const [x, y] = this.points[i];
          const [x2, y2] = this.points[i + 1];
          p.push([x, y],
            [((x2 + x) / 2) + randomWiggle(wiggle), ((y2 + y) / 2) + randomWiggle(wiggle)],
            [x2, y2]);
        }
        this.points = p;
        return true;
      },
      draw(c) {
        while (this.expandPoints()) { /* subdivide to full softness */ }
        const itr = c / this.maxRender;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.globalCompositeOperation = "hard-light";
        ctx.globalAlpha = 0.17 - (itr * 0.07);   // diluted: see ART_VERSION
        ctx.translate(this.x, this.y);
        if (this.scale) ctx.scale(1 + itr * 0.2, 1 + itr * 0.2);
        ctx.beginPath();
        ctx.moveTo(this.points[0][0], this.points[0][1]);
        for (let i = 0, len = this.points.length; i < len; i++) {
          ctx.lineTo(this.points[i][0], this.points[i][1]);
        }
        ctx.closePath();
        ctx.fillStyle = this.fill;
        ctx.fill();
        this.points = this.originalPoints;
      },
    };

    // Two compositions from the same engine. The interior page is the pen's
    // opening move: ten huge washes ringing the perimeter, colour bleeding
    // across the whole sheet. The ENDPAPER is a title-page wash: the same
    // ring, but small blooms that stain only the borders and leave the
    // centre cream for the cast portraits.
    const hw = W / 2, hh = H / 2;
    const count = end ? 14 : 10;
    for (let i = 0, len = count; i < len; i++) {
      new Blob({
        size: end ? W * (0.26 + Math.random() * 0.08) : W * (0.7 + Math.random() * 0.1),
        x: hw + (Math.cos((i / len) * twoPI) * hw),
        y: hh + (Math.sin((i / len) * twoPI) * hh),
      });
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
    return cv.toDataURL("image/jpeg", 0.85);
  }

  /** The flowers pen, near-verbatim: arc-petal roses in three colours, ring
   *  opacity climbing toward the heart, scattered on a lazy sine drift. Only
   *  window.innerWidth/Height became the page's own size. */
  function paintRoses(W, H, end, dark = false) {
    const cv = document.createElement("canvas");
    cv.width = W; cv.height = H;
    const ctx = cv.getContext("2d");
    // The ground is painted in, so a dark page needs its own painting. The
    // blooms are the same; over black they read as the cover's pinks do.
    ctx.fillStyle = dark ? "#140a0f" : "#fffaf6";
    ctx.fillRect(0, 0, W, H);

    const flowers = [
      { color: "#fd97ad", radius: 80, variable: 600, amount: 12 },
      { color: "#e165a8", radius: 60, variable: 720, amount: 18 },
      { color: "#efc2ab", radius: 40, variable: 800, amount: 9 },
    ];
    const getRandomNum = (v) => Math.round((Math.random() * v) - (Math.random() * v));
    const radians = (deg) => (deg * Math.PI) / 180;
    const findPointOnCircle = (ox, oy, r, deg) => {
      const a = radians(deg);
      return { x: r * Math.cos(a) + ox, y: r * Math.sin(a) + oy };
    };
    function arcPetal(x0, y0, radius, startAngle, endAngle, petalWidth) {
      const s = findPointOnCircle(x0, y0, radius, startAngle);
      const e = findPointOnCircle(x0, y0, radius, endAngle);
      const cp1 = findPointOnCircle(x0, y0, radius, startAngle + 35);
      const cp2 = findPointOnCircle(x0, y0, radius, endAngle - 35);
      const cb1 = findPointOnCircle(x0, y0, radius * petalWidth, startAngle + 50);
      const cb2 = findPointOnCircle(x0, y0, radius * petalWidth, endAngle - 50);
      ctx.moveTo(s.x, s.y);
      ctx.bezierCurveTo(cp1.x, cp1.y, cp2.x, cp2.y, e.x, e.y);
      ctx.bezierCurveTo(cb2.x, cb2.y, cb1.x, cb1.y, s.x, s.y);
    }
    function watercolorFlower(startx, starty, radius0, color) {
      const thickness = 1.4, amt = 30, ringamt = 4.5;
      const angleincrement = 360 / ringamt;
      let opacity = 10, radius = radius0;
      const radiusincrement = radius / amt;
      ctx.fillStyle = color;
      for (let i = 0; i < amt; i++) {
        const startAngle = i * angleincrement;
        const midAngle = startAngle + 90;
        const endAngle = startAngle + 180;
        ctx.beginPath();
        const origin = findPointOnCircle(startx, starty, radius, midAngle);
        arcPetal(origin.x, origin.y, radius, startAngle, endAngle, thickness);
        ctx.filter = `opacity(${opacity}%)`;
        ctx.fill();
        ctx.closePath();
        radius -= radiusincrement;
        opacity += 5;
      }
      opacity = 20;
      const decrement = radius0 / 4;
      let layerradius = radius0;
      for (let l = 0; l < 4; l++) {
        ctx.beginPath();
        ctx.arc(startx, starty, layerradius, 0, Math.PI * 2);
        ctx.filter = `opacity(${opacity}%)`;
        ctx.fill();
        ctx.closePath();
        opacity += 10;
        layerradius -= decrement;
      }
    }
    function randomFlowers(variableamt, amount, color, radius) {
      const xdist = (W * 1.1) / amount;
      const ydist = (H * 2.5) / amount;
      for (let y = 0; y < amount; y++) {
        const inc = Math.sin(y / amount);
        const curY = (inc * y) * ydist;
        const curX = (inc * y) * xdist;
        watercolorFlower(
          curX + getRandomNum(variableamt),
          curY + getRandomNum(variableamt),
          radius + getRandomNum(20),
          color
        );
      }
    }
    if (end) {
      // ONE bloom, drawn by the flower pen itself at feature size, sitting in
      // the lower-right corner so the page edge crops it. Nothing else — the
      // rest is clean paper for the title and the cast. (The previous garland
      // was a ring of small blooms composed here rather than by the pen, and
      // it read as scattered blobs.)
      ctx.globalAlpha = 0.8;
      watercolorFlower(W * 0.9, H * 0.94, W * 0.38, "#fd97ad");
      ctx.globalAlpha = 1;
    } else {
      for (const f of flowers) randomFlowers(f.variable, f.amount, f.color, f.radius);
    }
    ctx.filter = "none";
    return cv.toDataURL("image/jpeg", 0.85);
  }

  const PAINTED_THEMES = { watercolor: paintWatercolor, roses: paintRoses };
  // Bump when the painters change so cached paintings are redone; without it
  // albums painted by an older version keep their heavier pigment forever.
  const ART_VERSION = 3;

  /** Paint once per album (or reuse the cache), and dress the page elements.
   *  For every unpainted binding this clears any inline art so the theme's
   *  own CSS shows through. */
  async function ensurePageArt(a) {
    const painter = PAINTED_THEMES[a?.theme];
    if (!painter) {
      document.body.style.removeProperty("--djpb-page-art");
      document.body.style.removeProperty("--djpb-end-art");
      return;
    }
    let art = a.pageArt;
    const dark = a.shade === "dark";
    if (!art?.dataUrl || !art.endUrl || art.theme !== a.theme || art.v !== ART_VERSION ||
        Boolean(art.dark) !== dark) {
      // 900×1260 outpaints the page at any album size; `cover` does the
      // rest. The endpaper gets its own composition from the same pen.
      art = {
        theme: a.theme,
        dark,
        v: ART_VERSION,
        dataUrl: painter(900, 1260, false, dark),
        endUrl: painter(900, 1260, true, dark),
      };
      a.pageArt = art;
      try {
        const prev = await req(tx("sessions").get(a.sessionId));
        await req(tx("sessions", "readwrite")
          .put({ ...(prev || {}), sessionId: a.sessionId, pageArt: art }));
      } catch { /* uncached: repainted (differently) next open */ }
    }
    if (album !== a) return;   // switched away while painting
    document.body.style.setProperty("--djpb-page-art", `url("${art.dataUrl}")`);
    document.body.style.setProperty("--djpb-end-art", `url("${art.endUrl}")`);
  }

  /** The cast plate: a FIXED treatment, deliberately independent of the
   *  frame dial — the dramatis personae page stays composed whatever the
   *  loose photos are wearing. Each binding dresses `.castframe` its own way
   *  (pockets, keylines, ticks, neon) purely in CSS.
   *
   *  The frame is a square that CROPS the portrait rather than letterboxing
   *  it. That is the fix for the old drift: with object-fit:contain the img
   *  element stayed wide while the visible picture shrank inside it, so
   *  corners anchored to empty box instead of to the photograph. Cover means
   *  element box and visible picture are the same rectangle, so corners
   *  always grip the picture — and both cast members match in size. */
  function castPortrait(src, alt, tilt) {
    const mount = document.createElement("div");
    mount.className = "castmount";
    mount.style.setProperty("--tilt", `${tilt.toFixed(1)}deg`);

    const frame = document.createElement("div");
    frame.className = "castframe";

    const img = document.createElement("img");
    img.className = "castphoto";
    img.src = src;
    img.alt = alt;
    img.loading = "lazy";
    // The plate crops to a square, so clicking opens the full portrait —
    // the zoom-in cursor was previously decorative here.
    img.addEventListener("click", () => {
      $("lightbox-img").src = src;
      $("lightbox").hidden = false;
    });
    frame.appendChild(img);

    // Four corner elements every binding restyles; keyline-only themes
    // simply hide them and draw on .castframe instead.
    for (const pos of ["tl", "tr", "bl", "br"]) {
      const c = document.createElement("span");
      c.className = `castcorner ${pos}`;
      frame.appendChild(c);
    }
    mount.appendChild(frame);
    return mount;
  }

  function mountPhoto(src, alt, tilt, frame, chinText) {
    const mount = document.createElement("div");
    mount.className = "mount";
    mount.dataset.frame = normFrame(frame);
    mount.style.setProperty("--tilt", `${tilt.toFixed(1)}deg`);

    // The print shrink-wraps the photograph; frames, corners and chin all
    // anchor HERE, so they sit on the photo whatever its shape.
    const print = document.createElement("div");
    print.className = "print";

    const img = document.createElement("img");
    img.className = "photo";
    img.src = src;
    img.alt = alt;
    print.appendChild(img);

    // Kraft corners are elements the other frames simply hide.
    for (const pos of ["tl", "tr", "bl", "br"]) {
      const c = document.createElement("span");
      c.className = `corner ${pos}`;
      print.appendChild(c);
    }
    // The chin: instant film's writing strip, the filmstrip's frame number.
    const chin = document.createElement("span");
    chin.className = "chin";
    chin.textContent = chinText || "";
    print.appendChild(chin);

    mount.appendChild(print);
    return mount;
  }

  // ---------- turning ----------

  function turn(delta) {
    if (!album || turning) return;
    const next = tidyCastOnLeave(pageIndex + delta);
    if (next < 0 || next >= pageCount()) return;
    turning = true;

    const live = $("page-live");
    const under = $("page-under");

    if (delta > 0) {
      renderPage(under, next);                 // next page waits beneath
      live.classList.add("turn-fwd");          // current bends away
      live.addEventListener("animationend", () => {
        live.classList.remove("turn-fwd");
        pageIndex = next;
        renderPage(live, pageIndex);           // live becomes the new page
        under.innerHTML = "";
        turning = false;
        updateChrome();
      }, { once: true });
    } else {
      renderPage(under, pageIndex);            // current page waits beneath
      pageIndex = next;
      renderPage(live, pageIndex);             // previous page…
      live.classList.add("turn-back");         // …turns back into place
      live.addEventListener("animationend", () => {
        live.classList.remove("turn-back");
        under.innerHTML = "";
        turning = false;
        updateChrome();
      }, { once: true });
    }
  }

  // ---------- wiring ----------

  // Page turns use the blank outer margins of the live page instead of
  // transparent overlay buttons. That keeps controls inside the page (heart,
  // photo, caption, tools) clickable even when they sit near an edge.
  $("page-live").addEventListener("click", (e) => {
    if (turning || !album) return;

    // Only the page's own blank margin turns. The old test was "did this
    // click miss a control", which counted the ruled area around a caption
    // box and the space beside the inscription — exactly where you aim when
    // you mean to start typing, so the page flipped instead. Aiming had to
    // be done from the middle of the box, which is the reported annoyance.
    const target = e.target;
    const blank = target === e.currentTarget ||
      target.classList.contains("page-inner") ||
      target.classList.contains("cast-foot");
    if (!blank) return;
    // Anything the reader is editing keeps the page still while they work.
    const active = document.activeElement;
    if (active && active.closest?.("#page-live") &&
        active.matches("textarea, input, [contenteditable='true']")) return;

    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width) return;
    const x = e.clientX - rect.left;
    if (x <= rect.width * 0.15) turn(-1);
    else if (x >= rect.width * 0.85) turn(1);
  });
  $("edge-prev").addEventListener("click", () => turn(-1));
  $("edge-next").addEventListener("click", () => turn(1));
  $("ribbon").addEventListener("click", () => {
    favoritesOnly = !favoritesOnly;
    pageIndex = 0;
    renderPage($("page-live"), pageIndex);
    updateChrome();
  });
  $("back-to-shelf").addEventListener("click", () => { pruneEmptyCast(); renderShelf(); });
  // Start a chapter here. The marker takes "now", so it lands after the
  // newest photograph — which is where "here" is when you're reading.
  $("add-chapter").addEventListener("click", async () => {
    album.chapters = album.chapters || [];

    // "Start a new chapter HERE" — at the page you are looking at, not at
    // this moment in time. Pages are ordered by timestamp, so a chapter
    // stamped "now" sorted after every photograph already in the album:
    // anyone adding chapters to a book they had been keeping for months
    // found all of them stacked at the back. The chapter now takes a moment
    // just before whatever page you are on, and lands in front of it.
    const items = pageItems();
    const here = items[pageIndex - itemOffset()];      // undefined on front matter
    const first = items[0];
    const at = here ? here.at - 1
      : (pageIndex < itemOffset() && first ? first.at - 1 : Date.now());

    album.chapters.push({
      id: `ch_${Date.now().toString(36)}`,
      at,
      title: "",
      note: "",
      photoId: null,
    });
    await saveChapters();
    const after = pageItems();
    const idx = after.findIndex((i) => i.kind === "chapter" && i.ch.id === album.chapters.at(-1).id);
    goToPage(idx >= 0 ? idx + itemOffset() : pageCount() - 2);
    updateChrome();
  });

  // Close the story, or lift the ending again. Never a one-way door: people
  // finish an album and then keep playing.
  // ---------- export: the book, as one file ----------

  const QUALITIES = [
    { id: "web", cap: 1400, q: 0.82, label: "Web quality",
      note: "Sharp on any screen, small enough to send. Right for almost everyone.",
      perPhoto: 190 * 1024 },
    { id: "full", cap: 2600, q: 0.94, label: "Full quality",
      note: "Close to the originals. Best if you want to print a page or zoom right in.",
      perPhoto: 900 * 1024 },
  ];

  const prettySize = (bytes) => (bytes >= 1024 * 1024 * 1024
    ? `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`
    : `${Math.max(1, Math.round(bytes / 1024 / 1024))} MB`);

  /** Photos are stored as lossless PNGs, which is right for the archive and
   *  far too heavy for a file you send someone — base64 adds a third again
   *  on top. So the reader picks, and is told what the choice costs before
   *  making it rather than after a four-minute wait. */
  function askExportQuality(sessionId, name) {
    const count = (album?.sessionId === sessionId ? album.photos.length : 0);
    const box = $("exportq");
    const list = $("exportq-choices");
    list.innerHTML = "";

    for (const q of QUALITIES) {
      const est = Math.round(q.perPhoto * Math.max(1, count) * 1.37);  // base64 overhead
      const row = document.createElement("button");
      row.type = "button";
      row.className = "exportq-row";
      const h = document.createElement("strong");
      h.textContent = q.label;
      const sub = document.createElement("small");
      sub.textContent = q.note;
      const size = document.createElement("span");
      size.className = "exportq-size";
      size.textContent = count ? `about ${prettySize(est)}` : "";
      row.append(h, sub, size);
      row.addEventListener("click", () => {
        box.hidden = true;
        exportAsPage(sessionId, name, q);
      });
      list.appendChild(row);
    }

    const heavy = QUALITIES[1].perPhoto * Math.max(1, count) * 1.37;
    const warn = $("exportq-warn");
    if (count > 60) {
      warn.hidden = false;
      warn.textContent = `This album has ${count} photographs. Full quality would make a ` +
        `file of roughly ${prettySize(heavy)} — slow to open and too big for most chat apps ` +
        `to carry. Web quality is the sensible choice at this length.`;
    } else if (count > 20) {
      warn.hidden = false;
      warn.textContent = "Larger files take a while to write and to open. " +
        "Web quality looks the same on a screen.";
    } else {
      warn.hidden = true;
    }
    box.hidden = false;
  }

  $("exportq-cancel").addEventListener("click", () => ($("exportq").hidden = true));
  $("exportq").addEventListener("click", (e) => { if (e.target === $("exportq")) $("exportq").hidden = true; });

  // ---------- saved casts ----------
  // A cast belongs to an album, but the PEOPLE don't: someone running a
  // dozen scenarios in the same world was re-adding the same faces to every
  // new book. A saved cast is that list — names, notes and portraits —
  // lifted out and kept on its own, ready to drop into any album.
  //
  // They live in extension storage rather than the album database, so they
  // outlive any one book. Portraits are already scaled down on the way in,
  // so a set of a dozen is small.

  const CAST_SETS_KEY = "djpbCastSets";

  async function readCastSets() {
    try {
      const o = await chrome.storage.local.get({ [CAST_SETS_KEY]: {} });
      return o[CAST_SETS_KEY] || {};
    } catch { return {}; }
  }
  async function writeCastSets(map) {
    try { await chrome.storage.local.set({ [CAST_SETS_KEY]: map }); return true; }
    catch { return false; }
  }

  const newCastId = () => `cast_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  const castKey = (c) => String(c?.name || "").trim().toLowerCase();

  function closeCastSets() {
    const box = $("castsets");
    if (!box || box.hidden) return;
    box.hidden = true;
    $("castsets-list").innerHTML = "";
  }

  async function openCastSets() {
    if (!album) return;
    const people = (album.cast || []).filter((c) => !castIsEmpty(c));
    $("castsets-sub").textContent = people.length
      ? `${people.length} on this album's cast`
      : "This album has nobody on its cast yet";
    $("castsets-store").disabled = people.length === 0;
    $("castsets-name").value = "";
    await renderCastSets();
    $("castsets").hidden = false;
    $("castsets-name").focus();
  }

  async function renderCastSets() {
    const list = $("castsets-list");
    list.innerHTML = "";
    const sets = await readCastSets();
    const all = Object.values(sets).sort((a, b) => (b.at || 0) - (a.at || 0));
    if (!all.length) {
      const empty = document.createElement("p");
      empty.className = "castsets-empty";
      empty.textContent = "No saved casts yet. Name this album's cast above and it will be here for the next book.";
      list.appendChild(empty);
      return;
    }

    for (const set of all) {
      const row = document.createElement("div");
      row.className = "castsets-row";

      const faces = document.createElement("div");
      faces.className = "castsets-faces";
      for (const c of set.cast.slice(0, 5)) {
        const img = document.createElement("img");
        img.alt = "";
        img.loading = "lazy";
        if (c.img) img.src = c.img; else img.className = "blank";
        faces.appendChild(img);
      }
      row.appendChild(faces);

      const text = document.createElement("button");
      text.type = "button";
      text.className = "castsets-text";
      const h = document.createElement("strong");
      h.textContent = set.name;
      const sub = document.createElement("small");
      const names = set.cast.map((c) => c.name).filter(Boolean);
      sub.textContent = `${set.cast.length} character${set.cast.length === 1 ? "" : "s"}` +
        (names.length ? ` — ${names.slice(0, 4).join(", ")}${names.length > 4 ? "…" : ""}` : "");
      text.append(h, sub);
      text.title = `Add these characters to ${album.title || "this album"}`;
      text.addEventListener("click", () => loadCastSet(set));
      row.appendChild(text);

      const update = document.createElement("button");
      update.type = "button";
      update.className = "castsets-mini";
      update.textContent = "Update";
      update.title = "Replace this saved cast with the one on this album";
      update.addEventListener("click", async () => {
        const people = (album.cast || []).filter((c) => !castIsEmpty(c));
        if (!people.length) return;
        const ok = await askConfirm({
          title: `Update “${set.name}”?`,
          body: `It will hold this album's ${people.length} character${people.length === 1 ? "" : "s"} instead of its current ${set.cast.length}.`,
          yes: "Update", no: "Leave it", danger: false,
        });
        if (!ok) return;
        const sets2 = await readCastSets();
        sets2[set.id] = { ...set, cast: people.map(stripCastEntry), at: Date.now() };
        await writeCastSets(sets2);
        await renderCastSets();
      });
      row.appendChild(update);

      const del = document.createElement("button");
      del.type = "button";
      del.className = "castsets-mini danger";
      del.textContent = "✕";
      del.title = "Forget this saved cast";
      del.addEventListener("click", async () => {
        const ok = await askConfirm({
          title: `Forget “${set.name}”?`,
          body: "The characters stay in any album you already added them to.",
          yes: "Forget it",
        });
        if (!ok) return;
        const sets2 = await readCastSets();
        delete sets2[set.id];
        await writeCastSets(sets2);
        await renderCastSets();
      });
      row.appendChild(del);

      list.appendChild(row);
    }
  }

  /** Only the parts of a cast entry that mean anything in another book. */
  const stripCastEntry = (c) => ({ name: c.name || "", note: c.note || "", img: c.img || null });

  async function storeCastSet() {
    const people = (album.cast || []).filter((c) => !castIsEmpty(c));
    if (!people.length) return;
    const name = $("castsets-name").value.trim() ||
      album.title || `Cast of ${people.length}`;
    const sets = await readCastSets();
    const id = newCastId();
    sets[id] = { id, name, at: Date.now(), cast: people.map(stripCastEntry) };
    const ok = await writeCastSets(sets);
    if (!ok) {
      await askConfirm({
        title: "Couldn't save that cast",
        body: "Extension storage refused the write — it may be full.",
        yes: "OK", no: "Close", danger: false,
      });
      return;
    }
    $("castsets-name").value = "";
    await renderCastSets();
  }

  /** Add a saved cast to this album. Anyone already here by name is left
   *  alone: loading a set should never overwrite a portrait or note the
   *  reader has already set on this book. */
  async function loadCastSet(set) {
    album.cast = album.cast || [];
    const here = new Set(album.cast.map(castKey).filter(Boolean));
    const incoming = set.cast.filter((c) => !here.has(castKey(c)));
    if (!incoming.length) {
      await askConfirm({
        title: "Everyone is already here",
        body: `This album's cast already lists ${set.cast.length === 1 ? "that character" : "all of those characters"} by name.`,
        yes: "OK", no: "Close", danger: false,
      });
      return;
    }
    // Blank rows the reader started get filled before new ones are added.
    for (const c of incoming) {
      const blank = album.cast.find((x) => castIsEmpty(x));
      if (blank) Object.assign(blank, stripCastEntry(c));
      else album.cast.push({ id: newCastId(), ...stripCastEntry(c) });
    }
    await saveCast();
    closeCastSets();
    goToPage(1);                       // the first cast page
    renderPage($("page-live"), pageIndex);
    updateChrome();
  }

  $("castsets-close").addEventListener("click", closeCastSets);
  $("castsets-store").addEventListener("click", storeCastSet);
  $("castsets").addEventListener("click", (e) => { if (e.target === $("castsets")) closeCastSets(); });
  $("castsets-name").addEventListener("keydown", (e) => {
    e.stopPropagation();
    if (e.key === "Enter") storeCastSet();
  });
  document.addEventListener("keydown", (e) => {
    if ($("castsets").hidden) return;
    e.stopPropagation();
    if (e.key === "Escape") closeCastSets();
  }, true);

  // ---------- index ----------
  // A sheet over the book rather than pages in it: a long album's index
  // would itself be a dozen pages to flip through. Every page is a tile —
  // its picture, because nobody remembers a page number, only the photo —
  // and chapters break the grid into sections.

  function closeIndex() {
    const box = $("index");
    if (!box || box.hidden) return;
    box.hidden = true;
    $("index-grid").innerHTML = "";   // release the <img>s; the object URLs are shared and stay
  }

  function openIndex() {
    if (!album) return;
    // Not while you're standing on a cast page — that blank row is one you
    // may be about to fill in.
    if (!(pageIndex >= 1 && pageIndex < itemOffset())) pruneEmptyCast();
    const grid = $("index-grid");
    grid.innerHTML = "";
    const items = pageItems();
    const off = itemOffset();
    const photosOnly = items.filter((it) => it.kind === "photo").length;
    $("index-sub").textContent = favoritesOnly
      ? `${photosOnly} favourite${photosOnly === 1 ? "" : "s"}`
      : `${photosOnly} photograph${photosOnly === 1 ? "" : "s"}` +
        (album.chapters?.length ? ` · ${album.chapters.length} chapter${album.chapters.length === 1 ? "" : "s"}` : "");

    let current = null;
    const tile = (page, { src, label, title, kind }) => {
      const t = document.createElement("button");
      t.type = "button";
      t.className = "ix-tile" + (kind ? ` ix-${kind}` : "") + (page === pageIndex ? " current" : "");
      if (src) {
        const img = document.createElement("img");
        img.src = src;
        img.alt = "";
        img.loading = "lazy";
        img.decoding = "async";
        t.appendChild(img);
      } else {
        const blank = document.createElement("span");
        blank.className = "ix-blank";
        blank.textContent = kind === "pocket" ? "▭" : kind === "end" ? "❦" : "";
        t.appendChild(blank);
      }
      const num = document.createElement("span");
      num.className = "ix-num";
      num.textContent = label;
      t.appendChild(num);
      if (title) t.title = title;
      t.addEventListener("click", () => { closeIndex(); goToPage(page); });
      if (page === pageIndex) current = t;
      grid.appendChild(t);
      return t;
    };
    const heading = (page, text) => {
      const h = document.createElement("button");
      h.type = "button";
      h.className = "ix-heading" + (page === pageIndex ? " current" : "");
      h.textContent = text;
      h.addEventListener("click", () => { closeIndex(); goToPage(page); });
      if (page === pageIndex) current = h;
      grid.appendChild(h);
    };

    // Front matter.
    const coverRec = album.photos.find((r) => r.id === album.coverId) || album.photos.at(-1) || null;
    tile(0, { src: coverRec ? photoUrl(coverRec) : "", label: favoritesOnly ? "♥" : "Title", kind: "title",
              title: favoritesOnly ? "Favourites" : album.title });
    for (let i = 0; i < castPages(); i++) {
      const face = castList().slice(i * CAST_PER_PAGE, (i + 1) * CAST_PER_PAGE).find((c) => c.img);
      tile(1 + i, { src: face?.img || "", label: `Cast ${LOWER_ROMAN[i + 1] || i + 1}`, kind: "cast",
                    title: "Dramatis personae" });
    }

    // The story. Page numbers match the counter under the book.
    items.forEach((it, i) => {
      const page = off + i;
      if (it.kind === "chapter") {
        heading(page, `Chapter ${roman(it.number)}${it.ch.title ? ` — ${it.ch.title}` : ""}`);
        return;
      }
      const rec = it.rec;
      tile(page, { src: photoUrl(rec), label: String(i + 1), kind: "photo",
                   title: (rec.caption || "").replace(/\s+/g, " ").slice(0, 120) });
    });

    if (storyEnded()) tile(off + items.length, { label: "The End", kind: "end", title: "The End" });
    tile(pageCount() - 1, { label: favoritesOnly ? "End" : "Pocket", kind: "pocket",
                            title: favoritesOnly ? "End of favourites" : "Back pocket — unfiled captures" });

    $("index").hidden = false;
    // Land on where you are, not the top.
    if (current) requestAnimationFrame(() => current.scrollIntoView({ block: "center" }));
  }

  $("index-btn").addEventListener("click", openIndex);
  $("index-close").addEventListener("click", closeIndex);
  $("index").addEventListener("click", (e) => { if (e.target === $("index")) closeIndex(); });
  document.addEventListener("keydown", (e) => {
    if ($("index").hidden) return;
    // The reader's arrow keys must not turn pages under the sheet.
    e.stopPropagation();
    if (e.key === "Escape") closeIndex();
  }, true);

  $("add-cast").addEventListener("click", async () => {
    if (!castList().length) { await addCastMember(); goToPage(1); }
    else goToPage(1);
  });

  $("end-story").addEventListener("click", async () => {
    album.endedAt = album.endedAt ? null : Date.now();
    await saveStoryEnd(album.endedAt);
    updateChrome();
    if (album.endedAt) goToPage(itemOffset() + pageItems().length);
    else { pageIndex = Math.min(pageIndex, pageCount() - 1); renderPage($("page-live"), pageIndex); }
  });

  // The counter doubles as the way in: click it and type a page number.
  // No new chrome on the page for something most people never need.
  $("page-count").addEventListener("click", () => {
    if ($("page-count").querySelector("input")) return;
    const box = document.createElement("input");
    box.type = "number";
    box.min = "1";
    box.max = String(pageCount() - 2);
    box.value = String(Math.max(1, pageIndex));
    box.className = "page-jump";
    const restore = () => updateChrome();
    box.addEventListener("blur", restore);
    box.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") { goToPage(Number(box.value) || pageIndex); }
      if (e.key === "Escape") { restore(); }
    });
    $("page-count").textContent = "";
    $("page-count").appendChild(box);
    box.focus();
    box.select();
  });

  $("design-btn").addEventListener("click", () => {
    const pop = $("theme-pop");
    if (!pop.childElementCount) {
      const row = (label) => {
        const l = document.createElement("div");
        l.className = "pop-label";
        l.textContent = label;
        const r = document.createElement("div");
        r.className = "pop-row";
        pop.append(l, r);
        return r;
      };

      // On a phone the popover is a bottom sheet that covers the tools row —
      // including the button that opened it — so it needs its own way out.
      const head = document.createElement("div");
      head.className = "pop-head";
      const done = document.createElement("button");
      done.type = "button";
      done.className = "pop-done";
      done.textContent = "Done ✕";
      done.addEventListener("click", () => { pop.hidden = true; });
      head.appendChild(done);
      pop.appendChild(head);

      const bindings = row("Binding");
      for (const [id, label] of THEMES) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "swatch";
        b.dataset.theme = id; // the mini binds in its colors
        const mini = document.createElement("i");
        mini.className = "mini";
        const name = document.createElement("span");
        name.textContent = label;
        b.append(mini, name);
        b.addEventListener("click", async () => {
          album.theme = id;
          applyTheme(id);
          ensurePageArt(album).catch(() => {});
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, theme: id }));
          for (const s of bindings.querySelectorAll(".swatch")) {
            s.classList.toggle("active", s === b);
          }
        });
        bindings.appendChild(b);
      }

      // Light or dark ground — only for bindings that paint one. Not a new
      // binding: the same Roses, the same blooms, over black instead of blush.
      const shadeRow = row("Ground");
      shadeRow.classList.add("shade-row");
      for (const [id, label] of [["light", "Light"], ["dark", "Dark"]]) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "swatch shade-swatch" + ((album.shade || "light") === id ? " active" : "");
        b.dataset.shade = id;
        b.textContent = label;
        b.addEventListener("click", async () => {
          album.shade = id;
          applyShade(id);
          ensurePageArt(album).catch(() => {});
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, shade: id }));
          for (const x of shadeRow.querySelectorAll(".shade-swatch")) x.classList.toggle("active", x === b);
        });
        shadeRow.appendChild(b);
      }
      const syncShadeRow = () => {
        const show = album.theme === "roses";
        shadeRow.hidden = !show;
        const label = shadeRow.previousElementSibling;   // row() adds the label just before
        if (label?.classList.contains("pop-label")) label.hidden = !show;
      };
      syncShadeRow();
      // keep it in step when a binding is picked
      bindings.addEventListener("click", () => setTimeout(syncShadeRow, 0));

      const framesRow = row("Frames");
      for (const [id, label] of FRAMES) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "swatch fswatch";
        const mini = document.createElement("i");
        mini.className = "mini";
        mini.dataset.frame = id;   // the mini wears the material itself
        const name = document.createElement("span");
        name.textContent = label;
        b.append(mini, name);
        b.addEventListener("click", async () => {
          album.frame = id;
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, frame: id }));
          for (const s of framesRow.querySelectorAll(".swatch")) {
            s.classList.toggle("active", s === b);
          }
          renderPage($("page-live"), pageIndex);   // the open page redresses
        });
        framesRow.appendChild(b);
      }

      const fonts = row("Handwriting");
      for (const [id, label] of FONTS) {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "fontchip";
        if (id !== "default") b.dataset.font = id; // the sample writes itself
        const aa = document.createElement("i");
        aa.className = "aa";
        aa.textContent = "Aa";
        const name = document.createElement("span");
        name.textContent = label;
        b.append(aa, name);
        b.addEventListener("click", async () => {
          album.font = id;
          applyFont(id);
          const prev = await req(tx("sessions").get(album.sessionId));
          await req(tx("sessions", "readwrite")
            .put({ ...(prev || {}), sessionId: album.sessionId, font: id }));
          for (const s of fonts.querySelectorAll(".fontchip")) {
            s.classList.toggle("active", s === b);
          }
        });
        fonts.appendChild(b);
      }
    }
    for (const s of pop.querySelectorAll(".swatch:not(.fswatch)")) {
      s.classList.toggle("active",
        s.dataset.theme === normTheme(album?.theme));
    }
    for (const s of pop.querySelectorAll(".fswatch")) {
      s.classList.toggle("active",
        s.querySelector(".mini")?.dataset.frame === normFrame(album?.frame));
    }
    for (const s of pop.querySelectorAll(".fontchip")) {
      s.classList.toggle("active",
        (s.dataset.font || "default") === (album?.font || "default"));
    }
    pop.hidden = !pop.hidden;
  });

  // ---------- backup & restore ----------
  // Extension storage is tied to the extension's identity. Updating in place
  // keeps it; loading from a NEW folder, or removing and re-adding, gives
  // Chrome a different id and the albums are simply not there any more. A
  // portable file is the only thing that survives that, so here is one.

  const blobToDataUrl = (blob) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(new Error("read failed"));
    r.readAsDataURL(blob);
  });
  const dataUrlToBlob = async (u) => (await fetch(u)).blob();

  /** Where a finished file should go.
   *
   *  The share sheet exists because downloading on a phone is a dead end.
   *  On a desktop it's the opposite: Windows' sheet has no "save to disk"
   *  target, so handing it the file strands you with no way to reach
   *  Downloads. Save on desktop, offer the sheet on touch, and fall back to
   *  a download either way. Once it's on disk you can still share it from
   *  the file manager. */
  const prefersShareSheet = () =>
    window.matchMedia("(hover: none) and (pointer: coarse)").matches;

  async function deliverFile(blob, name, mime, title) {
    if (prefersShareSheet() && navigator.canShare) {
      try {
        const file = new File([blob], name, { type: mime });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title });
          return "shared";
        }
      } catch (err) {
        if (err?.name === "AbortError") return "cancelled";
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
    return "saved";
  }

  /** @param onlySession export just this album (undefined = everything)
   *  @param share    hand the file to the OS share sheet when available */
  async function backupAll(btn, onlySession, share, titleHint) {
    const original = btn.textContent;
    btn.textContent = "Gathering…";
    try {
      let [images, sessions] = await Promise.all([
        req(tx("images").getAll()),
        req(tx("sessions").getAll()),
      ]);
      if (onlySession) {
        images = images.filter((r) => r.sessionId === onlySession);
        sessions = sessions.filter((s) => s.sessionId === onlySession);
      }

      // The file is assembled as a list of string fragments handed straight
      // to Blob(), never as one JSON string. JSON.stringify() has to build
      // its whole result in memory, and V8 caps a single string at ~512MB —
      // so a large library used to die on "Backup failed" with no
      // explanation. Per-record stringify keeps every fragment ~1MB, and
      // each data URL is dropped as soon as it is written, which also halves
      // peak memory. Same bytes out, no ceiling.
      const parts = ['{"format":"dreamjourney-photobook-backup","version":2,"savedAt":'];
      parts.push(JSON.stringify(new Date().toISOString()));

      let imageCount = 0;
      parts.push(',"images":[');
      for (const r of images) {
        if (imageCount) parts.push(",");
        parts.push(JSON.stringify({
          sessionId: r.sessionId, caption: r.caption || "", prompt: r.prompt || "",
          source: r.source || "", favorite: r.favorite === true,
          // Only present when this photo overrides the album's frame; absent
          // means "wear whatever the album wears", which is the default.
          ...(r.frame ? { frame: r.frame } : {}),
          createdAt: r.createdAt || Date.now(), dataUrl: await blobToDataUrl(r.blob),
        }));
        imageCount += 1;
      }
      parts.push(']');

      parts.push(',"sessions":[');
      let n = 0;
      for (const s of sessions) {
        if (n++) parts.push(",");
        parts.push(JSON.stringify({
          ...s,
          titleBlob: s.titleBlob ? await blobToDataUrl(s.titleBlob) : null,
          referenceBlob: s.referenceBlob ? await blobToDataUrl(s.referenceBlob) : null,
        }));
      }
      parts.push(']}');

      const stamp = new Date().toISOString().slice(0, 10);
      const safe = (onlySession ? (titleHint || album?.title || "album") : "photobook")
        .replace(/[^\w -]+/g, "").trim() || "photobook";
      const name = onlySession ? `${safe}-album-${stamp}.json` : `photobook-backup-${stamp}.json`;
      const blob = new Blob(parts, { type: "application/json" });

      // On a phone, "download a file" is a dead end — the share sheet is how
      // it actually gets to another device or another person.
      const how = await deliverFile(blob, name, "application/json", safe);
      if (how === "cancelled") { btn.textContent = original; return; }
      btn.textContent = `${imageCount} photo${imageCount === 1 ? "" : "s"} ✓`;
    } catch (err) {
      console.warn("[SnapScapes] backup failed:", err);
      btn.textContent = "Backup failed";
    }
    setTimeout(() => (btn.textContent = original), 3000);
  }

  async function restoreFrom(file, btn) {
    const original = btn.textContent;
    btn.textContent = "Restoring…";
    try {
      const data = JSON.parse(await file.text());
      if (data?.format !== "dreamjourney-photobook-backup") {
        throw new Error("that isn't a SnapScapes backup file");
      }

      // Restores ADD to what's here — an existing album is never wiped by one.
      const existing = await req(tx("images").getAll());
      const seen = new Set(existing.map((r) => `${r.sessionId}|${r.createdAt}`));

      // Every blob is decoded BEFORE its transaction opens. Awaiting inside
      // the add() argument let the event loop turn, and IndexedDB commits a
      // transaction the moment it goes idle — so the store had already closed
      // by the time add() ran and no photo was ever restored.
      let added = 0;
      for (const r of data.images || []) {
        if (seen.has(`${r.sessionId}|${r.createdAt}`)) continue; // already here
        const blob = await dataUrlToBlob(r.dataUrl);
        await req(tx("images", "readwrite").add({
          sessionId: r.sessionId, blob,
          caption: r.caption || "", prompt: r.prompt || "",
          source: r.source || "restored", favorite: r.favorite === true,
          ...(r.frame ? { frame: r.frame } : {}),
          createdAt: r.createdAt || Date.now(),
        }));
        added += 1;
      }
      // Backups written before the scrapbook was removed may still carry a
      // "scrapbook" array. It is ignored rather than rejected, so those older
      // files still restore their albums cleanly.
      for (const s of data.sessions || []) {
        const prev = await req(tx("sessions").get(s.sessionId)).catch(() => null);
        const titleBlob = s.titleBlob
          ? await dataUrlToBlob(s.titleBlob) : (prev?.titleBlob || null);
        const referenceBlob = s.referenceBlob
          ? await dataUrlToBlob(s.referenceBlob) : (prev?.referenceBlob || null);
        await req(tx("sessions", "readwrite").put({ ...s, titleBlob, referenceBlob }));
      }
      btn.textContent = `Restored ${added} photo${added === 1 ? "" : "s"} ✓`;
      renderShelf();
    } catch (err) {
      console.warn("[SnapScapes] restore failed:", err);
      btn.textContent = `Failed: ${err.message}`.slice(0, 40);
    }
    setTimeout(() => (btn.textContent = original), 4000);
  }

  $("backup-btn").addEventListener("click", (e) => backupAll(e.currentTarget));

  // ---------- the album picker ----------
  //
  // Share, move and save-as-page are all one-album actions that used to live
  // inside the album, which meant you had to open a book to send it. They sit
  // on the shelf now, so each one asks which album first.

  let pickerChoice = null;

  async function shelfAlbums() {
    const [images, sessions] = await Promise.all([
      req(tx("images").getAll()),
      req(tx("sessions").getAll()),
    ]);
    const byId = new Map();
    for (const r of images) {
      if (r.sessionId === "unfiled") continue;
      const a = byId.get(r.sessionId)
        || { sessionId: r.sessionId, count: 0, latest: 0, coverRec: null };
      a.count += 1;
      if ((r.createdAt || 0) >= a.latest) { a.latest = r.createdAt || 0; a.coverRec = r; }
      byId.set(r.sessionId, a);
    }
    for (const s of sessions) {
      const a = byId.get(s.sessionId);
      if (!a) continue;
      a.title = s.customTitle || s.album?.title || s.sheet?.album?.title || null;
      a.blurb = s.blurb || "";
      a.coverBlob = s.coverBlob || null;   // an image the user supplied
    }
    return [...byId.values()].sort((x, y) => y.latest - x.latest);
  }

  function closePicker() {
    $("picker").hidden = true;
    $("picker-list").innerHTML = "";
    pickerChoice = null;
  }

  /** @param onPick  runs with the chosen album once Continue is pressed */
  async function openPicker({ title, sub, action, onPick }) {
    const albums = await shelfAlbums();
    if (!albums.length) return;

    $("picker-title").textContent = title;
    $("picker-sub").textContent = sub;
    $("picker-go").textContent = action;
    $("picker-go").disabled = true;
    pickerChoice = null;

    const list = $("picker-list");
    list.innerHTML = "";
    for (const a of albums) {
      const name = a.title || `Session ${a.sessionId.slice(0, 8)}`;
      const row = document.createElement("button");
      row.className = "picker-row";
      row.type = "button";
      row.setAttribute("aria-pressed", "false");

      const tick = document.createElement("span");
      tick.className = "picker-tick";
      tick.setAttribute("aria-hidden", "true");

      const thumb = document.createElement("img");
      thumb.className = "picker-thumb";
      thumb.alt = "";
      if (a.coverRec) thumb.src = photoUrl(a.coverRec);

      const text = document.createElement("span");
      text.className = "picker-text";
      const h = document.createElement("strong");
      h.textContent = name;
      const meta = document.createElement("small");
      meta.textContent = a.blurb
        ? `${a.count} photo${a.count === 1 ? "" : "s"} · ${a.blurb}`
        : `${a.count} photo${a.count === 1 ? "" : "s"}`;
      text.append(h, meta);

      row.append(tick, thumb, text);
      // One at a time: picking a book releases the one before it.
      row.addEventListener("click", () => {
        for (const other of list.querySelectorAll(".picker-row")) {
          other.classList.remove("chosen");
          other.setAttribute("aria-pressed", "false");
        }
        row.classList.add("chosen");
        row.setAttribute("aria-pressed", "true");
        pickerChoice = { ...a, name };
        $("picker-go").disabled = false;
      });
      list.appendChild(row);
    }

    $("picker").hidden = false;
    $("picker-go").onclick = () => {
      if (!pickerChoice) return;
      const chosen = pickerChoice;
      closePicker();
      onPick(chosen);
    };
  }

  $("picker-cancel").addEventListener("click", closePicker);
  $("picker").addEventListener("click", (e) => {
    if (e.target === $("picker")) closePicker();
  });
  // Escape closes it, like every other dialog here. Without this the picker
  // sat over the shelf swallowing clicks until you found Cancel.
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !$("picker").hidden) {
      e.stopPropagation();
      closePicker();
    }
  }, true);

  // Sending an album to a person and moving it to your own second device
  // produce byte-identical files, so they are one action. If the shared copy
  // ever diverges from the archived one — smaller, and with the sender's
  // sheet stripped — that is the point to split this back into two.
  $("share-btn").addEventListener("click", () => openPicker({
    title: "Save an album to a file",
    sub: "One file holding this album. Send it to someone or move it to your other device — either way, they open SnapScapes and press Restore to load it.",
    action: "Make the file",
    onPick: (a) => backupAll($("share-btn"), a.sessionId, true, a.name),
  }));

  $("restore-btn").addEventListener("click", () => $("restore-input").click());
  $("restore-input").addEventListener("change", (e) => {
    const file = e.target.files[0];
    e.target.value = "";
    if (file) restoreFrom(file, $("restore-btn"));
  });

  /** Ask the host chat page (when embedded) for the newest reply as rendered.
   *  Resolves "" outside the overlay or if the page doesn't answer in time. */
  function requestHostLatest() {
    if (!EMBED) return Promise.resolve("");
    return new Promise((resolve) => {
      const done = (v) => { clearTimeout(timer); removeEventListener("message", on); resolve(v); };
      const on = (e) => {
        // Only the page that embedded this album may answer. browse.html runs
        // in the extension's own origin with access to chrome.* and the whole
        // photobook, and any script on the host page can postMessage into the
        // frame — so the sender is checked, not just the message shape.
        if (e.source !== parent) return;
        if (e.data?.source === "djpb-host" && e.data.cmd === "latest-reply") {
          done(String(e.data.text || ""));
        }
      };
      const timer = setTimeout(() => done(""), 1500);
      addEventListener("message", on);
      parent.postMessage({ source: "djpb-album", cmd: "latest-reply" }, "*");
    });
  }

  // A copy that needs neither the extension nor the site: one HTML file with
  // the photos embedded, openable in any browser, forever.
  $("export-btn").addEventListener("click", () => openPicker({
    title: "Save an album as a book",
    sub: "One HTML file holding the whole album. Anyone can open it in a browser — no extension needed.",
    action: "Choose a size",
    onPick: (a) => askExportQuality(a.sessionId, a.name),
  }));

  async function exportAsPage(sessionId, titleHint, quality) {
    const btn = $("export-btn");
    const original = btn.textContent;
    btn.textContent = "Binding…";
    const wasIndex = pageIndex;
    const wasFav = favoritesOnly;
    try {
      if (!album || album.sessionId !== sessionId) await openAlbum(sessionId);
      favoritesOnly = false;

      const readAsDataUrl = (blob) => new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = () => rej(new Error("read failed"));
        r.readAsDataURL(blob);
      });

      const toDataUrl = async (blob) => {
        try {
          const bmp = await createImageBitmap(blob);
          const scale = Math.min(1, quality.cap / Math.max(bmp.width, bmp.height));
          const canvas = document.createElement("canvas");
          canvas.width = Math.round(bmp.width * scale);
          canvas.height = Math.round(bmp.height * scale);
          canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
          bmp.close?.();
          const out = canvas.toDataURL("image/jpeg", quality.q);
          const orig = await readAsDataUrl(blob);
          return out.length < orig.length ? out : orig;   // a small source can grow
        } catch {
          return readAsDataUrl(blob);   // transparent PNGs, odd codecs
        }
      };

      // Every blob: URL on the page, resolved once. The pages are rendered by
      // the reader's OWN renderPage below, so they carry object URLs; swapping
      // them for data URLs afterwards is what makes the file standalone.
      const urlMap = new Map();
      for (const rec of album.photos) {
        urlMap.set(photoUrl(rec), await toDataUrl(rec.blob));
      }
      for (const c of album.cast || []) {
        if (c.img) urlMap.set(c.img, c.img);      // already a data URL
      }
      if (album.titleBlob) {
        const el = $("page-live").querySelector(".title-plate img");
        if (el?.src?.startsWith("blob:")) urlMap.set(el.src, await toDataUrl(album.titleBlob));
      }

      // Render each page with the reader's own code, into a stage that is
      // laid out but out of sight, then take the markup. Rebuilding these
      // pages by hand would mean two renderers drifting apart; this way the
      // book in the file is the book on screen, by construction.
      const stage = document.createElement("div");
      stage.id = "page-live";
      stage.style.cssText = "position:fixed;left:-99999px;top:0;width:520px;height:720px";
      document.body.appendChild(stage);

      const last = pageCount() - 1;          // the back pocket isn't part of the book
      const pages = [];
      for (let i = 0; i <= last; i++) {
        if (i === last && !album.unfiled?.length) { /* pocket page: skip */ }
        if (i === last) continue;
        btn.textContent = `Binding… ${Math.round((i / Math.max(1, last)) * 100)}%`;
        renderPage(stage, i);
        pages.push(sanitisePage(stage.firstElementChild, urlMap));
        await new Promise((r) => setTimeout(r, 0));   // let the tab breathe
      }
      stage.remove();

      const css = await (await fetch(chrome.runtime.getURL("browse.css"))).text();
      const doc = bookDocument({
        title: album.title || titleHint || "Album",
        theme: album.theme || "",
        font: album.font || "",
        shade: album.shade === "dark" ? "dark" : "",
        css,
        pages,
      });

      const safe = String(album.title || titleHint || "album").replace(/[^\w -]+/g, "").trim() || "album";
      const blob = new Blob([doc], { type: "text/html" });
      const how = await deliverFile(blob, `${safe}.html`, "text/html", album.title);
      if (how === "cancelled") { btn.textContent = original; return; }
      btn.textContent = how === "shared" ? "Sent \u2713" : `Saved \u2713 ${prettySize(blob.size)}`;
    } catch (err) {
      console.warn("[SnapScapes] export failed:", err);
      btn.textContent = "Couldn't save";
    } finally {
      favoritesOnly = wasFav;
      pageIndex = wasIndex;
      if (album) { renderPage($("page-live"), pageIndex); updateChrome(); }
    }
    setTimeout(() => (btn.textContent = original), 3500);
  }

  /** A rendered page, made fit for a file: no controls, no live URLs, and
   *  the things you type turned into the things you typed. */
  function sanitisePage(inner, urlMap) {
    const clone = inner.cloneNode(true);

    // Editable fields hold their value in the DOM, not in the markup, so a
    // plain serialise would lose every caption and inscription. Any input,
    // not just type="text": the cast's fields carry no type attribute.
    for (const field of clone.querySelectorAll("textarea, input")) {
      const text = field.value || field.getAttribute("value") || "";
      if (!text.trim()) { field.remove(); continue; }
      const p = document.createElement("div");
      p.className = field.tagName === "TEXTAREA" ? "note-text" : "line-text";
      p.textContent = text;
      field.replaceWith(p);
    }

    // Controls that only make sense in the extension.
    for (const el of clone.querySelectorAll(
      ".note-tools, .cast-del, .cast-add, .cast-drop, .cast-sets, .favorite-heart, .page-jump, .add-plate")) {
      el.remove();
    }
    // Placeholders — "Add a title image", an unnamed cast row — are prompts
    // to do something, and there is nothing to do in a saved book.
    for (const el of clone.querySelectorAll(".empty")) el.remove();

    // Everything else built as a button IS the content: a cast portrait, a
    // name and a note are each a button in the reader, so removing buttons
    // wholesale emptied the entire cast page. Turn them into plain elements
    // instead — the stylesheet matches on class, not on tag.
    for (const el of clone.querySelectorAll("button")) {
      if (!el.textContent.trim() && !el.querySelector("img")) { el.remove(); continue; }
      const plain = document.createElement("div");
      plain.className = el.className;
      plain.innerHTML = el.innerHTML;
      el.replaceWith(plain);
    }
    for (const el of clone.querySelectorAll("select, [contenteditable]")) {
      if (el.tagName === "SELECT") el.remove();
      else el.removeAttribute("contenteditable");
    }

    for (const img of clone.querySelectorAll("img")) {
      const hit = urlMap.get(img.getAttribute("src"));
      if (hit) img.setAttribute("src", hit);
      else if ((img.getAttribute("src") || "").startsWith("blob:")) img.remove();
      img.removeAttribute("loading");
    }
    for (const el of clone.querySelectorAll("[style*='blob:']")) {
      const style = el.getAttribute("style");
      el.setAttribute("style", style.replace(/blob:[^)"']+/g, (m) => urlMap.get(m) || m));
    }
    return clone.outerHTML;
  }

  /** The file: the album's own stylesheet, its pages, and just enough script
   *  to turn them. No database, no editing — a keepsake, not a working copy. */
  function bookDocument({ title, theme, font, shade = "", css, pages }) {
    const esc = (s) => String(s || "").replace(/[&<>"]/g,
      (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
    const data = JSON.stringify(pages)
      .replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");

    return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<style>
${css}
/* The file's own additions. #book takes its size from script in the reader
   (fitBook), which this file doesn't have — without it the book collapses
   and you see one page and nothing to turn. Sized here instead. */
body { margin: 0; background: #0d0a14; display: flex; align-items: center;
       justify-content: center; min-height: 100vh; }
#reader { display: flex; flex-direction: column; align-items: center;
          gap: 12px; padding: 16px; box-sizing: border-box; }
#book { position: relative; }
.note-text, .line-text { white-space: pre-wrap; }
/* In the reader a long caption sits in a textarea that scrolls itself. As
   static text it just overflowed a fixed-height page and was cut off, so
   the page scrolls instead. */
#page-live .page-inner { overflow-y: auto; overscroll-behavior: contain; }
#page-live .page-inner::-webkit-scrollbar { width: 8px; }
#page-live .page-inner::-webkit-scrollbar-thumb {
  background: rgba(127, 127, 127, 0.35); border-radius: 4px;
}
.cast-nm, .cast-nt { cursor: default; }
#bookfoot { display: flex; align-items: center; gap: 14px;
            font: 12px system-ui, sans-serif; color: #b3a8c8; }
#bookfoot button {
  background: rgba(255, 255, 255, 0.06); color: #e9e4f5;
  border: 1px solid rgba(255, 255, 255, 0.18); border-radius: 999px;
  width: 34px; height: 34px; font-size: 16px; line-height: 1; cursor: pointer;
}
#bookfoot button:hover:not(:disabled) { background: rgba(255, 255, 255, 0.14); }
#bookfoot button:disabled { opacity: 0.3; cursor: default; }
#folio { min-width: 90px; text-align: center; letter-spacing: .04em; }
@media print {
  body { background: #fff; }
  #bookfoot, .page-edge { display: none !important; }
  #book { box-shadow: none; width: 100% !important; height: auto !important; }
}
</style></head>
<body${theme ? ` data-theme="${esc(theme)}"` : ""}${font ? ` data-font="${esc(font)}"` : ""}${shade ? ` data-shade="${esc(shade)}"` : ""}>
<section id="reader" aria-label="${esc(title)}">
  <div id="book">
    <div id="fore-edge" aria-hidden="true"></div>
    <div id="page-live"></div>
    <button id="edge-prev" class="page-edge" type="button" title="Previous page"><span>&lsaquo;</span></button>
    <button id="edge-next" class="page-edge" type="button" title="Next page"><span>&rsaquo;</span></button>
  </div>
  <div id="bookfoot">
    <button id="nav-prev" type="button" aria-label="Previous page">&lsaquo;</button>
    <span id="folio"></span>
    <button id="nav-next" type="button" aria-label="Next page">&rsaquo;</button>
  </div>
</section>
<script>
(function () {
  var pages = ${data};
  var i = 0;
  var live = document.getElementById("page-live");
  var book = document.getElementById("book");
  var folio = document.getElementById("folio");
  var edge = document.getElementById("fore-edge");
  var buttons = ["edge-prev", "nav-prev"].map(function (id) { return document.getElementById(id); });
  var nexts = ["edge-next", "nav-next"].map(function (id) { return document.getElementById(id); });

  // The reader sizes the book from script; this is that, shortened. 3:4,
  // as tall as the window allows, never wider than it.
  function fit() {
    var availH = Math.max(240, window.innerHeight - 96);
    var availW = Math.max(240, window.innerWidth * 0.94);
    var w = Math.min(availW, availH * 0.75);
    book.style.width = Math.round(w) + "px";
    book.style.height = Math.round(w * 4 / 3) + "px";
    book.style.maxHeight = "none";
  }

  function show(n) {
    i = Math.max(0, Math.min(n, pages.length - 1));
    live.innerHTML = pages[i];
    folio.textContent = (i + 1) + " of " + pages.length;
    buttons.forEach(function (b) { if (b) b.disabled = i === 0; });
    nexts.forEach(function (b) { if (b) b.disabled = i === pages.length - 1; });
    if (edge) edge.style.width = Math.min(12, 3 + (pages.length - 1 - i) * 1.6) + "px";
  }

  buttons.forEach(function (b) { if (b) b.addEventListener("click", function () { show(i - 1); }); });
  nexts.forEach(function (b) { if (b) b.addEventListener("click", function () { show(i + 1); }); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "ArrowRight" || e.key === " ") { e.preventDefault(); show(i + 1); }
    if (e.key === "ArrowLeft") show(i - 1);
    if (e.key === "Home") show(0);
    if (e.key === "End") show(pages.length - 1);
  });
  var x0 = null;
  live.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  live.addEventListener("touchend", function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 40) show(i + (dx < 0 ? 1 : -1));
    x0 = null;
  }, { passive: true });

  window.addEventListener("resize", fit);
  fit();
  show(0);
}());
<\/script>
</body></html>`;
  }

  // Outside tap and Escape both dismiss the design sheet.
  document.addEventListener("pointerdown", (e) => {
    const pop = $("theme-pop");
    if (!pop || pop.hidden) return;
    if (pop.contains(e.target) || $("design-btn").contains(e.target)) return;
    pop.hidden = true;
  }, true);
  document.addEventListener("keydown", (e) => {
    const pop = $("theme-pop");
    if (e.key === "Escape" && pop && !pop.hidden) {
      e.stopPropagation();
      pop.hidden = true;
    }
  }, true);

  $("add-photos").addEventListener("click", () => $("add-input").click());
  $("add-input").addEventListener("change", async (e) => {
    if (!album) return;
    const sessionId = album.sessionId;
    const added = [];
    for (const file of e.target.files) {
      added.push(await req(tx("images", "readwrite").add({
        sessionId,
        blob: file,
        caption: "",          // the filename is not a caption; leave the line free
        source: "upload",
        createdAt: Date.now(),
      })));
    }
    e.target.value = "";
    if (!added.length) return;

    // Land on the photograph itself, not on the last page of the book. The
    // bookmark used to be set to 9999, which clamps to the back pocket — so
    // adding a photo dropped you past it and you had to turn back to write
    // the caption. With several added at once, the FIRST is where you start,
    // and the rest follow in order as you turn.
    await openAlbum(sessionId);
    const items = pageItems();
    const at = items.findIndex((it) => it.kind === "photo" && it.rec.id === added[0]);
    if (at < 0) return;
    goToPage(itemOffset() + at);
    renderPage($("page-live"), pageIndex);
    updateChrome();
    // Writing the caption is the reason you are on this page, so the cursor
    // is already in it. (A focused field also holds the page still, so the
    // click that lands here can't turn it.)
    requestAnimationFrame(() => $("page-live").querySelector(".note textarea")?.focus());
  });
  $("lightbox-close").addEventListener("click", () => ($("lightbox").hidden = true));
  $("lightbox").addEventListener("click", (e) => {
    if (e.target.id === "lightbox") $("lightbox").hidden = true;
  });

  document.addEventListener("keydown", (e) => {
    if (e.target.matches?.("textarea, input, [contenteditable='true']")) return;
    if (!$("lightbox").hidden && e.key === "Escape") {
      $("lightbox").hidden = true;
      return;
    }
    if ($("reader").hidden) return;
    if (e.key === "ArrowRight") turn(1);
    if (e.key === "ArrowLeft") turn(-1);
    if (e.key === "Escape") {
      if (EMBED) parent.postMessage({ source: "djpb-album", cmd: "close" }, "*");
      else renderShelf();
    }
  });

  // Swipe on touch: a thumb drags the page. Three guards, all of which
  // matter on a phone and none of which matter with a mouse:
  //   - a gesture that starts in a scrollable control belongs to that control
  //   - the movement must be clearly horizontal, or scrolling a long note
  //     would flip the page out from under the reader
  //   - it must be a swipe, not a slow drag
  let touch = null;
  document.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 1) { touch = null; return; }
    const t = e.touches[0];
    if (t.target?.closest?.("textarea, input, #theme-pop, #lightbox, .note-tools")) {
      touch = null;
      return;
    }
    touch = { x: t.clientX, y: t.clientY, at: Date.now() };
  }, { passive: true });
  document.addEventListener("touchend", (e) => {
    const start = touch;
    touch = null;
    if (!start || $("reader").hidden || !$("lightbox").hidden) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - start.x;
    const dy = t.clientY - start.y;
    if (Math.abs(dx) < 55) return;                    // too small to mean it
    if (Math.abs(dx) < Math.abs(dy) * 1.6) return;    // that was a scroll
    if (Date.now() - start.at > 800) return;          // a drag, not a swipe
    turn(dx < 0 ? 1 : -1);
  }, { passive: true });

  // ---------- boot ----------

  const params = new URLSearchParams(location.search);
  const EMBED = params.get("embed") === "1";

  // Standalone tab on a phone in desktop mode: scale itself the same way the
  // chat page does. Safe here precisely BECAUSE it is top-level — there is no
  // parent zoom to double up with, which is what went wrong in the overlay.
  if (!EMBED) {
    let ownZoom = 1;
    const fitViewport = () => {
      const base = innerWidth * ownZoom;
      const want = window.isPhone(base) && base > 900
        ? Math.min(2.6, Math.max(1, base / 470))
        : 1;
      if (Math.abs(want - ownZoom) < 0.03) return;
      ownZoom = want;
      if (want === 1) document.documentElement.style.removeProperty("zoom");
      else document.documentElement.style.setProperty("zoom", want.toFixed(2));
      setTimeout(fitBook, 120);
    };
    fitViewport();
    addEventListener("orientationchange", () => setTimeout(fitViewport, 250));
    // Same fitted layout as the overlay uses, driven by the real screen size.
    const markCompact = () => document.body.classList.toggle("compact", innerWidth < 900);
    markCompact();
    addEventListener("resize", () => setTimeout(markCompact, 150));
  }

  // NOTE: the album deliberately does NOT zoom itself when embedded. It lives in an iframe
  // inside a page that may already be zoomed, and applying a second zoom here
  // magnified everything a second time — which is what cut the page off at the
  // top and bottom. Instead the book is measured to fit the space available.

  /** Size the book so the WHOLE page is visible, even if that makes it small.
   *  Done in JS with measured pixels because viewport units are unreliable
   *  here: an iframe's units don't reflect a parent's zoom, and dvh is missing
   *  in some mobile Chromium builds (which silently voids any calc using it). */
  function fitBook() {
    const book = $("book");
    if (!book || $("reader").hidden) return;

    const tools = $("reader-tools");
    const chromeH =
      (tools ? tools.getBoundingClientRect().height : 40) +  // tools row
      46 +                                                   // back / close row
      16;                                                    // breathing room

    // Measure the reader itself where possible: it knows the frame's real
    // height, whereas innerHeight can be wrong inside a zoomed iframe.
    const readerH = $("reader").clientHeight || innerHeight;
    const box = Math.min(readerH || innerHeight, innerHeight || readerH);

    const availH = Math.max(180, box - chromeH);
    const availW = Math.max(180, (($("reader").clientWidth || innerWidth) * 0.94));

    // 3:4 keeps the book's proportions, but on a tall phone that leaves a band
    // of dead space below — and squeezes the note into a few clipped lines.
    // Width still comes from 3:4; the height then grows to take what's left.
    const width = Math.min(availW, availH * 0.75);
    let height = width * 4 / 3;

    const compact = document.body.classList.contains("compact") || innerWidth < 900;
    if (compact && availH > height + 24) {
      height = Math.min(availH, Math.round(height * 1.35));   // fill the gap
    }

    book.style.width = `${Math.round(width)}px`;
    book.style.height = `${Math.round(height)}px`;
    book.style.maxHeight = "none";
  }

  addEventListener("resize", () => {
    setTimeout(fitBook, 120);
  });
  addEventListener("orientationchange", () => {
    setTimeout(fitBook, 220);
  });

  if (EMBED) {
    document.body.classList.add("embed");
    const x = $("embed-close");
    x.hidden = false;
    x.addEventListener("click", () =>
      parent.postMessage({ source: "djpb-album", cmd: "close" }, "*"));
  }

  document.addEventListener("keydown", (e) => {
    // In the overlay, Esc from the shelf hands control back to the site page.
    if (EMBED && e.key === "Escape" && $("reader").hidden && $("lightbox").hidden) {
      parent.postMessage({ source: "djpb-album", cmd: "close" }, "*");
    }
  });

  (async () => {
    db = await openDb();
    const wanted = params.get("session");
    if (wanted) {
      await openAlbum(wanted).catch(renderShelf);
    } else {
      renderShelf();
    }
  })();
})();
