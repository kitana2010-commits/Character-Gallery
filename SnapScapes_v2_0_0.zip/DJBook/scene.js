// scene.js — where the scene is, and the thinking block's own answer to that.
//
// Loaded by the service worker (importScripts) after condense.js.
//
// Location is the one thing prose states once and then assumes, so no single
// text is a reliable source. This module reads several, newest first, and
// reports which one answered — so the UI can say "from the reply" vs "carried
// from an earlier message", and so a pinned location knows whether it is
// correcting a guess or refining a fact.
//
// Sources, strongest first:
//   thinking  WHERE: from the reply's own thinking block (regenerated every turn)
//   reply     an arrival or "in the <place>" statement in the reply's prose
//   player    the same, in the player's message that prompted this reply
//   history   the same, in the previous replies on screen (newest first)
//   memory    the location recorded the last time the player sent a message
//
// Nothing found → no location. A prompt with no Location line lets the image
// model pick something plausible from the rest; a wrong line makes it draw
// the wrong room with confidence.
//
// The Memory Nexus panel is never read for location: it runs several replies
// behind the chat, so what it says is a room the scene may already have left.

const SceneLocator = (() => {
  const { stripDialogue, stripMarkup, isDirective, escapeRe } = PromptCondenser;

  /** Sentences with speech removed but attribution kept. The condenser's own
   *  splitter also drops "she said, sitting in her room" as quotation debris
   *  — right for ranking moments, wrong here, where that tail is the only
   *  place the room is named. */
  function sentencesOf(text) {
    return stripDialogue(stripMarkup(String(text || "")))
      .split(/(?<=[.!?\u2026])\s+(?=["\u201C(]?[A-Za-z])/)
      .map((x) => x.trim())
      .filter((x) => x.length > 8);
  }

  // ---------- vocabulary ----------

  /** Places a scene can be IN. Furniture is deliberately absent: "on the
   *  table" is where the cup is, not where the scene is. */
  const PLACES = [
    // rooms
    "room", "bedroom", "bathroom", "kitchen", "hall", "hallway", "corridor",
    "library", "office", "study", "parlour", "parlor", "lounge", "cellar",
    "basement", "attic", "loft", "chamber", "throne room", "dining room",
    "living room", "ballroom", "nursery", "pantry", "workshop", "lab",
    "laboratory", "infirmary", "dungeon", "cell", "vault", "armoury", "armory",
    "barracks", "stable", "stables", "barn", "shed", "garage", "greenhouse",
    "conservatory", "chapel", "sanctuary", "crypt", "tomb", "foyer", "lobby",
    "stairwell", "elevator", "lift", "closet", "wardrobe", "shower", "bath",
    "tub", "pool", "gym", "classroom", "dormitory", "dorm", "clinic", "ward",
    "cabin", "tent", "hut", "cottage", "house", "home", "apartment", "flat",
    "mansion", "manor", "palace", "castle", "keep", "tower", "fort",
    "fortress", "citadel", "temple", "shrine", "church", "cathedral",
    "monastery", "abbey", "inn", "tavern", "pub", "bar", "cafe", "café",
    "diner", "restaurant", "shop", "store", "market", "bakery", "smithy",
    "forge", "brothel", "theatre", "theater", "arena", "stadium", "museum",
    "gallery", "school", "academy", "university", "hospital", "prison",
    "jail", "station", "airport", "harbour", "harbor", "port", "docks", "dock",
    "pier", "warehouse", "factory", "mill", "mine", "mines", "quarry",
    "camp", "campsite", "encampment", "outpost", "base", "bunker", "hangar",
    "hotel", "motel", "suite", "penthouse", "rooftop", "roof", "balcony",
    "terrace", "porch", "veranda", "patio", "deck", "courtyard", "yard",
    "garden", "orchard", "vineyard", "cemetery", "graveyard",
    // outdoors
    "forest", "woods", "wood", "grove", "clearing", "glade", "meadow", "field",
    "fields", "pasture", "hill", "hills", "hillside", "mountain", "mountains",
    "cliff", "cliffs", "ridge", "valley", "canyon", "gorge", "ravine", "cave",
    "cavern", "tunnel", "passage", "swamp", "marsh", "bog", "desert", "dunes",
    "beach", "shore", "shoreline", "coast", "cove", "bay", "lake", "lakeside",
    "river", "riverbank", "stream", "creek", "waterfall", "spring", "pond",
    "island", "jungle", "plain", "plains", "steppe", "tundra", "glacier",
    "ruins", "battlefield", "crossroads", "road", "roadside", "path", "trail",
    "lane", "street", "streets", "alley", "alleyway", "avenue", "boulevard",
    "square", "plaza", "bridge", "gate", "gates", "wall", "walls", "rampart",
    "ramparts", "battlements", "park", "playground", "parking lot", "car park",
    "city", "town", "village", "hamlet", "settlement", "district", "quarter",
    "slum", "slums", "sewer", "sewers", "catacombs", "underground", "wasteland",
    // vehicles and vessels
    "car", "truck", "van", "cab", "taxi", "bus", "train", "carriage", "wagon",
    "cart", "boat", "ship", "vessel", "hold", "cockpit", "cabin", "airship",
    "shuttle", "bridge", "helicopter", "plane", "jet", "elevator",
  ];

  /** A word that turns a capitalised phrase into a named place ("the Gilded
   *  Cup" is not, "the Gilded Cup Tavern" is). Lore keys count too. */
  const PLACE_TITLE_WORDS = new Set([
    "inn", "tavern", "pub", "bar", "cafe", "café", "diner", "restaurant",
    "hotel", "motel", "manor", "hall", "house", "estate", "castle", "keep",
    "tower", "fort", "fortress", "citadel", "palace", "temple", "shrine",
    "church", "cathedral", "abbey", "monastery", "academy", "school",
    "university", "college", "hospital", "clinic", "library", "museum",
    "gallery", "theatre", "theater", "arena", "stadium", "market", "square",
    "plaza", "park", "garden", "gardens", "bridge", "gate", "gates", "harbour",
    "harbor", "port", "docks", "station", "airport", "road", "street",
    "avenue", "lane", "boulevard", "alley", "district", "quarter", "ward",
    "city", "town", "village", "kingdom", "empire", "realm", "province",
    "county", "forest", "woods", "mountain", "mountains", "peak", "valley",
    "lake", "river", "sea", "ocean", "island", "isle", "beach", "bay", "cove",
    "ruins", "caves", "cave", "mines", "camp", "base", "outpost", "prison",
    "asylum", "club", "lounge", "office", "tower", "apartments", "heights",
    "court", "plaza", "arcade", "mall", "pier", "wharf", "farm", "ranch",
    "vineyard", "cemetery", "graveyard", "crypt", "sanctum", "spire", "hold",
  ]);

  const PLACE_ALT = PLACES.map(escapeRe).join("|");
  const PREP = "(?:in|inside|into|within|on|onto|at|aboard|across|through|" +
               "behind|beneath|under|beside|near|outside|out into|out onto|" +
               "back in|back at|back to|down in|up in|up on|down on|" +
               "toward|towards|to)";
  const DET = "(?:the|a|an|his|her|their|its|this|that|our|my|your)";

  /** "in the <adj adj> place" — a static statement of setting. */
  const STATIC_RE = new RegExp(
    `\\b${PREP}\\s+${DET}\\s+((?:[a-z][a-z'-]*\\s+){0,3}(?:${PLACE_ALT}))\\b`, "i");

  /** Arriving somewhere is stronger than being somewhere: it marks a scene
   *  change, and it happens LATE in a reply (the last place named is where
   *  the reply leaves everyone). */
  const ARRIVAL_RE = new RegExp(
    "\\b(?:entered|enters|entering|arrived (?:at|in)|arrives (?:at|in)|reached|reaches|" +
    "stepped (?:into|inside|out into|out onto|onto|through the door(?:way)? (?:into|of))|" +
    "steps (?:into|inside|out into|out onto|onto)|walked (?:into|out into|out onto|through the (?:doors?|gates?) (?:into|of))|" +
    "walks (?:into|out into|out onto)|strode (?:into|out into)|stormed (?:into|out into)|" +
    "burst (?:into|through the door into)|slipped (?:into|inside|out into)|" +
    "led (?:her|him|them|the way) (?:into|to|through the door into)|" +
    "followed (?:her|him|them) (?:into|to)|carried (?:her|him|them) (?:into|to)|" +
    "pulled (?:her|him|them) (?:into|inside)|pushed (?:her|him|them) (?:into|through the door into)|" +
    "pulled (?:into|up (?:to|at|outside)|in at)|parked (?:at|outside|in|by)|" +
    "made it (?:to|into|back to)|found (?:himself|herself|themselves) (?:in|inside|at|on)|" +
    "climbed (?:into|onto|up to)|descended (?:into|to)|crossed into|emerged (?:into|onto|from the .{0,30} into)|" +
    "came (?:into|to|out into|back to|back into)|returned to|retreated (?:into|to)|fled (?:into|to)|" +
    "ducked (?:into|inside)|settled (?:into|in)|sat down in|took (?:her|him|them) to|brought (?:her|him|them) (?:to|into))" +
    `\\s+${DET}?\\s*((?:[a-z][a-z'-]*\\s+){0,3}(?:${PLACE_ALT}))\\b`, "i");

  /** "…of the car" after a place phrase: "the front seat of the car". Kept
   *  because the tail names the real place and the head only the spot. */
  const OF_TAIL_RE = new RegExp(`^\\s+of\\s+${DET}\\s+((?:[a-z][a-z'-]*\\s+){0,2}(?:${PLACE_ALT}))\\b`, "i");

  /** A spot that is only a place because of what follows it: "the front
   *  seat" is nowhere, "the front seat of the car" is a car. */
  const SPOT = "(?:seat|backseat|corner|edge|foot|head|middle|centre|center|end|" +
               "side|top|bottom|steps|threshold|doorway|entrance|mouth|heart|" +
               "depths|shadows?|far end|back|front|floor|window|table|bar|counter)";
  const SPOT_RE = new RegExp(
    `\\b(?:in|inside|on|at|by|beside|near|against)\\s+${DET}\\s+((?:[a-z][a-z'-]*\\s+){0,2}${SPOT})` +
    `\\s+of\\s+${DET}\\s+((?:[a-z][a-z'-]*\\s+){0,2}(?:${PLACE_ALT}))\\b`, "i");

  /** Capitalised, place-flavoured names: "at the Rusty Nail Tavern",
   *  "in Ashford", "to Blackwater Keep". */
  const NAMED_RE = /\b(?:in|inside|into|at|to|toward|towards|through|across|near|outside|back (?:in|at|to))\s+(?:the\s+)?([A-Z][\w'’-]+(?:\s+(?:of|the|de|du|la|le)\s+)?(?:\s?[A-Z][\w'’-]+){0,3})/g;

  /** The sentence is not about the present scene. */
  const NOT_NOW = /\b(remember\w*|recall\w*|reminisc\w*|thought (?:of|about|back)|think(?:s|ing)? (?:of|about|back)|dream\w*|imagin\w*|pictur(?:ed|ing)|used to|had been|had once|once (?:been|lived|stood)|years? ago|months? ago|weeks? ago|days? ago|long ago|back (?:when|then)|last (?:night|week|year|time)|yesterday|the other day|(?:would|could|might|should|will|shall) (?:be|go|head|return|meet|wait|find|end up)|if (?:they|he|she|we|you|i)|wish\w*|wanted to (?:be|go|see)|planned? to|promised to|supposed to|meant to|talk\w* about|spoke of|told (?:him|her|them) about|mention\w*|story|stories|tale|legend|rumou?r\w*|heard (?:of|about|that))\b/i;

  /** The place is where they are NOT. */
  const NEGATED = /\b(?:not|never|no longer|nowhere near|far from|away from|left|leaving|leave|abandon\w*|escap\w*|out of|gone from)\s+(?:\w+\s+){0,2}$/i;

  /** Template placeholders that leak through a WHERE: field. */
  const PLACEHOLDER = /[\[\]{}<>]|\b(?:location|setting|where they are|current place|tbd|unknown|n\/a|none)\b\s*$/i;

  // ---------- helpers ----------

  const collapse = (s) => String(s || "").replace(/\s+/g, " ").trim();

  /** Strip the "in the" and normalise the phrase for the prompt. */
  function tidyPhrase(phrase) {
    let p = collapse(phrase).toLowerCase();
    p = p.replace(/^(?:the|a|an|his|her|their|its|this|that|our|my|your)\s+/, "");
    return p ? `the ${p}` : "";
  }

  function isCastName(word, cast) {
    const w = String(word).toLowerCase();
    return cast.some((n) => String(n).toLowerCase().split(/\s+/)[0] === w);
  }

  /** Every place statement in one text, in reading order, already filtered
   *  to sentences that describe the present. Each hit: {where, kind, index}.
   *  kind: "arrival" | "static" | "named" | "lore". */
  function findPlaces(text, { cast = [], lore = {} } = {}) {
    const hits = [];
    const sentences = sentencesOf(text);

    sentences.forEach((sentence, index) => {
      if (isDirective(sentence)) return;
      if (NOT_NOW.test(sentence)) return;

      const consider = (re, kind, group = 1) => {
        const m = sentence.match(re);
        if (!m) return null;
        const before = sentence.slice(0, m.index);
        if (NEGATED.test(before)) return null;
        let where = m[group];
        // "the front seat" says nothing; "the front seat of the car" does.
        const tail = sentence.slice(m.index + m[0].length).match(OF_TAIL_RE);
        if (tail) where = `${where} of the ${tail[1]}`;
        return { where: tidyPhrase(where), kind, index, sentence };
      };

      const arrival = consider(ARRIVAL_RE, "arrival");
      if (arrival) hits.push(arrival);
      const spot = sentence.match(SPOT_RE);
      if (spot && !NEGATED.test(sentence.slice(0, spot.index))) {
        hits.push({ where: `${tidyPhrase(spot[1])} of the ${spot[2].toLowerCase()}`,
                    kind: "static", index, sentence });
      }
      const stat = spot ? null : consider(STATIC_RE, "static");
      if (stat && (!arrival || stat.where !== arrival.where)) hits.push(stat);

      // Named places, filtered hard: must carry a place word or match lore.
      for (const m of sentence.matchAll(NAMED_RE)) {
        const name = collapse(m[1]);
        const words = name.toLowerCase().split(/\s+/);
        if (words.some((w) => isCastName(w, cast))) continue;
        const last = words[words.length - 1];
        const lower = name.toLowerCase();
        const loreKey = Object.keys(lore).find((k) =>
          k === lower || k === last || lower.startsWith(k + " ") || lower.endsWith(" " + k));
        const entry = loreKey ? lore[loreKey] : null;
        if (!PLACE_TITLE_WORDS.has(last) && !entry) continue;
        const before = sentence.slice(0, m.index);
        if (NEGATED.test(before)) continue;
        hits.push(entry
          ? { where: entry.entryName || name, kind: "lore", index, sentence, loreText: entry.text }
          : { where: name, kind: "named", index, sentence });
      }
    });

    // Lore location entries mentioned by trigger word anywhere in a present-
    // tense sentence: authored, so they beat anything we infer.
    for (const [key, entry] of Object.entries(lore || {})) {
      if (entry?.type !== "location" || key.length < 4) continue;
      const re = new RegExp(`(?<![a-z0-9])${escapeRe(key)}(?![a-z0-9])`, "i");
      sentences.forEach((sentence, index) => {
        if (!re.test(sentence) || NOT_NOW.test(sentence) || isDirective(sentence)) return;
        if (hits.some((h) => h.index === index && h.kind === "lore")) return;
        hits.push({ where: entry.entryName || key, kind: "lore", index, sentence, loreText: entry.text });
      });
    }

    return hits;
  }

  /** The place a text leaves the scene in: the LAST arrival if there is one
   *  (arrivals are scene changes), else the last lore/named/static mention. */
  function bestPlace(text, opts) {
    const hits = findPlaces(text, opts);
    if (!hits.length) return null;
    const last = (kind) => hits.filter((h) => h.kind === kind).at(-1) || null;
    const arrival = last("arrival");
    const lore = last("lore");
    const named = last("named");
    const stat = last("static");
    // An authored lore location at or after the arrival is the more specific
    // answer; a capitalised name in the SAME sentence as the arrival is the
    // same place spelled properly. Otherwise the arrival marks the newest change.
    if (lore && (!arrival || lore.index >= arrival.index)) return lore;
    if (arrival) return named && named.index === arrival.index ? named : arrival;
    if (named && (!stat || named.index >= stat.index)) return named;
    return stat;
  }

  // ---------- thinking block ----------

  /** WHO/WHERE/NOW/PRESSURE from the reply's thinking block. The site strips
   *  the <thinking> tags when rendering, so accept the tagged block or the
   *  bare pipe-delimited header fields. */
  function mineThinking(raw) {
    const text = String(raw || "");
    const block = text.match(/<thinking>([\s\S]*?)<\/thinking>/i);
    // Most chats have no SNAP template at all. Outside a real <thinking>
    // block, only a pipe-delimited header line ("WHO: … | WHERE: … | NOW: …")
    // counts, so a "where:" inside ordinary prose can't be read as a field.
    const source = block ? block[1]
      : (text.split(/\r?\n/).find((l) => /\bWHO:.*\|.*\b(WHERE|NOW):/i.test(l)) || "");
    const field = (key) => {
      const m = source.match(new RegExp(`\\b${key}:\\s*([^|\\n]+)`, "i"));
      return m ? collapse(m[1]) : "";
    };
    return {
      who: field("WHO").split(/,\s*/).map((s) => s.trim()).filter(Boolean),
      where: field("WHERE"),
      now: field("NOW"),
      pressure: field("PRESSURE"),
    };
  }

  /** A WHERE: line worth trusting: real text, not a template placeholder. */
  function usableThinkingWhere(where) {
    const w = collapse(where);
    if (w.length < 3 || w.length > 140) return "";
    if (PLACEHOLDER.test(w)) return "";
    return w;
  }

  // ---------- resolution ----------

  /**
   * @param thinkWhere   WHERE: from the thinking block, if any
   * @param reply        the snapped reply's prose (instructions stripped)
   * @param player       the player's message that prompted it ("" if unknown)
   * @param history      earlier replies' prose, NEWEST FIRST
   * @param memory       {where, source, at} recorded at the last send, or null
   * @param cast, lore   from the sheet
   * @returns {where, source, loreText}  where === "" when nothing is known
   */
  function resolveLocation({
    thinkWhere = "", reply = "", player = "", history = [], memory = null,
    cast = [], lore = {},
  }) {
    const opts = { cast, lore };
    const loreFor = (where) => {
      const hit = Object.entries(lore).find(([k, e]) =>
        e?.type === "location" && new RegExp(`(?<![a-z0-9])${escapeRe(k)}(?![a-z0-9])`, "i").test(where));
      return hit ? hit[1].text : "";
    };
    const out = (where, source, loreText) => ({
      where: collapse(where), source, loreText: loreText || loreFor(where) || "",
    });

    const fromThinking = usableThinkingWhere(thinkWhere);
    if (fromThinking) return out(fromThinking, "thinking");

    const inReply = bestPlace(reply, opts);
    if (inReply) return out(inReply.where, "reply", inReply.loreText);

    const inPlayer = bestPlace(player, opts);
    if (inPlayer) return out(inPlayer.where, "player", inPlayer.loreText);

    for (const older of history) {
      const hit = bestPlace(older, opts);
      if (hit) return out(hit.where, "history", hit.loreText);
    }

    if (memory?.where) return out(memory.where, "memory");

    return { where: "", source: "none", loreText: "" };
  }

  /** What the player sends is worth remembering: at the next snap it is the
   *  "one turn ago" answer, which beats a Nexus panel that runs 3–7 behind. */
  function memoryFromSend({ lastUserMsg = "", lastReply = "", previous = null, cast = [], lore = {} }) {
    const opts = { cast, lore };
    const think = mineThinking(lastReply);
    const fromThinking = usableThinkingWhere(think.where);
    const pick = fromThinking ? { where: fromThinking, source: "thinking" }
      : (bestPlace(lastUserMsg, opts) && { ...bestPlace(lastUserMsg, opts), source: "player" })
      || (bestPlace(stripThinking(lastReply), opts) && { ...bestPlace(stripThinking(lastReply), opts), source: "reply" });
    if (!pick) return previous || null;
    return { where: pick.where, source: pick.source, at: Date.now() };
  }

  function stripThinking(text) {
    return String(text || "")
      .replace(/```?\s*<thinking>[\s\S]*?<\/thinking>\s*```?/gi, "")
      .replace(/<thinking>[\s\S]*?<\/thinking>/gi, "");
  }

  return {
    PLACES, findPlaces, bestPlace, mineThinking, usableThinkingWhere,
    resolveLocation, memoryFromSend, stripThinking,
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = SceneLocator;
