// draft.js — one snapped reply in, editable image prompts out.
//
// Loaded by the service worker after condense.js, scene.js and sheet.js.
//
// The pipeline, in order:
//   readTurn        strip the bot's SNAP: section, mine the thinking block,
//                   strip template/instruction lines → clean prose
//   resolveCast     who is in frame (thinking WHO → names in prose → sheet)
//   resolvePeople   gender, pose per character, the one key interaction
//   resolveScene    WHERE (scene.js), then weather / time / fire / mood / props
//   rankMoments     candidate sentences to draw, optional LLM upgrade
//   assemble        the prompt text, one draft per moment
//
// Every step is a plain function of its inputs so it can be tested in node;
// only Drafter.build touches storage.

const Drafter = (() => {
  const PC = PromptCondenser;

  // ---------- text helpers ----------

  const collapseWs = (s) => String(s || "").replace(/\s+/g, " ").trim();

  /** OOC notes and bracketed asides are for the writer, not the picture. */
  function stripAsides(t) {
    return String(t || "")
      .replace(/\[[^\]]*\]/g, " ")
      .replace(/\([Oo][Oo][Cc][^)]*\)/g, " ")
      .replace(/\s+([.,!?])/g, "$1")
      .replace(/([.!?])\s*[.,]+/g, "$1")
      .replace(/\s+/g, " ")
      .trim();
  }

  function tidyProse(s) {
    return String(s || "")
      .replace(/\r\n?/g, "\n")
      .replace(/[ \t]+/g, " ")
      .replace(/ *\n */g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  /** Cut long prose on a paragraph or sentence boundary. */
  function clipProse(text, max) {
    const t = String(text || "");
    if (t.length <= max) return t;
    const head = t.slice(0, max);
    const para = head.lastIndexOf("\n\n");
    if (para > max * 0.6) return head.slice(0, para).trim();
    const sentence = Math.max(head.lastIndexOf(". "), head.lastIndexOf("\u201d "),
                              head.lastIndexOf('" '));
    if (sentence > max * 0.6) return head.slice(0, sentence + 1).trim();
    return head.replace(/\s\S*$/, "").trim() + "\u2026";
  }

  /** Trim to N words on a word boundary, no trailing function word. */
  function clampWords(text, n) {
    const w = String(text).trim().split(/\s+/);
    if (w.length <= n) return String(text).trim();
    const out = w.slice(0, n);
    while (out.length && /^(for|and|but|the|a|an|with|of|to|in|on|at|as|before|while|that|his|her|their)$/i
             .test(out[out.length - 1])) out.pop();
    return out.join(" ").replace(/[,;:]$/, "");
  }

  const firstOf = (name) => String(name || "").split(/\s+/)[0].toLowerCase();

  // ---------- step 1: read the turn ----------

  function readTurn({ replyText, thinkText }) {
    const reply = PC.stripSnapSection(replyText || "");
    const combined = thinkText ? `<thinking>${thinkText}</thinking>\n${reply}` : reply;
    const thinking = SceneLocator.mineThinking(combined);

    let prose = SceneLocator.stripThinking(combined)
      .replace(/^\s*Thinking Process\s*(Show|Hide)?\s*$/gim, "")
      .replace(/^\s*(?:\[|\(\()[^\]\)]{0,200}(?:\]|\)\))\s*$/gm, "")   // OOC lines
      .trim();
    // The site renders <thinking> as a widget with the tags stripped, so tag
    // removal alone can leave the template behind as plain text.
    prose = PC.stripInstructions(prose) || reply;

    // A prompt the roleplay model wrote for itself (SNAP: in its template).
    const botPrompt = PC.extractSnapSection(thinkText) || PC.extractSnapSection(replyText);

    return { prose, thinking, botPrompt };
  }

  // ---------- step 2: who is in frame ----------

  function cleanName(n) {
    return String(n || "").replace(/[\[\]{}()<>"'`*_]/g, " ").replace(/\s+/g, " ").trim();
  }

  /**
   * @returns {{cast: string[], characters: Object}} cast in frame, plus the
   *   sheet's characters extended with anyone the Nexus or lorebooks describe.
   */
  function resolveCast({ sheet, thinking, prose, nexus }) {
    const known = sheet.characters || {};
    const castSet = new Map();
    const add = (name) => {
      const clean = cleanName(name);
      if (clean.length < 2) return;
      const key = firstOf(clean);
      if (!castSet.has(key)) castSet.set(key, clean);
    };

    // Everyone on the sheet is a candidate; the thinking block's WHO list is
    // the bot's own answer and comes next; then anyone named in the prose.
    for (const c of Object.values(known)) add(c.name);
    for (const n of thinking.who || []) add(n);

    const hay = " " + String(prose).toLowerCase() + " ";
    for (const c of Object.values(known)) {
      const first = firstOf(c.name);
      if (first.length > 2 && new RegExp(`[^a-z0-9]${PC.escapeRe(first)}[^a-z0-9]`).test(hay)) add(c.name);
    }

    // No sheet at all: fall back to the capitalised words the prose repeats.
    if (!castSet.size) {
      const STOP = new Set(["the", "he", "she", "they", "it", "his", "her", "their",
        "and", "but", "then", "there", "this", "that", "a", "an", "i", "you"]);
      const counts = new Map();
      for (const m of String(prose).matchAll(/\b([A-Z][a-z]{2,})\b/g)) {
        if (STOP.has(m[1].toLowerCase())) continue;
        counts.set(m[1], (counts.get(m[1]) || 0) + 1);
      }
      [...counts.entries()].filter(([, n]) => n >= 2)
        .sort((a, b) => b[1] - a[1]).slice(0, 3).forEach(([w]) => add(w));
    }
    const cast = [...castSet.values()];

    // Appearance-only sources for people the card doesn't describe.
    const characters = { ...known };
    const isKnown = (name) => Object.values(characters).some((c) => firstOf(c.name) === firstOf(name));

    // Nexus: APPEARANCE ONLY. Its scene and state lines run several replies
    // behind the chat and are never read; what someone looks like doesn't
    // go stale, and that is what keeps a recurring face consistent.
    for (const [nexusName, desc] of Object.entries(nexus?.descs || {})) {
      const match = cast.find((c) => {
        const a = firstOf(c), b = firstOf(nexusName);
        return a === b || a.startsWith(b) || b.startsWith(a);
      });
      const key = match || nexusName;
      if (!isKnown(key)) characters[key] = { name: key, appearance: desc, role: "side" };
    }
    for (const name of cast) {
      if (isKnown(name)) continue;
      const hit = Sheet.loreFor(sheet, name, "character") || Sheet.loreFor(sheet, name, null);
      if (hit?.text) {
        characters[name] = { name, appearance: hit.text, portrait: hit.portrait || null, role: "side" };
      }
    }
    return { cast, characters };
  }

  // ---------- step 3: people ----------

  const MALE_RE = /\b(he|his|him|man|male|lord|commander|father|brother|son)\b/g;
  const FEMALE_RE = /\b(she|her|hers|woman|female|lady|mother|sister|daughter|beauty)\b/g;

  function tallyGender(hay) {
    const t = String(hay || "").toLowerCase();
    const m = (t.match(MALE_RE) || []).length;
    const f = (t.match(FEMALE_RE) || []).length;
    return m > f ? "m" : f > m ? "f" : null;
  }

  function guessGender(sheet, name) {
    const c = Object.values(sheet.characters || {}).find((x) => firstOf(x.name) === firstOf(name));
    const lore = Sheet.loreFor(sheet, name, null);
    return tallyGender(`${c?.appearance || ""} ${lore?.text || ""}`);
  }

  /** [{name, gender}] — from the card, then the prose around each name, then
   *  elimination when two people remain and one is known. */
  function resolveCastGenders(sheet, cast, prose, playerMsg) {
    const out = cast.map((name) => ({ name, gender: guessGender(sheet, name) }));
    const sentences = String(prose || "").split(/(?<=[.!?])\s+/);

    for (const c of out) {
      if (c.gender) continue;
      const first = firstOf(c.name);
      if (first.length < 3) continue;
      const mine = sentences.filter((x) => x.toLowerCase().includes(first));
      if (mine.length) c.gender = tallyGender(mine.join(" "));
    }

    const userName = Object.values(sheet.characters || {}).find((c) => c.role === "user")?.name;
    const you = userName && out.find((c) => firstOf(c.name) === firstOf(userName));
    if (you && !you.gender) {
      const lead = String(playerMsg || "").match(/\b(he|his|him|she|her|hers)\b/i);
      if (lead) you.gender = /^h(e|is|im)$/i.test(lead[1]) ? "m" : "f";
    }

    const unknown = out.filter((c) => !c.gender);
    if (out.length === 2 && unknown.length === 1) {
      const known = out.find((c) => c.gender);
      if (/\b(he|his|him)\b/i.test(prose) && /\b(she|her|hers)\b/i.test(prose)) {
        unknown[0].gender = known.gender === "m" ? "f" : "m";
      }
    }
    return out;
  }

  /** Pose per character and the single key interaction. */
  function resolvePeople({ sheet, cast, prose, playerMsg }) {
    const castWithGender = resolveCastGenders(sheet, cast, prose, playerMsg);
    const states = PC.extractPose(prose, castWithGender);

    // What the player just did is often stated nowhere else.
    if (playerMsg.length > 4) {
      for (const [name, text] of Object.entries(PC.extractPose(playerMsg, castWithGender))) {
        if (!states[name] && text) states[name] = text;
      }
    }
    for (const [name, text] of Object.entries(states)) {
      if (PC.isDirective(text)) delete states[name];
    }

    // Anyone still without a pose gets their most visual sentence, recency-weighted.
    const sentences = PC.splitSentences(PC.stripMarkup(prose));
    for (const name of cast) {
      if (states[name]) continue;
      const short = firstOf(name);
      if (short.length < 3) continue;
      const named = sentences.filter((s) => s.toLowerCase().includes(short));
      if (!named.length) continue;
      const rank = (s) => PC.scoreSentence(s).score +
        (sentences.indexOf(s) / Math.max(1, sentences.length - 1)) * 2;
      named.sort((a, b) => rank(b) - rank(a));
      states[name] = named[0];
    }

    let interaction = null;
    try { interaction = PC.extractInteraction(prose, castWithGender); }
    catch (err) { console.warn("[SnapScapes] interaction pass skipped:", err?.message || err); }

    return { castWithGender, states, interaction };
  }

  // ---------- step 4: the scene ----------

  const CARRY_MS = 45 * 60 * 1000;

  /**
   * Location from scene.js, then atmosphere. Conditions the prose stated on
   * an earlier turn carry forward only while the location is unchanged.
   * @returns {{scene, memory}} memory is the record to store, or null
   */
  function resolveScene({ sheet, thinking, prose, playerMsg, history, cast, memory }) {
    const scene = {
      who: cast,
      now: stripAsides(thinking.now),
      pressure: stripAsides(thinking.pressure),
    };

    const loc = SceneLocator.resolveLocation({
      thinkWhere: thinking.where, reply: prose, player: playerMsg, history,
      memory: memory?.where ? memory : null,
      cast, lore: sheet.lore || {},
    });
    scene.where = cleanName(loc.where);
    scene.whereSource = loc.source;
    scene.whereLore = loc.loreText || Sheet.matchLore(sheet, scene.where);

    scene.framing = PC.detectDistance(prose) || "";
    scene.props = PC.findProps(prose);
    const moodHit = PC.detectMood(prose, scene.pressure || "");
    if (moodHit) scene.mood = moodHit.mood;

    // Fresh conditions: this reply, its thinking, and (if it's the newest
    // reply) the player's message that prompted it.
    const freshText = [prose, thinking.now || "", playerMsg].join("\n");
    const fresh = PC.detectConditions(freshText);
    // The location phrase itself can carry conditions ("the rain-slick street").
    const stale = PC.detectConditions(scene.where);

    const stored = memory || {};
    const sameScene = !stored.where || !scene.where ||
      stored.where.toLowerCase().slice(0, 24) === scene.where.toLowerCase().slice(0, 24);
    const recent = !stored.at || (Date.now() - stored.at) < CARRY_MS;
    const carried = sameScene && recent ? stored : {};

    const freshExclusive = Boolean(fresh.fire || fresh.fireflies);
    scene.weather = fresh.weather || (freshExclusive ? "" : (carried.weather || stale.weather || ""));
    scene.time = fresh.time || carried.time || stale.time || "";
    scene.dark = fresh.dark || carried.dark || false;
    scene.bright = fresh.bright || carried.bright || false;
    scene.fire = fresh.fire || (carried.fire === "steady" ? "steady" : false) ||
                 (stale.fire === "steady" ? "steady" : false) || false;
    scene.fireflies = fresh.fireflies || false;
    scene.romance = fresh.romance || false;
    scene.garden = fresh.garden || stale.garden || false;

    // Remember this scene when we learned something new about it.
    const strongWhere = ["thinking", "reply", "player"].includes(loc.source);
    const learned = strongWhere || Object.keys(fresh).length > 0;
    const next = learned ? {
      ...carried,
      ...fresh,
      where: strongWhere ? scene.where : (stored.where || scene.where || ""),
      whereSource: strongWhere ? loc.source : (stored.whereSource || loc.source),
      fireflies: fresh.fireflies || false,
      romance: fresh.romance || false,
      fire: fresh.fire || (carried.fire === "steady" ? "steady" : false),
      at: Date.now(),
    } : null;

    return { scene, memory: next };
  }

  // ---------- step 5: moments ----------

  const FALLBACK_MOMENT = (subject) => ({
    subject, lighting: [], label: "This moment", score: null, source: "fallback",
  });

  /** Ranked candidate sentences, with the LLM upgrade when configured. */
  async function rankMoments({ prose, playerMsg, scene, sheet, cast, states, cfg, llm }) {
    const raw = PC.condense(prose, 8).candidates;
    const kept = raw.filter((m) => !PC.isDirective(m.subject || ""));
    const stripped = (kept.length ? kept : raw)
      .map((m) => ({ ...m, subject: stripAsides(m.subject) }))
      .filter((m) => m.subject);
    let candidates = (stripped.length ? stripped : kept).slice(0, 3);

    if (llm && (cfg.condenser === "llm" || cfg.condenser === "claude")) {
      try {
        const upgraded = await llm(prose, castForModel(sheet), cfg);
        if (upgraded.length) {
          candidates = upgraded;
          for (const p of upgraded[0]?.characters || []) {
            const match = cast.find((n) => firstOf(n).startsWith(firstOf(p.name)));
            if (match) states[match] = p.doing;
          }
          // A model that read the whole passage knows the setting better than
          // a carried-over or opening-scene guess does.
          const weakWhere = !["thinking", "reply", "player"].includes(scene.whereSource);
          const setting = upgraded[0]?.setting?.[0];
          if (weakWhere && setting) {
            scene.where = collapseWs(setting);
            scene.whereSource = "model";
            scene.whereLore = Sheet.matchLore(sheet, scene.where);
          }
        }
      } catch (err) {
        console.warn("[SnapScapes] LLM condense failed, using heuristic:", err.message);
      }
    }

    if (!candidates.length) {
      const subject =
        (playerMsg.length > 8 ? playerMsg : "") ||
        stripAsides(scene.now) ||
        stripAsides(collapseWs(prose)).slice(0, 200) ||
        collapseWs(prose).slice(0, 200);
      candidates = [FALLBACK_MOMENT(subject)];
    }
    return candidates;
  }

  /** The cast as the LLM instruction wants it. */
  function castForModel(sheet) {
    return {
      cast: Object.values(sheet.characters || {}).filter((c) => c.name).map((c) => ({
        name: c.name,
        role: c.role === "user" ? "user" : "char",
        appearance: String(c.appearance || "").slice(0, 200),
      })),
    };
  }

  // ---------- step 6: assemble ----------

  /**
   * The picture is the MOMENT: what is happening, where, in what light.
   * Reference images carry what people look like, so the Characters block
   * is names + card appearance only (and the card hides it unless the
   * Appearance toggle is on). Per-character "Right now" poses used to sit
   * on each line; they were clauses glued together by pronoun guesswork and
   * read worse than the whole sentences Context is built from, so movement
   * now lives only in Context.
   */
  function buildPrompt(sheet, scene, moment, style, states = {}, interaction = null) {
    const cast = (scene.who || []).length ? scene.who : Object.keys(sheet.characters);
    const lines = [];
    lines.push("Create an image of this moment.");
    lines.push("");

    // The key interaction leads the Context line. It used to also add a
    // second "Name: <first 12 words of the card>" line for everyone in it —
    // raw card text, so bios leaked in mid-sentence, and it sat outside the
    // Characters block where the card's appearance toggle couldn't reach it.
    const interactionLead = interaction?.text || "";

    const used = new Set(); // never say the same sentence twice

    // Someone with no description anywhere would be drawn as an invented
    // stranger, so they become scene detail instead of a listed character.
    const described = [];
    const extras = [];
    for (const name of cast) {
      const c = Sheet.lookupCharacter(sheet, name);
      const lore = c ? null : Sheet.loreFor(sheet, name, null);
      const appearance = c?.appearance || lore?.text || "";
      if (appearance) described.push({ name, appearance, role: c ? c.role : "side" });
      else if (states[name]) extras.push({ name, state: states[name] });
    }

    const SIDE_APPEARANCE_WORDS = 10;
    const SIDE_POSE_WORDS = 7;
    const MAX_SIDE = 2;

    const leads = described.filter((p) => p.role !== "side");
    const sides = described.filter((p) => p.role === "side").slice(0, MAX_SIDE);

    // Names and looks only. The Snap card removes this block unless the
    // Appearance toggle is on (for backends that take no reference images).
    if (leads.length || sides.length) {
      lines.push("Characters:");
      for (const p of leads) lines.push(`- ${p.name} — ${Sheet.promptAppearance(p.appearance)}`);
      for (const p of sides) lines.push(`- ${p.name} — ${clampWords(p.appearance, SIDE_APPEARANCE_WORDS)}`);
      lines.push("");
    }

    if (extras.length) {
      lines.push("Also in frame: " + extras.slice(0, MAX_SIDE)
        .map((e) => clampWords(e.name + " (" + e.state.replace(/\.$/, "") + ")", SIDE_POSE_WORDS + 3) + ")")
        .join("; ").replace(/\)\)/g, ")"));
      lines.push("");
      for (const e of extras) used.add(e.state);
    }

    const dot = (s) => (/[.!?\u2026]$/.test(s.trim()) ? s.trim() : s.trim() + ".");
    const norm = (t) => String(t).toLowerCase().replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
    // Same beat, different words: the interaction pass says "Kellas pulled
    // Euri close" and the moment sentence says "He pulled Euri close against
    // the wall as boots…". Substring matching missed that; word overlap
    // (most of the shorter's words in the longer) catches it.
    const STOP = new Set(["the", "a", "an", "and", "as", "at", "to", "of", "in", "on", "his",
      "her", "their", "he", "she", "they", "him", "them", "it", "with", "for", "that"]);
    const contentWords = (t) => new Set(norm(t).split(" ").filter((w) => w.length > 2 && !STOP.has(w)));
    const alreadySaid = (t) => {
      const a = norm(t);
      if (!a) return true;
      const aw = contentWords(t);
      for (const prev of used) {
        const b = norm(prev);
        if (!b) continue;
        if (b.includes(a) || a.includes(b)) return true;
        const bw = contentWords(prev);
        const [small, big] = aw.size <= bw.size ? [aw, bw] : [bw, aw];
        if (small.size >= 3) {
          let hit = 0;
          for (const w of small) if (big.has(w)) hit += 1;
          if (hit / small.size >= 0.7) return true;
        }
      }
      return false;
    };

    const ctxParts = [];
    if (interactionLead) used.add(interactionLead);
    if (scene.userAction) { ctxParts.push(dot(scene.userAction)); used.add(scene.userAction); }
    if (scene.now && !used.has(scene.now)) { ctxParts.push(dot(scene.now)); used.add(scene.now); }
    if (moment?.subject && !alreadySaid(moment.subject)) {
      ctxParts.push(dot(moment.subject));
      used.add(moment.subject);
    }
    if (ctxParts.length) {
      const CTX_WORDS = 55;
      let ctx = ctxParts.join(" ");
      const words = ctx.split(/\s+/);
      if (words.length > CTX_WORDS) ctx = words.slice(0, CTX_WORDS).join(" ").replace(/[,;:]$/, "") + "…";
      lines.push(`Context: ${interactionLead ? `${dot(interactionLead)} ${ctx}` : ctx}`);
      lines.push("");
    } else if (interactionLead) {
      lines.push(`Context: ${dot(interactionLead)}`);
      lines.push("");
    }

    // Only a location we actually know. No line at all beats a wrong one —
    // an image model will invent a plausible room; it can't un-draw the
    // opening scene from six chapters ago.
    if (scene.where) {
      const time = scene.time ? ` (${scene.time})` : "";
      lines.push(`Location: ${scene.where}${time}${scene.whereLore ? ` — ${scene.whereLore}` : ""}`);
      lines.push("");
    }

    if (moment?.lighting?.length) {
      lines.push(`Lighting: ${moment.lighting.join(", ")}`);
      lines.push("");
    }
    if (scene.weather && scene.weather !== "clear") {
      lines.push(`Weather: ${scene.weather}`);
      lines.push("");
    }
    if (scene.props?.length) {
      lines.push(`Objects in the scene: ${scene.props.join(", ")}`);
      lines.push("");
    }
    if (scene.mood) {
      const m = PC.MOOD_TEXT[scene.mood];
      if (m) {
        lines.push(`Mood: ${m.say}${scene.pressure ? ` (${scene.pressure})` : ""}`);
        if (m.deny) lines.push(m.deny);
        lines.push("");
      }
    }
    if (style) lines.push(`Style: ${style}`);

    return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function assemble({ sheet, scene, moments, states, interaction, botPrompt, style }) {
    const drafts = moments.map((moment) => ({
      label: moment.label,
      prose: buildPrompt(sheet, scene, moment, style, states, interaction),
      negative: PC.SD_NEGATIVE,
    }));
    if (botPrompt) {
      const s = String(style || "").trim();
      drafts.unshift({
        label: "From the bot",
        fromBot: true,
        prose: s ? `${botPrompt}\n\nStyle: ${s}` : botPrompt,
        negative: PC.SD_NEGATIVE,
      });
      drafts.length = Math.min(drafts.length, 3);
    }
    return drafts;
  }

  // ---------- the whole thing ----------

  /**
   * Pure: no storage. Drafter.build (below) supplies the sheet and memory.
   *
   * @param replyText   the snapped reply, as displayed
   * @param thinkText   its collapsed thinking widget's text
   * @param playerMsg   the player's message that prompted it, or ""
   * @param history     earlier replies' prose, newest first
   * @param nexus       {descs} scraped from the Memory Nexus, or null
   * @param sheet       from Sheet.fromPayload
   * @param memory      the session's stored sceneMemory, or null
   * @param cfg         {style, condenser, …}
   * @param llm         optional async (text, castSheet, cfg) → candidates
   */
  async function draft({
    replyText = "", thinkText = "", playerMsg = "", history = [],
    nexus = null, sheet, memory = null, cfg = {}, llm = null,
  }) {
    const { prose, thinking, botPrompt } = readTurn({ replyText, thinkText });
    const { cast, characters } = resolveCast({ sheet, thinking, prose, nexus });
    const sheetPlus = { ...sheet, characters };

    const player = stripAsides(String(playerMsg || "").replace(/[*_~`]+/g, " "));
    const { states, interaction } = resolvePeople({ sheet: sheetPlus, cast, prose, playerMsg: player });

    const { scene, memory: nextMemory } = resolveScene({
      sheet: sheetPlus, thinking, prose, playerMsg: player, history, cast, memory,
    });
    if (player.length > 4) {
      const userChar = Object.values(sheet.characters || {}).find((c) => c.role === "user");
      scene.userAction = `${userChar?.name || "The player"} just: ${player.slice(0, 240)}`;
    }

    const moments = await rankMoments({
      prose, playerMsg: player, scene, sheet: sheetPlus, cast, states, cfg, llm,
    });
    const drafts = assemble({
      sheet: sheetPlus, scene, moments, states, interaction, botPrompt, style: cfg.style,
    });

    const portraits = Object.values(sheet.characters || {})
      .filter((c) => c.portrait).map((c) => ({ name: c.name, url: c.portrait }));

    return {
      drafts, scene, portraits,
      memory: nextMemory,
      replyClean: clipProse(tidyProse(prose), 4000),
      hasSheet: Object.keys(sheet.characters || {}).length > 0,
    };
  }

  /** The plain fallback when drafting itself throws. */
  function fallbackDraft(replyText, err) {
    const plain = collapseWs(replyText).slice(0, 400);
    return {
      drafts: [{
        label: "This moment",
        prose: plain ? `Create an image of this moment.\n\n${plain}` : "Create an image of this moment.",
        negative: PC.SD_NEGATIVE,
      }],
      scene: {}, portraits: [], memory: null,
      replyClean: clipProse(tidyProse(replyText), 4000),
      hasSheet: false,
      degraded: err?.message || "draft error",
    };
  }

  return {
    draft, fallbackDraft, buildPrompt,
    // exposed for tests
    readTurn, resolveCast, resolvePeople, resolveScene, rankMoments, castForModel,
    stripAsides, clipProse, tidyProse, clampWords,
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = Drafter;
