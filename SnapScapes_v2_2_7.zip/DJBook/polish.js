// polish.js — Claude writes the image prompt.
//
// Loaded by the service worker (importScripts) after draft.js.
//
// The built-in drafter still runs first and its prompt appears instantly.
// When "Claude writes the prompts" is on (Options → For tinkerers), the Snap
// card then asks for this pass and swaps Claude's moments in when they land.
//
// Claude gets the same material the drafter gathered — the reply, the bot's
// thinking, the player's last message, a little history, the cast with their
// appearances, and what the scene reader already knows — and returns up to
// three moments as JSON. toDrafts() turns each into labelled sections
// (In frame / Scene / Pose / Camera / Location / Lighting / Mood / Style), so
// the Snap card's appearance toggle and pinned-location edits keep working.
//
// v2.2.3: written as a director of photography — shot size, lens, angle,
// composition, motivated lighting and posing — and characters whose photo
// goes along as a reference are sent by name only.
//
// THE INSTRUCTION BELOW IS THE THING TO TUNE. If pictures keep missing
// something, the fix usually belongs in RULES.

const PromptPolish = (() => {
  const MODELS = {
    "claude-haiku-5-5": "Haiku 5.5",
    "claude-sonnet-5-5": "Sonnet 5.5",
    "claude-opus-5-5": "Opus 5.5",
  };
  const DEFAULT_MODEL = "claude-sonnet-5-5";

  const INSTRUCTION = `You are the director of photography for a single still frame. You turn a moment from an ongoing roleplay story into a prompt for an image model. The picture is kept in the reader's photo album and shown behind their chat, so it has to look like THIS moment of THEIR story, shot the way a professional cinematographer would shoot it, not a generic scene.

You will get, in tags:
- <characters>: who is in this story. Someone marked "reference photo attached" has a photo sent along with your prompt, and the image model takes their face, hair, build and features from it. Anyone else comes with a short description.
- <earlier>: the previous replies, oldest first, for context only.
- <player>: what the player just did or said. It often states the action the reply responds to.
- <reply>: the newest reply. The picture comes from here.
- <notes>: the story model's private planning for that reply. Useful for who is present and where, but the reply wins where they disagree.
- <known>: what an automatic reader already worked out (location, time, weather). A hint, not a rule.

Pick up to three moments from <reply>. Put the strongest first: the beat the reply builds toward, or its emotional peak. Each moment is ONE frozen instant a camera could catch. Make them different beats, and where it suits the story, different shots (a close-up and a wide, say), not the same beat reworded. If the reply only has one picture in it, return one.

For each moment return:
- label: 2 to 5 words naming the beat.
- characters: only the people visible in the frame, at most three, by their exact names from <characters>. "look" is what is true of them RIGHT NOW that a portrait couldn't show: what they're wearing, wet or tousled hair, blood, dirt, tears, flushed skin, what they hold. For someone with a reference photo, never describe their face, eyes, hair colour or build; the photo carries those. For someone without one, add a few words of appearance from the story. Leave "look" empty if nothing is known.
- scene: two or three sentences, present tense: who is where, doing what, and the one or two props or details that make this moment recognisable.
- pose: body language for each visible person: stance and where their weight sits, what their hands are doing, the tilt of the head, where the eyes go, the expression down to the small things (a jaw set tight, a half-smile), and how far apart they are and where they touch.
- camera: shot size, camera height and angle, lens, depth of field, and composition, chosen to tell this beat.
- location: where this is, specific to the story (a named place if it has one), plus the visible setting and background.
- lighting: the light source the scene motivates, its direction and quality, its colour temperature, and anything in the air.
- mood: the emotional tone and the colour palette, in a few words.

Directing the shot:
- Let the emotion choose the camera. Intimacy or tenderness: close-up or medium close-up, eye level, 85mm, shallow depth of field. Tension or power: low angle, harder light, tighter framing. Isolation or awe: a wide shot with negative space. Confrontation: an over-the-shoulder or a two-shot across the gap between them. Use a Dutch angle only for real disorientation.
- Compose with intent: rule of thirds, leading lines, foreground elements framing the subject, the focal point (usually a face or a pair of hands) placed where the eye lands first.
- Pose people the way a good photographer would: caught mid-motion, weight on one leg, bodies angled rather than square to the camera, hands busy with something specific (a glass, a sleeve, a jaw, a doorframe), eyelines that connect them or pointedly don't. No stiff, posed-for-the-camera stances unless the story calls for one.
- Light it like a film: one clear key light the scene justifies (candles, a window, moonlight, a fire, a neon sign), from a definite direction (side light, Rembrandt, backlight with a rim on the hair), soft or hard, warm or cool, with practical lights in frame where they belong. Add atmosphere when it fits: haze, dust in a beam of light, rain-wet reflections, breath in cold air.
- Use real photography and film vocabulary. It's what image models follow best.

Rules:
- The player's character is a person IN the picture, seen from outside like everyone else. Never write "you" or "your", and never describe the scene from their eyes.
- Describe only what a camera would see. No dialogue, thoughts, memories, backstory or sounds. No text, signs or lettering in the image.
- Never add a person, creature, object or place the story doesn't support. Where the story is silent (the background, the weather), choose details that fit the location instead of leaving gaps.
- Say what IS there, not what isn't: "an empty street" rather than "no people".
- Image services refuse explicit or graphic pictures, and a prompt that reads that way produces nothing. Write intimate and violent moments in tasteful, romantic, emotional language: closeness, touch, a held gaze, breath, light falling across skin, sheets, shadow or the frame's edge covering what needs covering; for violence, the tension, the aftermath, the look on a face rather than the wound. Keep what the moment means and leave out anything graphic.
- Don't mention art style, medium or rendering quality; the reader's house style is added after you.`;

  const SCHEMA = {
    type: "object",
    properties: {
      moments: {
        type: "array",
        items: {
          type: "object",
          properties: {
            label: { type: "string" },
            characters: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  look: { type: "string" },
                },
                required: ["name", "look"],
                additionalProperties: false,
              },
            },
            scene: { type: "string" },
            pose: { type: "string" },
            camera: { type: "string" },
            location: { type: "string" },
            lighting: { type: "string" },
            mood: { type: "string" },
          },
          required: ["label", "characters", "scene", "pose", "camera", "location", "lighting", "mood"],
          additionalProperties: false,
        },
      },
    },
    required: ["moments"],
    additionalProperties: false,
  };

  const clip = (s, n) => {
    const t = String(s || "").trim();
    return t.length <= n ? t : t.slice(0, n).replace(/\s\S*$/, "") + " …";
  };

  /** The user turn: everything the drafter gathered, in labelled tags. */
  function userMessage(ctx) {
    const parts = [];
    // Someone whose picture goes along as a reference needs no description:
    // the image model draws them from the photo, and a second, written
    // description only competes with it. Everyone else gets a short one.
    const first = (n) => String(n || "").trim().split(/\s+/)[0].toLowerCase();
    const withRef = new Set((ctx.refNames || []).map(first));
    const people = (ctx.characters || []).map((c) => {
      const who = c.role === "user" ? " (the player's character)" : c.role === "bot" ? " (main character)" : "";
      if (withRef.has(first(c.name))) return `- ${c.name}${who}: reference photo attached`;
      return `- ${c.name}${who}: ${clip(c.appearance, 400) || "appearance not given"}`;
    });
    parts.push(`<characters>\n${people.join("\n") || "(none known yet)"}\n</characters>`);

    const earlier = (ctx.history || []).slice(0, 2).reverse()
      .map((h, i) => `[${i + 1}] ${clip(h, 1500)}`);
    if (earlier.length) parts.push(`<earlier>\n${earlier.join("\n\n")}\n</earlier>`);
    if (ctx.player) parts.push(`<player>\n${clip(ctx.player, 1200)}\n</player>`);
    parts.push(`<reply>\n${clip(ctx.prose, 7000)}\n</reply>`);
    if (ctx.notes) parts.push(`<notes>\n${clip(ctx.notes, 2500)}\n</notes>`);

    const known = [];
    if (ctx.scene?.where) known.push(`location: ${ctx.scene.where}`);
    if (ctx.scene?.time) known.push(`time: ${ctx.scene.time}`);
    if (ctx.scene?.weather && ctx.scene.weather !== "clear") known.push(`weather: ${ctx.scene.weather}`);
    if (known.length) parts.push(`<known>\n${known.join("\n")}\n</known>`);
    return parts.join("\n\n");
  }

  /** One API call. Throws a short, human-readable error on any failure. */
  /** The built-in instruction, plus the reader's own (Options → For
   *  tinkerers → Your instructions for Claude). The built-in rules stay in
   *  charge, so a preference can't switch off, say, "no text in the image". */
  function systemFor(notes) {
    const extra = String(notes || "").trim();
    if (!extra) return INSTRUCTION;
    return `${INSTRUCTION}\n\nThe reader's own preferences. Follow them unless they conflict with the rules above:\n${extra}`;
  }

  async function write(ctx, { key, model, notes }) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 60000);
    let res;
    try {
      res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal: controller.signal,
        headers: {
          "content-type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true",
        },
        body: JSON.stringify({
          model: MODELS[model] ? model : DEFAULT_MODEL,
          max_tokens: 3000,   // three moments with pose and camera notes
          system: systemFor(notes),
          messages: [{ role: "user", content: userMessage(ctx) }],
          output_config: { format: { type: "json_schema", schema: SCHEMA } },
        }),
      });
    } catch (err) {
      throw new Error(err?.name === "AbortError" ? "Claude took too long" : "couldn't reach Claude");
    } finally {
      clearTimeout(timer);
    }

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      if (res.status === 401) throw new Error("Claude rejected the API key — check it in ⚙");
      if (res.status === 429) throw new Error("Claude is rate-limiting — try again in a moment");
      if (res.status === 529 || res.status >= 500) throw new Error("Claude is busy right now");
      if (/credit|billing/i.test(body)) throw new Error("your Claude account is out of credit");
      throw new Error(`Claude returned ${res.status}${body ? `: ${body.slice(0, 120)}` : ""}`);
    }
    const data = await res.json();
    if (data.stop_reason === "refusal") throw new Error("Claude declined to describe this scene");
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
    let parsed;
    try { parsed = JSON.parse(text); } catch { throw new Error("Claude's answer couldn't be read"); }
    const moments = (parsed.moments || []).filter((m) => m && String(m.scene || "").trim()).slice(0, 3);
    if (!moments.length) throw new Error("Claude didn't find a moment to draw");
    return { moments, model: MODELS[model] || MODELS[DEFAULT_MODEL], usage: data.usage || null };
  }

  /** Claude's moments → the Snap card's drafts, in the built-in sections. */
  function toDrafts(moments, ctx, style) {
    const byName = new Map((ctx.characters || []).map((c) => [String(c.name).toLowerCase(), c]));
    const dot = (s) => {
      const t = String(s || "").trim();
      return !t || /[.!?…]$/.test(t) ? t : t + ".";
    };
    return moments.map((m) => {
      const lines = ["Create an image of this moment.", ""];
      const people = (m.characters || []).filter((p) => p?.name).slice(0, 3);
      // Two blocks on purpose. "Characters:" holds each person's standing
      // looks from the sheet; the Snap card drops it when reference portraits
      // carry the faces (the Appearance toggle). "In frame:" holds what is
      // true of them in THIS moment — clothes, wet hair, what they hold — and
      // always stays, because no portrait can show it.
      // Nobody whose photo goes along as a reference: the image model
      // draws them from it, and a written description only competes.
      const firstOf = (n) => String(n || "").trim().split(/\s+/)[0].toLowerCase();
      const withRef = new Set((ctx.refNames || []).map(firstOf));
      const sheetLooks = people
        .filter((p) => !withRef.has(firstOf(p.name)))
        .map((p) => ({ p, known: byName.get(String(p.name).toLowerCase()) }))
        .filter(({ known }) => known?.appearance);
      if (sheetLooks.length) {
        lines.push("Characters:");
        for (const { p, known } of sheetLooks) {
          lines.push(`- ${p.name} — ${Sheet.promptAppearance(known.appearance)}`);
        }
        lines.push("");
      }
      const nowLines = people
        .map((p) => ({ name: p.name, look: String(p.look || "").trim() }))
        .filter((p) => p.look);
      if (nowLines.length) {
        lines.push("In frame:");
        for (const p of nowLines) lines.push(`- ${p.name}: ${dot(p.look)}`);
        lines.push("");
      }
      lines.push(`Scene: ${String(m.scene).trim()}`, "");
      if (m.pose) lines.push(`Pose: ${String(m.pose).trim()}`, "");
      if (m.camera) lines.push(`Camera: ${String(m.camera).trim()}`, "");
      else if (m.framing) lines.push(`Camera: ${String(m.framing).trim()}`, "");
      if (m.location) lines.push(`Location: ${String(m.location).trim()}`, "");
      if (m.lighting) lines.push(`Lighting: ${String(m.lighting).trim()}`, "");
      if (m.mood) lines.push(`Mood: ${String(m.mood).trim()}`, "");
      if (style) lines.push(`Style: ${style}`);
      return {
        label: String(m.label || "This moment").trim().slice(0, 60),
        prose: lines.join("\n").replace(/\n{3,}/g, "\n\n").trim(),
        negative: PromptCondenser.SD_NEGATIVE,
        byClaude: true,
      };
    });
  }

  return { write, toDrafts, userMessage, systemFor, MODELS, DEFAULT_MODEL, INSTRUCTION };
})();
