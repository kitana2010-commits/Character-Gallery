// options.js — v0.6.
//
// The one rule that matters here: chrome.permissions.request() must run while
// the click gesture is still live. v0.4 awaited a storage write first, which
// consumed the gesture and made the request throw. Permissions first, always.

const $ = (id) => document.getElementById(id);

/** Backdrop dimming, clamped to the range the field offers. 0 is a real
 *  choice — "don't dim it at all" — so only a blank or unparseable value
 *  falls back to the 35% default. `Number(v) || 35` used to treat 0 as
 *  missing, so a 0 typed here was saved and re-read as 35. */
const dimPercent = (v) => {
  const raw = String(v ?? "").trim();
  const n = Number(raw);
  return raw !== "" && Number.isFinite(n) ? Math.min(85, Math.max(0, n)) : 35;
};

const DEFAULTS = {
  preset: "openrouter",
  endpoint: "",
  modelOpenRouter: "google/gemini-2.5-flash-image",
  width: 768,
  height: 768,
  steps: 25,
  style: "stylized digital illustration, semi realistic anime inspired",
  bridge: "chatgpt",
  polish: "off",
  polishModel: "claude-sonnet-5-5",
  polishNotes: "",
  pageZoom: "auto",
  kbLiftOn: true,
};



/** The local Stable Diffusion address as a permission pattern. */
function originFor(endpoint) {
  try {
    const u = new URL(endpoint);
    return `${u.protocol}//${u.hostname}${u.port ? ":" + u.port : ""}/*`;
  } catch {
    return "http://127.0.0.1/*";
  }
}

async function load() {
  const cfg = await chrome.storage.sync.get(DEFAULTS);
  const { apiKeyOpenRouter, apiKeyAnthropic } =
    await chrome.storage.local.get({ apiKeyOpenRouter: "", apiKeyAnthropic: "" });
  $("apiKeyAnthropic").value = apiKeyAnthropic;
  $("polishOn").checked = cfg.polish === "claude";
  $("polishModel").value = cfg.polishModel || DEFAULTS.polishModel;
  $("polishNotes").value = cfg.polishNotes || "";
  // Open the tucked-away section only for someone already using it.
  if (cfg.polish === "claude") $("tinker").open = true;
  $("endpoint-a1111").value = cfg.endpoint || "";
  $("apiKeyOpenRouter").value = apiKeyOpenRouter;
  $("modelOpenRouter").value = cfg.modelOpenRouter || "";
  $("width").value = cfg.width;
  $("height").value = cfg.height;
  $("steps").value = cfg.steps;
  $("style").value = cfg.style;
  $("bridge").value = cfg.bridge;
  $("pageZoom").value = cfg.pageZoom || "auto";
  $("kbLiftOn").checked = cfg.kbLiftOn !== false;
  chrome.storage.local.get({ djpbBackdropOn: true, djpbBackdropDim: 35, djpbFx: true })
    .then((v) => {
      $("bdOn").checked = v.djpbBackdropOn !== false;
      $("bdFx").checked = v.djpbFx !== false;
      $("bdDim").value = dimPercent(v.djpbBackdropDim);
    })
    .catch(() => { $("bdOn").checked = true; $("bdDim").value = 35; });

  chrome.storage.local.get({ djpbAutoFill: true })
    .then((v) => { $("autoFill").checked = v.djpbAutoFill !== false; })
    .catch(() => { $("autoFill").checked = true; });
  chrome.storage.local.get({ djpbAutoSave: false })
    .then((v) => { $("autoSave").checked = v.djpbAutoSave === true; })
    .catch(() => { $("autoSave").checked = false; });
}

function save() {
  const endpoint = $("endpoint-a1111").value.trim();
  const orKey = $("apiKeyOpenRouter").value.trim();
  const claudeKey = $("apiKeyAnthropic").value.trim();
  const polishOn = $("polishOn").checked;
  const status = $("status");
  status.textContent = "";
  status.classList.remove("error");

  const finish = async (granted) => {
    if (granted === false) {
      status.textContent = "Permission declined — that service can't be reached until it's granted.";
      status.classList.add("error");
      return;
    }
    await chrome.storage.sync.set({
      endpoint,
      modelOpenRouter: $("modelOpenRouter").value.trim(),
      width: Number($("width").value) || DEFAULTS.width,
      height: Number($("height").value) || DEFAULTS.height,
      steps: Number($("steps").value) || DEFAULTS.steps,
      style: $("style").value.trim(),
      bridge: $("bridge").value,
      polish: polishOn && claudeKey ? "claude" : "off",
      polishModel: $("polishModel").value,
      polishNotes: $("polishNotes").value.trim().slice(0, 2000),
      pageZoom: $("pageZoom").value,
      kbLiftOn: $("kbLiftOn").checked,
    });
    await chrome.storage.local.set({
      apiKeyOpenRouter: orKey,
      apiKeyAnthropic: claudeKey,
    });
    // The key for the removed OpenAI image option: don't leave it sitting in
    // storage after the feature that used it is gone.
    await chrome.storage.local.remove(["apiKey"]);
    await chrome.storage.sync.remove(["model", "quality", "condenser",
      "condenserModel", "condenserModelClaude"]);
    status.textContent = polishOn && !claudeKey
      ? "Saved — add an Anthropic key to turn on Claude prompts."
      : "Saved ✓";
    setTimeout(() => (status.textContent = ""), 2500);
  };

  const origins = new Set();
  if (orKey) origins.add("https://openrouter.ai/*");
  if (endpoint) origins.add(originFor(endpoint));
  if (polishOn && claudeKey) origins.add("https://api.anthropic.com/*");

  if (origins.size) {
    // Synchronous call inside the click gesture — no await before this line.
    chrome.permissions.request({ origins: [...origins] }, (granted) => {
      if (chrome.runtime.lastError) {
        status.textContent = chrome.runtime.lastError.message;
        status.classList.add("error");
        return;
      }
      finish(granted);
    });
  } else {
    finish(true);
  }
}

$("reset-pill").addEventListener("click", async () => {
  await chrome.storage.local.remove(["djpbPillPos", "djpbToastPos"]);
  const btn = $("reset-pill");
  btn.textContent = "Reset \u2713 — reload the tabs";
  setTimeout(() => (btn.textContent = "Reset positions"), 3000);
});

// Zoom is something you eyeball, so apply it the moment it changes rather
// than making the user save and reload to see the result.
$("pageZoom").addEventListener("change", () =>
  chrome.storage.sync.set({ pageZoom: $("pageZoom").value }));

$("kbLiftOn").addEventListener("change", () =>
  chrome.storage.sync.set({ kbLiftOn: $("kbLiftOn").checked }));

// Snapscapes settings live in local storage, alongside the other per-device
// preferences, and apply the moment they change.
$("bdOn").addEventListener("change", () =>
  chrome.storage.local.set({ djpbBackdropOn: $("bdOn").checked }));
$("bdFx").addEventListener("change", () =>
  chrome.storage.local.set({ djpbFx: $("bdFx").checked }));
$("bdDim").addEventListener("change", () =>
  chrome.storage.local.set({ djpbBackdropDim: dimPercent($("bdDim").value) }));


$("autoFill").addEventListener("change", () =>
  chrome.storage.local.set({ djpbAutoFill: $("autoFill").checked }));
$("autoSave").addEventListener("change", () =>
  chrome.storage.local.set({ djpbAutoSave: $("autoSave").checked }));
chrome.storage.local.get({ djpbShelfBtn: true })
  .then((v) => { $("shelfBtn").checked = v.djpbShelfBtn !== false; })
  .catch(() => {});
$("shelfBtn").addEventListener("change", () =>
  chrome.storage.local.set({ djpbShelfBtn: $("shelfBtn").checked }));

$("save").addEventListener("click", save);
load();

