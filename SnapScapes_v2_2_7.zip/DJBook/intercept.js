// intercept.js — runs in the page's MAIN world.
//
// This is the only way to see the site's own network calls. A normal content
// script lives in an isolated world with its own `window`, so patching fetch
// there catches nothing the page does. The manifest must declare:
//
//   { "matches": [...], "js": ["intercept.js"], "world": "MAIN",
//     "run_at": "document_start" }
//
// document_start matters: the app's bundle grabs a reference to fetch early,
// and patching after that point misses everything.
//
// It reads only outbound bodies for one endpoint, and hands them to the
// isolated world by postMessage. It never modifies a request or a response.

(() => {
  const ENDPOINT = "/api/chat";
  const TAG = "djpb:payload";

  function publish(bodyText) {
    try {
      const data = JSON.parse(bodyText);
      if (!data?.sessionId) return;
      // Strip history before it leaves this script — the sheet needs the
      // character, persona, lorebook and plot, not the conversation. Keep only
      // the newest assistant message: the album's "paste latest reply" button.
      // thinkingTemplate is pulled out only so it doesn't ride along in rest.
      const { messages, thinkingTemplate, ...rest } = data;
      const list = Array.isArray(messages) ? messages : [];
      const lastReply = list
        .filter((m) => m?.role === "assistant" && typeof m.content === "string")
        .at(-1)?.content || "";
      // The player's own newest message: what THEY just did is often stated
      // nowhere else, and pose/context lives or dies on it.
      const lastUserMsg = list
        .filter((m) => m?.role === "user" && typeof m.content === "string")
        .at(-1)?.content || "";
      window.postMessage(
        { source: TAG, payload: rest, lastReply, lastUserMsg },
        window.location.origin
      );
    } catch {
      // Not JSON, or a shape we don't recognise. Ignore.
    }
  }

  // ---- reading RESPONSES, not just requests ----
  // The outbound POST only exists once the user sends something, which is why
  // a freshly-opened chat had no character sheet until you typed. The site
  // loads the same bot/persona/lorebook data when the chat OPENS, so we look
  // at inbound JSON too and take it from there. We never modify a response —
  // only a clone is read.

  const MAX_BODY = 3_000_000; // don't parse anything absurd
  // application/json and application/<x>+json, not x-ndjson or jsonl streams
  const JSON_DOC = /^\s*(?:application|text)\/(?:[\w.-]+\+)?json\b/i;

  /** Does this object look like the chat context we build a sheet from? */
  function looksLikeContext(o) {
    if (!o || typeof o !== "object") return false;
    const hasCast = o.bot || o.character || o.persona;
    const hasWorld = o.lorebooks || o.plot || o.lorebook;
    return Boolean(hasCast && (hasWorld || o.sessionId || o.id));
  }

  /** The payload is often wrapped ({data:{...}}, {session:{...}}). Look a few
   *  levels down rather than guessing the site's envelope. */
  function findContext(node, depth = 0) {
    if (!node || typeof node !== "object" || depth > 3) return null;
    if (looksLikeContext(node)) return node;
    for (const value of Array.isArray(node) ? node : Object.values(node)) {
      const hit = findContext(value, depth + 1);
      if (hit) return hit;
    }
    return null;
  }

  function sessionFromUrl() {
    const m = location.pathname.match(/\/session\/([0-9a-f-]{36})/i);
    return m ? m[1] : "";
  }

  function publishResponse(bodyText) {
    try {
      if (!bodyText || bodyText.length > MAX_BODY) return;
      if (bodyText[0] !== "{" && bodyText[0] !== "[") return;
      const ctx = findContext(JSON.parse(bodyText));
      if (!ctx) return;
      const payload = { ...ctx };
      // v2.2: only the chat in the address bar. 2.1 filed a response under
      // the object's own `id` first — a bot's id, or another chat's from a
      // list of recent chats — so data landed under the wrong key and the
      // worker's idea of "the last chat" drifted with it. Anything that
      // names a different chat (or any other id) is left alone.
      const here = sessionFromUrl();
      if (!here) return;
      const claimed = String(ctx.sessionId || ctx.id || "");
      if (claimed && claimed !== here) return;
      payload.sessionId = here;
      delete payload.messages;      // history never leaves the page
      window.postMessage(
        { source: TAG, payload, lastReply: "", lastUserMsg: "" },
        window.location.origin
      );
    } catch {
      // Not the shape we're after.
    }
  }

  function isApiUrl(url) {
    try {
      const u = new URL(url, location.href);
      return u.origin === location.origin && /\/api\//.test(u.pathname);
    } catch {
      return false;
    }
  }

  // ---- "a reply is generating" -------------------------------------
  // Broadcast to our content script, which lights the composer. Guarded so a
  // failure here can never disturb the page's own networking.
  let genTimer = 0;
  function signalGenerating(on) {
    try {
      window.postMessage({ source: TAG, generating: Boolean(on) }, "*");
      clearTimeout(genTimer);
      // Safety net: if a reply is abandoned or the connection drops, don't
      // leave the composer glowing forever.
      if (on) genTimer = setTimeout(() => { inFlight.length = 0; signalGenerating(false); }, 180000);
    } catch { /* ignore */ }
  }

  // v2.2.7: know when the reply has finished WITHOUT touching it.
  //
  // Until now this pumped a clone of the reply to see it end. A clone is a
  // tee, and a tee keeps the connection open for as long as either side is
  // still reading. So when the site stopped a reply by cancelling its own
  // reader, ours kept reading: the connection stayed open and the server
  // went on writing a reply the user had stopped. Stop didn't stop, and
  // editing an earlier message then ran into a reply still being generated.
  //
  // The browser already reports when a request is over (finished, aborted
  // or cancelled) to anyone who asks, and asking changes nothing about the
  // request. The reply itself is never read, cloned or wrapped here.
  const inFlight = [];   // chat requests whose reply hasn't finished
  const absolute = (url) => {
    try { const u = new URL(url, location.href); u.hash = ""; return u.href; } catch { return ""; }
  };
  function replyStarted(url) {
    const r = { url: absolute(url) };
    inFlight.push(r);
    signalGenerating(true);
    return r;
  }
  function replyEnded(r) {
    const i = inFlight.indexOf(r);
    if (i < 0) return;            // already counted
    inFlight.splice(i, 1);
    if (!inFlight.length) signalGenerating(false);
  }
  try {
    new PerformanceObserver((list) => {
      try {
        for (const entry of list.getEntries()) {
          if (!inFlight.length) return;
          const r = inFlight.find((x) => x.url && x.url === entry.name.split("#")[0]);
          if (r) replyEnded(r);
        }
      } catch { /* ignore */ }
    }).observe({ type: "resource" });
  } catch { /* no observer: the abort listener and the safety net remain */ }

  const nativeFetch = window.fetch;
  window.fetch = function (input, init) {
    // Read once, not once per branch. Still guarded: this IS the page's fetch,
    // so anything that throws here takes the site's networking down with it —
    // and `input` is whatever the app passed, which may be an exotic object
    // with a throwing `url` getter.
    let url = "";
    let isChatPost = false;
    try {
      url = typeof input === "string" ? input : input?.url || "";
    } catch { /* leave it empty; the request still goes through untouched */ }

    try {
      const method = (init?.method || input?.method || "GET").toUpperCase();
      if (method === "POST" && url.includes(ENDPOINT)) {
        isChatPost = true;
        const body = init?.body;
        if (typeof body === "string") publish(body);
      }
    } catch {
      // Never let instrumentation break the host app's request.
    }

    const p = nativeFetch.apply(this, arguments);
    // A reply is on its way. This signal comes from the request itself
    // rather than from guessing at the site's DOM, so it can't drift when
    // the site changes its markup.
    if (isChatPost) {
      try {
        const r = replyStarted(url);
        // It never got as far as a reply.
        p.catch(() => replyEnded(r));
        // Stop: the site aborts its own request. The observer reports this
        // too; listening here costs nothing and doesn't depend on it.
        const signal = init?.signal || input?.signal;
        signal?.addEventListener?.("abort", () => replyEnded(r), { once: true });
      } catch { /* never disturb the app's own handling */ }
    }
    try {
      // Not the chat reply itself (see above), and only a plain JSON
      // document: a line-by-line JSON stream is a reply by another name,
      // and reading a copy of one would hold it open the same way.
      if (!isChatPost && isApiUrl(url)) {
        p.then((res) => {
          try {
            const type = res.headers?.get?.("content-type") || "";
            if (!JSON_DOC.test(type)) return;
            res.clone().text().then(publishResponse).catch(() => {});
          } catch { /* never disturb the app's own handling */ }
        }).catch(() => {});
      }
    } catch { /* as above */ }
    return p;
  };

  // Some bundles use XHR for the same endpoint. Cover both.
  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__djpb = { method: String(method).toUpperCase(), url: String(url) };
    return open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    try {
      if (this.__djpb?.method === "POST" &&
          this.__djpb.url.includes(ENDPOINT) &&
          typeof body === "string") {
        publish(body);
      }
    } catch { /* as above */ }
    try {
      if (this.__djpb && isApiUrl(this.__djpb.url)) {
        this.addEventListener("load", () => {
          try {
            if (this.responseType && this.responseType !== "text") return;
            publishResponse(this.responseText);
          } catch { /* ignore */ }
        });
      }
    } catch { /* ignore */ }
    return send.apply(this, arguments);
  };
})();
